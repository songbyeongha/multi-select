# 배포 전 정리 계획 (Pre-Deployment Cleanup)

## 1️⃣ 삭제 대상 (아티팩트 & 캐시)

```
10613/
├── .serena/                    # ❌ 삭제 (개발용 Serena 캐시)
├── ai-history/                 # ❌ 삭제 (AI 작업 기록, 배포 불필요)
├── logs/                        # ❌ 삭제 (개발 로그)
├── .pytest_cache/              # ❌ 삭제 (pytest 실행 캐시)
└── __pycache__/               # ❌ 삭제 (파이썬 컴파일 파일)
```

**이유**:
- 빌드 아티팩트 (`.pytest_cache/`, `__pycache__/`)
- 개발 전용 (`.serena/`, `ai-history/`, `logs/`)
- 운영 중 재생성됨 (캐시)
- 파일 크기 최소화 (배포 패키지 가벼움)

---

## 2️⃣ 유지 대상

```
✅ src/                    # 핵심 소스 코드
✅ scripts/                # 진입점 스크립트
✅ tests/                  # 단위 테스트 (unit 포함)
✅ data/                   # 런타임 데이터 (catalog.example.json, .gitkeep)
✅ docs/                   # 운영 문서
✅ .github/workflows/      # CI/CD 파이프라인
✅ .env.example            # 환경 설정 템플릿
✅ requirements.txt        # 패키지 의존성
✅ README.md, CLAUDE.md    # 프로젝트 문서
```

---

## 3️⃣ 주석 정리 전략

### 3.1 **삭제 대상** (WHAT 설명)
```python
# ❌ 불필요한 주석 (코드 이름이 명확한 경우)
for table in selected_tables:  # 선택된 테이블 반복
    process(table)

# ✅ 정리 후
for table in selected_tables:
    process(table)
```

### 3.2 **유지 대상** (WHY 설명)
```python
# ✅ 필수 주석 (숨겨진 제약, 비직관적 로직)

# JSON-first: schema_metadata를 정본으로 사용
# Oracle DB 직접 조회는 prepare 단계(초기화)에서만 발생해야 함
if meta.get("tables"):
    full_schema = SchemaReader.from_meta(meta)
else:
    full_schema = SchemaReader.full_schema(db_path)

# 최대 3회 재시도 — 4회 이상은 infinite loop 위험
for attempt in range(1, 4):
    try:
        result = repair(sql, error)
    except Exception:
        pass
```

### 3.3 **정리 대상 파일** (상위 우선순위)
1. **agents/** - 주석 과다 (특히 decomposer.py, generation_nodes.py)
2. **tools/** - 불필요한 주석 (executor.py, guardrails.py)
3. **lg/** - 상태 설명 정리 (state.py, graph.py)
4. **ui/** - 렌더러 주석 (renderers.py, tabs/main_tab.py)
5. **feedback/** - 학습 로직 주석 (learner.py, evaluator.py)

---

## 4️⃣ .gitignore 업데이트

기존:
```
__pycache__/
*.pyc
.env
.pytest_cache/
```

**추가**:
```
# 배포 후 재생성 아티팩트
.serena/
ai-history/
logs/
*.log

# IDE 캐시
.vscode/
.idea/
*.swp
*.swo

# OS 파일
.DS_Store
Thumbs.db

# 기타 개발 파일
.env.local
.env.*.local
```

---

## 5️⃣ 배포 패키지 내용 (최종)

```
배포 패키지 (minimal production build)
│
├── src/text2sql/                    # 완전한 소스 코드
│   ├── agents/                      # 13 agents (주석 정리됨)
│   ├── lg/                          # LangGraph
│   ├── config/                      # 설정
│   ├── feedback/                    # 피드백 시스템
│   ├── llm/                         # LLM 클라이언트
│   ├── rag/                         # Vector search
│   ├── tools/                       # 유틸리티 (cache.py 포함)
│   ├── ui/                          # Streamlit UI
│   └── memory/                      # 대화 메모리
│
├── scripts/                         # 진입점
│   ├── run_cli.py                   # CLI
│   ├── run_ops.py                   # Operations
│   ├── health_check.py              # 헬스 체크
│   └── ...
│
├── tests/                           # 테스트
│   ├── unit/                        # Unit 테스트
│   ├── integration/                 # Integration 테스트
│   └── conftest.py
│
├── data/                            # 런타임 데이터
│   ├── catalog.example.json         # 샘플 카탈로그
│   ├── feedback/                    # 피드백 저장소 (비어있음)
│   ├── history/                     # 히스토리 저장소 (비어있음)
│   └── vector_store/                # ChromaDB (비어있음)
│
├── docs/                            # 문서
│   ├── START_HERE.md                # 시작 가이드
│   ├── CODEBASE_GUIDE.md            # 코드 구조
│   ├── PROJECT_STRUCTURE.md         # 프로젝트 맵
│   ├── operations/                  # 운영 가이드
│   └── ...
│
├── .github/workflows/               # CI/CD
│   └── ai-guard.yml
│
├── .env.example                     # 환경 템플릿
├── .gitignore                       # Git 무시 (업데이트)
├── requirements.txt                 # 패키지 목록
├── README.md                        # 프로젝트 소개
├── CLAUDE.md                        # 개발 규칙
└── pytest.ini                       # 테스트 설정
```

**예상 파일 크기**:
- 정리 전: ~50MB (캐시, 로그 포함)
- 정리 후: ~3-5MB (소스 + 문서만)

---

## 6️⃣ 실행 순서

### Phase 1: 파일 삭제 (이 작업)
```bash
# .serena/, ai-history/, logs/, .pytest_cache/, __pycache__/ 삭제
```

### Phase 2: 주석 정리 (다음 작업)
- agents/*.py
- tools/*.py
- lg/*.py

### Phase 3: .gitignore 업데이트

### Phase 4: 최종 검증
```bash
pytest -m unit          # 테스트 통과 확인
python scripts/run_ops.py doctor  # 연결 확인
streamlit run app.py    # UI 동작 확인
```

### Phase 5: 배포 패키지 생성
```bash
tar czf text-to-sql-assistant-v1.0.0.tar.gz \
  src/ scripts/ tests/ data/ docs/ \
  .env.example requirements.txt README.md CLAUDE.md
```

---

## 7️⃣ 주석 정리 예시

### Before (agents/decomposer.py 예상)
```python
# decomposer 노드를 실행한다
def decomposer(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """질문을 분석한다."""  # 너무 간단함
    
    question = state["question"]  # 질문을 가져온다
    db_id = state["db_id"]  # DB ID를 가져온다
    
    # LLM을 가져온다
    llm = get_llm()
    
    # 프롬프트를 생성한다
    prompt = P.DECOMPOSER_USR.format(question=question)
    
    # LLM을 호출한다
    result = llm.generate_json(prompt)
    
    # 의도를 추출한다
    intent = result.get("intent", "unknown")
    
    # query_pattern을 추출한다
    query_pattern = result.get("query_pattern", "")
    
    # extracted_values를 추출한다
    extracted_values = result.get("extracted_values", {})
    
    # 로그를 출력한다
    logger.info(f"분해 완료: {intent}")
    
    # 결과를 반환한다
    return {
        "intent": intent,
        "query_pattern": query_pattern,
        "extracted_values": extracted_values,
    }
```

### After (정리됨)
```python
def decomposer(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """질문 분석: 의도, 패턴, 추출 값 식별."""
    question = state["question"]
    
    llm = get_llm()
    prompt = P.DECOMPOSER_USR.format(question=question)
    result = llm.generate_json(prompt)
    
    intent = result.get("intent", "unknown")
    
    logger.info(f"분해 완료: {intent}")
    
    return {
        "intent": intent,
        "query_pattern": result.get("query_pattern", ""),
        "extracted_values": result.get("extracted_values", {}),
    }
```

**제거된 주석**:
- "decomposer 노드를 실행한다" → docstring으로 충분
- "질문을 가져온다" → 변수명이 명확
- "LLM을 호출한다" → 함수명이 명확
- "로그를 출력한다" → logger 호출 자체가 명확

**유지해야 할 주석** (비직관적인 경우):
```python
# 시간 표현 명확화: "이번 달" → "2025-05"
extracted_values["month"] = normalize_temporal_reference(...)

# Self-consistency: 3개 후보 중 동일 결과 다수결 선택
chosen_sql = select_majority_sql(sql_candidates)

# JSON-first: schema_metadata를 정본으로 사용
full_schema = SchemaReader.from_meta(meta)
```

---

## 8️⃣ 검증 체크리스트

정리 완료 후:

- [ ] `.serena/`, `ai-history/`, `logs/` 삭제 확인
- [ ] `.pytest_cache/`, `__pycache__/` 삭제 확인
- [ ] `pytest -m unit` 통과
- [ ] `scripts/run_ops.py doctor` 성공
- [ ] `streamlit run app.py` 정상 작동
- [ ] 파일 크기 50MB → 3-5MB 감소 확인
- [ ] 주석 정리 (agents/, tools/) 완료
- [ ] .gitignore 업데이트

---

## 📋 최종 배포 명령어

```bash
# 1. 정리 실행
rm -rf .serena/ ai-history/ logs/ .pytest_cache/ __pycache__

# 2. 주석 정리 (Serena로 진행)
# → agents/, tools/ 등 정리

# 3. .gitignore 업데이트
# → 개발 아티팩트 추가

# 4. 최종 검증
pytest -m unit
python scripts/run_ops.py doctor

# 5. 배포 패키지 생성
tar czf text-to-sql-assistant-v1.0.0.tar.gz \
  src/ scripts/ tests/ data/ docs/ \
  .env.example requirements.txt README.md CLAUDE.md pytest.ini

# 6. 배포
# → Docker 빌드 또는 직접 배포
```

---

**예상 시간**: 30-45분
**위험도**: 낮음 (캐시 & 로그만 삭제)
**롤백**: git reset --hard HEAD
