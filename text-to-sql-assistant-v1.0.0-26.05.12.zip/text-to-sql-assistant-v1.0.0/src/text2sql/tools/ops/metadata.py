"""Metadata management tools for Oracle."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Dict, List

from text2sql.config.settings import Settings
from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
from text2sql.tools.oracle_metadata import (
    ensure_seed_file,
    export_oracle_metadata_payload,
    scaffold_domain_hints,
    scaffold_manual_domain_hints,
    scaffold_manual_metadata,
    write_json,
)


def export_metadata(
    settings: Settings,
    *,
    db_id: str = "",
    include_tables: List[str] | None = None,
    exclude_tables: List[str] | None = None,
    sample_limit: int = 3,
    output_path: str | Path | None = None,
    manual_output_path: str | Path | None = None,
    hints_output_path: str | Path | None = None,
    manual_hints_output_path: str | Path | None = None,
) -> Dict[str, Any]:
    """Export Oracle metadata to JSON files.

    Returns:
        dict: Summary of the export operation.
    """
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
    )

    db_cfg = settings.db
    if db_cfg.dialect != "oracle":
        raise ValueError("T2SQL_DB_DIALECT must be set to oracle.")

    adapter = OracleAdapter(
        host=db_cfg.host,
        port=db_cfg.port,
        service_name=db_cfg.service_name,
        dsn=db_cfg.dsn,
        user=db_cfg.user,
        password=db_cfg.password,
        schema=db_cfg.schema,
        connect_timeout_sec=db_cfg.connect_timeout_sec,
    )

    info = adapter.test_connection()
    if not info["ok"]:
        raise RuntimeError(f"Oracle connection failed: {info['message']}")

    target_db_id = db_id or db_cfg.db_id or "oracle_db"
    root = Path.cwd() # Assume CWD is project root
    
    # Resolve paths
    meta_path = Path(output_path) if output_path else default_metadata_path(root / "src" / "text2sql" / "config", "oracle")
    manual_meta_path = Path(manual_output_path) if manual_output_path else sibling_overlay_path(meta_path)
    hints_path = Path(hints_output_path) if hints_output_path else default_domain_hints_path(root / "src" / "text2sql" / "config", "oracle")
    manual_hints_path = Path(manual_hints_output_path) if manual_hints_output_path else hints_path.with_name(f"{hints_path.stem}_manual{hints_path.suffix}")

    include = list(include_tables or [])
    exclude = list(exclude_tables or [])
    include.extend(db_cfg.include_table_list())
    exclude.extend(db_cfg.exclude_table_list())

    payload = export_oracle_metadata_payload(
        adapter,
        db_id=target_db_id,
        db_description=f"Oracle database ({target_db_id})",
        include_tables=include,
        exclude_tables=exclude,
        sample_limit=sample_limit,
    )

    # Write files
    write_json(meta_path, payload)
    ensure_seed_file(manual_meta_path, scaffold_manual_metadata())
    ensure_seed_file(hints_path, scaffold_domain_hints())
    ensure_seed_file(manual_hints_path, scaffold_manual_domain_hints())

    return {
        "ok": True,
        "db_id": target_db_id,
        "table_count": len(payload.get("tables", {})),
        "paths": {
            "metadata": str(meta_path),
            "manual_metadata": str(manual_meta_path),
            "domain_hints": str(hints_path),
            "manual_domain_hints": str(manual_hints_path),
        }
    }


def enrich_metadata(
    settings: Settings,
    *,
    db_id: str = "",
    catalog_paths: List[str] | None = None,
    sql_globs: List[str] | None = None,
    metadata_output: str | Path | None = None,
    hints_output: str | Path | None = None,
    dialect: str = "",
    min_relation_support: int = 1,
    max_few_shots: int = 40,
    skip_fill_descriptions: bool = False,
    report_path: str | Path | None = None,
) -> Dict[str, Any]:
    """Enrich metadata and domain hints from a SQL corpus.

    Returns:
        dict: Summary of the enrichment operation.
    """
    import os
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
        write_json_file,
    )
    from text2sql.tools.sql_metadata_enricher import (
        enrich_metadata_from_queries,
        get_overlay_entry,
        load_query_artifacts,
        update_overlay_file,
    )

    target_db_id = db_id or settings.db.db_id or "oracle_db"
    target_dialect = dialect or settings.db.dialect
    root = Path.cwd()

    # Resolve paths
    metadata_primary = (
        Path(settings.db.metadata_path)
        if settings.db.metadata_path
        else default_metadata_path(root / "src" / "text2sql" / "config", settings.db.dialect)
    )
    meta_out = Path(metadata_output) if metadata_output else (
        Path(settings.db.manual_metadata_path) if settings.db.manual_metadata_path else sibling_overlay_path(metadata_primary)
    )
    if not meta_out.is_absolute():
        meta_out = root / meta_out

    hints_primary_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    hints_primary = (
        Path(hints_primary_env)
        if hints_primary_env
        else default_domain_hints_path(root / "src" / "text2sql" / "config", settings.db.dialect)
    )
    hints_out = Path(hints_output) if hints_output else (
        Path(os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip())
        if os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
        else sibling_overlay_path(hints_primary)
    )
    if not hints_out.is_absolute():
        hints_out = root / hints_out

    report_out = Path(report_path) if report_path else root / "logs" / "sql_metadata_enrichment_report.json"
    if not report_out.parent.exists():
        report_out.parent.mkdir(parents=True, exist_ok=True)

    artifacts = load_query_artifacts(catalog_paths=catalog_paths or [], sql_globs=sql_globs or [], root_dir=root)
    if not artifacts:
        raise ValueError("No SQL corpus entries found.")

    base_metadata = settings.schema_metadata(target_db_id)
    if not base_metadata.get("tables"):
        raise RuntimeError(f"Metadata for db_id={target_db_id} is empty.")

    metadata_overlay = get_overlay_entry(meta_out, target_db_id)
    metadata_overlay.setdefault("name", base_metadata.get("name", target_db_id))
    metadata_overlay.setdefault("description", base_metadata.get("description", ""))
    metadata_overlay.setdefault("dialect", base_metadata.get("dialect", target_dialect))
    hints_overlay = get_overlay_entry(hints_out, target_db_id)

    enriched_metadata, enriched_hints, report = enrich_metadata_from_queries(
        db_id=target_db_id,
        artifacts=artifacts,
        base_metadata=base_metadata,
        metadata_overlay=metadata_overlay,
        domain_hints_overlay=hints_overlay,
        dialect=target_dialect,
        min_relation_support=min_relation_support,
        max_few_shots=max_few_shots,
        skip_fill_descriptions=skip_fill_descriptions,
    )

    update_overlay_file(meta_out, target_db_id, enriched_metadata)
    update_overlay_file(hints_out, target_db_id, enriched_hints)
    write_json_file(report_out, report)

    return {
        "ok": True,
        "db_id": target_db_id,
        "artifact_count": len(artifacts),
        "paths": {
            "metadata_overlay": str(meta_out),
            "hints_overlay": str(hints_out),
            "report": str(report_out),
        },
        "report_summary": {
            "total_queries": report.get("total_queries", 0),
            "inferred_relationships": len(report.get("inferred_relationships", [])),
        }
    }
