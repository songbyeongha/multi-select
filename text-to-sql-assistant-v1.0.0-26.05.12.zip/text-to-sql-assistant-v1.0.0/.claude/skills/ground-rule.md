# Ground Rule SKILL — Text-to-SQL Assistant 개발 가이드

> 🎯 **이 SKILL은 프로젝트의 "헌법"입니다.**
> 
> 모든 개발 작업은 아래 원칙을 따릅니다.
> 추가 질문이 있으면 CLAUDE.md → PROJECT_STRUCTURE.md → 이 문서 순서로 참고하세요.

---

## 📋 Quick Reference

### 절대 금지 (❌ NO-GO)
```
❌ LangGraph 구조 변경 (노드 추가/제거, 연결 순서 변경)
❌ GraphState 필드명 변경 (새 필드는 state.py에 정의 필수)
❌ SELECT *, DML(INSERT/UPDATE/DELETE), DDL(CREATE/ALTER/DROP)
❌ Agent에서 직접 DB 접근 (tools/executor.py 경유만 허용)
❌ Agent에서 직접 RAG 호출 (schema_selector가 유일한 진입점)
❌ print() 사용 (logger 사용 강제)
❌ hallucination (존재하지 않는 컬럼/테이블명 생성)
```

### 필수 규칙 (✅ MUST-HAVE)
```
✅ 모든 함수에 타입 힌트 (인자 + 반환값)
✅ 모든 함수에 Docstring (한 줄, 역할 명시)
✅ 모든 에러 경로 처리 (try/except)
✅ Logger 사용 (info, debug, error levels)
✅ 최소 수정 원칙 (요청받은 부분만)
✅ Unit 테스트 작성 (@pytest.mark.unit)
✅ Pre-commit 체크리스트 확인
```

---

## 🏗️ 시스템 아키텍처

### 13단계 LangGraph 파이프라인

```
사용자 질문
    ↓
[1] Decomposer
    ↓ (intent, query_pattern, extracted_values)
[2] SchemaSelector (RAG)
    ↓ (selected_tables, schema_text)
[3] ValueRetriever
    ↓ (mapped_values)
[4] JoinPlanner
    ↓ (join_plan, join_rationale)
[5] CandidateGenerator (3개 전략)
    ↓ (sql_candidates[])
[6] SQLPostProcess
    ↓ (normalized_sql)
[7] Guardrails (보안 검사)
    ↓ (is_valid, validation_errors)
[8] UnitTester (문법 검증)
    ↓ (ut_passed)
[9] ExecutePreview (Self-Consistency Voting)
    ↓ (exec_report, quality_score)
[10] Judge (품질 평가)
    ↓
[11] Repair (조건부, 최대 3회)
    ↓
[12] ResultOutput
    ↓
[13] Memory/Audit (피드백 저장)
    ↓
최종 결과 반환
```

### GraphState 중앙 저장소

모든 데이터는 `GraphState`를 통해 이동합니다:

```python
class GraphState:
    # 입력
    question: str                    # 사용자 질문
    database_id: str               # Oracle DB ID
    
    # Decomposer 출력
    intent: str                    # "aggregation", "filtering", etc.
    query_pattern: str             # "simple", "set_operation", etc.
    extracted_values: dict         # {"year": 2024, "region": "APAC"}
    
    # SchemaSelector 출력
    selected_tables: list[str]     # ["SALES", "PRODUCTS"]
    selected_columns: dict         # {"SALES": ["ID", "AMOUNT"]}
    schema_text: str              # 포맷된 스키마 텍스트
    full_schema: list[dict]       # 전체 스키마
    
    # JoinPlanner 출력
    join_plan: list[str]          # ["SALES.ID = ORDERS.ID"]
    join_rationale: str           # 조인 이유
    
    # CandidateGenerator 출력
    sql_candidates: list[SQLCandidate]  # 3개 후보
    
    # 실행 및 평가
    chosen_sql: str               # 최종 선택 SQL
    exec_report: ExecReport       # 실행 결과
    quality_score: float          # 0.0 ~ 1.0
    
    # 에러 추적
    repair_attempts: int          # repair 루프 횟수
    error_messages: list[str]     # 누적 에러 메시지
```

**규칙**: 각 노드는 자신이 담당하는 필드만 수정합니다.

---

## 🤖 13개 Agent 역할 상세 설명

### [1] Decomposer — 질문 분석 & 패턴 분류
**역할**: 사용자의 자연어 질문을 구조화  
**입력**: `question`  
**출력**: `intent`, `query_pattern`, `extracted_values`

**의도 분류**:
- `aggregation`: 합계, 평균, 최대/최소 (SUM, AVG, MAX, MIN)
- `filtering`: 조건 필터링 (WHERE 절)
- `ranking`: 상위/하위 (ORDER BY, LIMIT)
- `grouping`: 그룹화 (GROUP BY)
- `join_multi`: 다중 테이블 조인
- `set_operation`: UNION, EXCEPT, INTERSECT
- `time_series`: 시계열 분석 (날짜 범위)

**핵심 작업**: 상대 시간 표현 명확화 ("이번달" → "2024-05-01 ~ 2024-05-31")

**주의사항**: date_tools를 사용하여 현재 기준일을 적용합니다.

---

### [2] SchemaSelector — 테이블·컬럼 선택 (RAG)
**역할**: 하이브리드 RAG (BM25 + 벡터 검색 + LLM)로 관련 테이블 선택  
**입력**: `question`, `intent`, `extracted_values`  
**출력**: `selected_tables`, `selected_columns`, `schema_text`

**선택 전략**:
1. **BM25 검색**: 키워드 매칭 (상위 5개)
2. **벡터 검색**: 의미 유사도 (top-k)
3. **LLM 검증**: 선택된 테이블이 질문을 충족하는지 확인
4. **FK 보완**: 선택된 테이블 간 연결성 유지

**캐싱**: 질문-테이블 매핑을 300초 캐싱 (성능 최적화)

**주의사항**: 
- JSON 메타데이터 우선 (DB 직접 조회는 fallback)
- 상위 5개 테이블만 포함 (prompt 크기 제한)

---

### [3] ValueRetriever — 추출값 매핑 & 검증
**역할**: 질문에서 추출된 값을 DB 실제 값으로 매핑  
**입력**: `extracted_values`, `schema_text`  
**출력**: `mapped_values`

**검증 체크**:
- Enum 값 존재 확인 (예: `status` ∈ {ACTIVE, INACTIVE})
- 날짜 형식 검증 (ISO 8601)
- 숫자 범위 확인

**예시**:
```
사용자: "지역이 '미국'인 판매"
추출: {"region": "US"}  ← 실제 DB 값
```

---

### [4] JoinPlanner — JOIN 경로 계획
**역할**: 선택된 테이블 간 조인 조건 계획  
**입력**: `selected_tables`, `full_schema`  
**출력**: `join_plan`, `join_rationale`

**규칙**:
- **FK 기반만 허용**: Foreign Key 제약 조건 따름
- **Cartesian Join 금지**: 모든 조인 조건 명시
- **브리지 테이블 자동 추가**: 연결성 끊어지면 자동 보완

**예시**:
```
선택: [SALES, PRODUCTS, REGIONS]
JOIN 경로:
  - SALES.PRODUCT_ID = PRODUCTS.ID
  - SALES.REGION_ID = REGIONS.ID
```

---

### [5] CandidateGenerator — SQL 후보 생성 (핵심!)
**역할**: query_pattern별로 3개의 다양한 SQL 후보 생성  
**입력**: `schema_text`, `intent`, `selected_tables`  
**출력**: `sql_candidates[3]` (conservative, recall, metric)

**3가지 전략**:

| 전략 | 특징 | 언제 사용 |
|------|------|---------|
| **Conservative** | 안전한 문법, 명확한 조건 | 기본 선택 |
| **Recall** | 광범위 검색, 많은 데이터 | 정보 손실 위험시 |
| **Metric** | 복잡한 계산 (DENSE_RANK, PERCENTILE) | 순위, 백분위 문제 |

**각 후보에 할당**:
- Confidence score (0.0 ~ 1.0)
- Strategy name
- Explanation

**주의사항**: 다양성 중요 (같은 전략 3개 X)

---

### [6] SQLPostProcess — AST 정규화
**역할**: 생성된 SQL을 sqlglot으로 정규화  
**입력**: `sql_candidates[3]`  
**출력**: `normalized_sql`

**작업**:
- 포맷 일관성 (대소문자, 들여쓰기)
- LIMIT 자동 추가 (미포함시)
- 문법 오류 감지

---

### [7] Guardrails — 보안 게이트 (필수!)
**역할**: 위험한 SQL 차단  
**입력**: `sql_candidates[3]`  
**출력**: `is_valid`, `validation_errors`

**차단 목록**:
```
❌ SELECT *        → 구체적 컬럼 명시 필수
❌ INSERT          → DML 차단
❌ UPDATE          → DML 차단
❌ DELETE          → DML 차단
❌ CREATE TABLE    → DDL 차단
❌ DROP TABLE      → DDL 차단
❌ ALTER TABLE     → DDL 차단
```

**추가 규칙** (guardrail_rules.py):
- 존재하지 않는 컬럼 차단
- 존재하지 않는 테이블 차단

---

### [8] UnitTester — 정적 SQL 문법 검증
**역할**: LLM을 사용해 SQL 문법 오류 감지  
**입력**: `sql_candidates[3]`, `schema_text`  
**출력**: `ut_passed` (bool)

**심각도 분류**:
- `blocker`: 실행 불가 (차단)
- `high`: 경고 (실행 가능하지만 주의)
- `medium`, `low`: 정보성

---

### [9] ExecutePreview — DB 실행 & Self-Consistency Voting ⭐
**역할**: 3개 SQL 후보를 실행 후 다수결로 최적 선택  
**입력**: `sql_candidates[3]`  
**출력**: `exec_report`, `quality_score`, `chosen_sql`

**Self-Consistency Voting 과정**:
1. 3개 SQL 실행 (각각 LIMIT 50)
2. 결과 행 집합 비교 (순서 무시)
3. 같은 결과 반환하는 것이 2개 이상 → 해당 결과 채택
4. 모두 다르면 confidence 최고 SQL 선택

**예시**:
```
SQL1 결과: [(1, 'A'), (2, 'B')] ✓
SQL2 결과: [(1, 'A'), (2, 'B')] ✓
SQL3 결과: [(1, 'A'), (3, 'C')] ✗

→ SQL1 또는 SQL2 선택 (더 높은 confidence)
```

---

### [10] Judge — 품질 평가
**역할**: 질문-결과 일치도 평가  
**입력**: `question`, `exec_report`  
**출력**: `quality_score` (0.0 ~ 1.0)

**평가 기준**:
- 행 개수 합리성 (0이면 감점)
- 결과 컬럼 예상치 일치
- 데이터 타입 일치

---

### [11] Repair — SQL 수정 루프 (조건부)
**역할**: SQL 실행 오류 시 수정 및 재시도  
**입력**: `chosen_sql`, `error_message`  
**출력**: `fixed_sql`

**규칙**:
- 최대 3회 재시도
- 각 시도마다 에러 분석 + 근본 원인 파악
- 3회 모두 실패하면 safe_fail로 이동

**일반적 수정**:
- 컬럼명 오타 → 정정
- 테이블 조인 누락 → 추가
- 집계 함수 누락 → 추가

---

### [12] ResultOutput — 최종 결과 포맷
**역할**: DB 결과를 사용자 친화적 형식으로 변환  
**입력**: `exec_report`  
**출력**: `final_result`

**형식**:
- 테이블 (마크다운 또는 JSON)
- 요약 통계
- 실행 메타데이터 (실행 시간, 행 수)

---

### [13] Memory/Audit — 피드백 저장 & 학습
**역할**: 사용자 피드백을 데이터베이스에 저장  
**입력**: 전체 GraphState, 사용자 평점 (1~5)  
**출력**: `feedback_saved`

**피드백 활용**:
- **4~5점**: Few-shot 예제로 추가 (유사 질문시 참고)
- **1~2점**: 에러 패턴 기록 (repair 로직 개선)
- **3점**: 보관만 (사용 안 함)

---

## 💻 코드 작성 규칙

### 1. 함수 시그니처 (필수)
```python
def node_my_agent(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """역할을 명확히 설명하는 한 문장."""
    return {"output_field": value, "status": "success"}
```

**타입 힌트**:
- 입력: `state: GraphState, config: dict[str, Any]`
- 출력: `dict[str, Any]` (항상 dict, 전체 state와 merge)

---

### 2. 예외 처리 (필수)
```python
from text2sql.tools import logger

def my_function(state: GraphState) -> dict[str, Any]:
    try:
        result = some_operation(state.question)
        logger.info(f"작업 완료: {result}")
        return {"output": result, "status": "success"}
    except ValueError as e:
        logger.error(f"입력 오류: {e}")
        return {"error": str(e), "status": "failed"}
    except Exception as e:
        logger.error(f"예상 외 오류: {e}", exc_info=True)
        raise  # 알려지지 않은 에러는 재발생
```

**패턴**:
- 예상 가능한 에러: catch + log + return
- 예상 불가능한 에러: log + re-raise

---

### 3. 로깅 (필수)
```python
from text2sql.tools import logger

# ✅ 올바른 사용
logger.info(f"질문 수신: {question}")       # 주요 단계
logger.debug(f"선택 테이블: {tables}")      # 상세 정보
logger.error(f"SQL 오류: {error}", exc_info=True)  # 예외 포함

# ❌ 금지
print("debug")                              # logger 사용
logger.info(password)                       # 민감 정보
```

**로깅 레벨**:
- `info`: 주요 진행 상황 (질문 수신, 테이블 선택, SQL 생성 완료)
- `debug`: 상세 정보 (중간 값, 후보 선택)
- `error`: 오류 발생 (예외 포함, **exc_info=True 필수**)
- `warning`: 비정상이지만 계속 실행 (타임아웃 임박)

---

### 4. Docstring
```python
def schema_selector(state: GraphState) -> dict[str, Any]:
    """관련 테이블/컬럼 선택.
    
    RAG (BM25 + 벡터)를 통해 유사도 높은 테이블 선택.
    FK 관계 고려하여 JOIN 가능한 테이블만 포함.
    """
```

**규칙**: 한 줄(40글자 이하) + 필요시 상세 설명 (2-3줄)

---

## 🧪 테스트 작성 가이드

### Unit 테스트 (@pytest.mark.unit)
DB 불필요, mock 사용:

```python
@pytest.mark.unit
def test_decomposer_simple_question():
    """분해기가 단순 질문을 올바르게 구조화."""
    state = new_state(question="올해 매출은?")
    result = decomposer(state, {})
    
    assert result["intent"] == "aggregation"
    assert "current year" in result["query_pattern"]
    assert result["status"] == "success"

@pytest.mark.unit
def test_guardrails_blocks_dml():
    """guardrails가 INSERT 쿼리를 차단."""
    state = new_state(question="...")
    state.chosen_sql = "INSERT INTO table VALUES (1, 2)"
    
    result = guardrails(state, {})
    assert result["ok"] == False
    assert "DML" in result["reason"]
```

### Integration 테스트 (@pytest.mark.integration)
Oracle DB 필수, 파이프라인 통합:

```python
@pytest.mark.integration
def test_end_to_end_oracle_query():
    """E2E: 질문 → SQL → 결과."""
    state = new_state(question="최근 1개월 판매량", db_id="oracle_prod")
    
    graph = get_compiled_graph()
    result = graph.invoke(input=state)
    
    assert result["status"] == "completed"
    assert len(result["exec_report"]["rows"]) > 0
```

**실행**:
```bash
pytest tests/unit -m unit        # Unit만 (빠름)
pytest tests/ -m integration     # Integration만 (Oracle 필요)
pytest tests/ -v                 # 전체 (verbose)
```

---

## SQL 작성 규칙

### ✅ 올바른 패턴
```sql
SELECT 
    t1.col1,
    t2.col2,
    COUNT(*) as count_val
FROM table_1 t1
INNER JOIN table_2 t2 ON t1.id = t2.id
WHERE t1.status = 'ACTIVE'
GROUP BY t1.col1, t2.col2
ORDER BY count_val DESC
LIMIT 50
```

### ❌ 금지 패턴
```sql
SELECT *                         -- 구체적 컬럼 명시
SELECT ... LIMIT 1000000         -- 너무 많음
INSERT INTO ...                  -- DML 차단
UPDATE ...                        -- DML 차단
DELETE ...                        -- DML 차단
CREATE TABLE ...                 -- DDL 차단
```

### Oracle 고유 문법
```sql
-- LIMIT 대신 FETCH FIRST 사용 가능
SELECT ... FETCH FIRST 50 ROWS ONLY

-- 날짜 함수
TRUNC(SYSDATE, 'MM')             -- 월초
ADD_MONTHS(SYSDATE, -1)          -- 1개월 전
TO_DATE('2024-05-12', 'YYYY-MM-DD')

-- 문자열 함수
SUBSTR(col, 1, 10)               -- 부분 문자열
UPPER(col), LOWER(col)           -- 대소문자
TRIM(col)                        -- 공백 제거

-- 집계
SUM(), AVG(), COUNT(), MIN(), MAX()
STDDEV(), VARIANCE()
LISTAGG(col, ',') WITHIN GROUP (ORDER BY col)

-- Window Functions
ROW_NUMBER() OVER (PARTITION BY col ORDER BY col)
DENSE_RANK() OVER (PARTITION BY col ORDER BY col)
RANK() OVER (PARTITION BY col ORDER BY col)
```

---

## 코드 리뷰 체크리스트

커밋하기 전 **반드시** 확인:

### 구조
- [ ] LangGraph 노드 추가/제거 없음?
- [ ] graph.py 연결 순서 변경 없음?
- [ ] GraphState 필드명 변경 없음? (새 필드는 state.py에 정의?)

### 코드 품질
- [ ] 모든 함수에 타입 힌트? (인자 + 반환값)
- [ ] 모든 함수에 docstring? (역할 명시)
- [ ] 모든 에러 경로 처리? (try/except)
- [ ] print() 없음? (logger만 사용?)
- [ ] 불필요한 주석 제거? (WHY만 유지)

### 테스트
- [ ] Unit 테스트 작성? (@pytest.mark.unit)
- [ ] `pytest -m unit` 통과?
- [ ] 수동 테스트 완료? (CLI/Streamlit)

### 보안
- [ ] SELECT * 없음?
- [ ] DML/DDL 없음?
- [ ] hallucination (존재하지 않는 컬럼) 없음?

### 성능
- [ ] 불필요한 LLM 호출 제거?
- [ ] RAG 결과 최소화? (상위 10개만)
- [ ] LIMIT/FETCH FIRST 추가?

---

## 🚨 일반적인 실수 & 해결책

### 1. "SELECT * 사용"
```python
# ❌ 잘못됨
sql = f"SELECT * FROM {table}"

# ✅ 올바름
selected_cols = state.get("selected_columns", {}).get(table, [])
sql = f"SELECT {', '.join(selected_cols)} FROM {table}"
```

### 2. "에러 무시"
```python
# ❌ 잘못됨
try:
    result = executor.execute(sql)
except:
    return None

# ✅ 올바름
try:
    result = executor.execute(sql)
except OracleError as e:
    logger.error(f"Oracle 오류: {e}", exc_info=True)
    return {"status": "failed", "error": str(e)}
except Exception as e:
    logger.error(f"예상 외: {e}", exc_info=True)
    raise
```

### 3. "GraphState 직렬화 불가 타입"
```python
# ❌ 잘못됨
state["connection_object"] = oracle_conn  # 직렬화 불가

# ✅ 올바름
state["connection_id"] = "oracle_prod"    # 문자열/숫자만
```

### 4. "다른 Agent의 책임 침범"
```python
# ❌ 잘못됨 (candidate_generator에서 DB 실행)
def node_candidate_generator(state):
    sql = ...
    result = executor.execute(sql)  # 이건 execute_preview의 일!

# ✅ 올바름
def node_candidate_generator(state):
    sql = ...
    return {"sql_candidates": [SQLCandidate(sql)]}
    # execute_preview에서 실행
```

---

## 📚 참고 자료

| 항목 | 위치 |
|------|------|
| 13개 Agent 설명 | CLAUDE.md / 이 문서 |
| 프로젝트 구조 | docs/PROJECT_STRUCTURE.md |
| API 엔드포인트 | docs/operations/ENDPOINT_USAGE_GUIDE.md |
| 운영 가이드 | docs/operations/ |
| 스크립트 사용법 | docs/operations/SCRIPT_SELECTION_GUIDE.md |

---

## 🎯 개발 워크플로우

### 1단계: 요청 분석
- 요청 읽고 영향 범위 파악
- MUST-HAVE 규칙 확인

### 2단계: 설계
- 수정할 파일 결정
- GraphState 변경 필요한지 확인
- 테스트 케이스 설계

### 3단계: 구현
- 타입 힌트 + docstring
- logger 사용
- 예외 처리

### 4단계: 테스트
```bash
# Unit 테스트 작성 및 실행
pytest tests/unit -m unit -v

# 수동 테스트 (CLI)
python scripts/run_cli.py -q "테스트 질문"

# 수동 테스트 (UI)
streamlit run app.py
```

### 5단계: 코드 리뷰
- 체크리스트 확인
- 불필요한 주석 제거
- print() 검사

### 6단계: 커밋
```bash
git add src/ tests/
git commit -m "feat: 기능 설명

상세 설명..."
```

---

**마지막 업데이트**: 2025-05-12  
**버전**: v1.0  
**적용 범위**: text-to-sql-assistant 모든 개발
