#!/usr/bin/env python3
"""Validate Oracle connectivity and basic metadata access."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


def main():
    from text2sql.config.settings import get_settings
    from text2sql.tools.ops.diagnostics import check_oracle_connection

    settings = get_settings()
    
    print("=" * 60)
    print("Oracle Connection Check")
    print("=" * 60)

    results = check_oracle_connection(settings)
    
    print(f"  Host:         {results['host']}")
    print(f"  Port:         {results['port']}")
    print(f"  Service:      {results['service']}")
    print(f"  User:         {results['user']}")
    print(f"  Schema:       {results['schema']}")
    print()

    if not results["ok"]:
        print(f"[ERROR] {results['message']}")
        sys.exit(1)

    print("[1/5] Testing connection...")
    print(f"  [OK] {results['message']}")
    print()

    print(f"[2/5] Effective user/schema: {results.get('effective_user')} / {results.get('effective_schema')}")
    print()

    print("[3/5] Listing readable tables...")
    tables = results.get("tables", [])
    print(f"  Table count: {len(tables)}")
    if tables:
        for table_name in tables[:20]:
            print(f"    - {table_name}")
        if len(tables) > 20:
            print(f"    ... and {len(tables) - 20} more")


        system_like = [
            table_name
            for table_name in tables
            if table_name.upper().startswith(("AQ$_", "MVIEW$_", "LOGSTDBY$", "REDO_DB$"))
            or table_name.upper() in {"HELP", "SQLPLUS_PRODUCT_PROFILE"}
        ]
        if (info.get("schema") or "").upper() in {"SYSTEM", "SYS"} or len(system_like) >= max(5, len(tables) // 3):
            print("  [WARN] The current schema still looks like SYSTEM/SYS or a system-table schema.")
            print("         For production Text-to-SQL, use a business schema or tighten include/exclude filters.")
    print()

    print("[4/5] Checking metadata access...")
    metadata_ok = info.get("metadata_accessible", False)
    print(f"  ALL_* metadata views accessible: {'YES' if metadata_ok else 'NO (USER_* fallback)'}")
    if tables:
        sample_table = tables[0]
        table_meta = adapter.table_info(sample_table)
        print(f"  Sample table: {sample_table}")
        print(f"    Columns: {len(table_meta.columns)}")
        for column in table_meta.columns[:5]:
            pk = " [PK]" if column.is_pk else ""
            comment = f" -- {column.comment}" if column.comment else ""
            print(f"      {column.name}  {column.type}{pk}{comment}")
        if len(table_meta.columns) > 5:
            print(f"      ... and {len(table_meta.columns) - 5} more columns")
        print(f"    Foreign keys: {len(table_meta.foreign_keys)}")
    print()

    print("[5/5] Running sample SELECT...")
    if tables:
        sample_table = tables[0]
        owner = adapter.owner
        sql = f'SELECT * FROM "{owner}"."{sample_table}" WHERE ROWNUM <= 3'
        result = adapter.execute(sql, limit=3)
        if result["ok"]:
            print(f"  [OK] Query succeeded on {sample_table} ({result['row_count']} rows)")
            for row in result["rows"][:3]:
                print(f"    {dict(list(row.items())[:5])}")
        else:
            print(f"  [FAIL] Query failed: {result['error_message']}")
    print()

    adapter.close()
    print("=" * 60)
    print("Next recommended commands")
    print("=" * 60)
    print("  python scripts/run_ops.py first-run --db-id <db_id>")
    print("  python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>")
    print("  python scripts/run_ops.py test --db-id <db_id> --catalog <catalog.json>")
    print("  python scripts/run_ops.py release --db-id <db_id> --catalog <catalog.json>")


if __name__ == "__main__":
    main()
