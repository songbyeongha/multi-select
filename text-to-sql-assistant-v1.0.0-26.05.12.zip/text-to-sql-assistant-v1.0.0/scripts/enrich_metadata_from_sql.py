#!/usr/bin/env python3
"""Enrich metadata and domain hints from an existing SQL corpus."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def parse_args():
    parser = argparse.ArgumentParser(description="Enrich metadata from SQL corpus")
    parser.add_argument("--db-id", default="", help="Database ID")
    parser.add_argument("--catalog", action="append", default=[], help="JSON/JSONL/SQL catalog file with question+sql entries")
    parser.add_argument("--sql-glob", action="append", default=[], help="Glob pattern for .sql files relative to project root")
    parser.add_argument("--metadata-output", default="", help="Manual metadata overlay output path")
    parser.add_argument("--domain-hints-output", default="", help="Manual domain hints overlay output path")
    parser.add_argument("--dialect", default="", help="sqlglot dialect")
    parser.add_argument("--min-relation-support", type=int, default=1, help="Minimum SQL evidence count for inferred relationships")
    parser.add_argument("--max-few-shots", type=int, default=40, help="Maximum number of few-shot examples to keep")
    parser.add_argument("--skip-fill-descriptions", action="store_true", help="Do not auto-fill missing descriptions")
    parser.add_argument("--report", default="logs/sql_metadata_enrichment_report.json", help="Report output path")
    return parser.parse_args()


def main():
    from text2sql.config.settings import get_settings
    from text2sql.tools.ops.metadata import enrich_metadata

    args = parse_args()
    settings = get_settings()

    print("=" * 60)
    print("SQL Metadata Enrichment")
    print("=" * 60)

    try:
        results = enrich_metadata(
            settings,
            db_id=args.db_id,
            catalog_paths=args.catalog,
            sql_globs=args.sql_glob,
            metadata_output=args.metadata_output,
            hints_output=args.domain_hints_output,
            dialect=args.dialect,
            min_relation_support=args.min_relation_support,
            max_few_shots=args.max_few_shots,
            skip_fill_descriptions=args.skip_fill_descriptions,
            report_path=args.report,
        )
    except Exception as exc:
        print(f"[ERROR] Enrichment failed: {exc}")
        sys.exit(1)

    print(f"[OK] Enriched metadata for DB ID: {results['db_id']}")
    print(f"     Artifact count: {results['artifact_count']}")
    print(f"     Queries processed: {results['report_summary']['total_queries']}")
    print(f"     Relationships inferred: {results['report_summary']['inferred_relationships']}")
    print("     Files updated:")
    print(f"       - Metadata Overlay: {results['paths']['metadata_overlay']}")
    print(f"       - Hints Overlay:    {results['paths']['hints_overlay']}")
    print(f"       - Report:           {results['paths']['report']}")



if __name__ == "__main__":
    main()
