#!/usr/bin/env python3
"""Export Oracle metadata and seed editable overlay files."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


def parse_args():
    parser = argparse.ArgumentParser(description="Export Oracle metadata")
    parser.add_argument("--output", "-o", default="", help="Primary metadata output path")
    parser.add_argument("--manual-output", default="", help="Manual metadata overlay path")
    parser.add_argument("--domain-hints-output", default="", help="Oracle domain hints seed path")
    parser.add_argument("--domain-hints-manual-output", default="", help="Oracle manual domain hints overlay path")
    parser.add_argument("--include", default="", help="Comma-separated include tables")
    parser.add_argument("--exclude", default="", help="Comma-separated exclude tables")
    parser.add_argument("--samples", type=int, default=3, help="Sample value count per column")
    parser.add_argument("--db-id", default="", help="Database ID")
    return parser.parse_args()


def main():
    from text2sql.config.settings import get_settings
    from text2sql.tools.ops.metadata import export_metadata

    args = parse_args()
    settings = get_settings()

    db_id = args.db_id or settings.db.db_id or "oracle_db"
    include = [t.strip() for t in args.include.split(",") if t.strip()]
    exclude = [t.strip() for t in args.exclude.split(",") if t.strip()]

    print("=" * 60)
    print("Oracle Metadata Export")
    print("=" * 60)

    try:
        results = export_metadata(
            settings,
            db_id=db_id,
            include_tables=include,
            exclude_tables=exclude,
            sample_limit=args.samples,
            output_path=args.output,
            manual_output_path=args.manual_output,
            hints_output_path=args.domain_hints_output,
            manual_hints_output_path=args.domain_hints_manual_output,
        )
    except Exception as exc:
        print(f"[ERROR] Export failed: {exc}")
        sys.exit(1)

    print(f"[OK] Exported metadata for DB ID: {results['db_id']}")
    print(f"     Table count: {results['table_count']}")
    print("     Files generated:")
    print(f"       - Primary: {results['paths']['metadata']}")
    print(f"       - Manual:  {results['paths']['manual_metadata']}")
    print(f"       - Hints:   {results['paths']['domain_hints']}")
    print(f"       - M-Hints: {results['paths']['manual_domain_hints']}")



if __name__ == "__main__":
    main()
