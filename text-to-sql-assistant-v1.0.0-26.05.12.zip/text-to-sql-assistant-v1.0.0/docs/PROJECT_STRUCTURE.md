# 프로젝트 구조 완벽 가이드

## 개요

Text-to-SQL Assistant는 LangGraph 기반의 13단계 파이프라인으로 구성된 Oracle 쿼리 AI 시스템입니다.
이 문서는 전체 프로젝트 구조, 핵심 모듈, 데이터 흐름을 설명합니다.

---

## 🎯 핵심 개념 (5분 요약)

### 1. 목표
사용자의 자연언어 질문 → Oracle SQL로 변환 → 실행 → 결과 반환

### 2. 구조
```
사용자 입력 (질문)
    ↓
LangGraph 파이프라인 (13 노드)
    ├─ 분석: decomposer, schema_selector, value_retriever, join_planner
    ├─ 생성: candidate_generator (3개 SQL), sql_postprocess
    ├─ 검증: guardrails, unit_tester
    ├─ 실행: execute_preview, judge, repair (최대 3회)
    └─ 반환: result_output, memory/audit
    ↓
최종 결과 (SQL + 데이터)
```

### 3. 진입점
- **Web UI** (Streamlit): `app.py` → 대화형 인터페이스
- **CLI**: `scripts/run_cli.py` → 배치/자동화
- **Operations**: `scripts/run_ops.py` → 초기화/진단

---

## 📂 디렉토리 구조

```
10613/
├── app.py                              # Streamlit Web UI (메인 진입)
├── README.md                           # 프로젝트 개요
├── CLAUDE.md                           # 개발 규칙 (Ground Rule SKILL 통합)
├── requirements.txt                    # Python 패키지
├── pytest.ini                          # 테스트 설정
│
├── .claude/
│   └── skills/
│       └── ground-rule.md              # ⭐ Ground Rule SKILL (재사용 가능 가이드)
│
├── src/text2sql/                       # 핵심 소스 코드
│   ├── __init__.py
│   ├── lg/                             # LangGraph 파이프라인
│   │   ├── state.py                    # GraphState 정의 (모든 데이터 구조)
│   │   ├── graph.py                    # 노드 연결 및 조건부 실행
│   │   └── __init__.py
│   │
│   ├── agents/                         # 파이프라인 노드들 (13개)
│   │   ├── decomposer.py               # [1] 질문 구조화
│   │   ├── schema_nodes.py             # [2] 스키마 선택 (RAG)
│   │   ├── validation_nodes.py         # [3,4] 값 검증, JOIN 설계
│   │   ├── generation_nodes.py         # [5,6] SQL 생성 & 정규화
│   │   ├── guardrail_rules.py          # [7] 보안 검사
│   │   ├── repair_output.py            # [8-11] 검증, 실행, 평가, 수정
│   │   ├── _utils.py                   # 공용 유틸리티
│   │   └── __init__.py
│   │
│   ├── config/                         # 설정 & 메타데이터
│   │   ├── settings.py                 # 환경 설정 로드 (env)
│   │   ├── metadata_utils.py           # 메타데이터 유틸
│   │   ├── strategy_hints.json         # 쿼리 전략 힌트
│   │   ├── generated/                  # ⭐ 런타임 생성 (prepare 단계)
│   │   │   ├── schema_metadata_oracle.json      # 테이블/컬럼 (JSON)
│   │   │   ├── domain_hints_oracle.json         # 컬럼 설명
│   │   │   ├── schema_metadata_oracle_manual.json   # 사용자 정정
│   │   │   ├── domain_hints_oracle_manual.json     # 사용자 정정
│   │   │   └── README.md               # generated/ 설명
│   │   └── __init__.py
│   │
│   ├── llm/                            # LLM 클라이언트
│   │   ├── client.py                   # OpenAI/Azure 클라이언트
│   │   ├── prompts.py                  # 프롬프트 템플릿
│   │   └── __init__.py
│   │
│   ├── rag/                            # Vector Store (RAG)
│   │   ├── schema_rag.py               # 스키마 검색 (BM25 + 벡터)
│   │   ├── vector_store.py             # ChromaDB 인터페이스
│   │   └── __init__.py
│   │
│   ├── memory/                         # 대화 히스토리
│   │   ├── conversation.py             # 메시지 저장/조회
│   │   └── __init__.py
│   │
│   ├── feedback/                       # 피드백 & 학습 시스템
│   │   ├── store.py                    # 피드백 저장소
│   │   ├── evaluator.py                # 자동 평가
│   │   ├── auto_scorer.py              # 점수 계산
│   │   ├── learner.py                  # few-shot 업데이트
│   │   ├── logger.py                   # 감시 로깅
│   │   └── __init__.py
│   │
│   ├── tools/                          # 유틸리티 & 실행기
│   │   ├── executor.py                 # ⭐ SQL 실행 (유일한 DB 경로)
│   │   ├── guardrails.py               # 보안 검사 (DDL/DML 차단)
│   │   ├── db_adapters/                # DB 어댑터
│   │   │   ├── base.py                 # 기본 인터페이스
│   │   │   ├── oracle_adapter.py       # Oracle 구현
│   │   │   ├── factory.py              # Adapter 팩토리
│   │   │   └── __init__.py
│   │   ├── oracle_metadata.py          # Oracle 메타데이터 추출
│   │   ├── sql_postprocess.py          # SQL AST 정규화
│   │   ├── cache.py                    # 캐싱 유틸
│   │   ├── audit.py                    # 감시 로깅
│   │   ├── cli_display.py              # CLI 포맷팅
│   │   ├── date_tools.py               # 시간 파싱
│   │   ├── db_registry.py              # DB 레지스트리
│   │   ├── harness_catalog.py          # 카탈로그 관리
│   │   ├── release_gate.py             # 배포 게이트
│   │   ├── runtime_checks.py           # 런타임 검증
│   │   ├── sql_metadata_enricher.py    # SQL 메타데이터 강화
│   │   ├── ops_gateway.py              # Operations API
│   │   ├── ops/                        # Operations 모듈
│   │   │   ├── metadata.py             # 메타데이터 준비
│   │   │   ├── diagnostics.py          # 진단 도구
│   │   │   └── __init__.py
│   │   └── __init__.py
│   │
│   ├── ui/                             # Streamlit UI
│   │   ├── context.py                  # 앱 컨텍스트
│   │   ├── pipeline.py                 # 파이프라인 실행기
│   │   ├── sidebar.py                  # 사이드바
│   │   ├── renderers.py                # 결과 렌더링
│   │   ├── styles.py                   # CSS 스타일
│   │   ├── tabs/                       # 탭 UI
│   │   │   ├── main_tab.py             # 메인 질문 입력 탭
│   │   │   ├── batch_tab.py            # 배치 E2E 테스트 탭
│   │   │   ├── history_tab.py          # 히스토리 조회 탭
│   │   │   ├── learn_tab.py            # 피드백 & few-shot 탭
│   │   │   ├── operations_tab.py       # 운영 도구 탭
│   │   │   └── __init__.py
│   │   └── __init__.py
│
├── scripts/                            # 진입점 스크립트
│   ├── run_cli.py                      # ⭐ CLI 진입 (-q "질문")
│   ├── run_ops.py                      # ⭐ Operations (prepare, first-run, doctor)
│   ├── health_check.py                 # 헬스 체크
│   ├── check_domain_hints.py           # Domain hints 확인
│   ├── oracle_ops.py                   # Oracle 유틸리티
│   ├── run_e2e_suite.py                # E2E 테스트
│   ├── validate_query_catalog.py       # 카탈로그 검증
│   └── ... (기타 운영 스크립트)
│
├── tests/                              # 테스트
│   ├── conftest.py                     # pytest 설정
│   ├── unit/                           # Unit 테스트 (DB 불필요)
│   │   ├── test_graph_build.py         # Graph 구축 테스트
│   │   ├── test_imports.py             # Import 테스트
│   │   ├── test_pipeline_mock.py       # 파이프라인 mock 테스트
│   │   └── conftest.py
│   ├── integration/                    # Integration 테스트 (Oracle 필수)
│   │   ├── README.md                   # Integration 테스트 설명
│   │   └── __init__.py
│   └── test_guardrail_regression.py    # Guardrail 회귀 테스트
│
├── data/                               # 런타임 데이터
│   ├── catalog.json                    # 쿼리 카탈로그 (E2E 테스트용)
│   ├── catalog.example.json            # 카탈로그 예시
│   ├── bootstrap/                      # 부트스트랩 데이터
│   ├── feedback/                       # 피드백 저장소
│   │   ├── feedback_log.json           # 사용자 별점
│   │   ├── learn_log.jsonl             # few-shot examples
│   │   └── learn_log.txt               # 학습 로그
│   ├── history/                        # 히스토리
│   │   └── history.json                # 이전 질문/결과
│   └── vector_store/                   # ChromaDB
│       └── chroma.sqlite3              # 임베딩 저장소
│
├── docs/                               # 문서
│   ├── START_HERE.md                   # 🚀 시작 가이드 (필독)
│   ├── CODEBASE_GUIDE.md               # 코드베이스 구조
│   ├── ARCHITECTURE_DIAGRAMS.md        # 아키텍처 다이어그램
│   ├── PROJECT_STRUCTURE.md            # 이 파일
│   ├── README.md                       # 문서 홈
│   ├── 01-plan/                        # PDCA Plan 문서
│   ├── 02-design/                      # PDCA Design 문서
│   ├── 03-analysis/                    # PDCA Analysis 문서
│   ├── 04-report/                      # PDCA Report 문서
│   ├── metadata/                       # 메타데이터 설명
│   │   └── SQL_METADATA_ENRICHMENT.md
│   └── operations/                     # 운영 가이드
│       ├── FIRST_PRODUCTION_ATTACH.md
│       ├── OPERATOR_ONE_PAGE.md
│       ├── ENDPOINT_USAGE_GUIDE.md
│       ├── DAILY_OPERATIONS_CHECKLIST.md
│       ├── SCRIPT_SELECTION_GUIDE.md
│       ├── ORACLE_DB_QUICKSTART.md
│       └── RELEASE_CHECKLIST.md
│
├── logs/                               # 런타임 로그
│   └── audit_*.jsonl                   # 감시 로그
│
├── ai-history/                         # AI 작업 기록
│   └── tasks/                          # 타임스탬프 기반 작업 기록
│       └── {YYYYMMDD_HHMMSS}_{task_name}.md
│
├── .env                                # 환경 변수 (git ignore)
├── .env.example                        # 환경 변수 예시
├── .gitignore                          # Git 무시 파일
├── .github/workflows/                  # CI/CD 파이프라인
│   └── ai-guard.yml
│
└── .bkit/                              # bkit 런타임 상태
    └── runtime/
```

---

## 🔄 데이터 흐름

### GraphState (모든 데이터 중앙)
```python
class GraphState:
    # 입력
    question: str                       # 사용자 질문
    db_id: str                         # Oracle DB ID
    
    # 각 노드의 출력 (스테이트에 누적)
    intent: str                        # decomposer 출력
    selected_tables: list[str]         # schema_selector 출력
    schema_text: str                   # 스키마 정보
    sql_candidates: list[SQLCandidate] # candidate_generator 출력
    chosen_sql: str                    # 선택된 SQL
    exec_report: ExecReport            # execute_preview 출력
    quality_score: float               # judge 출력
    repair_attempts: int               # repair 시도 횟수
```

### 노드별 책임
```
[1] decomposer
    입력: question
    출력: intent, query_pattern, extracted_values
    ↓
[2] schema_selector (RAG)
    입력: question + intent
    출력: selected_tables, schema_text
    ↓
[3-6] value_retriever, join_planner, candidate_generator, sql_postprocess
    입력: selected_tables, schema_text
    출력: sql_candidates (3개)
    ↓
[7-9] guardrails, unit_tester, execute_preview
    입력: sql_candidates
    출력: exec_report (결과/에러)
    ↓
[10] judge
    입력: exec_report, question
    출력: quality_score, is_valid
    ↓
[11] repair (조건부, 최대 3회)
    입력: exec_report (if error)
    출력: 수정된 SQL + 재실행
    ↓
[12] result_output
    입력: chosen_sql, exec_report
    출력: 최종 결과
    ↓
[13] memory/audit
    입력: 전체 흐름
    출력: 피드백 저장 & 학습
```

---

## 🛠️ 핵심 모듈 상세

### 1. LangGraph (lg/)
- **state.py**: GraphState 정의 (직렬화 필요)
- **graph.py**: 노드 등록 및 조건부 라우팅
  ```python
  graph.add_node("decomposer", decomposer)
  graph.add_conditional_edges("judge", judge_routing)
  ```

### 2. Agents (agents/)
각 함수는 `(state: GraphState, config: dict) -> dict` 시그니처 준수

```python
def decomposer(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """질문 분석."""
    return {
        "intent": "...",
        "query_pattern": "...",
        "extracted_values": {...}
    }
```

### 3. RAG (rag/)
- **schema_rag.py**: BM25 + 벡터 검색
  ```python
  results = schema_rag.retrieve(
      question="...",
      k=10  # 상위 10개만 (비용 최소화)
  )
  ```
- **vector_store.py**: ChromaDB 래퍼

### 4. Executor (tools/executor.py)
유일한 DB 접근 경로
```python
executor = SQLExecutor()
result = executor.execute(db_path, sql, limit=50)
# → ExecReport(ok, rows, error_type, error_message)
```

### 5. Feedback (feedback/)
- **store.py**: 피드백 저장
- **learner.py**: few-shot 업데이트 (4~5점 시)
- **auto_scorer.py**: 자동 평가

---

## 📍 진입점 맵핑

### Web UI (app.py)
```
Streamlit run app.py
    ↓
app_context: AppContext (설정, 상태)
    ├─ tab_main: 단일 질문
    ├─ tab_batch: 카탈로그 E2E
    ├─ tab_history: 이전 결과
    ├─ tab_learn: 피드백 관리
    └─ tab_ops: 운영 도구
```

### CLI (scripts/run_cli.py)
```
python scripts/run_cli.py -q "질문"
    ↓
run_phase1_generate() → GraphState with sql_candidates
    ↓
run_phase2_execute() → ExecReport with results
```

### Operations (scripts/run_ops.py)
```
python scripts/run_ops.py {command}
    ├─ doctor: 연결 진단
    ├─ prepare: 메타데이터 추출 & LLM 강화
    └─ first-run: doctor + prepare + E2E
```

---

## 🔐 보안 게이트

### guardrails.py
모든 SQL 실행 전 필터:
```python
# ❌ 차단
SELECT *
INSERT, UPDATE, DELETE, DROP
SELECT FROM non_existent_table

# ✅ 허용
SELECT col1, col2 FROM table LIMIT 50
```

---

## 📊 메타데이터 계층

### 1순위: JSON (성능 최고)
```
src/text2sql/config/generated/
├── schema_metadata_oracle.json  # 테이블/컬럼 정의
└── domain_hints_oracle.json     # 컬럼 설명
```

### 2순위: LLM 생성 (초기화만)
```python
# prepare 단계에서만
metadata = extract_from_oracle()
hints = generate_with_llm(metadata)
save_to_json(hints)
```

### 3순위: 수동 오버레이
```
*_manual.json  # 사용자 정정사항
```

---

## 🧪 테스트 구조

### Unit 테스트 (@pytest.mark.unit)
DB 불필요, mock 사용
```python
@pytest.mark.unit
def test_decomposer():
    state = new_state(question="...")
    result = decomposer(state, {})
    assert result["intent"] == "..."
```

### Integration 테스트 (@pytest.mark.integration)
Oracle DB 필수
```python
@pytest.mark.integration
def test_end_to_end():
    state = new_state(question="...", db_id="...")
    # Full pipeline execution
```

---

## 📝 작업 기록 시스템

모든 코드 변경은 `ai-history/tasks/` 에 기록:
```
ai-history/tasks/
├── 20250512_120000_feature_xyz.md
├── 20250512_130000_bug_fix_abc.md
└── ...
```

포맷:
```markdown
# [Task Name]

## [요청]
사용자 입력 원문

## [분석]
- 문제: ...
- 범위: src/text2sql/agents/xyz.py

## [수정 내용]
- xyz.py: 변경 설명

## [변경 코드]
\`\`\`diff
Before:
After:
\`\`\`
```

---

## ✅ 체크리스트

### 새 기능 추가
- [ ] CLAUDE.md의 절대 규칙 확인
- [ ] GraphState에 필드 추가? (state.py)
- [ ] 타입 힌트 & Docstring
- [ ] Unit 테스트 작성
- [ ] `pytest -m unit` 통과
- [ ] ai-history/tasks/ 기록 작성

### 버그 수정
- [ ] 문제 노드 식별
- [ ] 재현 테스트 작성
- [ ] 최소 수정 적용
- [ ] 회귀 테스트 (기존 기능)
- [ ] ai-history/tasks/ 기록

---

## 🔗 참고

- **시작**: docs/START_HERE.md
- **규칙**: CLAUDE.md + `.claude/skills/ground-rule.md`
- **아키텍처**: docs/ARCHITECTURE_DIAGRAMS.md
- **운영**: docs/operations/OPERATOR_ONE_PAGE.md

---

**마지막 업데이트**: 2025-05-12
