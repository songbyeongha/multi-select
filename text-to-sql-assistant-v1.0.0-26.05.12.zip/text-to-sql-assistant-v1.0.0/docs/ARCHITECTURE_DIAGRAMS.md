# 아키텍처 다이어그램

> Text-to-SQL Assistant — 시스템 구조 시각화

---

## 1. LangGraph 파이프라인 흐름

```mermaid
flowchart TD
    START([▶ START]) --> decomposer

    decomposer["1️⃣ decomposer\n자연어 구조화\n(intent, query_pattern)"]
    schema_selector["2️⃣ schema_selector\n관련 테이블/컬럼 선택\n(RAG 기반)"]
    value_retriever["3️⃣ value_retriever\n자연어 값 → DB 값 매핑"]
    join_planner["4️⃣ join_planner\nJOIN 경로 설계\n(FK 기반)"]
    candidate_gen["5️⃣ candidate_generator\nSQL 3개 생성\n(conservative / recall / metric)"]
    sql_postprocess["6️⃣ sql_postprocess\nAST 정규화\n(sqlglot)"]
    guardrails["7️⃣ guardrails\n보안 검사\n(DDL/DML 차단)"]
    unit_tester["8️⃣ unit_tester\n문법 정적 검증"]
    execute_preview["9️⃣ execute_preview\n실제 DB 실행\n(timeout + row limit)"]
    judge["🔟 judge\n결과 품질 판단\n(질문 ↔ 결과 일치)"]
    repair["🔧 repair\nSQL 수정\n(에러 기반 재시도 max 3회)"]
    result_output["1️⃣1️⃣ result_output\n최종 결과 + 요약"]
    safe_fail["⛔ safe_fail\n안전 실패 응답"]
    END_NODE([⏹ END])

    decomposer --> schema_selector
    schema_selector --> value_retriever
    value_retriever --> join_planner
    join_planner --> candidate_gen
    candidate_gen --> sql_postprocess
    sql_postprocess --> guardrails

    guardrails -->|guard_passed ✅| unit_tester
    guardrails -->|fail ❌| repair

    unit_tester -->|ut_passed or is_valid ✅| execute_preview
    unit_tester -->|no valid candidates ❌| repair

    execute_preview -->|exec_report.ok ✅| judge
    execute_preview -->|실행 실패 ❌| repair

    judge -->|judge_accepted ✅| result_output
    judge -->|reject ❌| repair

    repair -->|retry_count < max_retries| guardrails
    repair -->|max 초과| safe_fail

    result_output --> END_NODE
    safe_fail --> END_NODE

    style START fill:#22c55e,color:#fff
    style END_NODE fill:#64748b,color:#fff
    style repair fill:#f97316,color:#fff
    style safe_fail fill:#ef4444,color:#fff
    style guardrails fill:#8b5cf6,color:#fff
    style judge fill:#8b5cf6,color:#fff
```

---

## 2. 시스템 전체 아키텍처

```mermaid
graph TB
    User(["👤 사용자\n브라우저"])

    subgraph Streamlit["Streamlit App (app.py)"]
        tabs["탭 UI\n질의실행 / 대량질의 / 히스토리\n학습로그 / 운영관리"]
        sidebar["Sidebar\n설정 (max_retries, HITL)"]
        context["AppContext\n(graph, db, rag 초기화)"]
    end

    subgraph LangGraph["LangGraph Pipeline (lg/graph.py)"]
        direction LR
        nodes["13개 Node\ndecomposer → ... → result_output"]
        state["GraphState\n(TypedDict, 전체 공유 상태)"]
    end

    subgraph Agents["Agents Layer (agents/)"]
        decomp["decomposer.py\nvalue_retriever"]
        schema_n["schema_nodes.py\nschema_selector / join_planner"]
        gen_n["generation_nodes.py\ncandidate_gen / sql_postprocess"]
        val_n["validation_nodes.py\nguardrails / unit_tester\nexecute_preview / judge"]
        rep_n["repair_output.py\nrepair / result_output / safe_fail"]
    end

    subgraph Tools["Tools Layer (tools/)"]
        executor["executor.py\n유일한 DB 접근 경로"]
        guardrail_t["guardrails.py\n보안 규칙"]
        sqlpp["sql_postprocess.py\nAST 정규화"]
        rag_t["rag/schema_rag.py\nBM25 + 벡터 검색"]
    end

    subgraph External["외부 의존성"]
        OracleDB[("🗄️ Oracle DB")]
        LLM(["🤖 LLM\nAzure / OpenAI"])
        Chroma[("🔍 ChromaDB\n벡터 스토어")]
    end

    subgraph Feedback["Feedback (feedback/)"]
        store["store.py\n피드백 저장"]
        learner["learner.py\nfew-shot 학습"]
        logger_f["logger.py\naudit 로그"]
    end

    User --> tabs
    tabs --> context
    sidebar --> context
    context --> LangGraph
    LangGraph --> Agents
    Agents --> Tools
    executor --> OracleDB
    Agents --> LLM
    rag_t --> Chroma
    LangGraph --> Feedback
```

---

## 3. 모듈 의존 관계

```mermaid
graph LR
    subgraph Entry["진입점"]
        app["app.py"]
        cli["scripts/run_cli.py"]
    end

    subgraph UI["ui/"]
        pipeline_ui["pipeline.py\n파이프라인 실행 래퍼"]
        tabs_ui["tabs/\nmain / batch / history\nlearn / operations"]
    end

    subgraph Core["핵심 파이프라인"]
        graph["lg/graph.py\nbuild_graph()"]
        state_m["lg/state.py\nGraphState"]
    end

    subgraph AgentFiles["agents/"]
        nodes_m["nodes.py\n(re-export)"]
        decomp_m["decomposer.py"]
        schema_m["schema_nodes.py"]
        gen_m["generation_nodes.py"]
        val_m["validation_nodes.py"]
        rep_m["repair_output.py"]
    end

    subgraph ToolFiles["tools/"]
        exec_m["executor.py ⭐"]
        guard_m["guardrails.py"]
        postproc["sql_postprocess.py"]
        rag_m["../rag/schema_rag.py"]
    end

    subgraph Config["config/"]
        settings_m["settings.py"]
        meta["metadata_utils.py"]
    end

    app --> UI
    cli --> graph
    UI --> pipeline_ui
    pipeline_ui --> graph
    graph --> nodes_m
    graph --> state_m
    nodes_m --> decomp_m
    nodes_m --> schema_m
    nodes_m --> gen_m
    nodes_m --> val_m
    nodes_m --> rep_m
    val_m --> exec_m
    schema_m --> rag_m
    gen_m --> guard_m
    gen_m --> postproc
    decomp_m --> settings_m
    exec_m --> settings_m

    style exec_m fill:#f97316,color:#fff
    style graph fill:#3b82f6,color:#fff
    style state_m fill:#3b82f6,color:#fff
```

---

## 핵심 설계 원칙

| 원칙 | 내용 |
|------|------|
| **단일 DB 접근** | `executor.py`만 Oracle DB에 접근. agents에서 직접 DB 호출 금지 |
| **GraphState 공유** | 모든 노드는 GraphState를 통해서만 데이터 전달 |
| **repair 루프** | 최대 3회, guardrails 재진입 방식으로 자가 수정 |
| **safe_fail 보장** | max_retries 초과 시 빈 결과가 아닌 명확한 실패 응답 반환 |
| **RAG 기반 스키마** | 전체 스키마를 LLM에 넘기지 않고 관련 테이블만 선택 |
