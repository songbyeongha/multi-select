"""
벡터 스토어  ──  Chroma + Embeddings 기반 스키마 시맨틱 검색
═══════════════════════════════════════════════════════════════
필수 의존성: chromadb, openai

사용 흐름:
  1. get_vector_store(db_id) 호출 시 인덱스 미빌드면 자동 빌드
  2. SchemaSelector.select() 에서 hybrid_search() 호출
  3. BM25 스코어 + 벡터 유사도 가중합으로 최종 테이블 선택

ChromaDB 격리:
  - Chroma 내부 SQLite 접근을 별도 subprocess에서 수행하여 메모리 충돌 방지
  - _ChromaWorker: main process의 프록시 클래스
  - _chroma_worker_loop: child process에서 실행되는 Chroma 루프
"""
from __future__ import annotations
import logging
import json
import multiprocessing
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional

from ..config.metadata_utils import payload_fingerprint
from ..config.settings import get_settings
from ..llm.client import build_azure_openai_client, build_openai_compatible_client

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Embedding 함수 — Provider-agnostic
# ═══════════════════════════════════════════════════════════════
class Embedder:
    """Provider-agnostic Embeddings 클라이언트.

    지원 provider:
      - azure_openai: AzureOpenAI 클라이언트
      - openai_compatible: OpenAI(base_url=...) 클라이언트
    """

    def __init__(self):
        cfg = get_settings().embed

        if cfg.provider == "azure_openai":
            if not cfg.endpoint or not cfg.azure_api_key:
                raise RuntimeError(
                    "Embedding 설정 누락 (azure_openai: SKCC_AZURE_ENDPOINT/KEY, "
                    "openai_compatible: T2SQL_EMBED_BASE_URL/API_KEY 확인)")
            self._client = build_azure_openai_client(
                azure_endpoint=cfg.endpoint,
                api_key=cfg.azure_api_key,
                api_version=cfg.api_version,
            )
            self._model = cfg.deployment
        else:
            if not cfg.base_url or not cfg.api_key:
                raise RuntimeError(
                    "OpenAI-compatible Embedding 설정 누락 "
                    "(T2SQL_EMBED_BASE_URL, T2SQL_EMBED_API_KEY 확인)")
            self._client = build_openai_compatible_client(
                base_url=cfg.base_url,
                api_key=cfg.api_key,
            )
            self._model = cfg.model

        self._cache: Dict[str, List[float]] = {}

    def embed(self, texts: List[str]) -> List[List[float]]:
        """텍스트 리스트 → 임베딩 벡터 리스트"""
        resp = self._client.embeddings.create(input=texts, model=self._model)
        results = [d.embedding for d in resp.data]
        for text, vec in zip(texts, results):
            self._cache[text] = vec
        return results

    def embed_one(self, text: str) -> List[float]:
        """단일 텍스트 임베딩 (캐시 활용)"""
        if text in self._cache:
            return self._cache[text]
        result = self.embed([text])[0]
        return result


# ═══════════════════════════════════════════════════════════════
# Chroma 벡터 스토어
# ═══════════════════════════════════════════════════════════════
_STORE_DIR = Path(__file__).resolve().parents[3] / "data" / "vector_store"
_MANIFEST_PATH = _STORE_DIR / "manifest.json"


# ── ChromaDB 워커 프로세스 (child process에서 실행) ────────────
# 주의: _handle_chroma_op, _chroma_worker_loop 는 spawn 컨텍스트에서
#       pickle 가능해야 하므로 반드시 module-level 함수로 정의한다.

def _handle_chroma_op(client: Any, op: str, task: Dict[str, Any]) -> Dict[str, Any]:
    """
    Chroma 연산 처리 — child process 내부에서 호출.
    client 는 이미 초기화된 chromadb.PersistentClient.
    """
    if op == "get_or_create_collection":
        client.get_or_create_collection(
            name=task["name"],
            metadata=task.get("metadata"),
        )
        return {"ok": True}
    if op == "create_collection":
        client.create_collection(
            name=task["name"],
            metadata=task.get("metadata"),
        )
        return {"ok": True}
    if op == "delete_collection":
        try:
            client.delete_collection(task["name"])
        except Exception:
            pass
        return {"ok": True}
    if op == "add":
        col = client.get_collection(task["name"])
        col.add(
            ids=task["ids"],
            documents=task.get("documents"),
            embeddings=task.get("embeddings"),
            metadatas=task.get("metadatas"),
        )
        return {"ok": True}
    if op == "count":
        try:
            col = client.get_collection(task["name"])
            return {"count": col.count()}
        except Exception:
            return {"count": 0}
    if op == "query":
        col = client.get_collection(task["name"])
        result = col.query(
            query_embeddings=task["query_embeddings"],
            n_results=task["n_results"],
            include=task.get("include", ["documents", "metadatas", "distances"]),
        )
        return {"result": result}
    if op == "stop":
        return {"stop": True}
    raise ValueError(f"알 수 없는 Chroma 연산: {op}")


def _chroma_worker_loop(req_queue: Any, res_queue: Any, persist_dir: str) -> None:
    """
    Chroma 워커 루프 — child process에서 실행.
    PersistentClient 를 한 번만 초기화하고 큐를 통해 연산을 처리한다.
    """
    import chromadb
    from chromadb.config import Settings as ChromaSettings

    try:
        client = chromadb.PersistentClient(
            path=persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        res_queue.put({"ready": True})
    except Exception as e:
        res_queue.put({"ready": False, "error": str(e)})
        return

    while True:
        try:
            msg = req_queue.get()
            op = msg.get("op", "")
            task = msg.get("task", {})
            result = _handle_chroma_op(client, op, task)
            res_queue.put({"ok": True, "data": result})
            if result.get("stop"):
                break
        except Exception as e:
            res_queue.put({"ok": False, "error": str(e)})


# ── ChromaDB 프로세스 프록시 (main process) ───────────────────

class _ChromaWorker:
    """
    ChromaDB 를 별도 subprocess에서 실행하는 프록시.

    - Chroma 내부 SQLite I/O를 child process에서 격리 → 메모리 충돌 방지
    - 프로세스가 죽으면 자동 재시작
    - 동일 persist_dir에 대해 하나의 인스턴스만 생성 (_get_chroma_worker 로 관리)
    """
    _TIMEOUT = 120  # seconds

    def __init__(self, persist_dir: str):
        self._persist_dir = persist_dir
        self._req_queue: Any = None
        self._res_queue: Any = None
        self._process: Optional[multiprocessing.Process] = None
        self._lock = threading.Lock()
        self._start()

    def _start(self) -> None:
        """child process 시작 및 초기화 완료 대기"""
        ctx = multiprocessing.get_context("spawn")
        self._req_queue = ctx.Queue()
        self._res_queue = ctx.Queue()
        self._process = ctx.Process(
            target=_chroma_worker_loop,
            args=(self._req_queue, self._res_queue, self._persist_dir),
            daemon=True,
        )
        self._process.start()
        msg = self._res_queue.get(timeout=self._TIMEOUT)
        if not msg.get("ready"):
            raise RuntimeError(f"ChromaDB 워커 초기화 실패: {msg.get('error')}")
        logger.debug(f"ChromaDB 워커 시작: {self._persist_dir}")

    def _ensure_alive(self) -> None:
        """프로세스가 종료되었으면 재시작"""
        if self._process is None or not self._process.is_alive():
            logger.warning("ChromaDB 워커 재시작")
            self._start()

    def _call(self, op: str, **task: Any) -> Dict[str, Any]:
        """child process에 연산 요청 후 결과 반환"""
        with self._lock:
            self._ensure_alive()
            self._req_queue.put({"op": op, "task": task})
            msg = self._res_queue.get(timeout=self._TIMEOUT)
            if not msg.get("ok"):
                raise RuntimeError(f"ChromaDB 오류 [{op}]: {msg.get('error')}")
            return msg.get("data", {})

    def get_or_create_collection(self, name: str,
                                 metadata: Optional[Dict[str, Any]] = None) -> None:
        self._call("get_or_create_collection", name=name, metadata=metadata)

    def create_collection(self, name: str,
                          metadata: Optional[Dict[str, Any]] = None) -> None:
        self._call("create_collection", name=name, metadata=metadata)

    def delete_collection(self, name: str) -> None:
        self._call("delete_collection", name=name)

    def add(self, collection_name: str, ids: List[str],
            documents: List[str], embeddings: List[List[float]],
            metadatas: List[Dict[str, Any]]) -> None:
        self._call("add", name=collection_name, ids=ids,
                   documents=documents, embeddings=embeddings,
                   metadatas=metadatas)

    def count(self, collection_name: str) -> int:
        result = self._call("count", name=collection_name)
        return int(result.get("count", 0))

    def query(self, collection_name: str, query_embeddings: List[List[float]],
              n_results: int, include: List[str]) -> Dict[str, Any]:
        result = self._call("query", name=collection_name,
                            query_embeddings=query_embeddings,
                            n_results=n_results, include=include)
        return result.get("result", {})

    def stop(self) -> None:
        """워커 프로세스 정상 종료"""
        try:
            if self._process and self._process.is_alive():
                self._req_queue.put({"op": "stop", "task": {}})
                self._process.join(timeout=5)
                if self._process.is_alive():
                    self._process.terminate()
        except Exception:
            pass


# ── 경로별 _ChromaWorker 싱글톤 ──────────────────────────────

_chroma_workers: Dict[str, _ChromaWorker] = {}
_worker_lock = threading.Lock()


def _get_chroma_worker(persist_dir: str) -> _ChromaWorker:
    """같은 persist_dir에 대해 _ChromaWorker를 단 하나만 생성한다."""
    with _worker_lock:
        if persist_dir not in _chroma_workers:
            _chroma_workers[persist_dir] = _ChromaWorker(persist_dir)
        return _chroma_workers[persist_dir]


class SchemaVectorStore:
    """
    DB 스키마를 벡터화하여 Chroma에 저장·검색하는 클래스.

    컬렉션명: schema_{db_id}
    문서: 테이블별 텍스트 (테이블명 + 컬럼 + FK + 샘플)
    메타데이터: table_name, column_count, has_fk

    ChromaDB 연산은 _ChromaWorker를 통해 별도 프로세스에서 실행된다.
    """

    def __init__(self, db_id: str, persist_dir: Path | str | None = None):
        self._db_id = db_id
        self._persist_dir = str(persist_dir or _STORE_DIR)
        self._collection_name = f"schema_{db_id}"
        # ChromaDB는 별도 프로세스에서 실행 (메모리 충돌 방지)
        self._worker = _get_chroma_worker(self._persist_dir)
        self._worker.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder: Optional[Embedder] = None
        # 인덱스 크기 캐시 — search() 호출마다 count() IPC를 발생시키지 않기 위해
        self._indexed_count: int = -1  # -1: 미확인

    @property
    def embedder(self) -> Embedder:
        if self._embedder is None:
            self._embedder = Embedder()
        return self._embedder

    # ── 인덱스 빌드 ───────────────────────────────────────
    def build_index(self, schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None):
        """
        스키마 정보로 벡터 인덱스 빌드 (기존 인덱스 덮어쓰기).

        Args:
            schema: SchemaReader.full_schema() 결과
            meta: schema_metadata 딕셔너리 (설명, 샘플값 등)
        """
        self._worker.delete_collection(self._collection_name)
        self._worker.create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )

        tables_meta = (meta or {}).get("tables", {})
        ids, docs, metadatas = [], [], []

        for tbl in schema:
            tname = tbl["table_name"]
            doc = self._table_to_text(tbl, tables_meta.get(tname, {}))
            ids.append(tname)
            docs.append(doc)
            metadatas.append({
                "table_name": tname,
                "column_count": len(tbl.get("columns", [])),
                "has_fk": int(len(tbl.get("foreign_keys", [])) > 0),
            })

        embeddings = self.embedder.embed(docs)
        self._worker.add(
            collection_name=self._collection_name,
            ids=ids,
            documents=docs,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        self._indexed_count = len(schema)
        logger.info(f"[{self._db_id}] 벡터 인덱스 빌드 완료: {len(schema)}개 테이블")

    # ── 검색 ──────────────────────────────────────────────
    def search(self, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        질문과 유사한 테이블 검색.

        Returns:
            [{"table_name": str, "score": float, "document": str}, ...]
            score: cosine similarity (0~1, 높을수록 유사)
        """
        # _indexed_count 캐시 사용 — count() IPC를 search() 호출마다 발생시키지 않는다.
        # is_indexed() 또는 build_index() 호출 시 갱신됨.
        n_results = min(top_k, self._indexed_count) if self._indexed_count > 0 else top_k
        query_embedding = self.embedder.embed_one(question)
        try:
            results = self._worker.query(
                collection_name=self._collection_name,
                query_embeddings=[query_embedding],
                n_results=n_results,
                include=["documents", "metadatas", "distances"],
            )
        except Exception as e:
            logger.debug("[%s] 벡터 검색 실패: %s", self._db_id, e)
            return []

        ids = (results.get("ids") or [[]])[0]
        if not ids:
            return []

        hits = []
        for i, doc_id in enumerate(ids):
            # Chroma cosine distance → similarity
            distance = results["distances"][0][i]
            similarity = 1.0 - distance
            hits.append({
                "table_name": doc_id,
                "score": similarity,
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
            })
        return hits

    def is_indexed(self) -> bool:
        """인덱스가 빌드되었는지 확인"""
        if self._indexed_count > 0:
            return True
        count = self._worker.count(self._collection_name)
        self._indexed_count = count
        return count > 0

    # ── 내부 ──────────────────────────────────────────────
    @staticmethod
    def _table_to_text(tbl: Dict[str, Any],
                       tmeta: Dict[str, Any] | None = None) -> str:
        """테이블 정보를 검색용 텍스트로 변환"""
        tmeta = tmeta or {}
        parts = [f"테이블: {tbl['table_name']}"]
        aliases = tbl.get("table_aliases") or tmeta.get("aliases") or tmeta.get("table_aliases") or []
        if aliases:
            parts.append("별칭: " + ", ".join(str(a) for a in aliases[:8]))

        desc = tmeta.get("description", "")
        if desc:
            parts.append(f"설명: {desc}")

        col_meta = tmeta.get("columns", {})
        col_parts = []
        for c in tbl.get("columns", []):
            cname = c["name"] if isinstance(c, dict) else str(c)
            ctype = c.get("type", "") if isinstance(c, dict) else ""
            cdesc = ""
            if isinstance(col_meta, dict):
                cm = col_meta.get(cname, {})
                cdesc = cm.get("description", "") if isinstance(cm, dict) else str(cm) if cm else ""
            col_str = f"{cname} ({ctype})"
            if cdesc:
                col_str += f" - {cdesc}"
            col_parts.append(col_str)
        parts.append("컬럼: " + ", ".join(col_parts))

        fk_parts = []
        for fk in tbl.get("foreign_keys", []):
            fk_parts.append(f"{fk['from']} → {fk['to_table']}.{fk['to_column']}")
        if fk_parts:
            parts.append("관계: " + ", ".join(fk_parts))

        # 컬럼 예시: sample_values 우선, 없으면 sample_rows에서 추출
        sample_text = tbl.get("sample_text") or tmeta.get("sample_text") or ""
        if sample_text:
            parts.append(f"예시: {sample_text}")
        else:
            sample_rows = tbl.get("sample_rows") or []
            rendered = []
            for c in tbl.get("columns", []):
                if not isinstance(c, dict):
                    continue
                cname = c["name"]
                col_sv = c.get("sample_values") or []
                if not col_sv and sample_rows:
                    # sample_rows에서 NULL 제외한 값 추출
                    col_sv = [
                        str(row[cname])
                        for row in sample_rows
                        if row.get(cname) is not None
                    ][:3]
                if col_sv:
                    rendered.append(f"{cname}={', '.join(str(v) for v in col_sv[:3])}")
            if rendered:
                parts.append("예시: " + "; ".join(rendered[:8]))

        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════
# 자동 인덱스 빌드
# ═══════════════════════════════════════════════════════════════
def _load_schema_and_meta(db_id: str) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    인덱스 구축/검증에 필요한 schema + metadata 로드.

    schema_metadata JSON이 있으면 JSON을 정본(source of truth)으로 사용한다.
    JSON이 없을 때만 Oracle DB에서 직접 조회하며, 경고 로그를 남긴다.
    (DB 직접 조회는 초기 prepare 단계에서만 실행되어야 한다.)
    """
    from ..tools.executor import SchemaReader
    from ..config.settings import get_settings

    settings = get_settings()
    meta = settings.schema_metadata(db_id)

    if meta.get("tables"):
        # JSON-first: schema_metadata를 정본으로 사용
        schema = SchemaReader.from_meta(meta)
        logger.info(
            "[%s] vector index: schema_metadata JSON 기준 로드 — %d개 테이블",
            db_id, len(schema),
        )
    else:
        # fallback: JSON 없음 → Oracle DB 직접 조회 (prepare 먼저 실행 권장)
        logger.warning(
            "[%s] vector index: schema_metadata JSON 없음 — Oracle DB 직접 조회 "
            "(prepare 먼저 실행하세요: python scripts/operations/run_ops.py prepare --db-id %s)",
            db_id, db_id,
        )
        schema = SchemaReader.full_schema("__oracle__")
        logger.info(
            "[%s] vector index: Oracle DB에서 %d개 테이블 로드",
            db_id, len(schema),
        )

    return schema, meta


def _schema_fingerprint(schema: List[Dict[str, Any]], meta: Dict[str, Any]) -> str:
    payload = meta if meta.get("tables") else {"schema": schema}
    return payload_fingerprint(payload)


def _load_manifest() -> Dict[str, Any]:
    if not _MANIFEST_PATH.exists():
        return {}
    try:
        return json.loads(_MANIFEST_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_manifest(manifest: Dict[str, Any]) -> None:
    _MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _ensure_index(store: SchemaVectorStore, db_id: str, *, force: bool = False) -> None:
    schema, meta = _load_schema_and_meta(db_id)
    fingerprint = _schema_fingerprint(schema, meta)
    manifest = _load_manifest()
    current = manifest.get(db_id, {})
    has_index = store.is_indexed()
    known_fingerprint = current.get("fingerprint")
    is_stale = known_fingerprint not in (None, fingerprint)

    if has_index and known_fingerprint is None and not force:
        manifest[db_id] = {
            "fingerprint": fingerprint,
            "table_count": len(schema),
        }
        _save_manifest(manifest)
        return

    if force or not has_index or is_stale:
        reason = "force rebuild" if force else "stale metadata" if is_stale else "missing index"
        logger.debug(f"[{db_id}] 벡터 인덱스 재구축 시작 ({reason})")
        store.build_index(schema, meta)
        manifest[db_id] = {
            "fingerprint": fingerprint,
            "table_count": len(schema),
        }
        _save_manifest(manifest)


# ═══════════════════════════════════════════════════════════════
# 유틸리티
# ═══════════════════════════════════════════════════════════════
_stores: Dict[str, SchemaVectorStore] = {}
_failed_dbs: set = set()
_store_lock = threading.Lock()


def get_vector_store(db_id: str) -> SchemaVectorStore:
    """벡터 스토어 싱글톤 — 인덱스 미빌드/오래된 경우 자동 재구축.

    멀티스레드 환경(Streamlit 등)에서 동시 호출 시 중복 build_index·Chroma 동시 쓰기 방지.
    """
    # 빠른 경로: 이미 캐시된 경우 lock 없이 반환
    if db_id in _failed_dbs:
        raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")
    if db_id in _stores:
        return _stores[db_id]

    with _store_lock:
        # lock 획득 후 재확인 (double-checked locking)
        if db_id in _failed_dbs:
            raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")
        if db_id in _stores:
            return _stores[db_id]
        try:
            store = SchemaVectorStore(db_id)
            _ensure_index(store, db_id)
            _stores[db_id] = store
        except Exception as e:
            _failed_dbs.add(db_id)
            logger.debug(f"[{db_id}] 벡터 스토어 초기화 실패 (BM25로 대체): {e}")
            raise

    return _stores[db_id]


def rebuild_vector_store(db_id: str) -> SchemaVectorStore:
    """최신 metadata/schema 기준으로 벡터 인덱스를 강제 재구축."""
    with _store_lock:
        store = _stores.get(db_id) or SchemaVectorStore(db_id)
        _stores[db_id] = store
        _failed_dbs.discard(db_id)
        _ensure_index(store, db_id, force=True)
    return store
