"""Diagnostic tools for database and environment checks."""
from __future__ import annotations

from typing import Any, Dict

from text2sql.config.settings import Settings
from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter


def check_oracle_connection(settings: Settings) -> Dict[str, Any]:
    """Check Oracle connectivity and basic metadata access.

    Returns:
        dict: Diagnostic results including 'ok' status and 'message'.
    """
    db_cfg = settings.db
    results = {
        "ok": True,
        "message": "",
        "host": db_cfg.host,
        "port": db_cfg.port,
        "service": db_cfg.service_name,
        "user": db_cfg.user,
        "schema": db_cfg.schema or "(user default)",
        "tables": [],
    }

    if db_cfg.dialect != "oracle":
        results["ok"] = False
        results["message"] = f"Current dialect is {db_cfg.dialect}, not oracle."
        return results

    try:
        adapter = OracleAdapter(
            host=db_cfg.host,
            port=db_cfg.port,
            service_name=db_cfg.service_name,
            dsn=db_cfg.dsn,
            user=db_cfg.user,
            password=db_cfg.password,
            schema=db_cfg.schema,
            connect_timeout_sec=db_cfg.connect_timeout_sec,
        )
    except Exception as exc:
        results["ok"] = False
        results["message"] = f"Failed to create Oracle adapter: {exc}"
        return results

    info = adapter.test_connection()
    if not info["ok"]:
        results["ok"] = False
        results["message"] = info["message"]
        return results

    results["message"] = info["message"]
    results["effective_user"] = info.get("user")
    results["effective_schema"] = info.get("schema")

    try:
        tables = adapter.list_tables()
        results["tables"] = tables
    except Exception as exc:
        results["message"] += f" (But failed to list tables: {exc})"

    return results
