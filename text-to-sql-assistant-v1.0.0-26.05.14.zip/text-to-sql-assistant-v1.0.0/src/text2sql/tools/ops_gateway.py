"""Unified operator command builders for public-facing ops workflows."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SCRIPTS_DIR = ROOT / "scripts"

# 폴더 재구조화(2026-05) 후 스크립트별 하위 카테고리 매핑.
# scripts/ 직속 파일이 카테고리 폴더로 이동되었기 때문에 한 곳에서 매핑.
SCRIPT_CATEGORIES: dict[str, str] = {
    "run_cli.py": "execution",
    "init.py": "execution",
    "run_ops.py": "operations",
    "oracle_ops.py": "operations",
    "check_oracle_connection.py": "diagnostics",
    "check_domain_hints.py": "diagnostics",
    "health_check.py": "diagnostics",
    "export_oracle_metadata.py": "metadata",
    "enrich_metadata_from_sql.py": "metadata",
    "setup_oracle_mfg_demo.py": "setup",
    "run_e2e_suite.py": "testing",
    "oracle_release_gate.py": "testing",
    "validate_query_catalog.py": "testing",
}


def _script_path(script_name: str) -> Path:
    """스크립트 이름 → 실제 경로 (카테고리 폴더 포함)."""
    category = SCRIPT_CATEGORIES.get(script_name, "")
    return (SCRIPTS_DIR / category / script_name) if category else (SCRIPTS_DIR / script_name)


def _script_command(script_name: str, *args: str) -> list[str]:
    return [sys.executable, str(_script_path(script_name)), *[str(arg) for arg in args if str(arg)]]


def build_doctor_command() -> list[str]:
    return _script_command("check_oracle_connection.py")


def build_cli_command(
    *,
    db_id: str = "",
    question: str = "",
    max_retries: int | None = None,
    hitl: bool = False,
) -> list[str]:
    command = _script_command("run_cli.py")
    if db_id:
        command.extend(["--db", db_id])
    if question:
        command.extend(["-q", question])
    if max_retries is not None:
        command.extend(["--max-retries", str(max_retries)])
    if hitl:
        command.append("--hitl")
    return command


def build_demo_command(
    *,
    admin_user: str = "",
    admin_password: str = "",
    service_name: str = "",
    host: str = "",
    port: int | None = None,
    schema_user: str = "",
    schema_password: str = "",
    drop_existing: bool = False,
    schema_only: bool = False,
) -> list[str]:
    command = _script_command("setup_oracle_mfg_demo.py")
    if admin_user:
        command.extend(["--admin-user", admin_user])
    if admin_password:
        command.extend(["--admin-password", admin_password])
    if service_name:
        command.extend(["--service-name", service_name])
    if host:
        command.extend(["--host", host])
    if port:
        command.extend(["--port", str(port)])
    if schema_user:
        command.extend(["--schema-user", schema_user])
    if schema_password:
        command.extend(["--schema-password", schema_password])
    if drop_existing:
        command.append("--drop-existing")
    if schema_only:
        command.append("--schema-only")
    return command


def build_prepare_commands(
    *,
    db_id: str = "",
    catalog: str = "",
    include: str = "",
    exclude: str = "",
    samples: int | None = None,
) -> list[tuple[str, list[str]]]:
    export_cmd = _script_command("export_oracle_metadata.py")
    if db_id:
        export_cmd.extend(["--db-id", db_id])
    if include:
        export_cmd.extend(["--include", include])
    if exclude:
        export_cmd.extend(["--exclude", exclude])
    if samples is not None:
        export_cmd.extend(["--samples", str(samples)])

    steps = [("metadata export", export_cmd)]
    if catalog:
        steps.append(
            (
                "catalog validate",
                _script_command("validate_query_catalog.py", "--catalog", catalog),
            )
        )
        enrich_cmd = _script_command("enrich_metadata_from_sql.py")
        if db_id:
            enrich_cmd.extend(["--db-id", db_id])
        enrich_cmd.extend(["--catalog", catalog])
        steps.append(("metadata enrich", enrich_cmd))
    return steps


def build_e2e_command(
    *,
    db_id: str = "",
    catalog: str,
    max_retries: int | None = None,
    report: str = "",
    limit: int | None = None,
    probe_timeout_sec: int | None = None,
    skip_llm_check: bool = False,
    record_feedback: bool = False,
    learn: bool = False,
    domain: str = "",
    tag: str = "",
    max_items: int | None = None,
) -> list[str]:
    command = _script_command("run_e2e_suite.py", "--catalog", catalog)
    if db_id:
        command.extend(["--db-id", db_id])
    if max_retries is not None:
        command.extend(["--max-retries", str(max_retries)])
    if report:
        command.extend(["--report", report])
    if limit is not None:
        command.extend(["--limit", str(limit)])
    if probe_timeout_sec is not None:
        command.extend(["--probe-timeout-sec", str(probe_timeout_sec)])
    if skip_llm_check:
        command.append("--skip-llm-check")
    if record_feedback:
        command.append("--record-feedback")
    if learn:
        command.append("--learn")
    if domain:
        command.extend(["--domain", domain])
    if tag:
        command.extend(["--tag", tag])
    if max_items is not None:
        command.extend(["--max-items", str(max_items)])
    return command


def build_release_command(
    *,
    db_id: str = "",
    catalog: str = "",
    e2e_report: str = "",
    report: str = "",
    max_retries: int | None = None,
    run_e2e: bool = True,
    run_pytest: bool = True,
    run_vulture: bool = True,
    allow_system_schema: bool = False,
) -> list[str]:
    command = _script_command("oracle_release_gate.py")
    if db_id:
        command.extend(["--db-id", db_id])
    if catalog:
        command.extend(["--catalog", catalog])
    if e2e_report:
        command.extend(["--e2e-report", e2e_report])
    if report:
        command.extend(["--report", report])
    if max_retries is not None:
        command.extend(["--max-retries", str(max_retries)])
    if run_e2e:
        command.append("--run-e2e")
    if run_pytest:
        command.append("--run-pytest")
    if run_vulture:
        command.append("--run-vulture")
    if allow_system_schema:
        command.append("--allow-system-schema")
    return command


def build_maintain_command(
    *,
    db_id: str = "",
    cycles: int | None = None,
    samples: int | None = None,
    report: str = "",
    sql_catalog: str = "",
    sql_glob: str = "",
    no_enrich: bool = False,
    no_metadata: bool = False,
    no_vector: bool = False,
    no_learn: bool = False,
    no_eval: bool = False,
    fail_under_score: int | None = None,
) -> list[str]:
    command = _script_command("oracle_ops.py")
    if cycles is not None:
        command.extend(["--cycles", str(cycles)])
    if samples is not None:
        command.extend(["--samples", str(samples)])
    if db_id:
        command.extend(["--db-id", db_id])
    if report:
        command.extend(["--report", report])
    if sql_catalog:
        command.extend(["--sql-catalog", sql_catalog])
    if sql_glob:
        command.extend(["--sql-glob", sql_glob])
    if no_enrich:
        command.append("--no-enrich")
    if no_metadata:
        command.append("--no-metadata")
    if no_vector:
        command.append("--no-vector")
    if no_learn:
        command.append("--no-learn")
    if no_eval:
        command.append("--no-eval")
    if fail_under_score is not None:
        command.extend(["--fail-under-score", str(fail_under_score)])
    return command


def build_check_hints_command(
    *,
    db_id: str,
    question: str = "",
    show_all: bool = False,
) -> list[str]:
    command = _script_command("check_domain_hints.py", "--db-id", db_id)
    if question:
        command.extend(["--question", question])
    if show_all:
        command.append("--show-all")
    return command


def build_daily_commands(*, db_id: str = "", catalog: str = "") -> list[tuple[str, list[str]]]:
    maintain_command = build_maintain_command(db_id=db_id, cycles=1, sql_catalog=catalog)
    return [
        ("doctor", build_doctor_command()),
        ("daily maintain", maintain_command),
    ]


def build_first_run_commands(
    *,
    db_id: str = "",
    catalog: str = "",
    include: str = "",
    exclude: str = "",
    samples: int | None = None,
    smoke_question: str = "",
    hitl: bool = False,
    max_retries: int | None = None,
    run_e2e: bool = False,
    e2e_report: str = "",
    limit: int | None = None,
    max_items: int | None = None,
) -> list[tuple[str, list[str]]]:
    steps: list[tuple[str, list[str]]] = [("doctor", build_doctor_command())]
    steps.extend(
        build_prepare_commands(
            db_id=db_id,
            catalog=catalog,
            include=include,
            exclude=exclude,
            samples=samples,
        )
    )
    if smoke_question:
        steps.append(
            (
                "cli smoke",
                build_cli_command(
                    db_id=db_id,
                    question=smoke_question,
                    max_retries=max_retries,
                    hitl=hitl,
                ),
            )
        )
    if run_e2e:
        steps.append(
            (
                "e2e",
                build_e2e_command(
                    db_id=db_id,
                    catalog=catalog,
                    max_retries=max_retries,
                    report=e2e_report,
                    limit=limit,
                    max_items=max_items,
                ),
            )
        )
    return steps
