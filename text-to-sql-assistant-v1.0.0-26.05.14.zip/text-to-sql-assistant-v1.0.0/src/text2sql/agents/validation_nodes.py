"""Validation nodes for guardrails, static review, preview execution, and judging."""
from __future__ import annotations
import json
import re
import time as _time
from ..lg.state import GraphState, SQLCandidate, ErrorType, ExecReport
from ..llm.client import get_llm_fast
from ..llm import prompts as P
from ..tools.executor import SQLExecutor
from ..tools.guardrails import SQLGuard
from ..config.settings import get_settings
from ._utils import trace, get_llm_for_node
from .guardrail_rules import _DEFAULT_RULES


# ═══════════════════════════════════════════════════════════════
# 7. Guardrails (Safety Gate)
# ═══════════════════════════════════════════════════════════════
def node_guardrails(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "Guardrails", "SQL 안전성 검증 시작")

    all_tables = [t["table_name"] for t in state.get("full_schema", [])]
    guard = SQLGuard(known_tables=all_tables or state.get("selected_tables"))
    candidates = state.get("candidates", [])
    passed_any = False

    _guard_dialect = state.get("dialect") or get_settings().db.dialect

    for c in candidates:
        vr = guard.validate(c.sql, dialect=_guard_dialect)
        c.is_valid = vr.valid
        c.validation_errors = vr.issues

        if c.is_valid:
            for rule in _DEFAULT_RULES:
                result = rule.check(state.get("question", ""), c.sql, state)
                if result.violated:
                    c.is_valid = False
                    c.validation_errors = list(c.validation_errors) + [result.message]
                    break

        if c.is_valid:
            c.sql = vr.sql  # LIMIT 추가된 SQL
            passed_any = True
            trace(state, "Guardrails", f"[{c.strategy}] ✅ 통과")
        else:
            trace(state, "Guardrails",
                  f"[{c.strategy}] ❌ 차단: {c.validation_errors}",
                  {"issues": c.validation_errors})

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "Guardrails",
          f"검증 완료 ({'통과' if passed_any else '차단'})",
          {"elapsed_ms": _elapsed})

    result = {**state, "candidates": candidates, "guard_passed": passed_any}

    if not passed_any:
        all_issues = []
        for c in candidates:
            if c.validation_errors:
                all_issues.extend(c.validation_errors)
        error_msg = "; ".join(all_issues) if all_issues else "SQL 안전성 검증 실패"

        _semantic_keywords = (
            "현재 날짜 기반 필터",
            "PERCENT_RANK",
            "그룹 라벨 컬럼",
            "현재 연도 - 1",
            "STRFTIME('%Y') 값은 CAST",
            "zero-sales 엔티티",
        )
        is_all_semantic = bool(all_issues) and all(
            any(kw in issue for kw in _semantic_keywords) for issue in all_issues
        )
        result["last_error_type"] = ErrorType.SEMANTIC if is_all_semantic else ErrorType.SAFETY
        result["last_error_msg"] = error_msg

    return result


# ═══════════════════════════════════════════════════════════════
# 8. SQLUnitTester (UT) – query_pattern 전달
# ═══════════════════════════════════════════════════════════════
def node_unit_tester(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "SQLUnitTester", "SQL 정적 검증 시작")

    llm = get_llm_fast()
    candidates = [c for c in state.get("candidates", []) if c.is_valid]
    passed_any = False

    query_pattern = state.get("query_pattern", "simple")

    for c in candidates:
        prompt = P.UT_USR.format(
            sql=c.sql,
            question=state["question"],
            intent=state.get("intent", ""),
            query_pattern=query_pattern,
            schema_text=state["schema_text"],
        )
        try:
            res = llm.generate_json(prompt, system=P.UT_SYS,
                                    node_name="UnitTester")
            severity = res.get("severity", "")
            issues = res.get("issues", [])

            if severity in ("blocker",):
                c.ut_passed = False
                c.ut_detail = f"[{severity}] {res.get('reasoning', '')}"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ❌ blocker: {issues}",
                      {"severity": severity, "issues": issues,
                       "reasoning": c.ut_detail})
            elif severity in ("high", "medium", "low"):
                c.ut_passed = True
                c.ut_detail = f"[{severity}] {res.get('reasoning', '')}"
                passed_any = True
                _icon = "⚠️" if severity == "high" else "✅"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] {_icon} {severity}",
                      {"severity": severity, "issues": issues,
                       "reasoning": c.ut_detail})
            else:
                c.ut_passed = res.get("passed", False)
                c.ut_detail = res.get("reasoning", "")
                if c.ut_passed:
                    passed_any = True
                _icon = "✅" if c.ut_passed else "❌"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] {_icon} {'통과' if c.ut_passed else '실패'}",
                      {"issues": issues, "reasoning": c.ut_detail})
        except Exception as e:
            try:
                res = llm.generate_json(prompt, system=P.UT_SYS,
                                        node_name="UnitTester")
                severity = res.get("severity", "")
                if severity in ("blocker",):
                    c.ut_passed = False
                elif severity:
                    c.ut_passed = True
                else:
                    c.ut_passed = res.get("passed", False)
                c.ut_detail = f"[{severity or 'retry'}] {res.get('reasoning', '')}"
                if c.ut_passed:
                    passed_any = True
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ⚠️ 재시도 → {'통과' if c.ut_passed else '실패'}",
                      {"severity": severity, "reasoning": c.ut_detail})
            except Exception as e2:
                c.ut_passed = False
                c.ut_detail = f"LLM 검증 2회 실패: {e} / {e2}"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ❌ LLM 검증 실패(2회): {e2}")

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "SQLUnitTester",
          f"정적 검증 완료 ({'통과' if passed_any else '실패'})",
          {"elapsed_ms": _elapsed, "model": llm.model_label})

    result = {**state, "candidates": state.get("candidates", []),
              "ut_passed": passed_any}

    if not passed_any:
        failed_issues = []
        for c in candidates:
            if not c.ut_passed and c.ut_detail:
                failed_issues.append(c.ut_detail)
        error_msg = "; ".join(failed_issues) if failed_issues else "SQL 정적 검증 실패"
        result["last_error_type"] = ErrorType.SEMANTIC
        result["last_error_msg"] = error_msg

    return result


# ═══════════════════════════════════════════════════════════════
# 9. ExecutePreview (DB) — Self-Consistency Voting
# ═══════════════════════════════════════════════════════════════
def _result_fingerprint(rows) -> str:
    """Generate fingerprint for result comparison (order-independent)."""
    if not rows:
        return "EMPTY"
    try:
        tuples = [tuple(r.values()) for r in rows]
        tuples.sort()
        return str(tuples)
    except Exception:
        return str(rows)


def node_execute_preview(state: GraphState) -> GraphState:
    """Self-Consistency Voting: 모든 후보를 실행하고 다수결로 최선 선택."""
    _t0 = _time.time()

    passed = [c for c in state.get("candidates", [])
              if c.is_valid and c.ut_passed]

    if not passed:
        fallback = [c for c in state.get("candidates", []) if c.is_valid]
        if fallback:
            trace(state, "ExecutePreview",
                  "⚠️ UT 전체 블로커 — is_valid 후보로 fallback 실행")
            passed = fallback

    if not passed:
        trace(state, "ExecutePreview", "❌ 실행 가능한 SQL 없음")
        return {
            **state,
            "exec_report": ExecReport(ok=False, error_type=ErrorType.SAFETY,
                                      error_message="실행 가능한 SQL 후보 없음"),
            "preview_sql": "",
            "last_error_type": state.get("last_error_type") or ErrorType.SAFETY,
            "last_error_msg": state.get("last_error_msg") or "실행 가능한 SQL 후보 없음",
        }

    settings = get_settings()
    executor = SQLExecutor(preview_limit=settings.pipeline.preview_limit)

    exec_results = []
    first_failure = None

    for c in passed:
        trace(state, "ExecutePreview",
              f"[{c.strategy}] SQL 실행",
              {"sql": c.sql})
        r = executor.execute(state["db_path"], c.sql)
        if r.ok:
            fp = _result_fingerprint(r.rows_preview)
            exec_results.append((c, r, fp))
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] ✅ ({r.row_count}행)")
        else:
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] ❌ [{r.error_type}] {r.error_message}")
            if first_failure is None:
                first_failure = (c, r)

    if not exec_results:
        best = first_failure[0] if first_failure else passed[0]
        report = first_failure[1] if first_failure else ExecReport(
            ok=False, error_type=ErrorType.UNKNOWN,
            error_message="모든 후보 실행 실패")
        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "ExecutePreview",
              f"❌ 모든 후보 실행 실패",
              {"elapsed_ms": _elapsed})
        return {**state, "exec_report": report, "preview_sql": best.sql,
                "selected_sql": best.sql}

    if len(exec_results) > 1:
        from collections import Counter
        fp_counts = Counter(fp for _, _, fp in exec_results)
        majority_fp = fp_counts.most_common(1)[0][0]
        majority_count = fp_counts[majority_fp]

        majority_candidates = [(c, r) for c, r, fp in exec_results
                               if fp == majority_fp]
        majority_candidates.sort(key=lambda x: x[0].confidence, reverse=True)
        best, report = majority_candidates[0]

        trace(state, "ExecutePreview",
              f"🗳️ Voting: {len(exec_results)}개 후보 중 {majority_count}개 동일 결과 → [{best.strategy}] 선택",
              {"total_exec": len(exec_results),
               "majority_count": majority_count,
               "unique_results": len(fp_counts)})
    else:
        best, report, _ = exec_results[0]

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "ExecutePreview",
          f"✅ 실행 성공: [{best.strategy}] ({report.row_count}행, {report.exec_ms:.0f}ms)",
          {"elapsed_ms": _elapsed})

    return {**state, "exec_report": report, "preview_sql": best.sql,
            "selected_sql": best.sql}


# ═══════════════════════════════════════════════════════════════
# 10. Judge / Voter
# ═══════════════════════════════════════════════════════════════
def node_judge(state: GraphState) -> GraphState:
    _t0 = _time.time()
    report = state.get("exec_report")

    if not report or not report.ok:
        trace(state, "Judge", "실행 실패 → reject")
        return {**state, "judge_accepted": False,
                "judge_rationale": "SQL 실행 실패",
                "last_error_type": report.error_type if report else ErrorType.UNKNOWN,
                "last_error_msg": report.error_message if report else "실행 불가"}

    settings = get_settings()
    allow_empty = settings.pipeline.allow_empty_result

    if report.row_count == 0 and allow_empty:
        trace(state, "Judge",
              "ℹ️ 결과 0행이지만 ALLOW_EMPTY_RESULT=true → LLM 판단 위임")

    trace(state, "Judge", "결과 품질 판단 시작")

    llm = get_llm_for_node(state, prefer_primary=True)
    preview = json.dumps(report.rows_preview[:10], ensure_ascii=False, default=str) \
              if report.rows_preview else "[]"

    empty_policy_hint = ""
    if report.row_count == 0 and allow_empty:
        empty_policy_hint = (
            "\n\n[빈 결과 정책]\n"
            "결과가 0행이지만, SQL과 필터/시간 조건이 질문 의도에 부합하면 "
            "accepted=true로 판단하세요. 데이터 자체가 없는 것은 SQL 오류가 아닙니다."
        )

    prompt = P.JUDGE_USR.format(
        question=state["question"],
        intent=state.get("intent", ""),
        sql=state.get("selected_sql", ""),
        result_preview=preview[:3000],
        row_count=report.row_count,
        limit=min(10, report.row_count),
    ) + empty_policy_hint

    try:
        res = llm.generate_json(prompt, system=P.JUDGE_SYS,
                                    node_name="Judge")
        accepted = res.get("accepted", False)
        reasoning = res.get("reasoning", "")
        score = res.get("score", 0.0)
        issues = res.get("issues", [])

        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "Judge",
              f"{'✅ 승인' if accepted else '❌ 거부'} (score={score})",
              {"reasoning": reasoning,
               "issues": issues,
               "elapsed_ms": _elapsed,
               "model": llm.model_label})

        if not accepted:
            failure_cat = res.get("failure_category", "")
            enriched_msg = reasoning
            if failure_cat and failure_cat != "none":
                enriched_msg = f"[{failure_cat}] {reasoning}"
            return {
                **state,
                "judge_accepted": False,
                "judge_rationale": reasoning,
                "last_error_type": ErrorType.SEMANTIC,
                "last_error_msg": enriched_msg,
            }

        return {
            **state,
            "judge_accepted": True,
            "judge_rationale": reasoning,
        }
    except Exception as e:
        trace(state, "Judge", f"⚠️ 판단 오류(실행 성공이므로 승인): {e}")
        return {**state, "judge_accepted": True,
                "judge_rationale": "Judge 오류 – 실행 성공으로 자동 승인"}
