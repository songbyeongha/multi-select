"""Candidate generation node."""
from __future__ import annotations
import json
import os
import re
import time as _time
from typing import Dict, List, Tuple
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..lg.state import GraphState, SQLCandidate
from ..llm.client import get_llm, get_llm_fast
from ..llm import prompts as P
from ..memory.conversation import get_memory
from ._utils import trace, get_reference_sql
from ..config.settings import get_settings
from ..feedback.learner import get_learner
from ..tools.sql_postprocess import SQLPostProcessor

_HINTS_PATH = Path(__file__).resolve().parents[1] / "config" / "strategy_hints.json"

def _load_strategies() -> Dict[str, List[Tuple[str, str]]]:
    with open(_HINTS_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: [tuple(pair) for pair in v] for k, v in raw.items()}

_STRATEGIES = _load_strategies()


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[0-9a-z가-힣_]+", (text or "").lower()) if len(token) > 1}


def _select_few_shots(question: str, few_shots: List[Dict[str, str]], limit: int = 5) -> tuple[List[Dict[str, str]], Dict[str, str] | None, bool]:
    """상위 N개 few-shot + seed(최고점 1개) + exact match여부를 한 번에 반환."""
    if not few_shots:
        return [], None, False

    normalized = (question or "").strip().lower()
    if not normalized:
        return few_shots[:limit], None, False

    # 정확히 일치하는 질문 찾기
    for item in few_shots:
        if (item.get("question") or "").strip().lower() == normalized and item.get("sql"):
            return few_shots[:limit], item, True

    question_tokens = _tokenize(question)
    if not question_tokens:
        return few_shots[:limit], None, False

    def _score(item: Dict[str, str]) -> tuple[int, int, int]:
        tokens = _tokenize(item.get("question", ""))
        overlap = len(question_tokens & tokens)
        contains_exact_phrase = int(item.get("question", "") in question)
        contains_group_keyword = int(any(token in item.get("question", "") for token in ("별", "상위", "하위", "전년", "월별", "5분")))
        return (contains_exact_phrase, overlap, contains_group_keyword)

    ranked = sorted(few_shots, key=_score, reverse=True)

    # seed: 최고점 1개 (overlap >= 4)
    seed = None
    for item in ranked:
        item_tokens = _tokenize(item.get("question", ""))
        overlap = len(question_tokens & item_tokens)
        if overlap >= 4 and item.get("sql"):
            seed = item
            break

    return ranked[:limit], seed, False


def _append_ref(base: str, new: str) -> str:
    """reference SQL 누적."""
    if not new:
        return base
    return f"{base}\n\n{new}" if base != "없음" else new


# ═══════════════════════════════════════════════════════════════
# 5. CandidateGenerator ×N  (전략 분기)
# ═══════════════════════════════════════════════════════════════
def node_candidate_generator(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "CandidateGenerator", "SQL 후보 생성 시작")

    candidates: List[SQLCandidate] = []

    query_pattern = state.get("query_pattern", "simple")
    strategies = list(_STRATEGIES.get(query_pattern, _STRATEGIES["simple"]))

    if query_pattern != "set_operation":
        q_lower = state["question"].lower()
        _negation = (
            bool(re.search(r'\b(not|never|does not|did not|do not|have not|without)\b', q_lower))
            or any(kw in q_lower for kw in ['없는', '않는', '않은', '아닌', '제외', '빼고'])
        )
        _intersection = (
            bool(re.search(r'\b(both|and also)\b', q_lower))
            or any(kw in q_lower for kw in ['모두', '동시에', '이면서'])
        )
        if _negation:
            strategies.append(("except_bonus",
                "반드시 EXCEPT를 사용하세요. SELECT ... EXCEPT SELECT ... 형태로 작성. "
                "NOT IN/NOT EXISTS 사용 금지."))
        elif _intersection:
            strategies.append(("intersect_bonus",
                "반드시 INTERSECT를 사용하세요. SELECT ... INTERSECT SELECT ... 형태로 작성."))

    strategies = strategies[:get_settings().pipeline.num_candidates]

    reference_sql = get_reference_sql(state["database_id"], query_pattern)

    _domain = get_settings().domain_hints(state["database_id"])
    _few_shots = _domain.get("few_shot_examples", [])
    few_shot_text = ""
    seed = None
    if _few_shots:
        ranked, seed, exact_match = _select_few_shots(state["question"], _few_shots, limit=5)
        for fs in ranked:
            few_shot_text += f"-- Q: {fs['question']}\n{fs['sql']}\n\n"
        few_shot_text = few_shot_text.rstrip()

        if seed:
            candidates.append(
                SQLCandidate(
                    sql=seed["sql"],
                    strategy="few_shot_seed",
                    confidence=0.98,
                    rationale=f"Seeded from learned example: {seed['question']}",
                )
            )
            trace(state, "CandidateGenerator", "few-shot seed candidate injected",
                  {"question": seed["question"][:120]})
            if exact_match:
                _elapsed = round((_time.time() - _t0) * 1000)
                trace(state, "CandidateGenerator",
                      "exact few-shot match selected; skipping LLM generation",
                      {"elapsed_ms": _elapsed})
                return {**state, "candidates": candidates}

    memory = get_memory()
    similar = memory.find_similar(state["question"], db_id=state["database_id"], threshold=0.5)
    if similar:
        memory_ref = f"\n-- 이전 유사 질문의 성공 SQL 참고:\n-- Q: {similar.question}\n{similar.sql}"
        reference_sql = _append_ref(reference_sql, memory_ref)
        trace(state, "CandidateGenerator", f"메모리 유사 질문 발견: '{similar.question[:50]}...'")

    _use_fast = state.get("use_fast_only", False) or query_pattern == "simple"
    _current_dialect = state.get("dialect") or get_settings().db.dialect
    _dialect_guide = P.get_dialect_guide(_current_dialect)

    _feedback_hints = ""
    try:
        _fb_learner = get_learner()
        _neg_hint = _fb_learner.get_negative_hints(state["database_id"], state["question"])
        _pos_ref = _fb_learner.get_positive_references(state["database_id"], state["question"])
        if _pos_ref:
            reference_sql = _append_ref(reference_sql, _pos_ref)
            trace(state, "CandidateGenerator", "피드백 기반 성공 SQL 참고 주입")
        if _neg_hint:
            _feedback_hints = _neg_hint
            trace(state, "CandidateGenerator", "피드백 기반 오류 패턴 주의사항 주입")
    except Exception as e:
        trace(state, "Feedback", f"피드백 힌트 로드 실패: {e}")

    def _generate_one(strategy_name: str, hint: str) -> SQLCandidate | None:
        prompt = P.COMPOSER_USR.format(
            current_date=state.get("current_date", "2024-01-01"),
            current_year=state.get("current_year", 2024),
            current_month=state.get("current_month", 1),
            dialect_guide=_dialect_guide,
            question=state["question"],
            intent=state.get("intent", ""),
            strategy=f"{strategy_name}: {hint}",
            query_pattern=query_pattern,
            reference_sql=reference_sql,
            few_shot_sql=few_shot_text,
            sub_questions=json.dumps(state.get("sub_questions", []),
                                     ensure_ascii=False),
            schema_text=state["schema_text"],
            join_plan="\n".join(state.get("join_plan", [])),
            extracted_values=json.dumps(state.get("extracted_values", {}),
                                        ensure_ascii=False),
        )
        if _feedback_hints:
            prompt += _feedback_hints
        try:
            _llm = get_llm_fast() if _use_fast else get_llm()
            res = _llm.generate_json(prompt, system=P.COMPOSER_SYS,
                                       node_name="CandidateGenerator")
            sql = res.get("sql", "")
            if sql:
                return SQLCandidate(
                    sql=sql,
                    strategy=strategy_name,
                    confidence=res.get("confidence", 0.8),
                    rationale=res.get("reasoning", ""),
                )
        except Exception:
            pass
        return None

    max_workers = min(len(strategies), 2)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(_generate_one, name, hint): name for name, hint in strategies}
        for future in as_completed(futures):
            try:
                candidate = future.result()
                if candidate:
                    candidates.append(candidate)
            except Exception:
                pass

    for candidate in candidates:
        trace(state, "CandidateGenerator", f"[{candidate.strategy}] SQL 생성 완료",
              {"sql": candidate.sql[:300], "confidence": candidate.confidence})

    _elapsed = round((_time.time() - _t0) * 1000)
    _gen_model = (get_llm_fast() if _use_fast else get_llm()).model_label
    trace(state, "CandidateGenerator", f"후보 {len(candidates)}개 생성 완료",
          {"elapsed_ms": _elapsed, "model": _gen_model})

    return {**state, "candidates": candidates}


# ═══════════════════════════════════════════════════════════════
# 6. SQLPostProcess — AST 기반 결정론적 후처리
# ═══════════════════════════════════════════════════════════════
def node_sql_postprocess(state: GraphState) -> GraphState:
    """
    CandidateGenerator가 생성한 SQL 후보에 결정론적 AST 변환을 적용.
    CAST 제거, alias 제거, LEFT→INNER JOIN, 방어적 패턴 제거.
    """
    candidates = state.get("candidates", [])
    changed = 0

    _pp_dialect = state.get("dialect") or get_settings().db.dialect
    processor = SQLPostProcessor()
    for candidate in candidates:
        original = candidate.sql
        candidate.sql = processor.process(candidate.sql, dialect=_pp_dialect)
        if candidate.sql != original:
            changed += 1

    if changed:
        trace(state, "SQLPostProcess",
              f"후보 {changed}/{len(candidates)}개 SQL 후처리 적용")
    else:
        trace(state, "SQLPostProcess", "변환 대상 없음")

    return {**state, "candidates": candidates}
