"""
Guardrail Rule objects — SQL 후보에 대한 개별 검증 규칙.

각 Rule은 GuardrailRule Protocol을 구현한다:
    check(question, sql, state) -> RuleResult

node_guardrails()에서 _DEFAULT_RULES 리스트를 순회하여 적용.
Design Ref: §4.1 — Option C Pragmatic Balance
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Protocol, Tuple

from ..lg.state import ErrorType

logger = logging.getLogger(__name__)


# ── 결과 타입 ─────────────────────────────────────────────────────
@dataclass
class RuleResult:
    """Guardrail Rule 검증 결과."""
    violated: bool
    message: str = ""
    error_type: ErrorType = ErrorType.SAFETY


# ── 프로토콜 ──────────────────────────────────────────────────────
class GuardrailRule(Protocol):
    """SQL 후보에 대한 단일 검증 규칙 인터페이스."""

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult: ...


# ═══════════════════════════════════════════════════════════════
# Rule 1: 암묵적 현재날짜 필터 (Temporal Filter)
# ═══════════════════════════════════════════════════════════════
_EXPLICIT_TEMPORAL_PHRASE_RE = re.compile(
    r"("
    r"\b(today|yesterday|tomorrow|current year|current month|this year|this month"
    r"|last \d+ (day|days|week|weeks|month|months|year|years)"
    r"|next \d+ (day|days|week|weeks|month|months|year|years)"
    r"|between|from|until|before|after|during)\b"
    r"|오늘|어제|내일|올해|이번 달|이번달|최근|지난|전년도|전년|다음 해|다음해|올해의"
    r"|\d{4}년|\d{1,2}월|\d{1,2}일|부터|까지|이후|이전"
    r")",
    re.IGNORECASE,
)


class TemporalFilterRule:
    """질문에 명시적 기간 조건이 없는데 SQL이 현재 날짜 기반 필터를 사용하는 경우 차단."""

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult:
        try:
            if self._has_explicit_temporal_phrase(question):
                return RuleResult(violated=False)
            if self._uses_implicit_date_filter(sql, state):
                return RuleResult(
                    violated=True,
                    message="질문에 명시적 기간 조건이 없는데 SQL이 현재 날짜 기반 필터를 사용합니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            return RuleResult(violated=False)
        except Exception:
            return RuleResult(violated=False)

    def _has_explicit_temporal_phrase(self, question: str) -> bool:
        return bool(_EXPLICIT_TEMPORAL_PHRASE_RE.search(question or ""))

    def _uses_implicit_date_filter(self, sql: str, state: Dict[str, Any]) -> bool:
        sql_lower = (sql or "").lower()
        if "where" not in sql_lower:
            return False
        current_date = str(state.get("current_date") or "")[:10]
        current_year = str(state.get("current_year") or "")[:4]
        current_month_value = state.get("current_month")
        try:
            current_month = f"{int(current_month_value):02d}" if current_month_value is not None else ""
        except (TypeError, ValueError):
            current_month = ""
        current_year_month = f"{current_year}-{current_month}" if current_year and current_month else ""

        dateish = any(
            token in sql_lower
            for token in (
                "date(",
                "datetime(",
                "strftime(",
                "current_date",
                "current_timestamp",
                "created_at",
                "updated_at",
                "invoicedate",
            )
        )
        if not dateish:
            return False

        if any(
            token in sql_lower
            for token in (
                "date('now'",
                'date("now"',
                "datetime('now'",
                'datetime("now"',
                "strftime('%y', 'now'",
                'strftime("%y", "now"',
                "strftime('%Y', 'now'",
                'strftime("%Y", "now"',
                "strftime('%y-%m', 'now'",
                'strftime("%y-%m", "now"',
                "strftime('%Y-%m', 'now'",
                'strftime("%Y-%m", "now"',
                "strftime('%y-%m-%d', 'now'",
                'strftime("%y-%m-%d", "now"',
                "strftime('%Y-%m-%d', 'now'",
                'strftime("%Y-%m-%d", "now"',
                "current_date",
                "current_timestamp",
            )
        ):
            return True

        literal_markers = tuple(
            marker.lower()
            for marker in (current_date, current_year_month, current_year)
            if marker
        )
        return any(marker in sql_lower for marker in literal_markers)


# ═══════════════════════════════════════════════════════════════
# Rule 2: 퍼센타일 멤버십 (Percentile)
# ═══════════════════════════════════════════════════════════════
class PercentileRule:
    """고객/사용자 percentile 필터에 CUME_DIST를 집계와 함께 사용하는 경우 차단."""

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult:
        try:
            if self._violated(question, sql):
                return RuleResult(
                    violated=True,
                    message="고객/사용자 percentile 필터는 grouped metric 기준에서 PERCENT_RANK를 사용해야 합니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            return RuleResult(violated=False)
        except Exception:
            return RuleResult(violated=False)

    def _violated(self, question: str, sql: str) -> bool:
        question_lower = (question or "").lower()
        sql_lower = (sql or "").lower()
        if "%" not in question_lower:
            return False
        if not any(token in question_lower for token in ("상위", "하위", "top", "bottom")):
            return False
        if not any(token in question_lower for token in ("고객", "사용자", "customer", "user")):
            return False
        if "cume_dist()" not in sql_lower:
            return False
        return any(token in sql_lower for token in ("count(", "sum(", "avg(", "count (", "sum (", "avg ("))


# ═══════════════════════════════════════════════════════════════
# Rule 3: 그룹 라벨 컬럼 (Group Label)
# ═══════════════════════════════════════════════════════════════

# Chinook DB (SQLite 테스트 환경) 전용 빌트인 힌트.
# Oracle 환경에서는 domain_hints의 group_label_hints에서 로드하거나 빈 리스트 반환.
_CHINOOK_GROUP_LABEL_HINTS: Tuple[Tuple[Tuple[str, ...], Tuple[str, ...]], ...] = (
    (("아티스트별", "artist별", "artist", "artist별로"), ("artist", "artistname")),
    (("장르별", "genre별", "genre", "genre별로"), ("genre", "genrename")),
    (("고객별", "customer별", "customer", "사용자별", "user별"), ("customer", "customerid", "customername", "username", "user")),
    (("국가별", "country별", "country", "국가별로"), ("country", "billingcountry")),
    (("서비스별", "service별", "service", "서비스별로"), ("service", "servicename")),
    (("연도별", "year별", "year", "연도별로"), ("year",)),
)


class GroupLabelRule:
    """그룹별 질문에 최종 SELECT 절에 그룹 라벨 컬럼이 없는 경우 차단.

    Oracle 환경: domain_hints의 group_label_hints 설정값 사용 (미설정 시 검증 비활성화).
    SQLite 환경: Chinook DB 빌트인 힌트 사용.
    """

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult:
        try:
            dialect = (state.get("dialect") or "oracle").lower()
            hints = self._get_hints(dialect)
            if not hints:
                return RuleResult(violated=False)
            if self._missing_label(question, sql, hints):
                return RuleResult(
                    violated=True,
                    message="그룹별 질문은 최종 SELECT에 그룹 라벨 컬럼을 포함해야 합니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            return RuleResult(violated=False)
        except Exception:
            return RuleResult(violated=False)

    def _get_hints(self, dialect: str) -> List[Tuple[Tuple[str, ...], Tuple[str, ...]]]:
        """dialect에 따라 그룹 라벨 힌트를 반환."""
        if dialect != "oracle":
            return list(_CHINOOK_GROUP_LABEL_HINTS)
        try:
            from ..config.settings import get_settings
            raw = get_settings().domain_hints("").get("group_label_hints", [])
            if raw and isinstance(raw[0], dict):
                return [(tuple(h["question_tokens"]), tuple(h["sql_tokens"])) for h in raw]
        except Exception:
            pass
        return []  # Oracle 환경에서 domain_hints 미설정 시 검증 비활성화

    def _missing_label(
        self,
        question: str,
        sql: str,
        hints: List[Tuple[Tuple[str, ...], Tuple[str, ...]]],
    ) -> bool:
        question_lower = (question or "").lower()
        if "별" not in question_lower and not any(
            token in question_lower for token in (" per ", " for each ")
        ):
            return False
        final_select = self._extract_final_select(sql)
        if not final_select:
            return False
        for question_tokens, sql_tokens in hints:
            if not any(token.lower() in question_lower for token in question_tokens):
                continue
            if any(token in final_select for token in sql_tokens):
                return False
            return True
        return False

    def _extract_final_select(self, sql: str) -> str:
        matches = list(re.finditer(r"\bselect\b", sql or "", re.IGNORECASE))
        if not matches:
            return ""
        start = matches[-1].end()
        from_match = re.search(r"\bfrom\b", (sql or "")[start:], re.IGNORECASE)
        if not from_match:
            return (sql or "")[start:].lower()
        end = start + from_match.start()
        return (sql or "")[start:end].lower()


# ═══════════════════════════════════════════════════════════════
# Rule 4: 전년 대비 계산 (YoY Calculation)
# ═══════════════════════════════════════════════════════════════
class YoyCalculationRule:
    """전년 대비 계산에서 잘못된 LAG 사용 또는 문자열 연도 산술을 차단."""

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult:
        try:
            if self._sparse_lag(question, sql):
                return RuleResult(
                    violated=True,
                    message="전년 대비 성장률은 이전 연도가 현재 연도 - 1인 경우만 비교해야 합니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            if self._string_year_arithmetic(question, sql):
                return RuleResult(
                    violated=True,
                    message="연도 산술 비교에 사용하는 STRFTIME('%Y') 값은 CAST(... AS INTEGER)로 정수 변환해야 합니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            return RuleResult(violated=False)
        except Exception:
            return RuleResult(violated=False)

    def _sparse_lag(self, question: str, sql: str) -> bool:
        question_lower = (question or "").lower()
        sql_lower = (sql or "").lower()
        if not any(token in question_lower for token in ("전년 대비", "전년도 대비", "year-over-year", "yoy")):
            return False
        if "lag(" not in sql_lower:
            return False
        if any(marker in sql_lower for marker in ("- 1", "-1", "prev_year", "previous_year")):
            return False
        return "year" in sql_lower

    def _string_year_arithmetic(self, question: str, sql: str) -> bool:
        question_lower = (question or "").lower()
        sql_lower = (sql or "").lower()
        if not any(token in question_lower for token in ("전년 대비", "전년도 대비", "year-over-year", "yoy")):
            return False
        uses_strftime_year = "strftime('%y'" in sql_lower or "strftime('%Y'" in sql_lower
        if not uses_strftime_year:
            return False
        if "cast(strftime('%y'" in sql_lower or "cast(strftime('%Y'" in sql_lower:
            return False
        return "- 1" in sql_lower or "-1" in sql_lower


# ═══════════════════════════════════════════════════════════════
# Rule 5: 판매 zero-sales 엔티티 (Sales Entity)
# ═══════════════════════════════════════════════════════════════
class SalesEntityRule:
    """판매/구매 기준 질문에서 zero-sales 엔티티를 LEFT JOIN으로 유지하는 경우 차단."""

    def check(self, question: str, sql: str, state: Dict[str, Any]) -> RuleResult:
        try:
            if self._violated(question, sql):
                return RuleResult(
                    violated=True,
                    message="판매/구매 기준 질문은 실제 거래 행만 대상으로 해야 하며 zero-sales 엔티티를 LEFT JOIN으로 유지하면 안 됩니다.",
                    error_type=ErrorType.SEMANTIC,
                )
            return RuleResult(violated=False)
        except Exception:
            return RuleResult(violated=False)

    def _violated(self, question: str, sql: str) -> bool:
        question_lower = (question or "").lower()
        sql_lower = (sql or "").lower()
        sales_tokens = ("판매", "팔린", "매출", "구매", "sold", "purchased", "revenue", "spent")
        zero_tokens = ("한 번도", "구매되지 않은", "판매되지 않은", "unsold", "zero", "0건")
        if not any(token in question_lower for token in sales_tokens):
            return False
        if any(token in question_lower for token in zero_tokens):
            return False
        if "left join" not in sql_lower:
            return False
        if not any(token in sql_lower for token in ("invoiceline", "invoice line", "invoice_items", "invoiceitem")):
            return False
        if "group by" in sql_lower:
            return False
        positive_filters = ("is not null", "> 0", ">0", "having sum(", "having count(")
        return not any(token in sql_lower for token in positive_filters)


# ═══════════════════════════════════════════════════════════════
# 기본 규칙 목록 — node_guardrails()에서 순서대로 적용
# ═══════════════════════════════════════════════════════════════
_DEFAULT_RULES: List[GuardrailRule] = [
    TemporalFilterRule(),
    PercentileRule(),
    GroupLabelRule(),
    YoyCalculationRule(),
    SalesEntityRule(),
]
