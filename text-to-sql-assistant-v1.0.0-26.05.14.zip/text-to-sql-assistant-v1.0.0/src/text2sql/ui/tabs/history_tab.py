"""Execution history tab."""
from __future__ import annotations

import streamlit as st

from ..renderers import format_sql

_FILTER_OPTIONS = ["전체", "성공만", "실패만"]


def render_history_tab() -> None:
    """Render session-level execution history with search and filter."""
    st.markdown("### 📜 실행 히스토리")

    history: list[dict] = st.session_state.history
    if not history:
        st.caption("아직 실행 기록이 없습니다.")
        return

    col_search, col_filter = st.columns([3, 1])
    with col_search:
        keyword = st.text_input(
            "검색",
            placeholder="질문 또는 SQL 키워드 검색...",
            label_visibility="collapsed",
        )
    with col_filter:
        status_filter = st.selectbox(
            "필터",
            _FILTER_OPTIONS,
            label_visibility="collapsed",
        )

    filtered = history
    if keyword.strip():
        kw = keyword.strip().lower()
        filtered = [
            item for item in filtered
            if kw in item.get("question", "").lower() or kw in item.get("sql", "").lower()
        ]
    if status_filter == "성공만":
        filtered = [item for item in filtered if item.get("success")]
    elif status_filter == "실패만":
        filtered = [item for item in filtered if not item.get("success")]

    st.caption(f"전체 {len(history)}건 중 {len(filtered)}건 표시")

    if not filtered:
        st.caption("검색 결과가 없습니다.")
    else:
        for item in reversed(filtered):
            icon = "✅" if item["success"] else "❌"
            with st.expander(f"{icon} {item['question'][:60]}"):
                st.markdown(f"**DB:** {item['db']}  |  **시간:** {item['time']:.1f}s")
                st.code(format_sql(item["sql"]), language="sql")
                if item.get("summary"):
                    st.info(item["summary"])

    if st.button("🗑️ 히스토리 초기화"):
        st.session_state.history = []
        from text2sql.ui.context import _save_history_to_file
        _save_history_to_file([])
        st.rerun()
