"""Sidebar rendering for runtime controls."""
from __future__ import annotations

import streamlit as st

from .context import AppContext


def render_sidebar(context: AppContext) -> tuple[int, bool]:
    """Render the global sidebar and return runtime controls."""
    settings = context.settings

    with st.sidebar:
        provider = settings.current_provider()
        dialect = settings.current_dialect()
        model = settings.current_model()

        st.markdown(f"### 🔌 환경: `{dialect}` + `{provider}`")
        st.caption(f"**DB Dialect:** `{dialect}`")
        st.caption(f"**LLM Provider:** `{provider}`")

        st.markdown("### 🤖 모델 정보")
        if settings.is_dual_model():
            st.caption(f"**메인 LLM:** `{model}` _(정확도 우선)_")
            st.caption("사용처: SQL 생성, Judge, Repair")
            fast_model = (
                settings.llm_fast_cfg.model
                if provider == "openai_compatible"
                else settings.llm_fast_cfg.azure_deployment
            )
            st.caption(f"**보조 LLM:** `{fast_model}` _(속도 우선)_")
            st.caption("사용처: 분석, 선택, 검증, 요약")
        else:
            st.caption(f"**LLM:** `{model}`")
            st.caption("모든 Agent가 이 모델을 사용합니다")

        st.divider()
        max_retries = st.slider("최대 Repair 시도", 1, 5, settings.pipeline.max_retries)

        st.divider()
        hitl_enabled = st.toggle(
            "🧑‍⚖️ SQL 실행 전 검토 (HITL)",
            value=False,
            help="활성화 시 SQL 생성 후 실행 전에 사용자가 검토·수정",
        )

        st.caption("스키마는 🛠️ 운영 관리 탭에서 확인하세요.")

    return max_retries, hitl_enabled
