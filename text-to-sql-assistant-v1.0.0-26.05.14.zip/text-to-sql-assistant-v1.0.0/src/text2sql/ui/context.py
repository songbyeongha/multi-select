"""Shared Streamlit app context and session-state helpers."""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import streamlit as st

from text2sql.config.settings import Settings, get_settings
from text2sql.tools.date_tools import get_date_tool

_logger = logging.getLogger(__name__)
MAX_HISTORY = 500
_ROOT = Path(__file__).resolve().parents[3]

ORACLE_PATH = "__oracle__"


def _history_file() -> Path:
    return _ROOT / "data" / "history" / "history.json"


def load_persistent_history() -> list[dict]:
    """Load execution history from JSON file. Returns empty list on any failure."""
    path = _history_file()
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        _logger.warning("히스토리 파일 로드 실패: %s", exc)
        return []


def _save_history_to_file(entries: list[dict]) -> None:
    """Overwrite history file with trimmed entries. Silent on failure."""
    path = _history_file()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        trimmed = entries[-MAX_HISTORY:]
        path.write_text(json.dumps(trimmed, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as exc:
        _logger.warning("히스토리 파일 저장 실패: %s", exc)


SESSION_DEFAULTS = {
    "history": [],
    "hitl_phase1_state": None,
    "hitl_phase1_elapsed": 0.0,
    "hitl_phase1_token_usage": None,
    "hitl_sql_approved": False,
    "hitl_repair_cycle": 0,
    "batch_phase1_results": [],
    "batch_approvals": {},
    "batch_results": [],
    "_hitl_question": "",
    "_hitl_db": "",
}


@dataclass(frozen=True)
class AppContext:
    settings: Settings
    db_map: dict[str, str]
    oracle_path: str
    current_ref: Any


def init_session_state() -> None:
    """Initialize Streamlit session state keys used across tabs."""
    for key, value in SESSION_DEFAULTS.items():
        if key not in st.session_state:
            if isinstance(value, list):
                st.session_state[key] = list(value)
            elif isinstance(value, dict):
                st.session_state[key] = dict(value)
            else:
                st.session_state[key] = value

    if not st.session_state.get("_history_loaded"):
        persistent = load_persistent_history()
        if persistent:
            st.session_state.history = persistent
        st.session_state["_history_loaded"] = True


@st.cache_resource
def build_app_context() -> AppContext:
    """Build immutable app-level context from settings and registry state."""
    settings = get_settings()
    date_tool = get_date_tool()
    return AppContext(
        settings=settings,
        db_map={},
        oracle_path=ORACLE_PATH,
        current_ref=date_tool.reference_date,
    )


def get_db_path(context: AppContext, db_id: str) -> str:
    """Return Oracle sentinel path."""
    return context.oracle_path


def append_history_entry(
    *,
    question: str,
    db: str,
    sql: str,
    success: bool,
    elapsed: float,
    summary: str,
) -> None:
    """Persist a lightweight execution record in session history and JSON file."""
    entry = {
        "question": question,
        "db": db,
        "sql": sql,
        "success": success,
        "time": elapsed,
        "summary": summary,
    }
    st.session_state.history.append(entry)
    _save_history_to_file(st.session_state.history)
