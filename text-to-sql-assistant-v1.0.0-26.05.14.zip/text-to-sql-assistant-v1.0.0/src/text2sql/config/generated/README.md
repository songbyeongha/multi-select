# generated 설정 폴더

이 폴더는 운영 DB에 처음 연결한 뒤 자동 생성되는 설정 자산만 보관합니다.

## 목적

- `schema_metadata*.json` 자동 생성 결과 보관
- `domain_hints*.json` 자동 생성 결과 보관
- manual overlay 파일을 같은 위치에 두어 통째로 백업·삭제·이동 가능하게 유지

## 운영 원칙

- 저장소의 정적 설정 파일과 분리합니다.
- 초기 배포 시에는 이 폴더가 비어 있어도 됩니다.
- `scripts/operations/run_ops.py first-run --db-id <db_id>` 또는 `prepare`를 실행하면 필요한 파일이 생성됩니다.
- 다른 환경으로 옮길 때는 이 폴더만 별도로 백업하거나 복사하면 됩니다.

## 대표 파일

- `schema_metadata_oracle.json`
- `schema_metadata_oracle_manual.json`
- `domain_hints_oracle.json`
- `domain_hints_oracle_manual.json`

## 정리 기준

- 운영 DB를 새로 붙일 때는 이 폴더 안의 기존 JSON을 삭제하고 다시 생성해도 됩니다.
- 파일이 없어도 애플리케이션 코드는 경로만 알고 있으며, 최초 실행 시 다시 만들어집니다.
