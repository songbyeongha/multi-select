# Docs 폴더 정리 및 재구성

## 요청

docs 폴더의 문서들을 성격에 맞게 폴더로 묶어서 정리해달라.

## 분석

### 기존 구조
```
docs/
├── README.md (색인)
├── START_HERE.md (초급)
├── PROJECT_STRUCTURE.md (구조)
├── ARCHITECTURE_DIAGRAMS.md (다이어그램)
├── CODEBASE_GUIDE.md (코드)
├── operations/ (운영)
│   ├── CLI_GETTING_STARTED.md
│   ├── DAILY_OPERATIONS_CHECKLIST.md
│   ├── ENDPOINT_USAGE_GUIDE.md
│   ├── FIRST_PRODUCTION_ATTACH.md
│   ├── OPERATOR_ONE_PAGE.md
│   ├── ORACLE_DB_QUICKSTART.md
│   ├── RELEASE_CHECKLIST.md
│   └── SCRIPT_SELECTION_GUIDE.md
└── metadata/
    └── SQL_METADATA_ENRICHMENT.md
```

### 문제
- 루트 레벨에 혼합된 파일들
- 폴더 구조가 불일관
- 문서 읽는 순서 불명확
- 역할별 분류 부족

### 해결 전략
문서를 역할/용도별로 4개 폴더로 정리:
1. **getting-started/** - 초급 (첫 시작)
2. **architecture/** - 설계 (시스템 이해)
3. **operations/** - 운영 (매일 사용)
4. **metadata/** - 고급 (메타데이터)

## 구현

### 1. 새 폴더 생성
```
getting-started/  (신규)
architecture/     (신규)
operations/       (기존 유지)
metadata/         (기존 유지)
```

### 2. 파일 이동
- START_HERE.md → getting-started/
- README.md → getting-started/INDEX.md (원본 README는 새로 작성)
- ARCHITECTURE_DIAGRAMS.md → architecture/
- PROJECT_STRUCTURE.md → architecture/
- CODEBASE_GUIDE.md → architecture/
- operations/* → 기존 위치 유지
- metadata/* → 기존 위치 유지

### 3. README 파일 작성

#### docs/README.md (메인 색인)
**역할:** 문서 네비게이션 가이드
**내용:**
- 읽는 순서 (처음/운영/배포/고급)
- 폴더별 설명
- 빠른 찾기 표

#### docs/getting-started/README.md
**역할:** 초급 문서 개요
**내용:**
- START_HERE.md 소개
- INDEX.md 소개
- 다음 단계 가이드

#### docs/architecture/README.md
**역할:** 아키텍처 문서 개요
**내용:**
- PROJECT_STRUCTURE.md 설명
- ARCHITECTURE_DIAGRAMS.md 설명
- CODEBASE_GUIDE.md 설명
- 언제 읽을지

#### docs/operations/README.md
**역할:** 운영 문서 개요
**내용:**
- 초급/중급/고급/심화 문서 분류
- 상황별 읽기 순서
  - 첫 시작
  - 매일
  - 배포
  - API 사용
- 전체 8개 문서 설명

#### docs/metadata/README.md
**역할:** 메타데이터 문서 개요
**내용:**
- SQL_METADATA_ENRICHMENT.md 설명
- 사용 시기
- 관련 스크립트

### 4. 최종 구조
```
docs/
├── README.md ⭐ 메인 색인 (신규)
│
├── getting-started/ 🌱 초급
│   ├── README.md (신규)
│   ├── START_HERE.md (이동)
│   └── INDEX.md (이동, 이전 README.md)
│
├── architecture/ 🏗️ 설계
│   ├── README.md (신규)
│   ├── PROJECT_STRUCTURE.md (이동)
│   ├── ARCHITECTURE_DIAGRAMS.md (이동)
│   └── CODEBASE_GUIDE.md (이동)
│
├── operations/ ⚙️ 운영
│   ├── README.md (신규)
│   ├── CLI_GETTING_STARTED.md (유지)
│   ├── OPERATOR_ONE_PAGE.md (유지)
│   ├── DAILY_OPERATIONS_CHECKLIST.md (유지)
│   ├── FIRST_PRODUCTION_ATTACH.md (유지)
│   ├── RELEASE_CHECKLIST.md (유지)
│   ├── ORACLE_DB_QUICKSTART.md (유지)
│   ├── ENDPOINT_USAGE_GUIDE.md (유지)
│   └── SCRIPT_SELECTION_GUIDE.md (유지)
│
└── metadata/ 📊 고급
    ├── README.md (신규)
    └── SQL_METADATA_ENRICHMENT.md (유지)
```

## 읽는 순서 (문서에 명시됨)

### 🟢 처음 시작
1. docs/README.md - 전체 가이드
2. docs/getting-started/START_HERE.md - 첫 시작
3. docs/operations/CLI_GETTING_STARTED.md - 상세 설정

### 🟡 시스템 이해
1. docs/architecture/PROJECT_STRUCTURE.md - 구조
2. docs/architecture/ARCHITECTURE_DIAGRAMS.md - 다이어그램
3. docs/architecture/CODEBASE_GUIDE.md - 코드

### 🟠 매일 운영
1. docs/operations/OPERATOR_ONE_PAGE.md - 요약
2. docs/operations/DAILY_OPERATIONS_CHECKLIST.md - 체크리스트

### 🔴 배포
1. docs/operations/RELEASE_CHECKLIST.md - 준비 체크
2. docs/operations/FIRST_PRODUCTION_ATTACH.md - 배포 가이드

### 🟣 고급
- docs/metadata/SQL_METADATA_ENRICHMENT.md - 메타데이터
- docs/operations/ENDPOINT_USAGE_GUIDE.md - API
- docs/operations/SCRIPT_SELECTION_GUIDE.md - 스크립트

## 파일 변경 요약

### 추가됨 (5개)
- ✅ docs/README.md
- ✅ docs/getting-started/README.md
- ✅ docs/architecture/README.md
- ✅ docs/operations/README.md
- ✅ docs/metadata/README.md

### 이동됨 (5개)
- ✅ START_HERE.md → getting-started/
- ✅ README.md → getting-started/INDEX.md
- ✅ ARCHITECTURE_DIAGRAMS.md → architecture/
- ✅ PROJECT_STRUCTURE.md → architecture/
- ✅ CODEBASE_GUIDE.md → architecture/

### 유지됨 (8개)
- ✅ operations/* (8개 파일)
- ✅ metadata/SQL_METADATA_ENRICHMENT.md

## 검증

✅ 폴더 구조 일관성  
✅ 모든 문서 이동 확인  
✅ README 파일 생성 (5개)  
✅ 읽는 순서 명시  
✅ 내부 링크 일관성  

## 결과

### 사용자 입장에서
- ✅ 명확한 폴더 구조
- ✅ 문서 읽는 순서가 가이드됨
- ✅ 상황별 읽을 문서가 명확
- ✅ 계층화된 학습 경로

### 유지보수 입장에서
- ✅ 표준화된 구조
- ✅ 폴더별 README로 일관성 유지
- ✅ 새 문서 추가 시 위치가 명확
- ✅ 문서 네비게이션 개선

## 관련 정리 작업

1. **scripts 폴더 정리** (완료)
   - 13개 스크립트를 6개 폴더로 조직화
   - 각 폴더에 README 추가

2. **scripts 문서 정리** (완료)
   - 한국어 표준화
   - 중복 제거
   - 읽는 순서 명시

3. **docs 폴더 정리** (현재, 완료)
   - 문서를 4개 폴더로 조직화
   - 각 폴더에 README 추가
   - 네비게이션 가이드 작성

---

**Status**: ✅ 완료  
**Time**: ~15분  
**파일 생성**: 5개 (README)  
**파일 이동**: 5개  
**파일 유지**: 8개  
**결과**: 명확한 문서 구조 + 읽는 순서 가이드
