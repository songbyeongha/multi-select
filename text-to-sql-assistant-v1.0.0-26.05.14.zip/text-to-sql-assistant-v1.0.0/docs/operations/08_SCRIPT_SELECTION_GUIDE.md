﻿# 스크립트 선택 가이드

"지금 무엇을 실행해야 하지?" 라는 질문에 답하는 가이드입니다.

---

## 상황별 선택

### 처음 연결하는 경우

```
Oracle 연결이 되는지 먼저 확인하고 싶다
  → run_ops.py doctor

전체 초기화를 한 번에 하고 싶다
  → run_ops.py first-run --db-id <id>

단계별로 직접 확인하면서 하고 싶다
  → run_ops.py doctor
  → run_ops.py prepare --db-id <id>
  → run_cli.py -q "테스트 질문"
```

### 질문 하나만 실행하고 싶은 경우

```powershell
.venv\Scripts\python.exe scripts\execution\run_cli.py -q "최근 한 달 생산량은?"
```

### 메타데이터를 갱신해야 하는 경우

```
DB 스키마가 변경됐다 / 처음 prepare를 다시 하고 싶다
  → run_ops.py prepare --db-id <id>

메타데이터 설명을 더 정교하게 만들고 싶다
  → 수동 오버레이 편집 후 run_ops.py maintain
  → docs/metadata/SQL_METADATA_ENRICHMENT.md 참고
```

### 매일 해야 할 작업

```powershell
.venv\Scripts\python.exe scripts\operations\run_ops.py daily --db-id <db-id>
```

이 명령 하나로 `doctor + maintain` 을 묶어서 실행합니다.

### 배포 전 검증

`--catalog` 는 E2E를 실행할 경우 필요하며, `--skip-e2e` 옵션으로 생략할 수 있습니다.

```powershell
.venv\Scripts\python.exe scripts\operations\run_ops.py release ^
    --db-id <db-id> ^
    --catalog data/catalog.json
```

E2E + pytest + vulture 를 순서대로 실행하고 게이트를 통과해야 배포합니다.

### Web UI를 띄우고 싶은 경우

```powershell
.venv\Scripts\python.exe -m streamlit run app.py
```

---

## 스크립트 역할 요약

| 스크립트 | 언제 쓰는가 |
|----------|------------|
| `scripts/operations/run_ops.py` | 운영 작업 전반. 처음 설정, 매일 유지보수, 배포 게이트 |
| `scripts/execution/run_cli.py` | 단건 질문 테스트. CI 스모크 테스트 |
| `app.py` | 사용자가 웹 브라우저로 직접 사용하는 채팅 UI |

---

## run_ops.py 서브커맨드 선택 트리

```
처음 사용하는가?
├── 예 → first-run (한 번에) 또는 doctor → prepare 순서로
└── 아니오
    ├── 매일 유지보수 → daily
    ├── 스키마 변경 → prepare
    ├── 회귀 테스트 → test  (--catalog 필수)
    ├── 배포 전 → release
    ├── 벡터/피드백 재구축 → maintain
    └── 도메인 힌트 점검 → check-hints
```

---

## 주요 옵션 참조

### run_ops.py prepare

```powershell
# 전체 스키마
prepare --db-id <db-id>

# 특정 테이블만
prepare --db-id <db-id> --include TABLE_A,TABLE_B

# 특정 테이블 제외
prepare --db-id <db-id> --exclude LOG_TABLE,TEMP_TABLE

# 샘플 값 수 조정 (기본 5)
prepare --db-id <db-id> --samples 10
```

### run_ops.py test

`--catalog` 는 필수 옵션입니다.

```powershell
test --db-id <db-id> --catalog data/catalog.json

# 결과 저장
test --db-id <db-id> --catalog data/catalog.json --report data/report.json

# 특정 도메인만
test --db-id <db-id> --catalog data/catalog.json --domain 생산
```

### run_ops.py check-hints

도메인 힌트가 올바르게 작동하는지 진단합니다 (Oracle 연결 불필요).

```powershell
# 상태 확인
check-hints --db-id <db-id>

# 질문 매칭 시뮬레이션
check-hints --db-id <db-id> -q "이번 달 공장별 생산량은?"

# 전체 목록 출력
check-hints --db-id <db-id> --show-all
```

### run_cli.py

```powershell
# 단건 질문
run_cli.py -q "질문"

# HITL 모드 (사람이 SQL 검토 후 실행)
run_cli.py -q "질문" --hitl

# 재시도 횟수 조정
run_cli.py -q "질문" --max-retries 3
```
