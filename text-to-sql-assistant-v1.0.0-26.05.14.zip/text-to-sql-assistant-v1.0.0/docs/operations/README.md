# 운영 (Operations)

Text-to-SQL 시스템을 매일 운영하고 배포하기 위한 문서들입니다.

## 📖 이 폴더의 문서들

### 🟢 초급 (매일 사용)

**01_CLI_GETTING_STARTED.md** ⭐ **먼저 읽으세요**
- 환경 설정 (.env 파일)
- Oracle 연결 확인
- 시스템 상태 점검
- 첫 질문 실행
- 트러블슈팅

**02_OPERATOR_ONE_PAGE.md**
- 운영자용 한 페이지 요약
- 주요 명령어
- 자주 하는 작업

### 🟡 중급 (일일 체크)

**03_DAILY_OPERATIONS_CHECKLIST.md**
- 매일 아침 해야 할 일
- 주간/월간 점검
- 상태 모니터링

**04_ORACLE_DB_QUICKSTART.md**
- Oracle 데이터베이스 빠른 시작
- SQL 연습용 데이터셋
- 기본 쿼리

### 🔴 고급 (배포 전)

**05_FIRST_PRODUCTION_ATTACH.md**
- 첫 배포 가이드
- 배포 전 확인사항
- 배포 후 검증

**06_RELEASE_CHECKLIST.md**
- 배포 준비 완전 체크리스트
- 단계별 확인 항목
- 롤백 계획

### 🟣 심화 (특수 상황)

**07_ENDPOINT_USAGE_GUIDE.md**
- REST API 엔드포인트
- 요청/응답 형식
- 사용 예제

**08_SCRIPT_SELECTION_GUIDE.md**
- 스크립트 선택 가이드
- 언제 어떤 스크립트를 사용할지
- 스크립트 흐름

## 🎯 상황별 읽기 순서

### 첫 시작 (처음 한 번)
1. [01_CLI_GETTING_STARTED.md](01_CLI_GETTING_STARTED.md) - 상세 설정
2. [02_OPERATOR_ONE_PAGE.md](02_OPERATOR_ONE_PAGE.md) - 요약 보기

### 매일 (아침마다)
1. [03_DAILY_OPERATIONS_CHECKLIST.md](03_DAILY_OPERATIONS_CHECKLIST.md) - 체크리스트
2. [02_OPERATOR_ONE_PAGE.md](02_OPERATOR_ONE_PAGE.md) - 필요한 명령어

### 배포 (1개월/분기마다)
1. [06_RELEASE_CHECKLIST.md](06_RELEASE_CHECKLIST.md) - 배포 준비
2. [05_FIRST_PRODUCTION_ATTACH.md](05_FIRST_PRODUCTION_ATTACH.md) - 배포 가이드

### API 사용 (개발자)
1. [07_ENDPOINT_USAGE_GUIDE.md](07_ENDPOINT_USAGE_GUIDE.md) - 엔드포인트

## 🔗 연관 문서

- 초급: [getting-started/01_START_HERE.md](../getting-started/01_START_HERE.md)
- 아키텍처: [architecture/01_PROJECT_STRUCTURE.md](../architecture/01_PROJECT_STRUCTURE.md)
- Scripts: [../../scripts/README.md](../../scripts/README.md)
- Scripts 폴더별: [../../scripts/execution/README.md](../../scripts/execution/README.md)

---

**빠른 시작**: [01_CLI_GETTING_STARTED.md](01_CLI_GETTING_STARTED.md)
