﻿# CLI / Web UI 사용 가이드

이 시스템의 세 가지 진입점 사용법을 설명합니다.

---

## 진입점 1 — run_cli.py (CLI)

자연어 질문 하나를 SQL로 변환하고 결과를 출력합니다.

### 기본 사용

```powershell
.venv\Scripts\python.exe scripts\execution\run_cli.py -q "최근 한 달 생산량을 보여줘"
```

### 주요 옵션

| 옵션 | 설명 | 예시 |
|------|------|------|
| `-q` / `--question` | 질문 (필수) | `-q "재고가 부족한 품목은?"` |
| `--db` | DB ID (.env의 T2SQL_DB_ID 오버라이드) | `--db oracle_prod` |
| `--hitl` | SQL 실행 전 사람이 검토·승인 | `--hitl` |
| `--max-retries` | 파이프라인 최대 재시도 수 (기본: 3) | `--max-retries 5` |
| `--no-feedback` | 피드백 저장 건너뜀 | `--no-feedback` |

### 출력 예시

```
[질문] 최근 한 달 생산량을 보여줘
[생성된 SQL]
  SELECT FACTORY_CD, SUM(PROD_QTY) AS TOTAL_QTY
  FROM PROD_RESULT
  WHERE PROD_DATE >= ADD_MONTHS(TRUNC(SYSDATE), -1)
  GROUP BY FACTORY_CD
  FETCH FIRST 50 ROWS ONLY

[결과 미리보기 — 3행 / 전체 5행]
  FACTORY_CD  TOTAL_QTY
  ──────────  ─────────
  F01         12,345
  F02          8,920
  F03          6,100
  ...
```

### HITL 모드 (Human-in-the-Loop)

```powershell
.venv\Scripts\python.exe scripts\execution\run_cli.py -q "재고 현황 보여줘" --hitl
```

SQL이 생성된 후 실행 여부를 묻습니다:
```
[생성된 SQL]
  SELECT ...

이 SQL을 실행하시겠습니까? [y/N]: y
```

`y` 입력 시 실행, `n` 또는 Enter 시 취소합니다.

---

## 진입점 2 — app.py (Streamlit Web UI)

### 실행

```powershell
.venv\Scripts\python.exe -m streamlit run app.py
```

브라우저에서 `http://localhost:8501` 접속.

### 포트 변경

```powershell
.venv\Scripts\python.exe -m streamlit run app.py --server.port 8502
```

### 탭 구성

| 탭 | 기능 |
|----|------|
| **메인** | 자연어 질문 입력 → SQL 생성 → 결과 표시 |
| **배치** | 여러 질문을 한 번에 처리 |
| **운영** | 연결 상태 확인, 메타데이터 상태 표시 |

### 메인 탭 사용

1. 질문 입력창에 자연어로 질문 입력
2. `실행` 버튼 클릭
3. 생성된 SQL과 결과 테이블 확인
4. 결과 하단 별점(★)으로 피드백 제출

### 피드백

| 점수 | 동작 |
|------|------|
| ★★★★★ / ★★★★ (4~5점) | `few_shot_examples`, `keyword_map`, `common_patterns` 자동 반영 |
| ★★★ (3점) | 기록만, 학습 반영 없음 |
| ★★ / ★ (1~2점) | 오류 패턴 기록 → repair 힌트에 반영 |

> **자동 피드백과 명시 피드백의 차이**
> 파이프라인 실행 후 자동으로 기록되는 피드백은 통계·이력 저장 용도로만 사용됩니다.
> `domain_hints` 반영은 사용자가 직접 별점 버튼을 클릭했을 때만 실행됩니다.

---

## 진입점 3 — run_ops.py (운영 도구)

운영 작업 전반을 담당합니다. 자세한 사용법은 서브커맨드별로 확인하세요.

```powershell
# 전체 도움말
.venv\Scripts\python.exe scripts\operations\run_ops.py --help

# 운영 가이드 출력
.venv\Scripts\python.exe scripts\operations\run_ops.py usage

# 특정 서브커맨드 도움말
.venv\Scripts\python.exe scripts\operations\run_ops.py prepare --help
```

서브커맨드 목록 → [OPERATOR_ONE_PAGE.md](OPERATOR_ONE_PAGE.md)

---

## 쿼리 카탈로그 (catalog.json)

카탈로그는 `prepare`, `test`, `release`, `first-run --run-e2e` 에서 사용하는 **선택적** 파일입니다.

### 역할

| 사용 위치 | 역할 |
|-----------|------|
| `prepare --catalog` | 정답 SQL을 파싱해 메타데이터 자동 강화 (`enrich`) |
| `test --catalog` | 질문 → 생성 SQL 결과 vs 정답 SQL 결과 행 단위 비교 (E2E 회귀 테스트) |
| `release --catalog` | 배포 게이트용 E2E 실행 |

### 형식

```json
{
  "queries": [
    {
      "case_id": "prod-001",
      "question": "이번 달 공장별 생산량 합계를 보여줘",
      "expected_sql": "SELECT FACTORY_CD, SUM(PROD_QTY) FROM PROD_RESULT WHERE ... GROUP BY FACTORY_CD FETCH FIRST 50 ROWS ONLY",
      "domain": "생산",
      "difficulty": "easy",
      "tags": ["집계", "날짜필터"],
      "title": "이번 달 공장별 생산량"
    }
  ]
}
```

**필수 필드**: `case_id`, `question`, `expected_sql`
**권장 필드**: `domain`, `difficulty`, `tags` (누락 시 경고, E2E 필터링에 사용)

최상위 배열 형식 `[{ ... }, { ... }]` 도 허용됩니다.

### 예시 파일

`data/catalog.example.json` — 제조업 도메인(생산/재고/품질) 케이스 5개 포함.
이 파일을 복사해 실제 업무 테이블/SQL로 교체하세요.

```powershell
copy data\catalog.example.json data\catalog.json
# 이후 catalog.json 에서 expected_sql 을 실제 DB SQL 로 수정
```

### 없어도 되는가?

예. 카탈로그 없이도 다음은 정상 작동합니다:
- `doctor`, `prepare`, `daily`, `maintain`
- `run_cli.py -q "..."`
- `app.py` (Streamlit)

`--run-e2e` 를 사용하지 않는 한 카탈로그는 필수가 아닙니다.

---

## 환경변수로 동작 제어

`.env` 파일에서 파이프라인 동작을 조정할 수 있습니다.

| 변수 | 기본값 | 설명 |
|------|--------|------|
| `T2SQL_MAX_RETRIES` | `3` | SQL 수정 재시도 최대 횟수 |
| `T2SQL_ENFORCE_LIMIT` | `true` | FETCH FIRST / ROWNUM 강제 추가 |
| `ALLOW_EMPTY_RESULT` | `true` | 빈 결과 허용 (false 시 재시도) |
| `T2SQL_AUTO_FEEDBACK` | `true` | 파이프라인 실행 결과 자동 로그 저장 (통계용). domain_hints 반영은 별도 사용자 별점 클릭 필요 |

---

## 팁

- **첫 번째 질문은 느릴 수 있습니다.** LLM 로딩과 벡터 검색 초기화 시간이 포함됩니다.
- **CLI를 CI에 활용하세요.** `run_cli.py -q "..."` 는 종료 코드 0(성공)/1(실패)을 반환합니다.
- **HITL 모드는 검증용입니다.** 운영 자동화에서는 HITL 없이 실행합니다.
