# Text-to-SQL CLI 초기 설정 가이드

처음 시작할 때 **CLI에서 실행해야 할 명령어들**을 단계별로 정리했습니다.

---

## 📋 1단계: 환경 설정

프로젝트 root에 `.env` 파일을 생성하고 다음 환경변수를 설정합니다:

```bash
# .env 파일 (프로젝트 root)
T2SQL_DB_DIALECT=oracle
T2SQL_DB_HOST=<호스트>
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=<서비스명>
T2SQL_DB_USER=<사용자>
T2SQL_DB_PASSWORD=<비밀번호>
T2SQL_DB_SCHEMA=<스키마>

# LLM 설정
T2SQL_LLM_PROVIDER=openai_compatible  # 또는 azure_openai
T2SQL_LLM_BASE_URL=<LLM API 주소>
T2SQL_LLM_API_KEY=<LLM API 키>
T2SQL_LLM_MODEL_PRIMARY=gpt-oss-120b  # 메인 모델 (정확도 우선)
T2SQL_LLM_MODEL_FAST=qwen3:8b          # 보조 모델 (속도 우선) — simple 패턴/검증에서 사용
T2SQL_LLM_TIMEOUT_SEC=60

# 선택사항
T2SQL_DB_ID=oracle_prod                # 데이터베이스 ID
T2SQL_EMBEDDING_PROVIDER=ollama        # embedding 제공자
T2SQL_NUM_CANDIDATES=2                 # SQL 후보 개수 (기본 2, 정확도 향상 시 3 권장)
T2SQL_MAX_RETRIES=3                    # repair 최대 재시도 횟수
ALLOW_EMPTY_RESULT=true                # 빈 결과 허용 여부
```

**LLM 제공자별 설정 예시:**
- **OpenAI Compatible (로컬 또는 API)**: base_url, api_key 설정
- **Azure OpenAI**: SKCC_AZURE_* 환경변수 설정

---

## ✅ 2단계: Oracle 연결 확인

기본 Oracle 연결을 테스트합니다:

```bash
python scripts/diagnostics/check_oracle_connection.py
```

**예상 출력:**
```
============================================================
Oracle Connection Check
============================================================
  Host:         <호스트>
  Port:         1521
  Service:      <서비스명>
  User:         <사용자>
  Schema:       <스키마>

[1/5] Testing connection...
  [OK] Connection succeeded: Connected as <사용자>@<서비스명>

[2/5] Effective user/schema: <사용자> / <스키마>

[3/5] Listing readable tables...
  Table count: 42
    - PLANTS
    - PRODUCTS
    - SALES_ORDERS
    ... and 39 more

[4/5] Checking metadata access...
  ALL_* metadata views accessible: YES
  Sample table: PLANTS
    Columns: 5
      PLANT_ID  NUMBER [PK]
      PLANT_CODE  VARCHAR2(20) [UNIQUE]
      PLANT_NAME  VARCHAR2(100)
      ...

[5/5] Running sample SELECT...
  [OK] Query succeeded on PLANTS (3 rows)
    {'PLANT_ID': 1, 'PLANT_CODE': 'FAC001', 'PLANT_NAME': 'Seoul Plant', ...}
```

**문제 해결:**
- `[FAIL] Connection failed`: DB 정보, 포트, 비밀번호 확인
- `[WARN] SYSTEM/SYS schema detected`: 업무 스키마 사용 권장

---

## 🔧 3단계: 시스템 상태 점검

12개 핵심 모듈을 점검합니다:

```bash
python scripts/diagnostics/health_check.py
```

**예상 출력:**
```
════════════════════════════════════════
  Text-to-SQL Health Check
════════════════════════════════════════
[OK]   imports  (12/12 모듈)
[OK]   config/settings
[OK]   GraphState  (14 fields)
[OK]   build_graph  (StateGraph)
[OK]   Oracle DB  (42 tables)
════════════════════════════════════════
결과: 5/5 통과  0 skipped  145ms
```

**상태별 의미:**
- `[OK]`: 정상 작동
- `[SKIP]`: 미설정 (선택사항)
- `[FAIL]`: 즉시 조치 필요

---

## 📊 4단계: 통합 운영 도구 실행

### 4-1. 워크플로 확인

```bash
python scripts/operations/run_ops.py usage
```

전체 운영 가이드와 서브커맨드 설명이 출력됩니다.

---

### 4-2. Doctor (진단)

```bash
python scripts/operations/run_ops.py doctor \
  --db-id oracle_prod
```

**검사 항목:**
- ✓ Oracle 연결
- ✓ 메타뷰(ALL_TABLES) 접근
- ✓ 읽기 가능한 테이블 목록
- ✓ 샘플 SELECT 실행

**출력 예시:**
```
[OK] Oracle connection succeeded
  Effective user: SCOTT
  Effective schema: SCOTT
[OK] Readable tables found: 42
[OK] Metadata access verified
```

---

### 4-3. Prepare (메타데이터 추출 + 도메인 강화)

```bash
python scripts/operations/run_ops.py prepare \
  --db-id oracle_prod \
  --cycles 1
```

**생성 파일:**
- `src/text2sql/config/oracle_metadata.json` (primary - 자동 생성)
- `src/text2sql/config/oracle_metadata_manual.json` (overlay - 수동 편집용)
- `src/text2sql/config/oracle_domain_hints.json` (키워드 매핑)
- `src/text2sql/config/oracle_domain_hints_manual.json` (수동 추가)

**출력 예시:**
```
=== Oracle Ops Cycle 1/1 ===
[OK] metadata sync completed: tables=42, relationships=38
[OK] learner completed: {'few_shots_added': 0, 'keywords_added': 15}
[OK] evaluator score=75 attention=False
[OK] report saved: logs/oracle_ops_report.json
```

---

### 4-4. Maintain (매일 실행)

```bash
python scripts/operations/run_ops.py daily \
  --db-id oracle_prod
```

**실행 내용:**
1. doctor (연결 확인)
2. maintain (1 cycle - 도메인 학습 + 평가)

초기 설정 후 **매일 한 번**씩 실행하면 자동으로 성능이 개선됩니다.

---

## 🧪 5단계: E2E 테스트

### 5-1. 테스트 카탈로그 준비 (선택사항)

`data/catalog.json` 파일을 생성합니다:

```json
[
  {
    "case_id": "001",
    "question": "올해 매출은?",
    "expected_sql": "SELECT SUM(amount) FROM sales WHERE YEAR(order_date)=YEAR(SYSDATE)",
    "domain": "sales",
    "difficulty": "easy",
    "tags": ["aggregation"]
  },
  {
    "case_id": "002",
    "question": "공장별 생산량을 보여줘",
    "expected_sql": "SELECT plant_id, SUM(qty) FROM production_orders GROUP BY plant_id",
    "domain": "manufacturing",
    "difficulty": "medium",
    "tags": ["grouping"]
  }
]
```

---

### 5-2. 회귀 테스트 실행

```bash
python scripts/operations/run_ops.py test \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --report logs/e2e_test_report.json
```

**출력 예시:**
```
[PASS] 올해 매출은?
[PASS] 공장별 생산량을 보여줘
[PASS] 지난달 매출 상위 고객
...
[FAIL] 안전재고보다 현재고가 낮은 품목

최종 결과:
  총 케이스: 25개
  통과: 24개
  실패: 1개
  Pass Rate: 96.0%

report saved: logs/e2e_test_report.json
```

---

## 🚢 6단계: 배포 게이트

```bash
python scripts/operations/run_ops.py release \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --run-e2e \
  --run-pytest \
  --fail-under-overall 90
```

**검사 항목:**
- E2E 회귀 테스트 (카탈로그 기반)
- pytest 단위 테스트
- vulture 코드 품질 검사
- 전체 배포 점수 ≥90%

**출력 예시:**
```
[PASS] Oracle release gate
  db_id=oracle_prod
  overall_score=92
  query_accuracy=94
  e2e_pass_rate=96.0
  vector_mode=fresh-index
  report=logs/oracle_release_gate.json
```

---

## 💬 7단계: CLI 대화형 모드

### 7-1. 단일 질문 실행

```bash
python scripts/execution/run_cli.py \
  --db oracle_prod \
  --question "올해 매출은?" \
  --max-retries 3
```

**출력 예시:**
```
════════════════════════════════════════════════════
  Text-to-SQL Pipeline — Oracle
════════════════════════════════════════════════════
질문: 올해 매출은?

[1/11] Decomposer
  의도: aggregation | 패턴: group_aggregate
[2/11] SchemaSelector
  선택된 테이블: SALES_ORDERS, SALES_ORDER_LINES
[3/11] ValueRetriever
  추출값: year=2024
...
[11/11] ResultOutput
  ✅ 성공

생성된 SQL:
  SELECT SUM(sol.unit_price * sol.ordered_qty)
  FROM sales_orders so
  INNER JOIN sales_order_lines sol ON so.sales_order_id = sol.sales_order_id
  WHERE YEAR(so.order_date) = YEAR(SYSDATE)

결과:
  TOTAL_SALES
  -----------
  1,250,000

결과 피드백 (1~5)
  5=매우좋음  4=좋음  3=보통  2=나쁨  1=매우나쁨  s=건너뛰기
  피드백 > 5
  ✅ 피드백 저장 완료 (매우좋음)
  ✨ 좋은 SQL을 자동 학습 데이터에 반영했습니다 (+1)
```

---

### 7-2. HITL (Human-In-The-Loop) 모드

```bash
python scripts/execution/run_cli.py \
  --db oracle_prod \
  --question "올해 매출은?" \
  --hitl
```

**특징:**
- SQL 생성 후 **실행 전 사용자 검토**
- `y`: 실행
- `n`: 취소
- `e`: SQL 수정
- `f`: 피드백으로 재생성

---

### 7-3. 피드백 자동 학습

```bash
python scripts/execution/run_cli.py \
  --db oracle_prod \
  --question "올해 매출은?"
```

질문 실행 후:
- **5점 평가**: 자동으로 few-shot 학습 데이터에 추가
- **4점 이상**: 도메인 힌트 강화
- **2점 이하**: 오류 패턴 기록 (다음 repair 개선)

---

## 🎯 초기 1회 설정 (First-run)

모든 단계를 한 번에 실행합니다:

```bash
python scripts/operations/run_ops.py first-run \
  --db-id oracle_prod \
  --smoke-question "데이터가 정상인가요?" \
  --run-e2e \
  --catalog data/catalog.json
```

**실행 순서:**
1. ✓ doctor (연결 확인)
2. ✓ prepare (메타데이터 추출)
3. ✓ test (E2E 회귀 테스트)
4. ✓ release (배포 게이트)

완료 시 배포 가능한 상태입니다.

---

## 📱 Streamlit UI 실행 (선택사항)

```bash
streamlit run app.py
```

**접속:**
- http://localhost:8501 에서 웹 인터페이스 접근
- 여러 탭:
  - **Main**: 질문 입력 및 실행
  - **Batch**: 여러 질문 한 번에 처리
  - **History**: 실행 이력 조회
  - **Learn**: 도메인 힌트 관리
  - **Operations**: 메타데이터 관리

---

## 🔑 핵심 명령어 요약표

| 단계 | 명령어 | 목적 | 소요시간 |
|------|--------|------|---------|
| 1 | `check_oracle_connection.py` | 연결 테스트 | 1-2분 |
| 2 | `health_check.py` | 시스템 점검 | 1분 |
| 3 | `run_ops.py doctor` | 진단 | 1-2분 |
| 4 | `run_ops.py prepare` | 메타 추출 | 5-10분 |
| 5 | `run_ops.py daily` | 매일 유지보수 | 10-15분 |
| 6 | `run_ops.py test` | E2E 테스트 | 5-20분 |
| 7 | `run_ops.py release` | 배포 게이트 | 15-30분 |
| 8 | `run_cli.py` | 대화형 모드 | 3-5분/질문 |
| 9 | `app.py` (streamlit) | 웹 UI | 2분 |

---

## ⏱️ 예상 소요 시간

| 작업 | 소요 시간 |
|------|----------|
| 환경 설정 | 5분 |
| 연결 확인 | 2분 |
| 건강 체크 | 1분 |
| Prepare | 5-10분 |
| 첫 질문 (CLI) | 3-5분 |
| E2E 테스트 (50개) | 10-15분 |
| **전체 초기 설정** | **약 30-40분** |

초기 설정 후:
- 매일 `daily` 명령: 10-15분
- CLI 질문 1개: 3-5분
- 웹 UI: 즉시 응답

---

## 🆘 트러블슈팅

### 연결 실패
```
[ERROR] Oracle connection failed: ...
```
- `.env` 파일의 DB 정보 확인
- Oracle 서버 상태 확인
- 방화벽/포트 확인

### LLM 응답 없음
```
[ERROR] LLM endpoint is unreachable
```
- `T2SQL_LLM_BASE_URL` 확인
- LLM 서버 상태 확인
- API 키 확인

### 메타데이터 비어있음
```
[경고] domain_hints 로드 결과가 비어 있습니다.
```
- `prepare` 명령 실행
- `oracle_domain_hints.json` 생성 확인

### 성능 저하
```
[WARN] cycle 10+ health score is still below target.
```
- E2E 카탈로그 추가 (SQL 예제 제공)
- `daily` 명령 여러 회 실행
- 도메인 힌트 수동 편집

---

## 📚 다음 단계

1. **기본 사용**: `run_cli.py` 또는 `app.py`로 질문 실행
2. **성능 개선**: E2E 카탈로그 추가 및 `daily` 반복 실행
3. **고급 설정**: 도메인 힌트 수동 편집 (json 파일)
4. **배포**: `release` 명령으로 배포 준비 확인

---

**시작 준비 완료!** 🚀 1단계부터 차근차근 진행하세요.
