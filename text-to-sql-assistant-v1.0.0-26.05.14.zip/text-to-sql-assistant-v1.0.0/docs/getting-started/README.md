# 시작하기 (Getting Started)

처음 Text-to-SQL 시스템을 사용하시는 분들을 위한 초급 문서입니다.

## 📖 이 폴더의 문서들

### 01_START_HERE.md ⭐ **먼저 읽으세요**
시스템의 개요와 첫 시작 방법을 설명합니다.
- 시스템이 무엇인지
- 필요한 준비물
- 첫 실행 방법

### 02_INDEX.md
전체 문서의 색인과 연결 지도입니다.
- 모든 문서 목록
- 주제별 분류
- 다음 단계 가이드

## 🎯 다음 단계

1. **01_START_HERE.md** 읽기 (5분)
2. **[../operations/01_CLI_GETTING_STARTED.md](../operations/01_CLI_GETTING_STARTED.md)** 읽기 (상세 설정, 15분)
3. **scripts 초기화** 실행
   ```bash
   python scripts/execution/init.py --db-id oracle_prod
   ```

## 🔗 연관 문서

- 상세 설정: [01_CLI_GETTING_STARTED.md](../operations/01_CLI_GETTING_STARTED.md)
- 시스템 이해: [01_PROJECT_STRUCTURE.md](../architecture/01_PROJECT_STRUCTURE.md)
- Scripts 가이드: [scripts/README.md](../../scripts/README.md)

---

**시작**: [01_START_HERE.md](01_START_HERE.md)
