# 아키텍처 (Architecture)

Text-to-SQL 시스템의 설계와 구조를 이해하기 위한 문서들입니다.

## 📖 이 폴더의 문서들

### 01_PROJECT_STRUCTURE.md
프로젝트의 폴더와 파일 구조를 설명합니다.
- src/ - 소스 코드
- scripts/ - 운영 스크립트
- tests/ - 테스트
- docs/ - 문서
- 각 폴더별 역할

### 02_ARCHITECTURE_DIAGRAMS.md
시스템의 다이어그램과 데이터 흐름을 시각화합니다.
- 13단계 LangGraph 파이프라인
- GraphState 데이터 구조
- 각 Agent의 역할

### 03_CODEBASE_GUIDE.md
주요 코드 모듈과 클래스를 설명합니다.
- text2sql.agents - Agent 구현
- text2sql.tools - 도구 (DB, RAG, 실행)
- text2sql.config - 설정 관리
- text2sql.lg - LangGraph 정의

## 🎯 언제 읽나요?

- **시스템을 처음 이해하고 싶을 때** → 01_PROJECT_STRUCTURE.md
- **파이프라인이 어떻게 동작하는지 알고 싶을 때** → 02_ARCHITECTURE_DIAGRAMS.md
- **특정 코드를 찾아 수정하고 싶을 때** → 03_CODEBASE_GUIDE.md

## 🔗 연관 문서

- 초급: [getting-started/01_START_HERE.md](../getting-started/01_START_HERE.md)
- 운영: [operations/README.md](../operations/README.md)
- Scripts: [../../scripts/README.md](../../scripts/README.md)

---

**시작**: [01_PROJECT_STRUCTURE.md](01_PROJECT_STRUCTURE.md)
