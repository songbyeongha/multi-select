# 문서 가이드

이 폴더의 문서들을 역할별로 정리했습니다.

## 📚 읽는 순서

### 🟢 처음 시작하는 경우
1. **[getting-started/01_START_HERE.md](getting-started/01_START_HERE.md)** - 첫 시작하기
2. **[getting-started/02_INDEX.md](getting-started/02_INDEX.md)** - 전체 문서 색인
3. **[operations/01_CLI_GETTING_STARTED.md](operations/01_CLI_GETTING_STARTED.md)** - 상세 CLI 가이드

### 🟡 시스템 이해하고 싶을 때
1. **[architecture/01_PROJECT_STRUCTURE.md](architecture/01_PROJECT_STRUCTURE.md)** - 프로젝트 구조
2. **[architecture/02_ARCHITECTURE_DIAGRAMS.md](architecture/02_ARCHITECTURE_DIAGRAMS.md)** - 시스템 다이어그램
3. **[architecture/03_CODEBASE_GUIDE.md](architecture/03_CODEBASE_GUIDE.md)** - 코드베이스 가이드

### 🟠 매일 운영할 때
1. **[operations/02_OPERATOR_ONE_PAGE.md](operations/02_OPERATOR_ONE_PAGE.md)** - 운영자 한 페이지
2. **[operations/03_DAILY_OPERATIONS_CHECKLIST.md](operations/03_DAILY_OPERATIONS_CHECKLIST.md)** - 일일 체크리스트
3. **[operations/01_CLI_GETTING_STARTED.md](operations/01_CLI_GETTING_STARTED.md)** - CLI 명령어

### 🔴 배포하기 전
1. **[operations/06_RELEASE_CHECKLIST.md](operations/06_RELEASE_CHECKLIST.md)** - 배포 체크리스트
2. **[operations/05_FIRST_PRODUCTION_ATTACH.md](operations/05_FIRST_PRODUCTION_ATTACH.md)** - 첫 배포 가이드

### 🟣 고급 주제
- **[metadata/01_SQL_METADATA_ENRICHMENT.md](metadata/01_SQL_METADATA_ENRICHMENT.md)** - 메타데이터 강화
- **[operations/07_ENDPOINT_USAGE_GUIDE.md](operations/07_ENDPOINT_USAGE_GUIDE.md)** - API 엔드포인트
- **[operations/08_SCRIPT_SELECTION_GUIDE.md](operations/08_SCRIPT_SELECTION_GUIDE.md)** - 스크립트 선택 가이드

## 📁 폴더 구조

### getting-started/ (🌱 초급)
- **01_START_HERE.md** ⭐ 첫 시작하기 (이 문서부터 읽으세요)
- **02_INDEX.md** - 전체 문서 색인

시스템을 처음 사용하는 분들을 위한 문서입니다.

### architecture/ (🏗️ 설계)
- **01_PROJECT_STRUCTURE.md** - 프로젝트 폴더/파일 구조
- **02_ARCHITECTURE_DIAGRAMS.md** - LangGraph 다이어그램, 파이프라인
- **03_CODEBASE_GUIDE.md** - 주요 코드 모듈 설명

시스템의 설계와 구조를 이해하고 싶을 때 읽으세요.

### operations/ (⚙️ 운영)
- **01_CLI_GETTING_STARTED.md** - CLI 초기 설정 가이드
- **02_OPERATOR_ONE_PAGE.md** - 운영자용 한 페이지 요약
- **03_DAILY_OPERATIONS_CHECKLIST.md** - 매일 할 일 체크리스트
- **04_ORACLE_DB_QUICKSTART.md** - Oracle 빠른 시작
- **05_FIRST_PRODUCTION_ATTACH.md** - 첫 배포 가이드
- **06_RELEASE_CHECKLIST.md** - 배포 준비 체크리스트
- **07_ENDPOINT_USAGE_GUIDE.md** - API 엔드포인트 사용법
- **08_SCRIPT_SELECTION_GUIDE.md** - 스크립트 선택 가이드

매일 시스템을 운영하고 배포할 때 필요한 문서들입니다.

### metadata/ (📊 데이터)
- **01_SQL_METADATA_ENRICHMENT.md** - SQL 사례로부터 메타데이터 강화

고급 사용자를 위한 메타데이터 관리 가이드입니다.

## 🎯 빠른 찾기

| 목적 | 문서 |
|------|------|
| 첫 시작 | [getting-started/01_START_HERE.md](getting-started/01_START_HERE.md) |
| 전체 색인 | [getting-started/02_INDEX.md](getting-started/02_INDEX.md) |
| 프로젝트 구조 | [architecture/01_PROJECT_STRUCTURE.md](architecture/01_PROJECT_STRUCTURE.md) |
| 시스템 다이어그램 | [architecture/02_ARCHITECTURE_DIAGRAMS.md](architecture/02_ARCHITECTURE_DIAGRAMS.md) |
| CLI 설정 | [operations/01_CLI_GETTING_STARTED.md](operations/01_CLI_GETTING_STARTED.md) |
| 일일 체크리스트 | [operations/03_DAILY_OPERATIONS_CHECKLIST.md](operations/03_DAILY_OPERATIONS_CHECKLIST.md) |
| 배포 가이드 | [operations/05_FIRST_PRODUCTION_ATTACH.md](operations/05_FIRST_PRODUCTION_ATTACH.md) |
| 메타데이터 | [metadata/01_SQL_METADATA_ENRICHMENT.md](metadata/01_SQL_METADATA_ENRICHMENT.md) |

## 📖 연관 문서

- **Scripts 가이드**: [`scripts/README.md`](../scripts/README.md)
- **Scripts 폴더별**: [`scripts/`](../scripts/)

---

**시작하기**: [getting-started/01_START_HERE.md](getting-started/01_START_HERE.md)
