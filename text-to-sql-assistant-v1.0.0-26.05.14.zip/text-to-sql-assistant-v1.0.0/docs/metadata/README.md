# 메타데이터 (Metadata)

SQL 사례로부터 메타데이터를 강화하는 고급 주제입니다.

## 📖 이 폴더의 문서들

### 01_SQL_METADATA_ENRICHMENT.md
SQL 쿼리 사례 모음으로부터 메타데이터와 도메인 힌트를 자동으로 강화합니다.

**내용:**
- 메타데이터 강화 프로세스
- 관계 추론 알고리즘
- Few-shot 예제 자동 생성
- 도메인 힌트 추출

## 🎯 언제 사용하나요?

### 필요한 경우
- 시스템의 정확도를 개선하고 싶을 때
- 기존 SQL 쿼리 사례가 많을 때
- 도메인 특화 키워드를 자동으로 학습하고 싶을 때

### 불필요한 경우
- 시스템이 정상 작동할 때
- SQL 사례가 5개 미만일 때

## 📊 관련 스크립트

```bash
# 메타데이터 강화
python scripts/metadata/enrich_metadata_from_sql.py \
  --db-id oracle_prod \
  --catalog data/catalog.json
```

자세한 내용: [scripts/metadata/README.md](../../scripts/metadata/README.md)

## 🔗 연관 문서

- Scripts 메타데이터: [scripts/metadata/README.md](../../scripts/metadata/README.md)
- 운영 가이드: [operations/01_CLI_GETTING_STARTED.md](../operations/01_CLI_GETTING_STARTED.md)

---

**시작**: [01_SQL_METADATA_ENRICHMENT.md](01_SQL_METADATA_ENRICHMENT.md)
