"""Root conftest — sys.path 설정 + 공용 fixture."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


@pytest.fixture
def project_root() -> Path:
    return Path(__file__).parent.parent


@pytest.fixture
def sample_state() -> dict:
    return {
        "question": "총 매출을 알려줘",
        "database_id": "test_db",
        "db_path": ":memory:",
        "dialect": "sqlite",
        "trace": [],
        "current_date": "2024-01-15",
        "current_year": 2024,
        "current_month": 1,
    }
