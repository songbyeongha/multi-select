"""Unit test conftest — LLM/DB/RAG mock fixture."""
from __future__ import annotations

import pytest
from unittest.mock import MagicMock


@pytest.fixture
def mock_llm():
    """LLM 호출 차단용 MagicMock."""
    llm = MagicMock()
    llm.invoke.return_value = MagicMock(content='{"intent": "aggregate", "query_pattern": "simple"}')
    return llm


@pytest.fixture
def mock_executor():
    """DB 실행 차단용 MagicMock — ExecReport(ok=True) 반환."""
    from text2sql.lg.state import ExecReport
    executor = MagicMock()
    executor.execute.return_value = ExecReport(ok=True, rows_preview=[], row_count=0)
    return executor


@pytest.fixture
def mock_rag():
    """schema_rag 조회 차단용 MagicMock — 빈 리스트 반환."""
    rag = MagicMock()
    rag.search.return_value = []
    return rag


@pytest.fixture
def minimal_state() -> dict:
    """파이프라인 노드 테스트용 최소 GraphState."""
    return {
        "question": "총 매출을 알려줘",
        "database_id": "test_db",
        "db_path": ":memory:",
        "dialect": "sqlite",
        "trace": [],
        "current_date": "2024-01-15",
        "current_year": 2024,
        "current_month": 1,
        "sub_questions": [],
        "intent": "",
        "query_pattern": "simple",
        "extracted_values": {},
        "full_schema": [],
        "selected_tables": [],
        "selected_columns": {},
        "schema_text": "",
        "selector_rationale": "",
        "join_plan": [],
        "join_rationale": "",
        "candidates": [],
        "guard_passed": False,
        "ut_passed": False,
        "exec_report": None,
        "preview_sql": "",
        "judge_accepted": False,
        "judge_rationale": "",
        "selected_sql": "",
        "repair_count": 0,
        "max_retries": 3,
        "last_error_type": None,
        "last_error_msg": None,
        "use_fast_only": False,
        "hitl_enabled": False,
        "token_usage": None,
        "final_sql": "",
        "final_result": None,
        "result_summary": "",
        "success": False,
        "error": None,
    }
