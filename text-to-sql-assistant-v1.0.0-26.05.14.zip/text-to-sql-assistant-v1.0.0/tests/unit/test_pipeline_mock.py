"""1~7단계 파이프라인 노드 mock 실행 검증.

LLM/DB/RAG는 MagicMock으로 대체하여 Oracle 없이 실행.
Design Ref: §3.6 — Mock 격리 전략
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from text2sql.lg.state import SQLCandidate


# ═══════════════════════════════════════════════════════════════
# 1단계: decomposer
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_decomposer_mock(minimal_state: dict) -> None:
    """LLM mock + SchemaReader mock 시 decomposer가 state를 반환."""
    mock_response = MagicMock()
    mock_response.content = '{"intent": "aggregate", "query_pattern": "simple", "sub_questions": []}'

    with patch("text2sql.agents.decomposer.get_llm_fast") as mock_llm, \
         patch("text2sql.agents.decomposer.SchemaReader.tables", return_value=[]):
        mock_llm.return_value.invoke.return_value = mock_response

        from text2sql.agents.decomposer import node_decomposer
        result = node_decomposer(minimal_state)

    assert isinstance(result, dict)
    assert "trace" in result


# ═══════════════════════════════════════════════════════════════
# 2단계: schema_selector
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_schema_selector_mock(minimal_state: dict) -> None:
    """schema_metadata JSON 기반으로 Oracle 없이 schema_selector 실행."""
    mock_response = MagicMock()
    mock_response.content = '{"selected_tables": [], "selected_columns": {}, "rationale": "test"}'

    fake_meta = {"tables": {}, "relationships": []}

    with patch("text2sql.agents.schema_nodes.get_llm_fast") as mock_llm, \
         patch("text2sql.agents.schema_nodes.SchemaSelector") as mock_selector_cls, \
         patch("text2sql.agents.schema_nodes.get_settings") as mock_settings, \
         patch("text2sql.agents.schema_nodes.SchemaReader.full_schema", return_value=[]):

        cfg = MagicMock()
        cfg.schema_metadata.return_value = fake_meta
        cfg.domain_hints.return_value = {}
        cfg.db.dialect = "sqlite"
        cfg.db.include_table_list.return_value = []
        cfg.db.exclude_table_list.return_value = []
        cfg.pipeline.num_candidates = 3
        mock_settings.return_value = cfg

        mock_selector = MagicMock()
        mock_selector.search.return_value = []
        mock_selector_cls.return_value = mock_selector
        mock_llm.return_value.invoke.return_value = mock_response

        from text2sql.agents.schema_nodes import node_schema_selector
        result = node_schema_selector(minimal_state)

    assert isinstance(result, dict)
    assert "selected_tables" in result


# ═══════════════════════════════════════════════════════════════
# 3단계: value_retriever
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_value_retriever_mock(minimal_state: dict) -> None:
    """filters 없을 때 value_retriever가 DB 없이 통과."""
    # selected_tables를 채우고 extracted_values.filters를 비워 DB 접근 차단
    state = {
        **minimal_state,
        "schema_text": "",
        "selected_tables": ["orders"],
        "extracted_values": {"filters": {}},
    }
    from text2sql.agents.decomposer import node_value_retriever
    result = node_value_retriever(state)
    assert isinstance(result, dict)
    assert "extracted_values" in result


# ═══════════════════════════════════════════════════════════════
# 4단계: join_planner
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_join_planner_mock(minimal_state: dict) -> None:
    """join_planner가 join_plan 필드를 가진 state를 반환."""
    mock_response = MagicMock()
    mock_response.content = '{"join_plan": [], "rationale": "no join needed"}'

    with patch("text2sql.agents.schema_nodes.get_llm_fast") as mock_llm:
        mock_llm.return_value.invoke.return_value = mock_response

        from text2sql.agents.schema_nodes import node_join_planner
        result = node_join_planner({
            **minimal_state,
            "selected_tables": [],
            "full_schema": [],
            "schema_text": "",
        })

    assert isinstance(result, dict)
    assert "join_plan" in result


# ═══════════════════════════════════════════════════════════════
# 5단계: candidate_generator
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_candidate_gen_mock(minimal_state: dict) -> None:
    """LLM mock 시 candidate_generator가 candidates 리스트를 반환."""
    mock_response = MagicMock()
    mock_response.content = "SELECT COUNT(*) FROM orders FETCH FIRST 50 ROWS ONLY"

    with patch("text2sql.agents.generation_nodes.get_llm") as mock_llm, \
         patch("text2sql.agents.generation_nodes.get_llm_fast") as mock_llm_fast, \
         patch("text2sql.agents.generation_nodes.get_learner") as mock_learner:

        mock_llm.return_value.invoke.return_value = mock_response
        mock_llm_fast.return_value.invoke.return_value = mock_response
        mock_learner.return_value.get_few_shots.return_value = []
        mock_learner.return_value.get_keyword_map.return_value = {}

        from text2sql.agents.generation_nodes import node_candidate_generator
        result = node_candidate_generator({
            **minimal_state,
            "schema_text": "## orders\n  id NUMBER [PK]",
            "selected_tables": ["orders"],
            "join_plan": [],
        })

    assert isinstance(result, dict)
    assert "candidates" in result
    assert isinstance(result["candidates"], list)


# ═══════════════════════════════════════════════════════════════
# 6단계: sql_postprocess
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_sql_postprocess_mock(minimal_state: dict) -> None:
    """유효한 candidates가 있을 때 sql_postprocess가 통과."""
    candidate = SQLCandidate(
        sql="SELECT COUNT(*) FROM orders",
        strategy="conservative",
        is_valid=True,
    )
    from text2sql.agents.generation_nodes import node_sql_postprocess
    result = node_sql_postprocess({**minimal_state, "candidates": [candidate]})
    assert isinstance(result, dict)
    assert "candidates" in result


# ═══════════════════════════════════════════════════════════════
# 7단계: guardrails — SELECT 통과 / DML 차단
# ═══════════════════════════════════════════════════════════════

@pytest.mark.unit
def test_node_guardrails_select_only(minimal_state: dict) -> None:
    """SELECT SQL은 guardrails를 통과해야 한다."""
    candidate = SQLCandidate(
        sql="SELECT COUNT(*) FROM invoice FETCH FIRST 50 ROWS ONLY",
        strategy="conservative",
        is_valid=True,
    )
    from text2sql.agents.validation_nodes import node_guardrails
    result = node_guardrails({
        **minimal_state,
        "candidates": [candidate],
        "full_schema": [],
        "selected_tables": ["invoice"],
    })
    assert result["guard_passed"] is True


@pytest.mark.unit
def test_node_guardrails_dml_blocked(minimal_state: dict) -> None:
    """DELETE SQL은 guardrails에서 차단되어야 한다."""
    candidate = SQLCandidate(
        sql="DELETE FROM invoice WHERE 1=1",
        strategy="conservative",
        is_valid=True,
    )
    from text2sql.agents.validation_nodes import node_guardrails
    result = node_guardrails({
        **minimal_state,
        "candidates": [candidate],
        "full_schema": [],
        "selected_tables": ["invoice"],
    })
    assert result["guard_passed"] is False
