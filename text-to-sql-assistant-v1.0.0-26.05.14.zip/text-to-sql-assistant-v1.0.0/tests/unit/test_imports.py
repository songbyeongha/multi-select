"""전체 핵심 모듈 import 검증 — parametrize로 모듈별 독립 실패 추적."""
import importlib

import pytest

# Design Ref: §3.4 — 핵심 16개 모듈 검증
MODULES = [
    "text2sql.lg.graph",
    "text2sql.lg.state",
    "text2sql.config.settings",
    "text2sql.agents.nodes",
    "text2sql.agents.decomposer",
    "text2sql.agents.schema_nodes",
    "text2sql.agents.generation_nodes",
    "text2sql.agents.validation_nodes",
    "text2sql.agents.repair_output",
    "text2sql.agents.guardrail_rules",
    "text2sql.tools.executor",
    "text2sql.tools.guardrails",
    "text2sql.tools.sql_postprocess",
    "text2sql.rag.schema_rag",
    "text2sql.feedback.store",
    "text2sql.ui.pipeline",
]


@pytest.mark.unit
@pytest.mark.parametrize("module_name", MODULES)
def test_module_imports(module_name: str) -> None:
    """각 모듈이 import 오류 없이 로드되는지 확인."""
    try:
        importlib.import_module(module_name)
    except ImportError as e:
        pytest.fail(f"ImportError in {module_name}: {e}")
    except Exception as e:
        pytest.fail(f"Unexpected error in {module_name}: {e}")
