"""GraphState 구조 + build_graph() 반환 객체 검증."""
import pytest
from langgraph.graph import StateGraph


@pytest.mark.unit
class TestGraphState:
    """GraphState TypedDict 필드 존재 확인."""

    def test_required_fields_exist(self) -> None:
        # Design Ref: §3.5 — GraphState 필수 필드 검증
        from text2sql.lg.state import GraphState
        hints = GraphState.__annotations__
        required = [
            "question", "database_id", "db_path",
            "candidates", "guard_passed", "ut_passed",
            "exec_report", "judge_accepted", "selected_sql",
            "repair_count", "max_retries",
            "final_sql", "final_result", "success",
        ]
        for field in required:
            assert field in hints, f"GraphState에 필수 필드 없음: {field}"

    def test_new_state_defaults(self) -> None:
        """new_state() 기본값 타입 검증."""
        from text2sql.lg.state import new_state
        state = new_state(
            question="테스트 질문",
            database_id="test",
            db_path=":memory:",
        )
        assert isinstance(state["candidates"], list)
        assert isinstance(state["trace"], list)
        assert state["guard_passed"] is False
        assert state["repair_count"] == 0
        assert state["success"] is False


@pytest.mark.unit
class TestBuildGraph:
    """build_graph() 반환 객체 검증."""

    def test_returns_state_graph(self) -> None:
        # Design Ref: §3.5 — build_graph 반환 타입
        from text2sql.lg.graph import build_graph
        g = build_graph()
        assert isinstance(g, StateGraph)

    def test_compiled_graph_callable(self) -> None:
        """get_compiled_graph() 반환 객체가 callable."""
        from text2sql.lg.graph import get_compiled_graph
        compiled = get_compiled_graph()
        assert callable(compiled.invoke)

    def test_graph_nodes_registered(self) -> None:
        """13개 노드 이름이 모두 등록되어 있는지 확인."""
        from text2sql.lg.graph import build_graph
        g = build_graph()
        registered = set(g.nodes.keys())
        expected = {
            "decomposer", "schema_selector", "value_retriever",
            "join_planner", "candidate_gen", "sql_postprocess",
            "guardrails", "unit_tester", "execute_preview",
            "judge", "repair", "result_output", "safe_fail",
        }
        missing = expected - registered
        assert not missing, f"미등록 노드: {missing}"
