# Integration Tests

Oracle DB 연결이 필요한 테스트입니다.

## 실행 조건

아래 환경변수가 설정된 경우에만 실행하세요:

```
T2SQL_DB_HOST=<oracle-host>
T2SQL_DB_USER=<user>
T2SQL_DB_PASSWORD=<password>
T2SQL_DB_SERVICE_NAME=<service>
```

## 실행 방법

```bash
pytest tests/integration/ -v -m integration
```

Oracle 환경변수가 없으면 `pytest.skip()`으로 자동 건너뜁니다.
