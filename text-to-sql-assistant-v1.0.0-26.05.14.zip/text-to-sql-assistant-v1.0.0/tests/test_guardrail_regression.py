"""Regression tests for guardrail_rules._DEFAULT_RULES.

Each test asserts the before/after equivalence guarantee promised when the
helper functions in validation_nodes.py were replaced by Rule classes.
"""
from __future__ import annotations

import pytest

from text2sql.agents.guardrail_rules import (
    GroupLabelRule,
    PercentileRule,
    RuleResult,
    SalesEntityRule,
    TemporalFilterRule,
    YoyCalculationRule,
    _DEFAULT_RULES,
)


# ── helpers ──────────────────────────────────────────────────────────────────

def _state(**kwargs):
    base = {
        "current_date": "2024-01-15",
        "current_year": 2024,
        "current_month": 1,
        "dialect": "sqlite",
    }
    base.update(kwargs)
    return base


def check(rule, question: str, sql: str, **state_kw) -> RuleResult:
    return rule.check(question, sql, _state(**state_kw))


# ═══════════════════════════════════════════════════════════════
# TemporalFilterRule
# ═══════════════════════════════════════════════════════════════

class TestTemporalFilterRule:
    rule = TemporalFilterRule()

    def test_pass_no_date_in_sql(self):
        r = check(self.rule, "총 매출을 알려줘", "SELECT SUM(total) FROM invoice")
        assert not r.violated

    def test_pass_explicit_temporal_phrase(self):
        r = check(self.rule, "올해 매출은?",
                  "SELECT SUM(total) FROM invoice WHERE strftime('%Y', invoicedate) = '2024'")
        assert not r.violated

    def test_violated_implicit_current_date(self):
        # "최근"은 명시적 시간 표현 → 통과. date('now') 없는 질문에서만 차단.
        r_pass = check(self.rule, "최근 매출을 알려줘",
                       "SELECT * FROM invoice WHERE invoicedate >= date('now', '-30 days')")
        assert not r_pass.violated

        r_violated = check(self.rule, "매출을 알려줘",
                           "SELECT * FROM invoice WHERE invoicedate >= date('now', '-30 days')")
        assert r_violated.violated

    def test_violated_literal_current_year(self):
        r = check(self.rule, "매출을 알려줘",
                  "SELECT * FROM invoice WHERE strftime('%Y', invoicedate) = '2024'")
        assert r.violated

    def test_pass_no_where_clause(self):
        r = check(self.rule, "총 매출", "SELECT SUM(total) FROM invoice")
        assert not r.violated

    def test_pass_explicit_date_range_in_question(self):
        r = check(self.rule, "2023년 매출을 알려줘",
                  "SELECT SUM(total) FROM invoice WHERE strftime('%Y', invoicedate)='2023'")
        assert not r.violated


# ═══════════════════════════════════════════════════════════════
# PercentileRule
# ═══════════════════════════════════════════════════════════════

class TestPercentileRule:
    rule = PercentileRule()

    def test_pass_no_percentile_question(self):
        r = check(self.rule, "매출 상위 고객 목록", "SELECT customer_id FROM invoice")
        assert not r.violated

    def test_pass_percent_rank_used(self):
        sql = ("SELECT customer_id FROM ("
               "SELECT customer_id, PERCENT_RANK() OVER (ORDER BY total DESC) pr "
               "FROM invoice) WHERE pr <= 0.05")
        r = check(self.rule, "상위 5% 고객", sql)
        assert not r.violated

    def test_violated_cume_dist_with_aggregate(self):
        sql = ("SELECT customer_id, count(invoice_id) FROM invoice "
               "GROUP BY customer_id HAVING cume_dist() <= 0.1")
        r = check(self.rule, "상위 10% 고객 수", sql)
        assert r.violated

    def test_pass_no_cume_dist(self):
        r = check(self.rule, "상위 10% 고객 매출",
                  "SELECT customer_id, sum(total) FROM invoice GROUP BY customer_id")
        assert not r.violated


# ═══════════════════════════════════════════════════════════════
# GroupLabelRule (SQLite dialect — Chinook hints)
# ═══════════════════════════════════════════════════════════════

class TestGroupLabelRule:
    rule = GroupLabelRule()

    def test_pass_artist_label_present(self):
        sql = "SELECT artist, count(*) FROM track GROUP BY artist"
        r = check(self.rule, "아티스트별 트랙 수", sql)
        assert not r.violated

    def test_violated_artist_label_missing(self):
        sql = "SELECT count(*) FROM track GROUP BY artist"
        r = check(self.rule, "아티스트별 트랙 수", sql)
        assert r.violated

    def test_pass_no_group_keyword_in_question(self):
        sql = "SELECT count(*) FROM track"
        r = check(self.rule, "총 트랙 수", sql)
        assert not r.violated

    def test_pass_oracle_no_hints(self):
        # Oracle dialect with no domain_hints → validation disabled
        r = self.rule.check("아티스트별 트랙 수", "SELECT count(*) FROM track",
                            _state(dialect="oracle"))
        assert not r.violated


# ═══════════════════════════════════════════════════════════════
# YoyCalculationRule
# ═══════════════════════════════════════════════════════════════

class TestYoyCalculationRule:
    rule = YoyCalculationRule()

    def test_pass_no_yoy_question(self):
        r = check(self.rule, "월별 매출", "SELECT month, sum(total) FROM invoice GROUP BY month")
        assert not r.violated

    def test_violated_sparse_lag(self):
        sql = ("SELECT year, sum_total, lag(sum_total) OVER (ORDER BY year) lag_total "
               "FROM annual_sales")
        r = check(self.rule, "전년 대비 매출 성장률", sql)
        assert r.violated

    def test_pass_lag_with_year_minus1(self):
        sql = ("SELECT year, sum_total, lag(sum_total) OVER (ORDER BY year) lag_total "
               "FROM annual_sales WHERE year >= current_year - 1")
        r = check(self.rule, "전년 대비 매출 성장률", sql)
        assert not r.violated

    def test_violated_string_year_arithmetic(self):
        sql = ("SELECT strftime('%Y', invoicedate) - 1 AS prev_year, sum(total) "
               "FROM invoice GROUP BY prev_year")
        r = check(self.rule, "전년 대비 성장률", sql)
        assert r.violated

    def test_pass_cast_strftime(self):
        sql = ("SELECT CAST(strftime('%Y', invoicedate) AS INTEGER) - 1 AS prev_year "
               "FROM invoice")
        r = check(self.rule, "전년 대비 성장률", sql)
        assert not r.violated


# ═══════════════════════════════════════════════════════════════
# SalesEntityRule
# ═══════════════════════════════════════════════════════════════

class TestSalesEntityRule:
    rule = SalesEntityRule()

    def test_pass_inner_join_sales(self):
        sql = ("SELECT c.customerid, sum(i.total) FROM customer c "
               "INNER JOIN invoice i ON c.customerid = i.customerid "
               "GROUP BY c.customerid")
        r = check(self.rule, "고객별 매출", sql)
        assert not r.violated

    def test_pass_zero_sales_question(self):
        sql = ("SELECT c.customerid FROM customer c "
               "LEFT JOIN invoiceline il ON c.customerid = il.customerid "
               "WHERE il.invoicelineid IS NULL")
        r = check(self.rule, "한 번도 구매되지 않은 고객", sql)
        assert not r.violated

    def test_violated_left_join_without_filter(self):
        sql = ("SELECT c.customerid FROM customer c "
               "LEFT JOIN invoiceline il ON c.customerid = il.customerid")
        r = check(self.rule, "판매 기준 고객 목록", sql)
        assert r.violated

    def test_pass_left_join_with_positive_filter(self):
        sql = ("SELECT c.customerid FROM customer c "
               "LEFT JOIN invoiceline il ON c.customerid = il.customerid "
               "WHERE il.invoicelineid IS NOT NULL")
        r = check(self.rule, "판매된 고객 목록", sql)
        assert not r.violated


# ═══════════════════════════════════════════════════════════════
# _DEFAULT_RULES list
# ═══════════════════════════════════════════════════════════════

def test_default_rules_count():
    assert len(_DEFAULT_RULES) == 5


def test_default_rules_all_implement_check():
    state = _state()
    for rule in _DEFAULT_RULES:
        result = rule.check("테스트 질문", "SELECT 1 FROM dual", state)
        assert isinstance(result, RuleResult)
