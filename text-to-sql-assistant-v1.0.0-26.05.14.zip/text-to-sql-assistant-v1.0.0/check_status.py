#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Quick health check for LLM, Embedding, and Oracle DB."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.config.settings import get_settings
from text2sql.tools.runtime_checks import probe_llm_endpoint, probe_embedding_endpoint

def main():
    settings = get_settings()

    print("\n" + "=" * 70)
    print("HEALTH CHECK: LLM + EMBEDDING + ORACLE")
    print("=" * 70 + "\n")

    # 1. LLM
    print("[1] LLM (Ollama)")
    print("-" * 70)
    llm = probe_llm_endpoint(settings, timeout_sec=10)
    print(f"Status:   {'OK' if llm.get('ok') else 'FAILED'}")
    print(f"Provider: {llm.get('provider')}")
    print(f"URL:      {llm.get('url')}")
    print(f"Message:  {llm.get('message')}")

    # 2. Embedding
    print("\n[2] Embedding Model")
    print("-" * 70)
    embedding = probe_embedding_endpoint(settings, timeout_sec=10)
    print(f"Status:   {'OK' if embedding.get('ok') else 'FAILED'}")
    print(f"Provider: {embedding.get('provider')}")
    print(f"Model:    {embedding.get('model')}")
    print(f"Message:  {embedding.get('message')}")

    # 3. Oracle
    print("\n[3] Oracle Database")
    print("-" * 70)
    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter

        adapter = OracleAdapter(
            host=settings.db.host,
            port=settings.db.port,
            service_name=settings.db.service_name,
            dsn=settings.db.dsn,
            user=settings.db.user,
            password=settings.db.password,
            schema=settings.db.schema,
            connect_timeout_sec=settings.db.connect_timeout_sec,
            query_timeout_ms=settings.guard.timeout_ms,
            read_only=settings.db.read_only,
        )
        conn = adapter.test_connection()

        print(f"Status:  {'OK' if conn.get('ok') else 'FAILED'}")
        print(f"Message: {conn.get('message')}")

        if conn.get("ok"):
            try:
                tables = adapter.list_tables()
                print(f"Tables:  {len(tables)} found")
                if tables:
                    print(f"Sample:  {', '.join(tables[:3])}")
            except Exception as e:
                print(f"Error listing tables: {e}")

        adapter.close()
    except Exception as e:
        print(f"Status:  FAILED")
        print(f"Error:   {e}")

    print("\n" + "=" * 70 + "\n")


if __name__ == "__main__":
    main()
