# testing/ - 테스트 및 검증

## 개요

E2E 회귀 테스트, 카탈로그 검증, 배포 준비도 확인.
**일반적으로 `init.py`가 자동 처리. 고급 사용자용.**

## 스크립트

### run_e2e_suite.py

테스트 카탈로그에 대해 E2E 회귀 테스트를 실행합니다.

```bash
python scripts/testing/run_e2e_suite.py \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --report logs/e2e_report.json
```

**기능:**
- 카탈로그에서 테스트 케이스 로드
- 각 질문에 대해 SQL 생성
- 기대값과 비교
- 통과/실패 보고

### validate_query_catalog.py

테스트 카탈로그의 구조와 내용을 검증합니다.

```bash
python scripts/testing/validate_query_catalog.py \
  --catalog data/catalog.json
```

**확인 항목:**
- JSON 스키마 유효성
- 필수 필드 (case_id, question, expected_sql)
- SQL 문법
- 도메인 태그

### oracle_release_gate.py

배포 준비도를 종합적으로 확인합니다.

```bash
python scripts/testing/oracle_release_gate.py \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --run-e2e \
  --run-pytest
```

**확인 항목:**
- E2E 회귀 테스트
- 단위 테스트 (pytest)
- 코드 품질 (vulture)
- 전체 점수 임계값

## 테스트 카탈로그 준비

`data/catalog.json` 예시:

```json
[
  {
    "case_id": "001",
    "question": "올해 매출은?",
    "expected_sql": "SELECT SUM(amount) FROM sales WHERE YEAR(order_date)=YEAR(SYSDATE)",
    "domain": "sales",
    "difficulty": "easy"
  },
  {
    "case_id": "002",
    "question": "공장별 생산량",
    "expected_sql": "SELECT plant_id, SUM(qty) FROM production GROUP BY plant_id",
    "domain": "manufacturing",
    "difficulty": "medium"
  }
]
```

## 사용 순서

1. **카탈로그 준비** (선택사항)
   ```bash
   # data/catalog.json 생성
   ```

2. **카탈로그 검증**
   ```bash
   python scripts/testing/validate_query_catalog.py --catalog data/catalog.json
   ```

3. **E2E 테스트 실행**
   ```bash
   python scripts/testing/run_e2e_suite.py \
     --db-id oracle_prod --catalog data/catalog.json
   ```

4. **배포 준비도 확인**
   ```bash
   python scripts/testing/oracle_release_gate.py \
     --db-id oracle_prod --catalog data/catalog.json --run-pytest
   ```

또는 통합 도구 사용:
```bash
python scripts/operations/run_ops.py test --db-id oracle_prod --catalog data/catalog.json
```

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md)
