#!/usr/bin/env python3
"""Validate a harness query catalog for E2E and regression usage."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))

# Windows cp949 호환: UTF-8 stdout/stderr 강제
for _s in ("stdout", "stderr"):
    _r = getattr(getattr(sys, _s, None), "reconfigure", None)
    if callable(_r):
        try: _r(encoding="utf-8")
        except Exception: pass


def parse_args():
    parser = argparse.ArgumentParser(description="Validate a Text-to-SQL query catalog")
    parser.add_argument("--catalog", required=True, help="Catalog path")
    parser.add_argument("--report", default="", help="Optional JSON report output path")
    parser.add_argument("--fail-on-warnings", action="store_true", help="Treat warnings as failures")
    return parser.parse_args()


def main():
    from text2sql.tools.harness_catalog import load_catalog_cases, validate_catalog_cases

    args = parse_args()
    catalog_path = Path(args.catalog)
    if not catalog_path.is_absolute():
        catalog_path = ROOT / catalog_path

    cases = load_catalog_cases(catalog_path)
    report = validate_catalog_cases(cases)
    print(f"catalog={catalog_path}")
    print(f"total={report['total']}")
    print(f"errors={len(report['errors'])}")
    print(f"warnings={len(report['warnings'])}")
    print(f"domains={report['coverage']['domains']}")
    print(f"tags={report['coverage']['tags']}")
    print(f"difficulties={report['coverage']['difficulties']}")

    if args.report:
        report_path = Path(args.report)
        if not report_path.is_absolute():
            report_path = ROOT / report_path
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"report={report_path}")

    if report["errors"]:
        for item in report["errors"]:
            print(f"[ERROR] {item}")
        sys.exit(2)

    if report["warnings"]:
        for item in report["warnings"]:
            print(f"[WARN] {item}")
        if args.fail_on_warnings:
            sys.exit(3)


if __name__ == "__main__":
    main()
