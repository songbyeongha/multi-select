# metadata/ - 메타데이터 관리

## 개요

Oracle 스키마 메타데이터를 추출하고 SQL 사례로부터 강화합니다.
**고급 사용자용. 일반적으로 `init.py`가 자동 처리.**

## 스크립트

### export_oracle_metadata.py

Oracle 데이터베이스에서 스키마 메타데이터를 추출합니다.

```bash
python scripts/metadata/export_oracle_metadata.py --db-id oracle_prod
```

**옵션:**
```bash
--db-id ID                데이터베이스 ID
--output PATH             메타데이터 저장 경로
--samples N               샘플 데이터 수 (기본값: 3)
```

**생성 파일:**
- `src/text2sql/config/oracle_metadata.json` (원본)
- `src/text2sql/config/oracle_metadata_manual.json` (수동 편집용 overlay)
- `src/text2sql/config/oracle_domain_hints.json` (키워드 매핑)
- `src/text2sql/config/oracle_domain_hints_manual.json` (수동 추가)

### enrich_metadata_from_sql.py

SQL 사례 모음(카탈로그)으로부터 메타데이터와 도메인 힌트를 강화합니다.

```bash
python scripts/metadata/enrich_metadata_from_sql.py \
  --db-id oracle_prod \
  --catalog data/catalog.json
```

**옵션:**
```bash
--db-id ID                데이터베이스 ID
--catalog PATH            테스트 카탈로그 경로
--output PATH             출력 경로
```

**기능:**
- JOIN 패턴에서 관계 추론
- 컬럼 사용 통계 추출
- Few-shot 예제 생성
- 도메인 힌트 자동 생성

## 사용 순서

1. **export_oracle_metadata.py** 실행
   ```bash
   python scripts/metadata/export_oracle_metadata.py --db-id oracle_prod
   ```

2. **enrich_metadata_from_sql.py** 실행 (카탈로그 있으면)
   ```bash
   python scripts/metadata/enrich_metadata_from_sql.py \
     --db-id oracle_prod --catalog data/catalog.json
   ```

3. **verify** 진단 도구로 확인
   ```bash
   python scripts/diagnostics/check_domain_hints.py --db-id oracle_prod
   ```

## 메타데이터 파일

- **oracle_metadata.json** - 자동 생성, 수정 금지
- **oracle_metadata_manual.json** - 수동 편집 가능 (테이블 설명 추가, 테이블 제외 등)
- **oracle_domain_hints.json** - 자동 생성, 키워드 매핑
- **oracle_domain_hints_manual.json** - 수동 편집 가능

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md)
