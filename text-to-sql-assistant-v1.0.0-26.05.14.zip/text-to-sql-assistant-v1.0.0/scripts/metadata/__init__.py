"""Metadata extraction and enrichment tools."""
