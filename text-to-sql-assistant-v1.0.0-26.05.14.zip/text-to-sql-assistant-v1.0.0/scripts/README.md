# Scripts 폴더 가이드

## 🚀 한 번에 초기 세팅하기 (첫 시작 시)

### 1단계: `.env` 파일 생성
프로젝트 root에 `.env` 파일을 만들고 다음을 입력합니다:

```bash
# Oracle 설정
T2SQL_DB_DIALECT=oracle
T2SQL_DB_HOST=<호스트>
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=<서비스명>
T2SQL_DB_USER=<사용자>
T2SQL_DB_PASSWORD=<비밀번호>
T2SQL_DB_SCHEMA=<스키마>

# LLM 설정
T2SQL_LLM_PROVIDER=openai_compatible
T2SQL_LLM_BASE_URL=<API 주소>
T2SQL_LLM_API_KEY=<API 키>
T2SQL_LLM_MODEL_PRIMARY=gpt-4
T2SQL_LLM_TIMEOUT_SEC=60
```

자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../docs/operations/01_CLI_GETTING_STARTED.md) 1단계 참고

### 2단계: 초기화 실행 (자동으로 모든 단계 수행)

```bash
python scripts/execution/init.py --db-id oracle_prod
```

**실행 내용:**
1. ✓ Oracle 연결 확인
2. ✓ 시스템 상태 점검
3. ✓ 메타데이터 추출
4. ⏭️ E2E 테스트 (카탈로그 있으면 자동 실행)
5. ⏭️ 배포 게이트 (선택사항)

완료되면 사용할 준비가 됩니다!

### 3단계: 첫 질문 실행

```bash
python scripts/execution/run_cli.py --db oracle_prod -q "올해 매출은?"
```

---

## 📋 문서 읽는 순서

### 처음 사용하는 경우
1. **이 문서** (README.md) - 초기 세팅 방법
2. [`docs/operations/01_CLI_GETTING_STARTED.md`](../docs/operations/01_CLI_GETTING_STARTED.md) - 상세 설정 및 트러블슈팅

### 자주 사용하는 경우
- `scripts/execution/` → CLI로 질문 실행
- `scripts/operations/` → 매일 유지보수

### 고급 사용 (성능 개선)
1. `scripts/metadata/` → 메타데이터 추출/강화
2. `scripts/testing/` → E2E 테스트로 검증
3. `scripts/diagnostics/` → 문제 진단

---

## 📁 폴더 구조 및 역할

### `execution/` - 실행 및 초기화
- **init.py** ⭐ **한 번에 초기 세팅** (가장 먼저 실행)
- **run_cli.py** - 일상적으로 질문 입력

```bash
# 초기 세팅
python scripts/execution/init.py --db-id oracle_prod

# 매일 사용
python scripts/execution/run_cli.py --db oracle_prod -q "질문"
```

### `diagnostics/` - 문제 진단
Oracle 연결, 시스템 상태, 도메인 힌트 확인

```bash
python scripts/diagnostics/check_oracle_connection.py
python scripts/diagnostics/health_check.py
python scripts/diagnostics/check_domain_hints.py --db-id oracle_prod
```

### `operations/` - 일상 운영
일반적으로 `init.py`가 자동으로 호출하므로 직접 사용할 필요 없음.
필요한 경우:

```bash
# 매일 실행 (자동 학습)
python scripts/operations/run_ops.py daily --db-id oracle_prod

# 메타데이터 재추출
python scripts/operations/run_ops.py prepare --db-id oracle_prod
```

### `metadata/` - 메타데이터 관리
고급 사용자만 필요

### `testing/` - 테스트 및 배포
E2E 테스트 및 배포 준비 확인 (일반적으로 `init.py`가 수행)

### `setup/` - 데모 셋업
로컬 개발 환경에서 데모 DB 생성 (선택사항)

---

## 💡 일반적인 사용 패턴

### 패턴 1: 첫 사용 (가장 일반적)
```bash
# 1. 초기화 (모든 단계 자동 수행)
python scripts/execution/init.py --db-id oracle_prod

# 2. 질문하기
python scripts/execution/run_cli.py --db oracle_prod -q "질문"
```

### 패턴 2: 매일 사용
```bash
# 아침마다 한번 (자동 개선)
python scripts/operations/run_ops.py daily --db-id oracle_prod

# 하루종일 질문하기
python scripts/execution/run_cli.py --db oracle_prod -q "질문1"
python scripts/execution/run_cli.py --db oracle_prod -q "질문2"
# ...
```

### 패턴 3: 성능 개선 원할 때
```bash
# E2E 테스트 카탈로그 준비 (data/catalog.json)
# ...

# 초기 세팅 + 테스트
python scripts/execution/init.py --db-id oracle_prod --catalog data/catalog.json --run-tests

# 매일 개선
python scripts/operations/run_ops.py daily --db-id oracle_prod
```

---

## 🔍 트러블슈팅

### 연결 문제
```bash
python scripts/diagnostics/check_oracle_connection.py
```
자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../docs/operations/01_CLI_GETTING_STARTED.md) - 트러블슈팅 섹션

### 시스템 문제
```bash
python scripts/diagnostics/health_check.py
```

### 상세 가이드
더 자세한 설명과 예제는 [`docs/operations/01_CLI_GETTING_STARTED.md`](../docs/operations/01_CLI_GETTING_STARTED.md)를 참고하세요.

---

## 📖 각 폴더별 상세 가이드

- [`execution/README.md`](execution/README.md) - 초기화 및 CLI
- [`diagnostics/README.md`](diagnostics/README.md) - 문제 진단
- [`operations/README.md`](operations/README.md) - 일상 운영
- [`metadata/README.md`](metadata/README.md) - 메타데이터 (고급)
- [`testing/README.md`](testing/README.md) - 테스트 (고급)
- [`setup/README.md`](setup/README.md) - 데모 셋업 (선택사항)

---

## ⚡ 빠른 명령어 참고

| 목적 | 명령어 | 언제 사용 |
|------|--------|---------|
| 초기화 | `python scripts/execution/init.py --db-id oracle_prod` | 첫 시작 |
| 질문 | `python scripts/execution/run_cli.py --db oracle_prod -q "..."` | 매일 |
| 상태 확인 | `python scripts/diagnostics/check_oracle_connection.py` | 문제 시 |
| 매일 개선 | `python scripts/operations/run_ops.py daily --db-id oracle_prod` | 매일 아침 |
| 웹 UI | `streamlit run app.py` | 편하게 사용 |

---

**시작하기:** `python scripts/execution/init.py --db-id oracle_prod`

**상세 가이드:** [`docs/operations/01_CLI_GETTING_STARTED.md`](../docs/operations/01_CLI_GETTING_STARTED.md)
