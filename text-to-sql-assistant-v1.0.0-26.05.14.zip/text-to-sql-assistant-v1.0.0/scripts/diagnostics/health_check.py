"""
Text-to-SQL 운영 상태 점검 스크립트.
Design Ref: §3.1 — 외부 의존성 없이 ANSI 컬러 직접 사용.
실행: python scripts/diagnostics/health_check.py
"""
from __future__ import annotations

import os
import sys
import time
import traceback
from pathlib import Path
from typing import Callable, List, Tuple

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

# Windows cp949 호환: UTF-8 stdout/stderr 강제
for _s in ("stdout", "stderr"):
    _r = getattr(getattr(sys, _s, None), "reconfigure", None)
    if callable(_r):
        try: _r(encoding="utf-8")
        except Exception: pass

# ── ANSI 컬러 ─────────────────────────────────────────────────
_GREEN  = "\033[92m"
_RED    = "\033[91m"
_YELLOW = "\033[93m"
_RESET  = "\033[0m"
_BOLD   = "\033[1m"

def _ok(label: str, detail: str = "") -> str:
    suffix = f"  ({detail})" if detail else ""
    return f"{_GREEN}[OK]  {_RESET} {label}{suffix}"

def _fail(label: str, detail: str = "") -> str:
    suffix = f"\n       {_RED}{detail}{_RESET}" if detail else ""
    return f"{_RED}[FAIL]{_RESET} {label}{suffix}"

def _skip(label: str, reason: str = "") -> str:
    suffix = f"  ({reason})" if reason else ""
    return f"{_YELLOW}[SKIP]{_RESET} {label}{suffix}"


# ── 체크 함수들 ───────────────────────────────────────────────

def check_imports() -> Tuple[str, bool]:
    """핵심 모듈 12개 import 확인."""
    modules = [
        "text2sql.lg.graph",
        "text2sql.lg.state",
        "text2sql.config.settings",
        "text2sql.agents.nodes",
        "text2sql.agents.guardrail_rules",
        "text2sql.tools.executor",
        "text2sql.tools.guardrails",
        "text2sql.tools.sql_postprocess",
        "text2sql.rag.schema_rag",
        "text2sql.feedback.store",
        "text2sql.ui.pipeline",
        "text2sql.lg.state",
    ]
    failed = []
    for mod in modules:
        try:
            __import__(mod)
        except Exception as e:
            failed.append(f"{mod}: {e}")

    total = len(modules)
    if failed:
        detail = "; ".join(failed[:3])
        return _fail("imports", detail), False
    return _ok("imports", f"{total}/{total} 모듈"), True


def check_settings() -> Tuple[str, bool]:
    """Settings() 인스턴스 생성 확인."""
    try:
        from text2sql.config.settings import Settings
        s = Settings()
        _ = s.db.dialect
        return _ok("config/settings"), True
    except Exception as e:
        return _fail("config/settings", str(e)), False


def check_graph_state() -> Tuple[str, bool]:
    """GraphState TypedDict 필수 필드 확인."""
    try:
        from text2sql.lg.state import GraphState
        hints = GraphState.__annotations__
        required = ["question", "candidates", "guard_passed", "final_sql", "success"]
        missing = [f for f in required if f not in hints]
        if missing:
            return _fail("GraphState", f"필드 누락: {missing}"), False
        return _ok("GraphState", f"{len(hints)} fields"), True
    except Exception as e:
        return _fail("GraphState", str(e)), False


def check_build_graph() -> Tuple[str, bool]:
    """build_graph() 호출 및 반환 타입 확인."""
    try:
        from text2sql.lg.graph import build_graph
        from langgraph.graph import StateGraph
        g = build_graph()
        if not isinstance(g, StateGraph):
            return _fail("build_graph", f"반환 타입 오류: {type(g)}"), False
        return _ok("build_graph", "StateGraph"), True
    except Exception as e:
        return _fail("build_graph", traceback.format_exc().strip().splitlines()[-1]), False


def check_oracle_db() -> Tuple[str, bool | None]:
    """Oracle DB 연결 (환경변수 없으면 SKIP)."""
    host = os.getenv("T2SQL_DB_HOST", "")
    user = os.getenv("T2SQL_DB_USER", "")
    if not host or not user:
        return _skip("Oracle DB", "T2SQL_DB_HOST / T2SQL_DB_USER 미설정"), None
    try:
        from text2sql.tools.db_adapters import get_adapter
        adapter = get_adapter()
        tables = adapter.list_tables()
        return _ok("Oracle DB", f"{len(tables)} tables"), True
    except Exception as e:
        return _fail("Oracle DB", str(e)), False


# ── 메인 ──────────────────────────────────────────────────────

def main() -> int:
    width = 40
    print(f"\n{_BOLD}{'━' * width}{_RESET}")
    print(f"{_BOLD}  Text-to-SQL Health Check{_RESET}")
    print(f"{_BOLD}{'━' * width}{_RESET}")

    checks: List[Callable] = [
        check_imports,
        check_settings,
        check_graph_state,
        check_build_graph,
        check_oracle_db,
    ]

    passed = skipped = failed = 0
    t_start = time.time()

    for fn in checks:
        line, result = fn()
        print(line)
        if result is True:
            passed += 1
        elif result is None:
            skipped += 1
        else:
            failed += 1

    elapsed = round((time.time() - t_start) * 1000)
    total = passed + failed

    print(f"{_BOLD}{'━' * width}{_RESET}")

    if failed == 0:
        status = f"{_GREEN}통과{_RESET}"
    else:
        status = f"{_RED}실패{_RESET}"

    print(
        f"결과: {_BOLD}{passed}/{total}{_RESET} {status}"
        f"  {_YELLOW}{skipped} skipped{_RESET}"
        f"  {elapsed}ms\n"
    )

    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
