"""Diagnostic tools for system health and connectivity checks."""
