# diagnostics/ - 문제 진단

## 개요

Oracle 연결, 시스템 상태, 도메인 힌트를 확인하는 진단 도구입니다.
**일반적으로 `init.py`가 자동으로 수행하므로 직접 사용할 필요 없음.**

문제 발생 시에만 수동으로 실행합니다.

## 스크립트

### check_oracle_connection.py

Oracle 데이터베이스 연결 및 기본 메타데이터 접근을 테스트합니다.

```bash
python scripts/diagnostics/check_oracle_connection.py
```

**확인 항목:**
- Oracle 연결
- 사용자/스키마 정보
- 읽을 수 있는 테이블 목록
- 메타데이터 뷰 접근
- 샘플 SELECT 쿼리

**결과 예시:**
```
[1/5] Testing connection...
  [OK] Connection succeeded: Connected as scott@oracle_prod

[3/5] Listing readable tables...
  Table count: 42
    - PLANTS
    - PRODUCTS
    - SALES_ORDERS
```

### health_check.py

12개 핵심 모듈을 점검합니다.

```bash
python scripts/diagnostics/health_check.py
```

**확인 항목:**
- Python 임포트 (12개 모듈)
- 설정/세팅
- GraphState 구조
- LangGraph 빌더
- Oracle DB 연결

### check_domain_hints.py

로드된 도메인 힌트와 키워드 매핑을 검사합니다.

```bash
python scripts/diagnostics/check_domain_hints.py --db-id oracle_prod
```

## 문제 해결

### Oracle 연결 실패
```bash
python scripts/diagnostics/check_oracle_connection.py
```

출력에서 다음을 확인하세요:
- Host, Port, Service 정보
- 사용자 및 권한
- 스키마 설정

### 시스템 점검 실패
```bash
python scripts/diagnostics/health_check.py
```

필수 패키지 설치:
```bash
pip install -r requirements.txt
```

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md) - 트러블슈팅
