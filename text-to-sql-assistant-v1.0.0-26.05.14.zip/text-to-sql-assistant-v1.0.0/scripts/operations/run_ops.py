#!/usr/bin/env python3
"""Oracle Text-to-SQL 통합 운영 도구.

서브커맨드 실행 순서 (처음 도입 시):
  doctor → prepare → test → release

일상 운영:
  daily  (또는 maintain)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))

# Windows cp949 호환: UTF-8 stdout/stderr 강제
for _s in ("stdout", "stderr"):
    _r = getattr(getattr(sys, _s, None), "reconfigure", None)
    if callable(_r):
        try: _r(encoding="utf-8")
        except Exception: pass

from text2sql.tools.ops_gateway import (
    build_check_hints_command,
    build_daily_commands,
    build_demo_command,
    build_doctor_command,
    build_e2e_command,
    build_first_run_commands,
    build_maintain_command,
    build_prepare_commands,
    build_release_command,
)

# ── 워크플로 가이드 (usage 서브커맨드 + --help epilog 공용) ──────
_WORKFLOW = """\
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Oracle Text-to-SQL 운영 가이드
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

[처음 DB 연결 시]
  python scripts/operations/run_ops.py doctor
      → Oracle 연결 + 메타뷰(ALL_TABLES 등) 접근 확인

  python scripts/operations/run_ops.py prepare --db-id mydb
      → 메타데이터 추출(export) + SQL 기반 자동 강화(enrich)

  python scripts/operations/run_ops.py test --db-id mydb --catalog data/catalog.json
      → E2E 회귀 테스트 실행, 결과를 --report 로 저장

  python scripts/operations/run_ops.py release --db-id mydb --catalog data/catalog.json
      → 배포 게이트 (E2E + pytest + vulture)

[매일 운영]
  python scripts/operations/run_ops.py daily --db-id mydb
      → doctor + maintain(1 cycle) 한 번에 실행

[처음 도입 한 번에 (first-run)]
  python scripts/operations/run_ops.py first-run --db-id mydb \\
      --smoke-question "최근 한 달 생산량은?" \\
      --run-e2e --catalog data/catalog.json

[데모 스키마 구축]
  python scripts/operations/run_ops.py demo \\
      --admin-user system --admin-password secret \\
      --service-name XEPDB1 --schema-user t2sql_demo

[명령 확인만 (실행 안 함)]
  python scripts/operations/run_ops.py --dry-run prepare --db-id mydb

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

_COMMANDS = [
    "usage", "doctor", "first-run", "prepare",
    "test", "release", "daily", "maintain", "demo",
    "check-hints",
]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="run_ops.py",
        description="Oracle Text-to-SQL 통합 운영 도구",
        epilog=_WORKFLOW,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="실제 실행 없이 실행될 명령어만 출력",
    )

    sub = parser.add_subparsers(dest="command", required=True, metavar="<커맨드>")

    # usage ─────────────────────────────────────────────────────────
    sub.add_parser(
        "usage",
        help="전체 운영 워크플로와 명령어 예시 출력",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # doctor ─────────────────────────────────────────────────────────
    sub.add_parser(
        "doctor",
        help="[1단계] Oracle 연결 + 메타뷰 접근 확인",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # first-run ───────────────────────────────────────────────────────
    p_first = sub.add_parser(
        "first-run",
        help="[통합] 처음 도입 시: doctor + prepare + 선택적 smoke/E2E",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_first.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_first.add_argument("--catalog", default="", help="쿼리 카탈로그 경로 (--run-e2e 시 필수)")
    p_first.add_argument("--include", default="", help="포함할 테이블 (쉼표 구분)")
    p_first.add_argument("--exclude", default="", help="제외할 테이블 (쉼표 구분)")
    p_first.add_argument("--samples", type=int, default=5, help="컬럼당 샘플 값 수 (기본: 5)")
    p_first.add_argument("--smoke-question", default="", help="CLI 스모크 테스트 질문")
    p_first.add_argument("--hitl", action="store_true", help="스모크 테스트를 HITL 모드로 실행")
    p_first.add_argument("--max-retries", type=int, default=2, help="파이프라인 최대 재시도 (기본: 2)")
    p_first.add_argument("--run-e2e", action="store_true", help="부트스트랩 후 E2E 실행")
    p_first.add_argument("--e2e-report", default="", help="E2E 결과 저장 경로")
    p_first.add_argument("--limit", type=int, default=20, help="결과 비교 행 수 제한 (기본: 20)")
    p_first.add_argument("--max-items", type=int, default=0, help="E2E 케이스 최대 실행 수 (0=전체)")

    # prepare ────────────────────────────────────────────────────────
    p_prep = sub.add_parser(
        "prepare",
        help="[2단계] 메타데이터 추출 + SQL 기반 자동 강화",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_prep.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_prep.add_argument("--catalog", default="", help="쿼리 카탈로그 경로 (enrich 에 사용)")
    p_prep.add_argument("--include", default="", help="포함할 테이블 (쉼표 구분)")
    p_prep.add_argument("--exclude", default="", help="제외할 테이블 (쉼표 구분)")
    p_prep.add_argument("--samples", type=int, default=5, help="컬럼당 샘플 값 수 (기본: 5)")

    # test ────────────────────────────────────────────────────────────
    p_test = sub.add_parser(
        "test",
        help="[3단계] E2E 회귀 테스트 실행",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_test.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_test.add_argument("--catalog", required=True, help="쿼리 카탈로그 경로 (필수)")
    p_test.add_argument("--max-retries", type=int, default=2, help="파이프라인 최대 재시도 (기본: 2)")
    p_test.add_argument("--report", default="", help="E2E 결과 저장 경로")
    p_test.add_argument("--limit", type=int, default=20, help="결과 비교 행 수 제한 (기본: 20)")
    p_test.add_argument("--probe-timeout-sec", type=int, default=10, help="LLM 엔드포인트 프로브 타임아웃(초)")
    p_test.add_argument("--skip-llm-check", action="store_true", help="LLM 엔드포인트 프리플라이트 체크 건너뜀")
    p_test.add_argument("--record-feedback", action="store_true", help="E2E 결과를 피드백 레코드로 저장")
    p_test.add_argument("--learn", action="store_true", help="피드백 저장 후 learner 실행")
    p_test.add_argument("--domain", default="", help="특정 도메인만 실행")
    p_test.add_argument("--tag", default="", help="특정 태그만 실행")
    p_test.add_argument("--max-items", type=int, default=0, help="최대 실행 케이스 수 (0=전체)")

    # release ─────────────────────────────────────────────────────────
    p_rel = sub.add_parser(
        "release",
        help="[4단계] 배포 게이트 (E2E + pytest + vulture)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_rel.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_rel.add_argument("--catalog", default="", help="쿼리 카탈로그 경로 (--skip-e2e 미사용 시 필수)")
    p_rel.add_argument("--e2e-report", default="", help="기존 E2E 결과 경로 (재사용 시)")
    p_rel.add_argument("--report", default="", help="릴리즈 게이트 결과 저장 경로")
    p_rel.add_argument("--max-retries", type=int, default=2, help="파이프라인 최대 재시도 (기본: 2)")
    p_rel.add_argument("--skip-e2e", action="store_true", help="E2E 실행 건너뜀")
    p_rel.add_argument("--skip-pytest", action="store_true", help="pytest 실행 건너뜀")
    p_rel.add_argument("--skip-vulture", action="store_true", help="vulture 실행 건너뜀")
    p_rel.add_argument("--allow-system-schema", action="store_true", help="SYSTEM/SYS 스키마 허용")

    # daily ───────────────────────────────────────────────────────────
    p_daily = sub.add_parser(
        "daily",
        help="[매일] doctor + maintain(1 cycle) 일괄 실행",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_daily.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_daily.add_argument("--catalog", default="", help="쿼리 카탈로그 경로")

    # maintain ────────────────────────────────────────────────────────
    p_maint = sub.add_parser(
        "maintain",
        help="[정기] 메타데이터 갱신 + 벡터 재구축 + 자동 학습",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_maint.add_argument("--db-id", default="", help="데이터베이스 ID")
    p_maint.add_argument("--cycles", type=int, default=1, help="유지보수 사이클 수 (기본: 1)")
    p_maint.add_argument("--samples", type=int, default=5, help="컬럼당 샘플 값 수 (기본: 5)")
    p_maint.add_argument("--report", default="", help="유지보수 결과 저장 경로")
    p_maint.add_argument("--catalog", default="", help="쿼리 카탈로그 경로")
    p_maint.add_argument("--sql-glob", default="", help="SQL 파일 glob 패턴")
    p_maint.add_argument("--no-enrich", action="store_true", help="enrich 건너뜀")
    p_maint.add_argument("--no-metadata", action="store_true", help="메타데이터 추출 건너뜀")
    p_maint.add_argument("--no-vector", action="store_true", help="벡터 재구축 건너뜀")
    p_maint.add_argument("--no-learn", action="store_true", help="learner 건너뜀")
    p_maint.add_argument("--no-eval", action="store_true", help="evaluator 건너뜀")
    p_maint.add_argument("--fail-under-score", type=int, default=0, help="임계 점수 미달 시 실패 처리 (0=비활성)")

    # check-hints ─────────────────────────────────────────────────────
    p_check = sub.add_parser(
        "check-hints",
        help="[진단] 도메인 힌트 상태 확인 + 질문 매칭 시뮬레이션",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_check.add_argument("--db-id", required=True, help="데이터베이스 ID")
    p_check.add_argument("--question", "-q", default="", help="시뮬레이션할 질문")
    p_check.add_argument(
        "--show-all", action="store_true",
        help="keyword_map / few_shots / patterns 전체 목록 출력",
    )

    # demo ────────────────────────────────────────────────────────────
    p_demo = sub.add_parser(
        "demo",
        help="[선택] 제조업 데모 Oracle 스키마 구축",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    p_demo.add_argument("--admin-user", default="", help="Oracle 관리자 계정")
    p_demo.add_argument("--admin-password", default="", help="Oracle 관리자 비밀번호")
    p_demo.add_argument("--service-name", default="", help="Oracle 서비스명")
    p_demo.add_argument("--host", default="", help="Oracle 호스트")
    p_demo.add_argument("--port", type=int, default=0, help="Oracle 포트")
    p_demo.add_argument("--schema-user", default="", help="데모 스키마 사용자")
    p_demo.add_argument("--schema-password", default="", help="데모 스키마 비밀번호")
    p_demo.add_argument("--drop-existing", action="store_true", help="기존 스키마 삭제 후 재생성")
    p_demo.add_argument("--schema-only", action="store_true", help="현재 스키마 내 객체만 재생성")

    return parser


def _execute_steps(steps: list[tuple[str, list[str]]], *, dry_run: bool) -> int:
    """단계별 명령어를 순차 실행한다.

    Args:
        steps: (라벨, 명령어 리스트) 튜플 목록.
        dry_run: True이면 실행하지 않고 명령어만 출력.

    Returns:
        0: 전체 성공, 그 외: 실패한 단계의 종료 코드.
    """
    total = len(steps)
    for idx, (label, command) in enumerate(steps, start=1):
        prefix = f"[{idx}/{total}]"
        print(f"\n{prefix} {label}")
        print("  실행: " + " ".join(command))
        if dry_run:
            print("  (--dry-run: 건너뜀)")
            continue
        result = subprocess.run(command, cwd=str(ROOT))
        if result.returncode != 0:
            print(
                f"\n[FAIL] {prefix} '{label}' 실패 (종료 코드: {result.returncode})\n"
                f"  → 위 오류 메시지를 확인한 뒤 재실행하거나,\n"
                f"    먼저 'python scripts/operations/run_ops.py doctor' 로 연결 상태를 점검하세요."
            )
            return result.returncode
    print("\n[OK] 모든 단계 완료.")
    return 0


def main() -> int:  # noqa: C901
    parser = _build_parser()
    args = parser.parse_args()
    command: str = args.command

    # usage ────────────────────────────────────────────────────────────
    if command == "usage":
        print(_WORKFLOW)
        return 0

    # doctor ───────────────────────────────────────────────────────────
    if command == "doctor":
        return _execute_steps(
            [("Oracle 연결 + 메타뷰 확인", build_doctor_command())],
            dry_run=args.dry_run,
        )

    # first-run ────────────────────────────────────────────────────────
    if command == "first-run":
        if args.run_e2e and not args.catalog:
            print("[ERROR] --run-e2e 사용 시 --catalog 가 필수입니다.")
            print("  예시: --catalog data/query_catalog.json")
            return 2
        max_items = args.max_items if args.max_items > 0 else None
        return _execute_steps(
            build_first_run_commands(
                db_id=args.db_id,
                catalog=args.catalog,
                include=args.include,
                exclude=args.exclude,
                samples=args.samples,
                smoke_question=args.smoke_question,
                hitl=args.hitl,
                max_retries=args.max_retries,
                run_e2e=args.run_e2e,
                e2e_report=args.e2e_report,
                limit=args.limit,
                max_items=max_items,
            ),
            dry_run=args.dry_run,
        )

    # prepare ──────────────────────────────────────────────────────────
    if command == "prepare":
        return _execute_steps(
            build_prepare_commands(
                db_id=args.db_id,
                catalog=args.catalog,
                include=args.include,
                exclude=args.exclude,
                samples=args.samples,
            ),
            dry_run=args.dry_run,
        )

    # test ─────────────────────────────────────────────────────────────
    if command == "test":
        max_items = args.max_items if args.max_items > 0 else None
        return _execute_steps(
            [
                (
                    "E2E 회귀 테스트",
                    build_e2e_command(
                        db_id=args.db_id,
                        catalog=args.catalog,
                        max_retries=args.max_retries,
                        report=args.report,
                        limit=args.limit,
                        probe_timeout_sec=args.probe_timeout_sec,
                        skip_llm_check=args.skip_llm_check,
                        record_feedback=args.record_feedback,
                        learn=args.learn,
                        domain=args.domain,
                        tag=args.tag,
                        max_items=max_items,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    # release ──────────────────────────────────────────────────────────
    if command == "release":
        run_e2e = not args.skip_e2e
        if run_e2e and not args.catalog:
            print("[ERROR] --skip-e2e 미사용 시 --catalog 가 필수입니다.")
            print("  E2E 없이 실행: python scripts/operations/run_ops.py release --skip-e2e")
            return 2
        return _execute_steps(
            [
                (
                    "배포 게이트",
                    build_release_command(
                        db_id=args.db_id,
                        catalog=args.catalog,
                        e2e_report=args.e2e_report,
                        report=args.report,
                        max_retries=args.max_retries,
                        run_e2e=run_e2e,
                        run_pytest=not args.skip_pytest,
                        run_vulture=not args.skip_vulture,
                        allow_system_schema=args.allow_system_schema,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    # daily ────────────────────────────────────────────────────────────
    if command == "daily":
        return _execute_steps(
            build_daily_commands(db_id=args.db_id, catalog=args.catalog),
            dry_run=args.dry_run,
        )

    # maintain ─────────────────────────────────────────────────────────
    if command == "maintain":
        fail_under_score = args.fail_under_score if args.fail_under_score > 0 else None
        return _execute_steps(
            [
                (
                    "유지보수 사이클",
                    build_maintain_command(
                        db_id=args.db_id,
                        cycles=args.cycles,
                        samples=args.samples,
                        report=args.report,
                        sql_catalog=args.catalog,
                        sql_glob=args.sql_glob,
                        no_enrich=args.no_enrich,
                        no_metadata=args.no_metadata,
                        no_vector=args.no_vector,
                        no_learn=args.no_learn,
                        no_eval=args.no_eval,
                        fail_under_score=fail_under_score,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    # demo ─────────────────────────────────────────────────────────────
    if command == "demo":
        return _execute_steps(
            [
                (
                    "데모 스키마 구축",
                    build_demo_command(
                        admin_user=args.admin_user,
                        admin_password=args.admin_password,
                        service_name=args.service_name,
                        host=args.host,
                        port=args.port or None,
                        schema_user=args.schema_user,
                        schema_password=args.schema_password,
                        drop_existing=args.drop_existing,
                        schema_only=args.schema_only,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    # check-hints ──────────────────────────────────────────────────────
    if command == "check-hints":
        return _execute_steps(
            [
                (
                    "도메인 힌트 진단",
                    build_check_hints_command(
                        db_id=args.db_id,
                        question=args.question,
                        show_all=args.show_all,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    # fallback ─────────────────────────────────────────────────────────
    print(f"\n[ERROR] 알 수 없는 커맨드: '{command}'")
    print(f"  사용 가능: {', '.join(_COMMANDS)}")
    print("  도움말: python scripts/operations/run_ops.py --help")
    print("  가이드: python scripts/operations/run_ops.py usage")
    return 2


if __name__ == "__main__":
    sys.exit(main())
