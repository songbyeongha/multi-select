# operations/ - 일상 운영

## 개요

시스템을 운영하고 유지보수하는 도구입니다.
**일반적으로 `init.py`가 자동으로 호출하므로 직접 사용할 필요 없음.**

고급 사용자나 특정 상황에서만 직접 사용합니다.

## 스크립트

### run_ops.py (통합 오퍼레이션 도구)

모든 운영 작업을 수행하는 주요 스크립트입니다.

```bash
python scripts/operations/run_ops.py <명령어> [옵션]
```

**주요 명령어:**

#### doctor - 시스템 진단
```bash
python scripts/operations/run_ops.py doctor --db-id oracle_prod
```
Oracle 연결, 테이블 목록, 메타데이터 접근 확인

#### prepare - 메타데이터 추출
```bash
python scripts/operations/run_ops.py prepare --db-id oracle_prod --cycles 1
```
Oracle에서 스키마 메타데이터 추출 및 도메인 강화

#### daily - 일일 유지보수
```bash
python scripts/operations/run_ops.py daily --db-id oracle_prod
```
doctor + prepare 자동 실행 (매일 한 번 권장)

#### test - E2E 테스트
```bash
python scripts/operations/run_ops.py test \
  --db-id oracle_prod \
  --catalog data/catalog.json
```
테스트 카탈로그를 이용한 회귀 테스트

#### release - 배포 게이트
```bash
python scripts/operations/run_ops.py release \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --run-pytest
```
E2E 테스트 + 단위 테스트 + 코드 품질 검사

### oracle_ops.py

레거시 스크립트 (사용 비권장, `run_ops.py`로 통합됨)

## 사용 시나리오

### 매일 아침 자동 개선
```bash
python scripts/operations/run_ops.py daily --db-id oracle_prod
```

### 메타데이터 재추출
```bash
python scripts/operations/run_ops.py prepare --db-id oracle_prod --samples 10
```

### E2E 테스트
```bash
python scripts/operations/run_ops.py test \
  --db-id oracle_prod \
  --catalog data/catalog.json \
  --report logs/test_report.json
```

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md)
