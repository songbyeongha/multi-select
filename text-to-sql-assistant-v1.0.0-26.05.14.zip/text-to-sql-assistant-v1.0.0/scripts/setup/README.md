# setup/ - 셋업 및 데모

## 개요

로컬 개발 환경에서 데모 데이터베이스를 생성합니다.
**선택사항. 실제 운영 DB가 있으면 필요 없음.**

## 스크립트

### setup_oracle_mfg_demo.py

Oracle 제조 도메인 데모 데이터베이스를 생성합니다.

```bash
python scripts/setup/setup_oracle_mfg_demo.py
```

**생성 항목:**
- 테이블 (PLANTS, PRODUCTS, SALES_ORDERS 등)
- 샘플 제조 데이터
- 인덱스 및 제약조건
- 뷰 및 관계

## 사용 시나리오

### 로컬 개발 환경 셋업
```bash
python scripts/setup/setup_oracle_mfg_demo.py
```

### 메타데이터 추출 (데모 DB 사용)
```bash
python scripts/metadata/export_oracle_metadata.py --db-id oracle_mfg_demo
```

### CLI 테스트
```bash
python scripts/execution/run_cli.py --db oracle_mfg_demo -q "공장별 생산량"
```

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md)
