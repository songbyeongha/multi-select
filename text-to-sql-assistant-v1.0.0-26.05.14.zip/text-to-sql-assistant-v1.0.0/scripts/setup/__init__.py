"""Setup and demonstration utilities."""
