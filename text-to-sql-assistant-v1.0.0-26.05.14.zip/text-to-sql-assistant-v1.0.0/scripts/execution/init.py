#!/usr/bin/env python3
"""
Text-to-SQL 초기화 스크립트 — 한 번의 실행으로 모든 설정 완료.

사용법:
  python scripts/execution/init.py --db-id oracle_prod [--catalog data/catalog.json]

기능:
  1. Oracle 연결 확인
  2. 시스템 상태 점검
  3. 메타데이터 추출
  4. 도메인 힌트 생성
  5. E2E 테스트 (카탈로그 있으면)
  6. 배포 게이트 (선택사항)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))

# Windows cp949 호환: UTF-8 stdout/stderr 강제
for _s in ("stdout", "stderr"):
    _r = getattr(getattr(sys, _s, None), "reconfigure", None)
    if callable(_r):
        try: _r(encoding="utf-8")
        except Exception: pass

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")


def _run_command(cmd: list[str], description: str) -> bool:
    """명령어 실행 및 결과 반환."""
    print(f"\n{'='*60}")
    print(f"🔄 {description}")
    print(f"{'='*60}")
    print(f"실행: {' '.join(cmd)}")
    print()

    result = subprocess.run(cmd, cwd=str(ROOT))

    if result.returncode == 0:
        print(f"✅ {description} 완료")
        return True
    else:
        print(f"❌ {description} 실패 (종료 코드: {result.returncode})")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Text-to-SQL 초기화 — 한 번의 실행으로 모든 설정 완료",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
예시:
  python scripts/execution/init.py --db-id oracle_prod
  python scripts/execution/init.py --db-id oracle_prod --catalog data/catalog.json
  python scripts/execution/init.py --db-id oracle_prod --run-tests
        """
    )
    parser.add_argument(
        "--db-id",
        required=True,
        help="데이터베이스 ID (필수)",
    )
    parser.add_argument(
        "--catalog",
        default="",
        help="E2E 테스트 카탈로그 경로 (선택사항)",
    )
    parser.add_argument(
        "--run-tests",
        action="store_true",
        help="배포 게이트까지 실행 (pytest + vulture 포함)",
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=5,
        help="메타데이터 샘플 수 (기본값: 5)",
    )

    args = parser.parse_args()
    db_id = args.db_id

    print(f"\n{'█'*60}")
    print(f"  Text-to-SQL 초기화 스크립트 v1.0")
    print(f"  {'█'*60}")
    print(f"  데이터베이스: {db_id}")
    print(f"  프로젝트 경로: {ROOT}")
    print(f"{'█'*60}\n")

    results = {}
    failed = []

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 1. Oracle 연결 확인
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    step_name = "[1/6] Oracle 연결 확인"
    if _run_command(
        [sys.executable, "scripts/diagnostics/check_oracle_connection.py"],
        step_name,
    ):
        results[step_name] = "✅"
    else:
        results[step_name] = "❌"
        failed.append(step_name)
        print("\n⚠️  Oracle 연결에 실패했습니다.")
        print("   .env 파일의 다음을 확인하세요:")
        print("   - T2SQL_DB_HOST")
        print("   - T2SQL_DB_PORT")
        print("   - T2SQL_DB_SERVICE_NAME")
        print("   - T2SQL_DB_USER")
        print("   - T2SQL_DB_PASSWORD")
        sys.exit(1)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 2. 시스템 상태 점검
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    step_name = "[2/6] 시스템 상태 점검"
    if _run_command(
        [sys.executable, "scripts/diagnostics/health_check.py"],
        step_name,
    ):
        results[step_name] = "✅"
    else:
        results[step_name] = "❌"
        failed.append(step_name)
        print("\n⚠️  시스템 점검에 실패했습니다.")
        print("   필수 패키지가 설치되었는지 확인하세요:")
        print("   pip install -r requirements.txt")
        sys.exit(1)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 3. 메타데이터 추출
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    step_name = "[3/6] 메타데이터 추출 및 도메인 강화"
    if _run_command(
        [
            sys.executable,
            "scripts/operations/run_ops.py",
            "prepare",
            "--db-id", db_id,
            "--samples", str(args.samples),
        ],
        step_name,
    ):
        results[step_name] = "✅"
    else:
        results[step_name] = "❌"
        failed.append(step_name)
        print("\n⚠️  메타데이터 추출에 실패했습니다.")
        print("   Oracle 연결 및 권한을 재확인하세요.")
        sys.exit(1)

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 4. E2E 테스트 (카탈로그 있으면)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    if args.catalog:
        catalog_path = ROOT / args.catalog
        if catalog_path.exists():
            step_name = "[4/6] E2E 회귀 테스트"
            if _run_command(
                [
                    sys.executable,
                    "scripts/operations/run_ops.py",
                    "test",
                    "--db-id", db_id,
                    "--catalog", str(catalog_path),
                    "--report", "logs/e2e_init_report.json",
                ],
                step_name,
            ):
                results[step_name] = "✅"
            else:
                results[step_name] = "⚠️  일부 실패"
                # E2E 실패는 심각하지 않음 (진행)
        else:
            print(f"\n⚠️  카탈로그를 찾을 수 없습니다: {catalog_path}")
            step_name = "[4/6] E2E 회귀 테스트"
            results[step_name] = "⏭️  건너뜀"
    else:
        step_name = "[4/6] E2E 회귀 테스트"
        print(f"\n⏭️  {step_name} - 카탈로그가 없어 건너뜁니다")
        print("   카탈로그를 준비하면: python scripts/execution/init.py --db-id {db_id} --catalog data/catalog.json")
        results[step_name] = "⏭️  건너뜀"

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 5. 배포 게이트 (선택사항)
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    step_name = "[5/6] 배포 게이트"
    if args.run_tests and args.catalog:
        catalog_path = ROOT / args.catalog
        if _run_command(
            [
                sys.executable,
                "scripts/operations/run_ops.py",
                "release",
                "--db-id", db_id,
                "--catalog", str(catalog_path),
                "--run-e2e",
                "--run-pytest",
                "--fail-under-overall", "75",
                "--report", "logs/release_gate_init.json",
            ],
            step_name,
        ):
            results[step_name] = "✅"
        else:
            results[step_name] = "⚠️  일부 조건 미충족"
    else:
        print(f"\n⏭️  {step_name} - 선택사항 (--run-tests 플래그 필요)")
        results[step_name] = "⏭️  건너뜀"

    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    # 6. 최종 상태
    # ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    print(f"\n{'='*60}")
    print("📊 초기화 완료 결과")
    print(f"{'='*60}\n")

    for step, status in results.items():
        print(f"{status} {step}")

    if failed:
        print(f"\n❌ {len(failed)}개 단계 실패:")
        for step in failed:
            print(f"   - {step}")
        sys.exit(1)

    print(f"\n{'='*60}")
    print("✅ 모든 초기화 단계 완료!")
    print(f"{'='*60}\n")

    print("🚀 다음 단계:")
    print(f"   # 첫 질문 실행:")
    print(f"   python scripts/execution/run_cli.py --db {db_id} -q '올해 매출은?'\n")
    print(f"   # 또는 웹 UI 시작:")
    print(f"   streamlit run app.py\n")
    print(f"   # 또는 매일 자동 업데이트:")
    print(f"   python scripts/operations/run_ops.py daily --db-id {db_id}\n")


if __name__ == "__main__":
    main()
