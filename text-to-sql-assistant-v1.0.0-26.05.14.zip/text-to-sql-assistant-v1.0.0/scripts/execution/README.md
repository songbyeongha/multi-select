# execution/ - 실행 및 초기화

## 개요

CLI를 통해 시스템을 초기화하고 질문을 실행하는 스크립트들입니다.

## 스크립트

### init.py ⭐ **가장 먼저 실행**

한 번의 명령으로 모든 초기 설정을 완료합니다.

```bash
python scripts/execution/init.py --db-id oracle_prod
```

**자동 실행 단계:**
1. Oracle 연결 확인
2. 시스템 상태 점검
3. 메타데이터 추출
4. E2E 테스트 (카탈로그 있으면)
5. 배포 게이트 (선택사항)

**옵션:**
```bash
--db-id DBID              (필수) 데이터베이스 ID
--catalog PATH            (선택) E2E 테스트 카탈로그 경로
--run-tests               (선택) 배포 게이트까지 실행
--samples N               (선택) 메타데이터 샘플 수 (기본값: 5)
```

**예제:**
```bash
# 기본 초기화
python scripts/execution/init.py --db-id oracle_prod

# 테스트까지 포함
python scripts/execution/init.py --db-id oracle_prod \
  --catalog data/catalog.json --run-tests
```

### run_cli.py

실행 후 질문을 입력하면 자동으로 SQL을 생성하고 실행합니다.

```bash
python scripts/execution/run_cli.py --db oracle_prod -q "올해 매출은?"
```

**옵션:**
```bash
--db DB_ID                (필수) 데이터베이스 ID
-q, --question QUESTION   (필수) 질문
--max-retries N           (선택) 재시도 횟수 (기본값: 3)
--hitl                    (선택) 사용자 검토 모드
```

**예제:**
```bash
# 단일 질문 실행
python scripts/execution/run_cli.py --db oracle_prod -q "공장별 생산량"

# 사용자 검토 모드 (실행 전에 SQL 확인)
python scripts/execution/run_cli.py --db oracle_prod -q "..." --hitl
```

## 시작 순서

1. **첫 사용:** `init.py` 실행 (자동으로 모든 설정)
2. **매일 사용:** `run_cli.py`로 질문 입력

## 상세 가이드

더 자세한 내용: [`docs/operations/01_CLI_GETTING_STARTED.md`](../../docs/operations/01_CLI_GETTING_STARTED.md)
