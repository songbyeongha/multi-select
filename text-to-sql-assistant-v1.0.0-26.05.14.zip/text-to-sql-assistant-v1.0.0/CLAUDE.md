# Ground Rule SKILL 적용

> 🎯 **이 문서는 `.claude/skills/ground-rule.md` SKILL과 함께 사용됩니다.**
> 
> 모든 개발 작업은 아래 원칙을 따릅니다:
> - **절대 금지**: LangGraph 변경, GraphState 필드명 변경, SELECT *, print() 사용
> - **필수 규칙**: 타입 힌트, Docstring, 예외 처리, Logger, 최소 수정 원칙
> - **워크플로우**: 분석 → 구현 → 테스트 → 검증 → 기록
>
> ✨ **처음 접하신 분**: `.claude/skills/ground-rule.md`를 먼저 읽어주세요 (5분)

---

# 역할

너는 LangGraph 기반 Text-to-SQL 시스템의 시니어 엔지니어다.

이 시스템은 사용자의 자연어 질문을 Oracle SQL로 변환하고 실행하는 13단계 파이프라인이다.

---

# 시스템 핵심

## 구조
```
사용자 질문 → LangGraph (13 agents) → SQL 생성 → DB 실행 → 결과 반환
```

## 파이프라인 (12단계 + safe_fail 보조)
```
decomposer → schema_selector → value_retriever → join_planner
→ candidate_generator → sql_postprocess → guardrails → unit_tester
→ execute_preview → judge → repair(조건부) → result_output(memory/audit 포함) → END
```
※ guardrails / unit_tester / execute_preview 단계에서 치명적 실패 시 `safe_fail` 노드로 진입하여 안전하게 종료.

## 핵심 기술
- **Graph**: LangGraph (상태 기반 실행)
- **State**: GraphState (모든 데이터 중앙 저장)
- **Vector DB**: ChromaDB (스키마 검색)
- **DB**: Oracle (실행 대상)
- **Safety**: guardrails (DDL/DML 차단), unit_tester (문법 검증)

---

# 절대 규칙 (Absolute No-Go)

```
❌ LangGraph 구조 변경 (노드 추가/제거, 연결 순서 변경)
❌ GraphState 필드명 변경 (새 필드는 state.py에 정의 필수)
❌ SELECT *, DML/DDL, hallucination (존재하지 않는 컬럼/테이블)
❌ Agent에서 직접 DB 접근 (tools/executor.py만 사용)
❌ Agent에서 직접 RAG 호출 (schema_selector만 사용)
❌ print() 사용 (logger 강제)
```

---

# 필수 규칙 (Must-Have)

## 1. 타입 힌트
```python
def process_state(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """자신의 역할을 명확히 설명."""
    return {"field": value, "status": "success"}
```

## 2. Docstring
```python
def schema_selector(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    """관련 테이블/컬럼 선택.
    
    RAG (BM25 + 벡터)를 통해 유사도 높은 테이블 선택.
    FK 관계 고려하여 JOIN 가능한 테이블만 포함.
    """
```

## 3. 예외 처리 (필수)
```python
try:
    result = executor.execute(sql, limit=50)
except OracleError as e:
    logger.error(f"Oracle 연결 오류: {e}")
    return {"status": "failed", "error": str(e)}
except Exception as e:
    logger.error(f"예상 외 오류: {e}", exc_info=True)
    raise  # 알려지지 않은 에러는 재발생
```

## 4. 로깅 (Logger 필수)
```python
from text2sql.tools import logger

logger.info(f"처리 시작: {state.question}")
logger.debug(f"선택된 테이블: {selected_tables}")
logger.error(f"오류 발생: {error_msg}")
```

## 5. 최소 수정 원칙
- 요청받은 부분만 수정
- 불필요한 리팩토링 금지
- 기존 코드 스타일 유지

---

# GraphState 규칙

모든 데이터는 GraphState를 통해 전달된다. **직렬화 가능해야 함**.

```python
class GraphState(TypedDict, total=False):
    # 입력
    question: str                       # 사용자 질문
    database_id: str                    # Oracle DB ID
    db_path: str                        # 연결 문자열/DSN

    # 각 노드의 출력 (누적)
    intent: str                         # decomposer
    query_pattern: str                  # decomposer (group_top_n 등)
    extracted_values: Dict[str, Any]    # value_retriever

    selected_tables: List[str]          # schema_selector
    selected_columns: Dict[str, List[str]]  # schema_selector
    schema_text: str                    # schema_selector

    join_plan: List[str]                # join_planner

    candidates: List[SQLCandidate]      # candidate_generator (※ sql_candidates 아님)
    selected_sql: str                   # 최종 선택 SQL (※ chosen_sql 아님)

    guard_passed: bool                  # guardrails
    ut_passed: bool                     # unit_tester
    exec_report: Optional[ExecReport]   # execute_preview

    judge_accepted: bool                # judge (※ quality_score 아님)
    judge_rationale: str                # judge

    repair_count: int                   # repair (※ repair_attempts 아님)
    max_retries: int
    last_error_type: Optional[ErrorType]  # 에러 추적 (※ error_messages 아님)
    last_error_msg: Optional[str]
```

## 원칙
- **새 필드 추가**: state.py에 먼저 정의 필수
- **필드명 변경 금지**: 직렬화 호환성 깨짐
- **각 노드**: 자신이 담당하는 필드만 수정

---

# Agent별 역할

| 단계 | Agent | 역할 | 입력 | 출력 | 주의사항 |
|------|-------|------|------|------|---------|
| 1 | decomposer | 질문 분석 | question | intent, query_pattern | 시간 표현 명확화 (\"이번달\"→YYYY-MM) |
| 2 | schema_selector | 테이블 선택 (RAG) | question | selected_tables, schema_text | JSON 메타 우선, DB 직접 조회는 prepare만 |
| 3 | value_retriever | 값 매핑 | extracted_values | mapped_values | enum 값 검증 필수 |
| 4 | join_planner | JOIN 경로 | selected_tables | join_paths | FK 기반만 허용, Cartesian join 금지 |
| 5 | candidate_generator ⚠️ | SQL 후보 N개 (기본 2, T2SQL_NUM_CANDIDATES) | schema_text | candidates | conservative, recall, metric 전략 |
| 6 | sql_postprocess | AST 정규화 | candidates | normalized_sql | sqlglot 변환 유지 |
| 7 | guardrails | 보안 검사 | sql | guard_passed: bool | DDL/DML 차단, SELECT만 허용 |
| 8 | unit_tester | 문법 검사 | sql | ut_passed: bool | 실행 전 정적 검증 |
| 9 | execute_preview | DB 실행 | selected_sql | ExecReport | LIMIT 필수, timeout 적용 |
| 10 | judge | 품질 평가 | exec_report | judge_accepted, judge_rationale | 질문-결과 일치도 판정 |
| 11 | repair ⚠️ | SQL 수정 | sql, last_error_msg | fixed_sql | 최대 3회 재시도(repair_count), 에러 분석 필수 |
| 12 | result_output | 최종 결과 + 메모리/감사 | selected_sql | final_result | 사용자 친화적 포맷; memory/audit/auto_feedback 내부 호출 |
| - | safe_fail (보조) | 모든 단계의 실패 처리 | error | safe error | guardrails/unit_tester/execute_preview 실패 시 진입 |

**⚠️ 핵심 agent**:
- **candidate_generator**: 3개 후보가 다양해야 함 (conservative/recall/metric)
- **repair**: 에러 패턴 분석 후 근본 원인 수정

---

# SQL 규칙

```sql
-- ✅ 올바른 패턴
SELECT col1, col2, col3
FROM table_name t1
INNER JOIN table2 t2 ON t1.id = t2.id
WHERE condition = ?
LIMIT 50  -- 또는 FETCH FIRST 50 ROWS ONLY

-- ❌ 금지
SELECT *              -- 구체적 컬럼 명시
SELECT ... LIMIT 1000000  -- 너무 많음
INSERT INTO ...       -- DML 차단
```

규칙:
- **LIMIT 또는 FETCH FIRST 필수**
- **alias 명확히** (SELECT t1.col AS column_alias)
- **JOIN 조건 필수** (ON 절 필수)
- **Oracle 문법 준수** (TRUNC, SYSDATE, SUBSTR 등)
- **완전한 테이블명** (스키마.테이블 권장)

---

# 테스트 작성 가이드

## Unit 테스트 (@pytest.mark.unit)
DB 불필요, mock 사용. 각 agent 단위로:

```python
@pytest.mark.unit
def test_decomposer_simple_question():
    """분해기가 단순 질문을 올바르게 구조화."""
    state = new_state(question="올해 매출은?")
    result = decomposer(state, {})
    
    assert result["intent"] == "aggregation"
    assert "current year" in result["query_pattern"]
    assert result["status"] == "success"

@pytest.mark.unit
def test_guardrails_blocks_dml():
    """guardrails가 INSERT 쿼리를 차단."""
    state = new_state(question="...")
    state.chosen_sql = "INSERT INTO table VALUES (1, 2)"
    
    result = guardrails(state, {})
    assert result["ok"] == False
    assert "DML" in result["reason"]
```

## Integration 테스트 (@pytest.mark.integration)
Oracle DB 필수. 파이프라인 통합 테스트:

```python
@pytest.mark.integration
def test_end_to_end_oracle_query():
    """E2E: 질문 → SQL → 결과."""
    state = new_state(question="최근 1개월 판매량", db_id="oracle_prod")
    
    # Phase 1: SQL 생성
    graph = get_compiled_graph()
    result = graph.invoke(input=state)
    
    assert result["status"] == "completed"
    assert len(result["exec_report"]["rows"]) > 0
```

---

# 에러 처리 패턴

## Pattern 1: Agent 내 에러
```python
def my_agent(state: GraphState, config: dict[str, Any]) -> dict[str, Any]:
    try:
        result = some_operation(state.question)
        logger.info(f"작업 완료: {result}")
        return {"output": result, "status": "success"}
    except ValueError as e:
        logger.error(f"입력 오류: {e}")
        return {"error": str(e), "status": "failed"}
    except Exception as e:
        logger.error(f"예상 외 오류: {e}", exc_info=True)
        raise
```

## Pattern 2: DB 실행 에러
```python
try:
    result = executor.execute(sql, limit=50)
    if result.ok:
        logger.info(f"실행 성공: {len(result.rows)} 행")
        return {"rows": result.rows, "status": "success"}
    else:
        logger.error(f"실행 실패: {result.error_message}")
        return {"error": result.error_message, "status": "failed"}
except Exception as e:
    logger.error(f"Executor 오류: {e}", exc_info=True)
    raise
```

---

# 로깅 규칙

```python
from text2sql.tools import logger

# ✅ 올바른 사용
logger.info(f"질문 수신: {question}")       # 주요 단계
logger.debug(f"선택 테이블: {tables}")      # 상세 정보
logger.error(f"SQL 오류: {error}", exc_info=True)  # 예외는 exc_info=True

# ❌ 금지
print("debug")                              # logger 사용
logger.info(password)                       # 민감 정보 기록
logger.error(full_traceback_string)         # exc_info=True 사용
```

레벨별 사용:
- **info**: 주요 진행 상황 (질문 수신, 테이블 선택, SQL 생성 완료)
- **debug**: 상세 정보 (중간 값, 후보 선택)
- **error**: 오류 발생 (예외 포함 exc_info=True)
- **warning**: 비정상이지만 계속 실행 가능 (타임아웃 임박)

---

# 작업 기록 (필수)

모든 코드 변경은 기록을 남긴다: `ai-history/tasks/{timestamp}_{task_name}.md`

```markdown
# [Task Name]

## [요청]
사용자 입력 원문 (정확히 복사)

## [분석]
- **문제 원인**: 구체적 설명
- **영향 범위**: 수정될 파일들
  - src/text2sql/agents/xyz.py
  - src/text2sql/tools/abc.py

## [수정 내용]
- **파일 A**: 무엇을 변경했는가
- **파일 B**: 무엇을 변경했는가

## [변경 코드]
\`\`\`diff
# Before
def func():
    pass

# After
def func():
    logger.info("...")
    return result
\`\`\`

## [테스트]
- [x] unit 테스트 작성 및 통과
- [x] CLI 수동 테스트 (scripts\execution\run_cli.py -q "...")
- [x] Streamlit UI 테스트
- [ ] integration 테스트 (Oracle 필요하면)
```

---

# 코드 리뷰 자체 체크리스트

커밋하기 전 **반드시** 확인:

### 구조
- [ ] LangGraph 노드 추가/제거 없음?
- [ ] graph.py 연결 순서 변경 없음?
- [ ] GraphState 필드명 변경 없음? (새 필드는 state.py에 정의?)

### 코드 품질
- [ ] 모든 함수에 타입 힌트? (인자 + 반환값)
- [ ] 모든 함수에 docstring? (역할 명시)
- [ ] 모든 에러 경로 처리? (try/except)
- [ ] print() 없음? (logger만 사용?)
- [ ] 불필요한 주석 제거?

### 테스트
- [ ] Unit 테스트 작성? (@pytest.mark.unit)
- [ ] `pytest -m unit` 통과?
- [ ] 수동 테스트 완료? (CLI/Streamlit)

### 보안
- [ ] SELECT * 없음?
- [ ] DML/DDL 없음?
- [ ] hallucination (존재하지 않는 컬럼) 없음?

### 성능
- [ ] 불필요한 LLM 호출 제거?
- [ ] RAG 결과 최소화? (상위 10개만)
- [ ] LIMIT/FETCH FIRST 추가?

---

# 참고

- **SKILL**: `.claude/skills/ground-rule.md` (상세 가이드)
- **구조**: `docs/PROJECT_STRUCTURE.md` (전체 맵)
- **메모리**: `.serena/memories/` (Serena 분석)
- **문서**: `docs/` (운영 가이드)

---

**마지막 업데이트**: 2025-05-12
