from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Dict, List

import pytest

from text2sql.eval.kpi_runner import (
    bind_runtime,
    compare_query_results,
    discover_repo,
    evaluate_spider_accuracy,
    has_live_azure_credentials,
    load_kpi_config,
    pick_cases,
    resolve_case_limit,
    render_query_correctness_summary,
    render_safety_summary,
    render_scenarios_summary,
    render_ttr_summary,
    resolve_output_dir,
    write_json,
)


def pytest_addoption(parser: pytest.Parser) -> None:
    group = parser.getgroup("kpi")
    group.addoption("--kpi-mode", action="store", default=None, choices=("smoke", "full"))
    group.addoption("--kpi-config", action="store", default=None)
    group.addoption("--kpi-output", action="store", default=None)
    group.addoption("--spider-baseline", action="store", default=None)
    group.addoption("--warm", action="store_true", default=False)
    group.addoption("--cold", action="store_true", default=False)
@pytest.fixture(scope="session")
def repo_discovery():
    return discover_repo()


@pytest.fixture(scope="session")
def repo_root(repo_discovery) -> Path:
    return repo_discovery.root


@pytest.fixture(scope="session")
def kpi_config_path(pytestconfig: pytest.Config, repo_root: Path) -> Path:
    value = pytestconfig.getoption("--kpi-config") or os.getenv("T2SQL_KPI_CONFIG")
    if value:
        path = Path(value)
        return path if path.is_absolute() else repo_root / path
    return repo_root / "tests" / "kpi" / "kpi_config.yaml"


@pytest.fixture(scope="session")
def kpi_config(kpi_config_path: Path) -> Dict[str, object]:
    return load_kpi_config(kpi_config_path)


@pytest.fixture(scope="session")
def kpi_mode(pytestconfig: pytest.Config, kpi_config: Dict[str, object]) -> str:
    return (
        pytestconfig.getoption("--kpi-mode")
        or os.getenv("T2SQL_KPI_MODE")
        or kpi_config.get("run", {}).get("mode", "full")
    )


@pytest.fixture(scope="session")
def kpi_output_dir(
    pytestconfig: pytest.Config,
    repo_discovery,
    kpi_config: Dict[str, object],
) -> Path:
    value = pytestconfig.getoption("--kpi-output") or os.getenv("T2SQL_KPI_OUTPUT_DIR")
    override = None
    if value:
        override = Path(value)
        if not override.is_absolute():
            override = repo_discovery.root / override
    return resolve_output_dir(repo_discovery, kpi_config, override)


@pytest.fixture(scope="session")
def runtime_handles(repo_discovery):
    return bind_runtime(repo_discovery)


@pytest.fixture(scope="session")
def live_azure_credentials() -> bool:
    return has_live_azure_credentials()


@pytest.fixture
def require_live_azure(live_azure_credentials: bool) -> None:
    if not live_azure_credentials:
        pytest.skip("Azure OpenAI live credentials are not available")


@pytest.fixture(scope="session")
def max_retries(kpi_config: Dict[str, object]) -> int:
    return int(kpi_config.get("run", {}).get("max_retries", 3))


@pytest.fixture(scope="session")
def chinook_cases(kpi_config: Dict[str, object], kpi_mode: str) -> List[Dict[str, object]]:
    return pick_cases(kpi_config, "chinook", kpi_mode)


@pytest.fixture(scope="session")
def monitor_cases(kpi_config: Dict[str, object], kpi_mode: str) -> List[Dict[str, object]]:
    return pick_cases(kpi_config, "monitor", kpi_mode)


@pytest.fixture(scope="session")
def ttr_cases(kpi_config: Dict[str, object], kpi_mode: str) -> List[Dict[str, object]]:
    return pick_cases(kpi_config, "ttr", kpi_mode)


@pytest.fixture(scope="session")
def safety_cases(kpi_config: Dict[str, object], kpi_mode: str) -> List[Dict[str, object]]:
    return pick_cases(kpi_config, "safety", kpi_mode)


@pytest.fixture(scope="session")
def scenario_cases(settings, kpi_config: Dict[str, object], kpi_mode: str) -> List[Dict[str, object]]:
    cases = list(settings.scenarios())
    limit = resolve_case_limit(kpi_config, "scenarios", kpi_mode)
    if limit is None:
        return cases
    return cases[:limit]


@pytest.fixture(scope="session")
def kpi_thresholds(kpi_config: Dict[str, object]) -> Dict[str, float]:
    return dict(kpi_config.get("kpi", {}))


@pytest.fixture(scope="session")
def spider_baseline_path(pytestconfig: pytest.Config, repo_root: Path, kpi_config: Dict[str, object]):
    value = pytestconfig.getoption("--spider-baseline") or os.getenv("T2SQL_KPI_SPIDER_BASELINE")
    if not value:
        value = kpi_config.get("paths", {}).get("spider_baseline")
    if not value:
        return None
    path = Path(value)
    return path if path.is_absolute() else repo_root / path


@pytest.fixture(scope="session")
def requested_ttr_modes(pytestconfig: pytest.Config, kpi_config: Dict[str, object]) -> List[str]:
    warm = pytestconfig.getoption("--warm")
    cold = pytestconfig.getoption("--cold")
    if warm and cold:
        return ["warm", "cold"]
    if warm:
        return ["warm"]
    if cold:
        return ["cold"]
    return list(kpi_config.get("run", {}).get("ttr_modes", ["warm"]))


@pytest.fixture(scope="session")
def ttr_assert_mode(kpi_config: Dict[str, object]) -> str:
    return str(kpi_config.get("run", {}).get("ttr_assert_mode", "warm"))


@pytest.fixture(scope="session")
def artifact_writer(kpi_output_dir: Path) -> Callable[[str, Dict[str, object]], Path]:
    def _write(name: str, payload: Dict[str, object]) -> Path:
        return write_json(kpi_output_dir / name, payload)

    return _write


@pytest.fixture(scope="session")
def comparer():
    return compare_query_results


@pytest.fixture(scope="session")
def report_renderers():
    return {
        "query_correctness": render_query_correctness_summary,
        "ttr": render_ttr_summary,
        "safety": render_safety_summary,
        "scenarios": render_scenarios_summary,
    }


@pytest.fixture(scope="session")
def spider_runner(repo_discovery, kpi_config, kpi_mode, max_retries, kpi_output_dir):
    def _run(baseline_path=None):
        return evaluate_spider_accuracy(
            repo_discovery,
            kpi_config,
            kpi_mode,
            max_retries,
            kpi_output_dir,
            baseline_path=baseline_path,
        )

    return _run


@pytest.fixture(scope="session")
def skip_spider_query_correctness() -> bool:
    return os.getenv("T2SQL_KPI_SKIP_SPIDER", "").lower() in {"1", "true", "yes"}
