from __future__ import annotations

import pytest

from text2sql.eval.kpi_runner import evaluate_scenarios, render_scenarios_summary, utc_now_iso

pytestmark = [pytest.mark.kpi, pytest.mark.slow, pytest.mark.benchmark]


def test_scenarios(
    require_live_azure,
    runtime_handles,
    repo_discovery,
    kpi_config,
    scenario_cases,
    max_retries,
    kpi_mode,
    kpi_thresholds,
    artifact_writer,
):
    report = evaluate_scenarios(
        runtime_handles,
        repo_discovery,
        kpi_config,
        scenario_cases,
        max_retries,
    )
    payload = {
        "suite": "scenarios",
        "generated_at": utc_now_iso(),
        "mode": kpi_mode,
        **report,
    }
    artifact_writer("scenarios.json", payload)
    print(render_scenarios_summary(report))

    if kpi_mode != "full":
        return

    pass_rate = report.get("pass_rate")
    assert pass_rate is not None, "Scenario tests did not execute any cases"
    assert pass_rate >= float(kpi_thresholds["scenario_min"])
