from __future__ import annotations

import warnings

import pytest

from text2sql.eval.kpi_runner import evaluate_local_query_cases, render_query_correctness_summary, utc_now_iso

pytestmark = [pytest.mark.kpi, pytest.mark.slow, pytest.mark.benchmark]


def test_query_correctness(
    require_live_azure,
    runtime_handles,
    repo_discovery,
    kpi_config,
    chinook_cases,
    monitor_cases,
    max_retries,
    spider_runner,
    spider_baseline_path,
    skip_spider_query_correctness,
    kpi_thresholds,
    kpi_mode,
    artifact_writer,
):
    chinook_report = evaluate_local_query_cases(
        runtime_handles,
        repo_discovery,
        kpi_config,
        chinook_cases,
        max_retries,
        worker_section="chinook",
    )
    monitor_report = evaluate_local_query_cases(
        runtime_handles,
        repo_discovery,
        kpi_config,
        monitor_cases,
        max_retries,
        worker_section="monitor",
    )
    spider_report = (
        {"status": "skip", "reason": "disabled_for_combined_run"}
        if skip_spider_query_correctness
        else spider_runner(spider_baseline_path)
    )
    if spider_report.get("status") == "measured" and spider_report.get("baseline_accuracy") is None:
        warnings.warn("Spider baseline not available; delta is omitted", RuntimeWarning)

    report = {
        "suite": "query_correctness",
        "generated_at": utc_now_iso(),
        "mode": kpi_mode,
        "chinook": chinook_report,
        "monitor": monitor_report,
        "spider": spider_report,
    }
    artifact_writer("query_correctness.json", report)
    print(render_query_correctness_summary(report))

    if kpi_mode == "smoke":
        return

    chinook_accuracy = chinook_report.get("accuracy")
    assert chinook_accuracy is not None, "Chinook KPI did not execute any cases"
    assert chinook_accuracy >= float(kpi_thresholds["chinook_min"])

    if spider_report.get("status") != "skip":
        spider_accuracy = spider_report.get("current_accuracy")
        assert spider_accuracy is not None, "Spider KPI could not produce accuracy"
        assert spider_accuracy >= float(kpi_thresholds["spider_min"])
