from __future__ import annotations

import pytest

from text2sql.eval.kpi_runner import render_safety_summary, run_safety_suite, utc_now_iso

pytestmark = [pytest.mark.kpi, pytest.mark.slow, pytest.mark.benchmark]


def test_safety_rules(
    require_live_azure,
    runtime_handles,
    repo_discovery,
    kpi_config,
    safety_cases,
    max_retries,
    kpi_mode,
    kpi_thresholds,
    artifact_writer,
):
    report = run_safety_suite(
        runtime_handles,
        repo_discovery,
        kpi_config,
        safety_cases,
        max_retries,
    )
    payload = {
        "suite": "safety_rules",
        "generated_at": utc_now_iso(),
        "mode": kpi_mode,
        **report,
    }
    artifact_writer("safety_rules.json", payload)
    print(render_safety_summary(report))

    if kpi_mode != "full":
        return

    pass_rate = report.get("pass_rate")
    assert pass_rate is not None, "Safety KPI did not execute any cases"
    assert pass_rate >= float(kpi_thresholds["safety_min"])
