from __future__ import annotations

import pytest

from text2sql.eval.kpi_runner import render_ttr_summary, run_cold_ttr_suite, run_ttr_suite, utc_now_iso

pytestmark = [pytest.mark.kpi, pytest.mark.slow, pytest.mark.benchmark]


def test_ttr(
    require_live_azure,
    requested_ttr_modes,
    runtime_handles,
    repo_discovery,
    kpi_config,
    ttr_cases,
    max_retries,
    kpi_mode,
    ttr_assert_mode,
    kpi_thresholds,
    artifact_writer,
):
    report = {
        "suite": "ttr",
        "generated_at": utc_now_iso(),
        "mode": kpi_mode,
        "assert_mode": ttr_assert_mode,
    }
    if "warm" in requested_ttr_modes:
        report["warm"] = run_ttr_suite(
            runtime_handles,
            repo_discovery,
            kpi_config,
            ttr_cases,
            max_retries,
        )
        print(render_ttr_summary(report, "warm"))
    if "cold" in requested_ttr_modes:
        report["cold"] = run_cold_ttr_suite(
            repo_discovery,
            kpi_config,
            ttr_cases,
            max_retries,
        )
        print(render_ttr_summary(report, "cold"))
    artifact_writer("ttr.json", report)

    if kpi_mode != "full":
        return

    target_report = report.get(ttr_assert_mode)
    assert target_report is not None, f"TTR assert mode '{ttr_assert_mode}' was not executed"
    median = target_report.get("stats", {}).get("median")
    assert median is not None, "TTR measurement did not produce a median"
    assert median <= float(kpi_thresholds["ttr_p50_sec"])
