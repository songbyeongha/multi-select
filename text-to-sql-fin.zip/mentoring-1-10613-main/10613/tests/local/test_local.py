"""
Local 유닛 테스트 — 파이프라인 핵심 컴포넌트
═══════════════════════════════════════════════════════════════
LLM 호출 없이 실행 가능한 로컬 컴포넌트 테스트입니다.

실행:
  pytest tests/local/test_local.py -v
"""
import os
import sys
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))


# ═══ 1. Settings ═══════════════════════════════════════════════
@pytest.mark.unit
class TestSettings:

    def test_settings_load(self, settings):
        assert settings.llm.deployment == os.getenv("SKCC_AZURE_MODEL", "gpt-4.1")

    def test_scenarios_load(self, settings):
        scenarios = settings.scenarios()
        assert len(scenarios) == 5, f"Expected 5 scenarios, got {len(scenarios)}"

    def test_schema_metadata(self, settings):
        meta = settings.schema_metadata("chinook")
        assert bool(meta), "chinook schema_metadata should not be empty"

    def test_domain_hints(self, settings):
        hints = settings.domain_hints("chinook")
        assert bool(hints), "chinook domain_hints should not be empty"

    def test_allow_empty_result_default(self, settings):
        assert settings.pipeline.allow_empty_result is True, (
            f"Expected allow_empty_result=True, got {settings.pipeline.allow_empty_result}"
        )


# ═══ 2. Guardrails ═════════════════════════════════════════════
@pytest.mark.unit
class TestGuardrails:

    def test_select_allowed(self, guard):
        r = guard.validate("SELECT * FROM users")
        assert r.valid, "SELECT should be allowed"

    def test_limit_inserted(self, guard):
        from text2sql.config.settings import get_settings
        r = guard.validate("SELECT * FROM users")
        if get_settings().guard.enforce_limit:
            assert "LIMIT" in r.sql.upper(), "LIMIT should be auto-inserted when enforce_limit=true"
        else:
            # enforce_limit=false (eval mode) — LIMIT not auto-inserted
            assert r.valid, "SQL should still be valid when enforce_limit=false"

    def test_drop_blocked(self, guard):
        r = guard.validate("DROP TABLE users")
        assert not r.valid, "DROP should be blocked"

    def test_delete_blocked(self, guard):
        r = guard.validate("DELETE FROM users WHERE id=1")
        assert not r.valid, "DELETE should be blocked"

    def test_existing_limit_preserved(self, guard):
        r = guard.validate("SELECT * FROM t LIMIT 10")
        assert r.valid
        assert r.sql.upper().count("LIMIT") == 1, "Existing LIMIT should not be duplicated"

    def test_fully_qualified_snowflake_table_allowed(self):
        from text2sql.tools.guardrails import SQLGuard

        guard = SQLGuard(["GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210131"])
        sql = "SELECT COUNT(*) FROM GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210131"
        result = guard.validate(sql, dialect="snowflake")
        assert result.valid, result.issues


# ═══ 3. SQLExecutor ════════════════════════════════════════════
@pytest.mark.unit
class TestExecutor:

    def test_chinook_query(self, executor, db_chinook):
        r = executor.execute(db_chinook, "SELECT COUNT(*) AS cnt FROM Artist")
        assert r.ok, f"Chinook query failed: {r.error_message}"
        assert r.rows_preview[0]["cnt"] > 0

    def test_monitor_query(self, executor, db_monitor):
        r = executor.execute(db_monitor, "SELECT COUNT(*) AS cnt FROM api_logs")
        assert r.ok, f"API Monitor query failed: {r.error_message}"
        assert r.rows_preview[0]["cnt"] > 0

    def test_nonexistent_table_schema_error(self, executor, db_chinook):
        from text2sql.lg.state import ErrorType
        r = executor.execute(db_chinook, "SELECT * FROM nonexistent_table")
        assert r.error_type == ErrorType.SCHEMA


# ═══ 4. SchemaReader ═══════════════════════════════════════════
@pytest.mark.unit
class TestSchemaReader:

    CHINOOK_REQUIRED = {
        "album", "artist", "track", "genre", "mediatype",
        "playlist", "playlisttrack", "invoice",
        "invoiceline", "customer", "employee",
    }
    API_REQUIRED = {"api_logs", "services", "error_codes"}

    def test_chinook_required_tables(self, db_chinook):
        from text2sql.tools.executor import SchemaReader
        tables = {t.lower() for t in SchemaReader.tables(db_chinook)}
        missing = self.CHINOOK_REQUIRED - tables
        assert len(missing) == 0, f"Missing chinook tables: {missing}"

    def test_monitor_required_tables(self, db_monitor):
        from text2sql.tools.executor import SchemaReader
        tables = {t.lower() for t in SchemaReader.tables(db_monitor)}
        missing = self.API_REQUIRED - tables
        assert len(missing) == 0, f"Missing monitor tables: {missing}"

    def test_schema_text_generation(self, chinook_schema):
        from text2sql.tools.executor import SchemaReader
        text = SchemaReader.format_text(chinook_schema)
        assert len(text) > 100, f"Schema text too short: len={len(text)}"


# ═══ 5. Schema RAG ═════════════════════════════════════════════
@pytest.mark.unit
class TestSchemaRAG:

    def test_sales_table_selection(self, chinook_schema):
        from text2sql.rag.schema_rag import SchemaSelector
        sel = SchemaSelector(
            keyword_map={"판매": ["Invoice", "InvoiceLine"]},
            relation_bonus={"Invoice": ["Customer"]},
        )
        scores = sel.select("국가별 판매 현황", chinook_schema)
        names = [s.table_name for s in scores]
        assert "Invoice" in names, f"Invoice not in selection: {names}"

    def test_join_plan_generation(self, chinook_schema):
        from text2sql.rag.schema_rag import JoinPlanner
        planner = JoinPlanner(chinook_schema)
        joins = planner.plan(["Invoice", "Customer"])
        assert len(joins) >= 1, f"No join plan generated: {joins}"

    def test_doc_text_includes_rich_metadata(self):
        from text2sql.rag.schema_rag import SchemaSelector

        selector = SchemaSelector(vector_weight=0.0)
        row = {
            "table_name": "EU_SOCCER.EU_SOCCER.LEAGUE",
            "short_name": "LEAGUE",
            "database_name": "EU_SOCCER",
            "schema_name": "EU_SOCCER",
            "table_description": "soccer league metadata",
            "ddl_excerpt": "CREATE TABLE LEAGUE (id NUMBER, name TEXT)",
            "sample_text": "name='England Premier League'",
            "table_aliases": ["LEAGUE", "EU_SOCCER.LEAGUE"],
            "columns": [
                {
                    "name": "name",
                    "type": "TEXT",
                    "description": "league name",
                    "sample_values": ["England Premier League"],
                }
            ],
        }
        doc = selector._doc_text(row)
        assert "soccer league metadata" in doc
        assert "England Premier League" in doc
        assert "CREATE TABLE LEAGUE" in doc
        assert "EU_SOCCER.LEAGUE" in doc


# ═══ 6. State ══════════════════════════════════════════════════
@pytest.mark.unit
class TestState:

    def test_initial_state(self):
        from text2sql.lg.state import new_state
        st = new_state("테스트", "chinook", "/tmp/chinook.db")
        assert st["question"] == "테스트"

    def test_success_false_default(self):
        from text2sql.lg.state import new_state
        st = new_state("테스트", "chinook", "/tmp/chinook.db")
        assert not st["success"]

    def test_repair_count_zero(self):
        from text2sql.lg.state import new_state
        st = new_state("테스트", "chinook", "/tmp/chinook.db")
        assert st["repair_count"] == 0


# ═══ 7. AuditLogger ════════════════════════════════════════════
@pytest.mark.unit
class TestAuditLogger:

    def test_audit_log_record(self):
        from text2sql.tools.audit import log_execution
        aid = log_execution("테스트 질문", "SELECT 1", "chinook", True, "테스트 요약")
        assert len(aid) > 0, "Audit log ID should not be empty"


# ═══ 8. Repair → Guardrails 경로 ═══════════════════════════════
@pytest.mark.unit
class TestRepairEdge:

    def test_repair_to_guardrails_edge(self):
        try:
            from text2sql.lg.graph import build_graph
            g = build_graph()
            compiled = g.compile()
            graph_json = compiled.get_graph().to_json()
            graph_data = json.loads(graph_json) if isinstance(graph_json, str) else graph_json

            repair_targets = set()
            for edge in graph_data.get("edges", []):
                if edge.get("source") == "repair":
                    repair_targets.add(edge.get("target"))

            assert "guardrails" in repair_targets, (
                f"Repair → Guardrails edge missing. Targets: {repair_targets}"
            )
            assert "candidate_gen" not in repair_targets, (
                f"Repair → CandidateGen edge should NOT exist. Targets: {repair_targets}"
            )
        except ImportError:
            # langgraph 미설치 시 소스 검증으로 대체
            graph_src = (ROOT / "src" / "text2sql" / "lg" / "graph.py").read_text(encoding="utf-8")
            assert '"guardrails"' in graph_src, "graph.py should reference guardrails"


# ═══ 9. 빈 결과(0행) 정책 ═══════════════════════════════════════
@pytest.mark.unit
class TestEmptyResultPolicy:

    def test_empty_exec_report_ok(self):
        from text2sql.lg.state import ExecReport
        empty_report = ExecReport(ok=True, rows_preview=[], row_count=0)
        assert empty_report.ok

    def test_allow_empty_result_setting(self, settings):
        assert hasattr(settings.pipeline, "allow_empty_result")

    def test_zero_rows_reaches_judge(self):
        from text2sql.lg.state import ExecReport
        empty_report = ExecReport(ok=True, rows_preview=[], row_count=0)
        assert empty_report.ok is True and empty_report.row_count == 0


@pytest.mark.unit
# ═══ 10. 그래프 순서 검증 ═══════════════════════════════════════
@pytest.mark.unit
class TestGraphOrdering:

    def test_decomposer_to_schema_selector(self):
        try:
            from text2sql.lg.graph import build_graph
            g = build_graph()
            compiled = g.compile()
            graph_json = compiled.get_graph().to_json()
            graph_data = json.loads(graph_json) if isinstance(graph_json, str) else graph_json

            decomposer_targets = set()
            schema_sel_targets = set()
            for edge in graph_data.get("edges", []):
                if edge.get("source") == "decomposer":
                    decomposer_targets.add(edge.get("target"))
                if edge.get("source") == "schema_selector":
                    schema_sel_targets.add(edge.get("target"))

            assert "schema_selector" in decomposer_targets, (
                f"Decomposer should connect to SchemaSelector. Targets: {decomposer_targets}"
            )
            assert "value_retriever" in schema_sel_targets, (
                f"SchemaSelector should connect to ValueRetriever. Targets: {schema_sel_targets}"
            )
        except ImportError:
            graph_src = (ROOT / "src" / "text2sql" / "lg" / "graph.py").read_text(encoding="utf-8")
            assert '"schema_selector"' in graph_src
            assert '"value_retriever"' in graph_src


# ═══ 11. ConversationMemory ═════════════════════════════════════
@pytest.mark.unit
class TestConversationMemory:

    def test_save_and_size(self, memory):
        memory.save("올해 가장 많이 팔린 앨범은?", "SELECT * FROM albums LIMIT 10", "chinook",
                     True, "Greatest Hits", row_count=5, tables_used=["albums", "invoices"])
        memory.save("실패한 쿼리", "SELECT * FROM bad_table", "chinook",
                     False, "FAIL", row_count=0, tables_used=["albums"])
        assert memory.size() == 2, f"Expected size=2, got {memory.size()}"

    def test_find_similar(self, memory):
        memory.save("올해 가장 많이 팔린 앨범은?", "SELECT * FROM albums LIMIT 10", "chinook",
                     True, "Greatest Hits", row_count=5, tables_used=["albums", "invoices"])
        similar = memory.find_similar("올해 가장 많이 팔린 앨범은 뭐야?", db_id="chinook")
        assert similar is not None and similar.success

    def test_get_failed_patterns(self, memory):
        memory.save("실패한 쿼리", "SELECT * FROM bad_table", "chinook",
                     False, "FAIL", row_count=0, tables_used=["albums"])
        failed = memory.get_failed_patterns(db_id="chinook", n=3)
        assert len(failed) >= 1 and "bad_table" in failed[0]

    def test_context_string(self, memory):
        memory.save("올해 가장 많이 팔린 앨범은?", "SELECT * FROM albums LIMIT 10", "chinook",
                     True, "Greatest Hits", row_count=5, tables_used=["albums"])
        ctx = memory.get_context_string(db_id="chinook", n=5)
        assert "[이전 대화 이력]" in ctx and "올해 가장" in ctx

    def test_wrong_db_filtering(self, memory):
        memory.save("올해 가장 많이 팔린 앨범은?", "SELECT * FROM albums", "chinook",
                     True, "Greatest Hits")
        result = memory.find_similar("올해 가장 많이 팔린 앨범은?", db_id="wrong_db")
        assert result is None


# ═══ 12. SQLExecutor 타임아웃 ═══════════════════════════════════
@pytest.mark.unit
class TestExecutorTimeout:

    def test_custom_timeout(self):
        from text2sql.tools.executor import SQLExecutor
        exe = SQLExecutor(timeout_ms=15000)
        assert exe._timeout_ms == 15000

    def test_default_timeout(self):
        from text2sql.tools.executor import SQLExecutor
        exe = SQLExecutor()
        assert exe._timeout_ms == 15000, f"Expected 15000, got {exe._timeout_ms}"


# ═══ 13. 버전 검증 ═════════════════════════════════════════════
@pytest.mark.unit
class TestVersion:

    def test_version(self):
        import text2sql
        assert text2sql.__version__ == "1.0.0", f"Expected 1.0.0, got {text2sql.__version__}"


# ═══ 14. TIMEOUT Repair 프롬프트 ════════════════════════════════
@pytest.mark.unit
class TestTimeoutRepairPrompt:

    def test_timeout_key_exists(self):
        try:
            from text2sql.llm.prompts import REPAIR_PROMPTS
            assert "TIMEOUT" in REPAIR_PROMPTS, (
                f"TIMEOUT not in REPAIR_PROMPTS keys: {list(REPAIR_PROMPTS.keys())}"
            )
        except ImportError:
            prompts_src = (ROOT / "src" / "text2sql" / "llm" / "prompts.py").read_text(encoding="utf-8")
            assert '"TIMEOUT"' in prompts_src

    def test_timeout_has_optimization_hints(self):
        try:
            from text2sql.llm.prompts import REPAIR_PROMPTS
            assert "early filtering" in REPAIR_PROMPTS.get("TIMEOUT", ""), (
                "TIMEOUT prompt should contain optimization hints"
            )
        except ImportError:
            prompts_src = (ROOT / "src" / "text2sql" / "llm" / "prompts.py").read_text(encoding="utf-8")
            assert "early filtering" in prompts_src


# ═══ 15. 설정값 연결 검증 ═══════════════════════════════════════
@pytest.mark.unit
class TestSettingsValues:

    def test_num_candidates(self, settings):
        assert settings.pipeline.num_candidates == 3

    def test_preview_limit(self, settings):
        assert settings.pipeline.preview_limit == 50

    def test_embed_deployment_field(self, settings):
        assert hasattr(settings.embed, "deployment"), "EmbedCfg should have deployment field"


# ═══ 16. 캐시 키 충돌 방지 ═══════════════════════════════════════
@pytest.mark.unit
class TestCacheKey:

    def test_different_prefix_different_key(self):
        try:
            import importlib.util
            spec = importlib.util.spec_from_file_location(
                "text2sql.agents._utils",
                ROOT / "src" / "text2sql" / "agents" / "_utils.py",
            )
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            make_cache_key = mod.make_cache_key

            k1 = make_cache_key("schema_sel", "test", "/db")
            k2 = make_cache_key("join_plan", "test", "/db")
            assert k1 != k2, f"Same cache key for different prefix: k1={k1}, k2={k2}"
            assert k1.startswith("schema_sel_") and k2.startswith("join_plan_")
        except Exception:
            utils_src = (ROOT / "src" / "text2sql" / "agents" / "_utils.py").read_text(encoding="utf-8")
            assert 'f"{prefix}_' in utils_src or "f\"{prefix}_" in utils_src


# ═══ 17. 벡터 스토어 모듈 ═══════════════════════════════════════
@pytest.mark.unit
class TestVectorStore:

    def test_module_exists(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "vector_store.py").read_text(encoding="utf-8")
        assert "class SchemaVectorStore" in src
        assert "class AzureEmbedder" in src

    def test_chromadb_import(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "vector_store.py").read_text(encoding="utf-8")
        assert "import chromadb" in src, "vector_store.py should import chromadb"

    def test_get_vector_store_utility(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "vector_store.py").read_text(encoding="utf-8")
        assert "def get_vector_store" in src

    def test_build_index_method(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "vector_store.py").read_text(encoding="utf-8")
        assert "def build_index" in src

    def test_cosine_similarity_conversion(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "vector_store.py").read_text(encoding="utf-8")
        assert "1.0 - distance" in src


# ═══ 18. SchemaSelector 하이브리드 검증 ═══════════════════════════
@pytest.mark.unit
class TestSchemaSelectorHybrid:

    def test_vector_weight_parameter(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "schema_rag.py").read_text(encoding="utf-8")
        assert "vector_weight" in src

    def test_db_id_parameter(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "schema_rag.py").read_text(encoding="utf-8")
        assert "db_id: str | None = None" in src

    def test_get_vector_scores_method(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "schema_rag.py").read_text(encoding="utf-8")
        assert "def _get_vector_scores" in src

    def test_merge_scores_method(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "schema_rag.py").read_text(encoding="utf-8")
        assert "def _merge_scores" in src

    def test_normalize_method(self):
        src = (ROOT / "src" / "text2sql" / "rag" / "schema_rag.py").read_text(encoding="utf-8")
        assert "def _normalize" in src

    def test_vector_weight_setting(self, chinook_schema):
        from text2sql.rag.schema_rag import SchemaSelector
        hs = SchemaSelector(vector_weight=0.3)
        assert hs._vector_weight == 0.3

    def test_bm25_only_mode(self, chinook_schema):
        from text2sql.rag.schema_rag import SchemaSelector
        hs = SchemaSelector(vector_weight=0.3)
        scores = hs.select("국가별 판매", chinook_schema, top_k=3, db_id=None)
        assert len(scores) >= 1, f"Expected at least 1 table, got {len(scores)}"


# ═══ 19. SQLPostProcessor ════════════════════════════════════
@pytest.mark.unit
class TestSQLPostProcessor:
    """AST 기반 SQL 후처리기 테스트"""

    @pytest.fixture
    def pp(self):
        from text2sql.tools.sql_postprocess import SQLPostProcessor
        return SQLPostProcessor()

    # ── CAST 제거 ─────────────────────────────────────────
    def test_remove_cast_int(self, pp):
        sql = "SELECT CAST(age AS INTEGER) FROM singer"
        result = pp.process(sql)
        assert "CAST" not in result.upper()
        assert "age" in result.lower()

    def test_remove_cast_text(self, pp):
        sql = "SELECT CAST(name AS TEXT), CAST(id AS INTEGER) FROM t"
        result = pp.process(sql)
        assert "CAST" not in result.upper()

    def test_cast_in_where(self, pp):
        sql = "SELECT * FROM t WHERE CAST(x AS INTEGER) > 5"
        result = pp.process(sql)
        assert "CAST" not in result.upper()
        assert "> 5" in result

    # ── alias 제거 ────────────────────────────────────────
    def test_strip_column_alias(self, pp):
        sql = "SELECT name AS singer_name, country AS singer_country FROM singer"
        result = pp.process(sql)
        # SELECT 절의 컬럼 alias가 제거되어야 함
        assert "singer_name" not in result
        assert "singer_country" not in result
        assert "name" in result.lower()

    def test_strip_count_alias(self, pp):
        sql = "SELECT COUNT(*) AS total FROM singer"
        result = pp.process(sql)
        assert "total" not in result.lower()
        assert "COUNT(*)" in result.upper()

    def test_preserve_cte_alias(self, pp):
        sql = "WITH base AS (SELECT id FROM t) SELECT * FROM base"
        result = pp.process(sql)
        # CTE 이름 "base"는 보존되어야 함
        assert "base" in result.lower()

    def test_preserve_subquery_alias(self, pp):
        sql = "SELECT * FROM (SELECT id FROM t) AS sub"
        result = pp.process(sql)
        assert "sub" in result.lower()

    # ── LEFT → INNER JOIN ────────────────────────────────
    def test_left_to_inner_join(self, pp):
        sql = "SELECT * FROM a LEFT JOIN b ON a.id = b.a_id"
        result = pp.process(sql)
        assert "LEFT" not in result.upper()
        assert "JOIN" in result.upper()

    def test_left_outer_to_inner(self, pp):
        sql = "SELECT * FROM a LEFT OUTER JOIN b ON a.id = b.a_id"
        result = pp.process(sql)
        assert "LEFT" not in result.upper()

    def test_inner_join_unchanged(self, pp):
        sql = "SELECT * FROM a JOIN b ON a.id = b.a_id"
        result = pp.process(sql)
        assert "JOIN" in result.upper()

    # ── 방어적 패턴 제거 ─────────────────────────────────
    def test_remove_coalesce(self, pp):
        sql = "SELECT COALESCE(name, 'N/A') FROM singer"
        result = pp.process(sql)
        assert "COALESCE" not in result.upper()
        assert "name" in result.lower()

    def test_remove_ifnull(self, pp):
        sql = "SELECT IFNULL(age, 0) FROM singer"
        result = pp.process(sql)
        assert "IFNULL" not in result.upper()

    def test_remove_is_not_null_join_column(self, pp):
        """JOIN ON 컬럼의 IS NOT NULL은 중복이므로 제거"""
        sql = (
            "SELECT * FROM t "
            "JOIN s ON t.id = s.t_id "
            "WHERE t.id IS NOT NULL AND age > 5"
        )
        result = pp.process(sql)
        assert "IS NOT NULL" not in result.upper()
        assert "age > 5" in result.lower()

    def test_preserve_is_not_null_independent_filter(self, pp):
        """JOIN과 무관한 독립 필터 IS NOT NULL은 보존"""
        sql = "SELECT * FROM t WHERE name IS NOT NULL AND age > 5"
        result = pp.process(sql)
        assert "NOT" in result.upper() and "NULL" in result.upper()
        assert "age > 5" in result.lower()

    def test_preserve_standalone_is_not_null(self, pp):
        """단독 IS NOT NULL은 비즈니스 필터이므로 보존"""
        sql = "SELECT * FROM t WHERE name IS NOT NULL"
        result = pp.process(sql)
        assert "WHERE" in result.upper()

    def test_only_join_col_is_not_null_removes_where(self, pp):
        """JOIN 컬럼만의 IS NOT NULL이면 WHERE 제거"""
        sql = (
            "SELECT * FROM t "
            "JOIN s ON t.id = s.t_id "
            "WHERE t.id IS NOT NULL"
        )
        result = pp.process(sql)
        assert "WHERE" not in result.upper()

    # ── 복합 변환 ─────────────────────────────────────────
    def test_combined_transforms(self, pp):
        sql = (
            "SELECT CAST(name AS TEXT) AS singer_name "
            "FROM singer JOIN album ON singer.id = album.singer_id "
            "WHERE singer.id IS NOT NULL AND COALESCE(country, 'US') = 'US'"
        )
        result = pp.process(sql)
        assert "CAST" not in result.upper()
        assert "COALESCE" not in result.upper()

    def test_no_change_simple_sql(self, pp):
        sql = "SELECT name, age FROM singer WHERE country = 'US'"
        result = pp.process(sql)
        # 변환 대상 없으면 의미 동일한 SQL 반환
        assert "name" in result.lower()
        assert "age" in result.lower()
        assert "country" in result.lower()

    def test_except_preserved(self, pp):
        sql = "SELECT name FROM singer EXCEPT SELECT name FROM composer"
        result = pp.process(sql)
        assert "EXCEPT" in result.upper()

    # ── 다중 WITH 병합 ───────────────────────────────────
    def test_merge_double_with(self, pp):
        """두 개의 WITH 절이 하나로 병합되어야 함"""
        sql = (
            "WITH cte1 AS (SELECT id FROM t) "
            "WITH cte2 AS (SELECT id FROM s) "
            "SELECT * FROM cte1 JOIN cte2 ON cte1.id = cte2.id"
        )
        result = pp.process(sql)
        # WITH 키워드는 하나만 존재해야 함
        assert result.upper().count("WITH") == 1, (
            f"Expected 1 WITH, got {result.upper().count('WITH')}: {result}"
        )
        assert "cte1" in result.lower()
        assert "cte2" in result.lower()

    def test_merge_triple_with(self, pp):
        """세 개의 WITH 절도 하나로 병합"""
        sql = (
            "WITH a AS (SELECT 1) "
            "WITH b AS (SELECT 2) "
            "WITH c AS (SELECT 3) "
            "SELECT * FROM a, b, c"
        )
        result = pp.process(sql)
        assert result.upper().count("WITH") == 1

    def test_single_with_unchanged(self, pp):
        """단일 WITH는 변경 없이 유지"""
        sql = "WITH base AS (SELECT id FROM t) SELECT * FROM base"
        result = pp.process(sql)
        assert "WITH" in result.upper()
        assert "base" in result.lower()

    def test_merge_with_multiline(self, pp):
        """줄바꿈이 포함된 다중 WITH도 병합"""
        sql = (
            "WITH cte1 AS (\n  SELECT id FROM t\n)\n"
            "WITH cte2 AS (\n  SELECT id FROM s\n)\n"
            "SELECT * FROM cte1 JOIN cte2 ON cte1.id = cte2.id"
        )
        result = pp.process(sql)
        assert result.upper().count("WITH") == 1



# ═══ 20. Guardrails EXCEPT Chain ═════════════════════════════
@pytest.mark.unit
class TestGuardrailsExceptChain:
    """EXCEPT 체인 감지 테스트"""

    def test_single_except_allowed(self, guard):
        r = guard.validate("SELECT id FROM a EXCEPT SELECT id FROM b")
        assert r.valid, f"Single EXCEPT should be allowed: {r.issues}"

    def test_except_chain_rejected(self, guard):
        r = guard.validate(
            "SELECT id FROM a EXCEPT SELECT id FROM b EXCEPT SELECT id FROM c"
        )
        assert not r.valid, "EXCEPT chain should be rejected"
        assert any("EXCEPT" in i for i in r.issues)
