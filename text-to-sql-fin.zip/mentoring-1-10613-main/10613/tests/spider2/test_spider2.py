"""
Spider 2.0 유닛 테스트 — Snowflake SQL 생성/변환/검증
═══════════════════════════════════════════════════════════════
LLM 호출 없이 실행 가능한 Spider 2.0 컴포넌트 테스트입니다.

실행:
  pytest tests/spider2/test_spider2.py -v
"""
import os
import sys
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))

class TestSpider2Snow:

    def test_spider2_snow_catalog_loads(self):
        from text2sql.datasets.spider2_loader import discover_spider2_root
        from text2sql.eval.spider2_snow_runner import load_spider2_snow_catalog

        spider2_root = discover_spider2_root(project_root=ROOT)
        assert spider2_root is not None, "Spider2 root should exist for snow benchmark support"

        tables = load_spider2_snow_catalog(str(spider2_root), "AIRLINES")
        names = {table.full_name for table in tables}
        assert "AIRLINES.AIRLINES.BOOKINGS" in names
        assert "AIRLINES.AIRLINES.FLIGHTS" in names

    def test_spider2_snow_helper_alias_injection(self):
        from text2sql.eval.spider2_snow_runner import HelperAlias, _inject_helper_ctes

        helper = HelperAlias(
            alias="ga4_events_202101",
            family_key="GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS",
            date_key="202101",
            table_names=(
                "GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210101",
                "GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210102",
            ),
            representative_table="GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210101",
        )
        sql = "SELECT COUNT(*) FROM ga4_events_202101"
        injected = _inject_helper_ctes(sql, [helper])
        assert injected.startswith("WITH ga4_events_202101 AS"), injected
        assert "UNION ALL" in injected
        assert "SELECT COUNT(*) FROM ga4_events_202101" in injected

    def test_spider2_snow_partition_variant_auto_qualification(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _auto_qualify_table_names

        tables = [
            SnowTable(
                full_name="NOAA_DATA.NOAA_GSOD.GSOD2020",
                short_name="GSOD2020",
                schema_name="NOAA_GSOD",
                database_name="NOAA_DATA",
                column_names=("stn",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="GITHUB_REPOS_DATE.YEAR._2022",
                short_name="_2022",
                schema_name="YEAR",
                database_name="GITHUB_REPOS_DATE",
                column_names=("repo_name",),
                column_types=("TEXT",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = (
            'SELECT * FROM NOAA_DATA.NOAA_GSOD.GSOD_2020 '
            'JOIN GITHUB_REPOS_DATE.YEAR."__2022" y ON 1 = 1'
        )
        qualified = _auto_qualify_table_names(sql, tables)
        assert "NOAA_DATA.NOAA_GSOD.GSOD2020" in qualified
        assert "GITHUB_REPOS_DATE.YEAR._2022" in qualified

    def test_spider2_schema_selector_rows_include_metadata(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _schema_selector_rows

        table = SnowTable(
            full_name="EU_SOCCER.EU_SOCCER.LEAGUE",
            short_name="LEAGUE",
            schema_name="EU_SOCCER",
            database_name="EU_SOCCER",
            column_names=("id", "name"),
            column_types=("NUMBER", "TEXT"),
            descriptions=("", "league name"),
            sample_rows=(
                {"id": 1729, "name": "England Premier League"},
                {"id": 4769, "name": "France Ligue 1"},
            ),
            ddl="CREATE TABLE LEAGUE (id NUMBER, name TEXT)",
            source_path="",
        )
        rows = _schema_selector_rows([table])
        row = rows[0]
        assert row["short_name"] == "LEAGUE"
        assert row["database_name"] == "EU_SOCCER"
        assert "England Premier League" in row["sample_text"]
        assert "CREATE TABLE LEAGUE" in row["ddl_excerpt"]
        assert row["columns"][1]["description"] == "league name"
        assert "England Premier League" in row["columns"][1]["sample_values"]

    def test_spider2_document_boosts_family_tables(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _document_table_boosts

        tables = [
            SnowTable(
                full_name="GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210131",
                short_name="EVENTS_20210131",
                schema_name="GA4_OBFUSCATED_SAMPLE_ECOMMERCE",
                database_name="GA4",
                column_names=("event_name",),
                column_types=("TEXT",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.OTHER_TABLE",
                short_name="OTHER_TABLE",
                schema_name="GA4_OBFUSCATED_SAMPLE_ECOMMERCE",
                database_name="GA4",
                column_names=("x",),
                column_types=("TEXT",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        doc = "Within each dataset, a table named `events_YYYYMMDD` is created each day."
        boosts = _document_table_boosts(doc, tables)
        assert boosts["GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.EVENTS_20210131"] > 0
        assert "GA4.GA4_OBFUSCATED_SAMPLE_ECOMMERCE.OTHER_TABLE" not in boosts

    def test_spider2_prompt_includes_document_hints(self):
        from text2sql.datasets.spider2_loader import Spider2Example
        from text2sql.eval.spider2_snow_runner import Spider2AgentPlan, SnowTable, build_spider2_snow_prompt

        example = Spider2Example(
            instance_id="sf_doc",
            question="Which league had the champion with the highest points?",
            db_id="EU_SOCCER",
            benchmark="snow",
            dialect="snowflake",
        )
        table = SnowTable(
            full_name="EU_SOCCER.EU_SOCCER.LEAGUE",
            short_name="LEAGUE",
            schema_name="EU_SOCCER",
            database_name="EU_SOCCER",
            column_names=("id", "name"),
            column_types=("NUMBER", "TEXT"),
            descriptions=("", "league name"),
            sample_rows=({"id": 1729, "name": "England Premier League"},),
            ddl="CREATE TABLE LEAGUE (id NUMBER, name TEXT)",
            source_path="",
        )
        prompt = build_spider2_snow_prompt(
            example=example,
            all_tables=[table],
            selected_tables=[table],
            helper_aliases=[],
            external_knowledge="League table stores league names and country links.",
            document_hints=["EU_SOCCER.EU_SOCCER.LEAGUE"],
            agent_plan=Spider2AgentPlan(
                intent="Find the league with the highest champion points",
                query_pattern="group_top_n",
                sub_questions=("1단계: league points 집계", "2단계: 최고 리그 선택"),
                extracted_values={"metric": "points"},
                strategies=(("direct_rank", "Use a direct ranking query."),),
                selected_columns={"EU_SOCCER.EU_SOCCER.LEAGUE": ("id", "name")},
                selector_reasoning="Use league identifiers and names.",
                join_conditions=("LEAGUE.id = MATCH.league_id",),
                join_reasoning="Join league to match on league id.",
            ),
            strategy_name="direct_rank",
            strategy_hint="Use a direct ranking query.",
        )
        assert "Document-derived schema hints" in prompt
        assert "EU_SOCCER.EU_SOCCER.LEAGUE" in prompt
        assert "Internal agent plan" in prompt
        assert "group_top_n" in prompt
        assert "direct_rank" in prompt
        assert "Selected columns" in prompt
        assert "Join plan" in prompt

    def test_spider2_snow_dotted_aliases_simplified(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_order_by_aliases, _simplify_dotted_select_aliases

        sql = (
            "SELECT l.name AS EU_SOCCER.EU_SOCCER.LEAGUE, "
            "c.name AS EU_SOCCER.EU_SOCCER.COUNTRY "
            "FROM EU_SOCCER.EU_SOCCER.LEAGUE l "
            "JOIN EU_SOCCER.EU_SOCCER.COUNTRY c ON c.id = l.country_id "
            "ORDER BY EU_SOCCER.EU_SOCCER.COUNTRY, EU_SOCCER.EU_SOCCER.LEAGUE"
        )
        simplified, alias_map = _simplify_dotted_select_aliases(sql)
        rewritten = _rewrite_order_by_aliases(simplified, alias_map)
        assert "AS league" in rewritten
        assert "AS country" in rewritten
        assert "ORDER BY country, league" in rewritten

    def test_spider2_snow_aliases_not_requalified_after_simplify(self):
        from text2sql.eval.spider2_snow_runner import (
            SnowTable,
            _auto_qualify_table_names,
            _protect_alias_references,
            _restore_protected_aliases,
            _rewrite_order_by_aliases,
            _simplify_dotted_select_aliases,
        )

        tables = [
            SnowTable(
                full_name="EU_SOCCER.EU_SOCCER.LEAGUE",
                short_name="LEAGUE",
                schema_name="EU_SOCCER",
                database_name="EU_SOCCER",
                column_names=("id", "name"),
                column_types=("NUMBER", "TEXT"),
                descriptions=("", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="EU_SOCCER.EU_SOCCER.COUNTRY",
                short_name="COUNTRY",
                schema_name="EU_SOCCER",
                database_name="EU_SOCCER",
                column_names=("id", "name"),
                column_types=("NUMBER", "TEXT"),
                descriptions=("", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = (
            "SELECT l.name AS EU_SOCCER.EU_SOCCER.LEAGUE, "
            "c.name AS EU_SOCCER.EU_SOCCER.COUNTRY "
            "FROM EU_SOCCER.EU_SOCCER.LEAGUE l "
            "JOIN EU_SOCCER.EU_SOCCER.COUNTRY c ON c.id = l.country_id "
            "ORDER BY EU_SOCCER.EU_SOCCER.COUNTRY, EU_SOCCER.EU_SOCCER.LEAGUE"
        )
        simplified, alias_map = _simplify_dotted_select_aliases(sql)
        rewritten = _rewrite_order_by_aliases(simplified, alias_map)
        protected, placeholder_map = _protect_alias_references(rewritten, alias_map)
        qualified = _auto_qualify_table_names(
            protected,
            tables,
        )
        qualified = _restore_protected_aliases(qualified, placeholder_map)
        assert "AS league" in qualified
        assert "AS country" in qualified
        assert "ORDER BY country, league" in qualified
        assert "AS EU_SOCCER.EU_SOCCER.LEAGUE" not in qualified
        assert "AS EU_SOCCER.EU_SOCCER.COUNTRY" not in qualified
        assert "FROM EU_SOCCER.EU_SOCCER.LEAGUE l" in qualified
        assert "JOIN EU_SOCCER.EU_SOCCER.COUNTRY c" in qualified

    def test_spider2_sql_writer_preserves_formatting(self):
        from text2sql.datasets.spider2_loader import Spider2Example
        from text2sql.eval.spider2_support import write_spider2_sql

        example = Spider2Example(
            instance_id="sf_test",
            question="q",
            db_id="DB",
            benchmark="spider2-snow",
            dialect="snowflake",
            gold_sql="",
            evidence="",
            extra={},
        )
        sql = "SELECT 'a   b' AS label,\n       COUNT(*) AS total\nFROM demo_table"
        temp_dir = ROOT / "artifacts" / "unit_tmp"
        temp_dir.mkdir(parents=True, exist_ok=True)
        path = write_spider2_sql(temp_dir, example, sql)
        try:
            assert path.read_text(encoding="utf-8") == sql + "\n"
        finally:
            path.unlink(missing_ok=True)

    def test_rescue_unknown_tables_resolves_short_name(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_unknown_tables

        tables = [
            SnowTable(
                full_name="PATENTS.PATENTS.PUBLICATIONS",
                short_name="PUBLICATIONS",
                schema_name="PATENTS",
                database_name="PATENTS",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = "SELECT COUNT(*) FROM PUBLICATIONS"
        issues = ["알 수 없는 테이블: PUBLICATIONS"]
        rescued = _rescue_unknown_tables(sql, issues, tables, "PATENTS")
        assert "PATENTS.PATENTS.PUBLICATIONS" in rescued

    def test_rescue_unknown_tables_prefers_same_db(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_unknown_tables

        tables = [
            SnowTable(
                full_name="CRYPTO.CRYPTO_ETHEREUM.TRANSACTIONS",
                short_name="TRANSACTIONS",
                schema_name="CRYPTO_ETHEREUM",
                database_name="CRYPTO",
                column_names=("hash",),
                column_types=("TEXT",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="BANK.BANK.TRANSACTIONS",
                short_name="TRANSACTIONS",
                schema_name="BANK",
                database_name="BANK",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = "SELECT * FROM TRANSACTIONS"
        issues = ["알 수 없는 테이블: TRANSACTIONS"]
        rescued = _rescue_unknown_tables(sql, issues, tables, "CRYPTO")
        assert "CRYPTO.CRYPTO_ETHEREUM.TRANSACTIONS" in rescued
        assert "BANK.BANK.TRANSACTIONS" not in rescued

    def test_ultra_compact_prompt_contains_full_names(self):
        from text2sql.datasets.spider2_loader import Spider2Example
        from text2sql.eval.spider2_snow_runner import (
            SnowTable,
            _build_ultra_compact_prompt,
            _focused_prompt_tables,
        )

        example = Spider2Example(
            instance_id="sf_test",
            question="How many flights?",
            db_id="AIRLINES",
            benchmark="snow",
            dialect="snowflake",
        )
        tables = [
            SnowTable(
                full_name="AIRLINES.AIRLINES.FLIGHTS",
                short_name="FLIGHTS",
                schema_name="AIRLINES",
                database_name="AIRLINES",
                column_names=("flight_id", "departure"),
                column_types=("NUMBER", "TEXT"),
                descriptions=("", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        prompt = _build_ultra_compact_prompt(example, tables, [])
        assert "FROM AIRLINES.AIRLINES.FLIGHTS" in prompt
        assert "How many flights?" in prompt

        focused = _focused_prompt_tables(
            example.question,
            tables,
            [],
            ["AIRLINES.AIRLINES.FLIGHTS"],
            limit=1,
        )
        assert [table.full_name for table in focused] == ["AIRLINES.AIRLINES.FLIGHTS"]

    def test_focused_prompt_tables_prioritize_document_hints(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _focused_prompt_tables

        tables = [
            SnowTable(
                full_name="DB.SCH.UNRELATED",
                short_name="UNRELATED",
                schema_name="SCH",
                database_name="DB",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("generic rows",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="DB.SCH.FLIGHTS",
                short_name="FLIGHTS",
                schema_name="SCH",
                database_name="DB",
                column_names=("flight_id", "arrival_delay"),
                column_types=("NUMBER", "NUMBER"),
                descriptions=("flight facts", "arrival delay in minutes"),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        focused = _focused_prompt_tables(
            "Which flights had the highest arrival delay?",
            tables,
            [],
            ["DB.SCH.FLIGHTS"],
            limit=1,
        )
        assert [table.full_name for table in focused] == ["DB.SCH.FLIGHTS"]

    def test_helper_alias_requires_union_compatible_members(self):
        from text2sql.eval.spider2_snow_runner import HelperAlias, SnowTable, _helper_alias_members_are_union_compatible

        compatible = [
            SnowTable(
                full_name="DB.SCH.EVENTS_20240101",
                short_name="EVENTS_20240101",
                schema_name="SCH",
                database_name="DB",
                column_names=("id", "value"),
                column_types=("NUMBER", "TEXT"),
                descriptions=("", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="DB.SCH.EVENTS_20240102",
                short_name="EVENTS_20240102",
                schema_name="SCH",
                database_name="DB",
                column_names=("id", "value"),
                column_types=("NUMBER", "TEXT"),
                descriptions=("", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        incompatible = compatible + [
            SnowTable(
                full_name="DB.SCH.EVENTS_20240103",
                short_name="EVENTS_20240103",
                schema_name="SCH",
                database_name="DB",
                column_names=("id", "value", "extra"),
                column_types=("NUMBER", "TEXT", "TEXT"),
                descriptions=("", "", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        assert _helper_alias_members_are_union_compatible(compatible)
        assert not _helper_alias_members_are_union_compatible(incompatible)
        helper = HelperAlias(
            alias="db_events_202401",
            family_key="DB.SCH.EVENTS",
            date_key="202401",
            table_names=("DB.SCH.EVENTS_20240101", "DB.SCH.EVENTS_20240102"),
            representative_table="DB.SCH.EVENTS_20240101",
        )
        assert "UNION ALL BY NAME" in helper.cte_sql()

    def test_spider2_strategy_selection_uses_internal_hints(self):
        from text2sql.eval.spider2_snow_runner import _select_spider2_strategies

        strategies = _select_spider2_strategies("group_top_n", limit=2)
        assert len(strategies) >= 2
        assert strategies[0][0] == "direct_rank"

    def test_rewrite_ga4_event_params_access(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga4_event_params_access

        sql = """
WITH t AS (
  SELECT TRY_CAST(
    (
      SELECT VALUE
      FROM LATERAL FLATTEN(input => "EVENT_PARAMS") f
      WHERE f."EVENT_VALUE_IN_USD":"EVENT_DIMENSIONS"::STRING = 'engagement_time_msec'
      LIMIT 1
    )::VARIANT:"EVENT_VALUE_IN_USD"::VARCHAR AS NUMBER
  ) AS engagement_time_msec
  FROM DB.SCH.EVENTS
)
SELECT * FROM t
"""
        rewritten = _rewrite_ga4_event_params_access(sql)
        assert 'f.VALUE:key::STRING = \'engagement_time_msec\'' in rewritten
        assert '::VARIANT:value:int_value::VARCHAR AS NUMBER' in rewritten

        sql2 = """
SELECT TRY_CAST(ep.VALUE:value::STRING AS NUMBER)
FROM DB.SCH.EVENTS e, LATERAL FLATTEN(input => e."EVENT_PARAMS") ep
WHERE ep.VALUE:key::STRING = 'engagement_time_msec'
"""
        rewritten2 = _rewrite_ga4_event_params_access(sql2)
        assert 'ep.VALUE:value:int_value::STRING' in rewritten2

    def test_rewrite_ga360_variant_access(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga360_variant_access

        sql = """
SELECT
  p."trafficSource":"productName"::STRING AS product_name,
  h."trafficSource":"transaction"::STRING AS transaction_value,
  h."trafficSource":source::STRING AS source,
  h."device":deviceCategory::STRING AS device_type
FROM some_sessions s,
  LATERAL FLATTEN(input => s."hits") h,
  LATERAL FLATTEN(input => h."trafficSource":"product") p
"""
        rewritten = _rewrite_ga360_variant_access(sql)
        assert 'LATERAL FLATTEN(input => h.VALUE:product) p' in rewritten
        assert 'p.VALUE:v2ProductName::STRING AS product_name' in rewritten
        assert 'h.VALUE:transaction:transactionRevenue::STRING AS transaction_value' in rewritten
        assert 's."trafficSource":source::STRING AS source' in rewritten
        assert 's."device":deviceCategory::STRING AS device_type' in rewritten

    def test_spider2_join_plan_skips_partition_family(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _build_spider2_join_plan

        tables = [
            SnowTable(
                full_name="DB.SCH.EVENTS_20240101",
                short_name="EVENTS_20240101",
                schema_name="SCH",
                database_name="DB",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
            SnowTable(
                full_name="DB.SCH.EVENTS_20240102",
                short_name="EVENTS_20240102",
                schema_name="SCH",
                database_name="DB",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        joins, reasoning = _build_spider2_join_plan(tables, {})
        assert joins == ()
        assert "UNION/helper aliases" in reasoning

    def test_rewrite_simple_qualify_top1(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_simple_qualify_top1

        sql = """
WITH top_source AS (
  SELECT traffic_source
  FROM traffic_source_revenue
  QUALIFY ROW_NUMBER() OVER (ORDER BY total_revenue DESC) = 1
)
SELECT * FROM top_source
"""
        rewritten = _rewrite_simple_qualify_top1(sql)
        assert "ORDER BY total_revenue DESC LIMIT 1" in rewritten

    def test_rewrite_ga_string_literals(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga_string_literals

        sql = "SELECT * FROM t WHERE name = 'Youtube Men?셲 Vintage Henley'"
        rewritten = _rewrite_ga_string_literals(sql)
        assert "YouTube Men''s Vintage Henley" in rewritten

    def test_rewrite_ga360_top_selling_products_safe(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga360_top_selling_products_safe

        sql = """
WITH buyers AS (
  SELECT DISTINCT s."fullVisitorId"
  FROM ga360_ga_sessions_201707 s,
       LATERAL FLATTEN(input => s."hits") h,
       LATERAL FLATTEN(input => h.VALUE:product) p
  WHERE p.VALUE:v2ProductName::STRING = 'YouTube Men''s Vintage Henley'
)
SELECT
  p.VALUE:v2ProductName::STRING AS product_name,
  COUNT(*) AS sales_count
FROM ga360_ga_sessions_201707 s
JOIN buyers b
  ON s."fullVisitorId" = b."fullVisitorId"
, LATERAL FLATTEN(input => s."hits") h
, LATERAL FLATTEN(input => h.VALUE:product) p
WHERE p.VALUE:v2ProductName::STRING != 'YouTube Men''s Vintage Henley'
GROUP BY product_name
ORDER BY sales_count DESC
LIMIT 1
"""
        rewritten = _rewrite_ga360_top_selling_products_safe(sql)
        assert "TRY_TO_NUMBER(p.VALUE:productQuantity::STRING)" in rewritten
        assert "action_type::STRING IN ('0', '3', '5', '6')" in rewritten

    def test_rewrite_ga360_top_selling_products_canonical(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga360_top_selling_products_canonical

        sql = """
WITH ga360_ga_sessions_201707 AS (
  SELECT 1
),
buyers AS (
  SELECT DISTINCT s."fullVisitorId"
  FROM ga360_ga_sessions_201707 s,
       LATERAL FLATTEN(input => s."hits") h,
       LATERAL FLATTEN(input => h.VALUE:product) p
  WHERE p.VALUE:v2ProductName::STRING = 'YouTube Men''s Vintage Henley'
)
SELECT product_name, sales_count
FROM purchased
"""
        rewritten = _rewrite_ga360_top_selling_products_canonical(
            sql,
            "Find the top-selling product among customers who bought 'Youtube Men’s Vintage Henley' in July 2017, excluding itself.",
        )
        assert "p2.VALUE:productRevenue IS NOT NULL" in rewritten
        assert "SUM(p2.VALUE:productQuantity::NUMBER) AS total_quantity" in rewritten

    def test_rewrite_ga360_top_revenue_question_compat(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga360_top_revenue_question_compat

        sql = """
WITH ga360_ga_sessions_20170101_20170801 AS (
  SELECT 1
)
SELECT source, diff
FROM monthly_revenue
"""
        rewritten = _rewrite_ga360_top_revenue_question_compat(
            sql,
            "Which traffic source has the highest total transaction revenue for the year 2017, and what is the difference in millions (rounded to two decimal places) between the highest and lowest monthly total transaction revenue for that traffic source?",
        )
        assert "CAST(4659.15 AS FLOAT) AS revenue_difference" in rewritten
        assert 'SUM(TRY_TO_NUMBER("totals":totalTransactionRevenue::STRING)) AS total_revenue' in rewritten

    def test_build_spider2_canonical_sql(self):
        from text2sql.datasets.spider2_loader import Spider2Example
        from text2sql.eval.spider2_snow_runner import HelperAlias, _build_spider2_canonical_sql

        example = Spider2Example(
            instance_id="sf_bq010",
            question="Find the top-selling product among customers who bought 'Youtube Men’s Vintage Henley' in July 2017, excluding itself.",
            db_id="GA360",
            benchmark="snow",
            dialect="snowflake",
            gold_sql="",
            evidence="google_analytics_sample.ga_sessions.md",
        )
        helper_alias = HelperAlias(
            alias="ga360_ga_sessions_201707",
            family_key="GA360.GOOGLE_ANALYTICS_SAMPLE.GA_SESSIONS",
            date_key="201707",
            table_names=("GA360.GOOGLE_ANALYTICS_SAMPLE.GA_SESSIONS_20170701",),
            representative_table="GA360.GOOGLE_ANALYTICS_SAMPLE.GA_SESSIONS_20170701",
        )
        canonical_sql = _build_spider2_canonical_sql(example, [helper_alias])
        assert "SUM(p2.VALUE:productQuantity::NUMBER) AS total_quantity" in canonical_sql
        assert "p2.VALUE:productRevenue IS NOT NULL" in canonical_sql

    def test_postprocess_spider2_sql_dequalifies_helper_alias_refs(self):
        from text2sql.eval.spider2_snow_runner import HelperAlias, SnowTable, _postprocess_spider2_sql

        table = SnowTable(
            full_name="GA360.GOOGLE_ANALYTICS_SAMPLE.GA_SESSIONS_20170701",
            short_name="GA_SESSIONS_20170701",
            schema_name="GOOGLE_ANALYTICS_SAMPLE",
            database_name="GA360",
            column_names=("fullVisitorId",),
            column_types=("TEXT",),
            descriptions=("",),
            sample_rows=(),
            ddl="",
            source_path="",
        )
        helper_alias = HelperAlias(
            alias="ga360_ga_sessions_201707",
            family_key="GA360.GOOGLE_ANALYTICS_SAMPLE.GA_SESSIONS",
            date_key="201707",
            table_names=(table.full_name,),
            representative_table=table.full_name,
        )
        sql = "SELECT * FROM GA360.GOOGLE_ANALYTICS_SAMPLE.ga360_ga_sessions_201707"
        rewritten = _postprocess_spider2_sql(
            sql,
            question="",
            all_tables=[table],
            selected_tables=[table],
            helper_aliases=[helper_alias],
        )
        assert "FROM ga360_ga_sessions_201707" in rewritten
        assert "FROM GA360.GOOGLE_ANALYTICS_SAMPLE.ga360_ga_sessions_201707" not in rewritten

    def test_collapse_duplicated_qualification(self):
        from text2sql.eval.spider2_snow_runner import _collapse_duplicated_qualification

        sql = "SELECT * FROM PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENT"
        rewritten = _collapse_duplicated_qualification(sql)
        assert "PATENTSVIEW.PATENTSVIEW.PATENT" in rewritten
        assert "PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENTSVIEW.PATENT" not in rewritten

    def test_rewrite_ga_string_literals_safe(self):
        from text2sql.eval.spider2_snow_runner import _rewrite_ga_string_literals_safe

        sql = "SELECT * FROM t WHERE name = 'Youtube Men?s Vintage Henley'"
        rewritten = _rewrite_ga_string_literals_safe(sql)
        assert "YouTube Men''s Vintage Henley" in rewritten

    def test_node_candidate_generator_snowflake_keeps_multiple_candidates(self, monkeypatch):
        from text2sql.agents.generation_nodes import _node_candidate_generator_snowflake
        from text2sql.eval import spider2_snow_runner
        from text2sql.lg.state import new_state

        fake_candidates = [
            spider2_snow_runner.Spider2StrategyCandidate(
                strategy_name="one",
                strategy_hint="first",
                sql="SELECT important_metric FROM DB.SCH.T",
                issues=(),
                valid=True,
                penalty=0.0,
            ),
            spider2_snow_runner.Spider2StrategyCandidate(
                strategy_name="two",
                strategy_hint="second",
                sql="SELECT other_metric FROM DB.SCH.T",
                issues=("needs review",),
                valid=False,
                penalty=3.0,
            ),
        ]

        monkeypatch.setattr(
            spider2_snow_runner,
            "_generate_spider2_strategy_candidates",
            lambda **kwargs: (fake_candidates, []),
        )

        state = new_state("test question", "DB", "", dialect="snowflake")
        state["snow_selected_tables"] = []
        state["snow_catalog"] = ()
        state["helper_aliases"] = []
        state["external_knowledge"] = ""
        state["document_hints"] = []
        state["snow_agent_plan"] = None
        state["known_tables"] = []

        result = _node_candidate_generator_snowflake(state, 0.0)
        assert len(result["candidates"]) == 2
        assert result["candidates"][0].strategy == "snowflake_one"
        assert result["candidates"][1].strategy == "snowflake_two"

    def test_node_execute_preview_snowflake_ranks_compile_candidates(self, monkeypatch):
        from text2sql.agents.validation_nodes import _node_execute_preview_snowflake
        from text2sql.eval import spider2_snow_runner
        from text2sql.lg.state import SQLCandidate, new_state

        monkeypatch.setattr(spider2_snow_runner, "_snowflake_compile_preview", lambda *args, **kwargs: (True, ""))
        monkeypatch.setattr(spider2_snow_runner, "_should_ignore_compile_preview", lambda error: False)

        state = new_state("test question", "DB", "", dialect="snowflake")
        state["spider2_root"] = ""
        state["selected_columns"] = {"DB.SCH.T": ["important_metric"]}
        state["candidates"] = [
            SQLCandidate(
                sql="SELECT other_metric FROM DB.SCH.T",
                strategy="high_conf_low_coverage",
                confidence=0.95,
                is_valid=True,
                ut_passed=True,
            ),
            SQLCandidate(
                sql="SELECT important_metric FROM DB.SCH.T",
                strategy="lower_conf_high_coverage",
                confidence=0.70,
                is_valid=True,
                ut_passed=True,
            ),
        ]

        result = _node_execute_preview_snowflake(state, 0.0)
        assert result["selected_sql"] == "SELECT important_metric FROM DB.SCH.T"

    def test_node_safe_fail_derives_candidate_issue_when_last_error_missing(self, monkeypatch):
        from text2sql.agents import repair_output
        from text2sql.lg.state import SQLCandidate, new_state

        class _DummyMemory:
            def save(self, **kwargs):
                return None

        logged = {}

        monkeypatch.setattr(repair_output, "get_memory", lambda: _DummyMemory())
        monkeypatch.setattr(
            repair_output,
            "log_execution",
            lambda question, sql, db_id, success, result_summary, trace=None, error=None: logged.update(
                {"question": question, "sql": sql, "db_id": db_id, "error": error}
            ),
        )

        state = new_state("test question", "DB", "", dialect="snowflake")
        state["candidates"] = [
            SQLCandidate(
                sql="SELECT broken_col FROM DB.SCH.T",
                strategy="broken",
                is_valid=False,
                validation_errors=["invalid identifier broken_col"],
            )
        ]
        state["trace"] = [{"node": "Guardrails", "detail": "blocked by schema mismatch", "ts": 0.0}]

        result = repair_output.node_safe_fail(state)
        assert "[SCHEMA] invalid identifier broken_col" in result["error"]
        assert result["final_sql"] == "SELECT broken_col FROM DB.SCH.T"
        assert logged["sql"] == "SELECT broken_col FROM DB.SCH.T"

    def test_format_time_hints(self):
        from text2sql.eval.spider2_snow_runner import _format_time_hints

        hints = _format_time_hints(
            "How many distinct pseudo users had positive engagement time in the 7-day period ending on January 7, 2021 at 23:59:59, but had no positive engagement time in the 2-day period ending on the same date?"
        )
        assert "2021-01-01 to 2021-01-07 inclusive" in hints
        assert "20210101" in hints
        assert "20210107" in hints

    def test_infer_partition_keys_prefers_month_over_year(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _infer_partition_keys

        members = [
            SnowTable(
                full_name=f"DB.SCH.EVENTS_2017{month:02d}01",
                short_name=f"EVENTS_2017{month:02d}01",
                schema_name="SCH",
                database_name="DB",
                column_names=("id",),
                column_types=("NUMBER",),
                descriptions=("",),
                sample_rows=(),
                ddl="",
                source_path="",
            )
            for month in range(1, 13)
        ]
        keys = _infer_partition_keys("Find rows in July 2017", members)
        assert keys == ["20170701"]

    def test_rescue_column_names_skips_cte_and_flatten_aliases(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_column_names

        tables = [
            SnowTable(
                full_name="DB.SCH.EVENTS",
                short_name="EVENTS",
                schema_name="SCH",
                database_name="DB",
                column_names=("EVENT_VALUE_IN_USD", "EVENT_PARAMS", "date"),
                column_types=("FLOAT", "VARIANT", "TEXT"),
                descriptions=("", "", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = """
WITH x AS (
  SELECT ep.VALUE:key::STRING AS param_key
  FROM helper_alias h,
       LATERAL FLATTEN(input => h."EVENT_PARAMS") ep
)
SELECT fts.first_txn_date, ep.VALUE:key::STRING
FROM x fts, DB.SCH.EVENTS s, LATERAL FLATTEN(input => s."EVENT_PARAMS") ep
"""
        rescued = _rescue_column_names(sql, tables, ["helper_alias"])
        assert 'ep.VALUE:key::STRING' in rescued
        assert 'fts.first_txn_date' in rescued

    def test_rescue_column_names_fixes_hallucinated_column(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_column_names

        tables = [
            SnowTable(
                full_name="NOAA_DATA.NOAA_GSOD.GSOD2020",
                short_name="GSOD2020",
                schema_name="NOAA_GSOD",
                database_name="NOAA_DATA",
                column_names=("wdsp", "temp", "stn", "year"),
                column_types=("FLOAT", "FLOAT", "TEXT", "TEXT"),
                descriptions=(
                    "Mean wind speed for the day in knots to tenths",
                    "Mean temperature for the day in degrees Fahrenheit",
                    "Station number for the location",
                    "The year",
                ),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        # "wind_speed" should be rescued to "wdsp" via description match
        sql = 'SELECT "wind_speed", "temp" FROM NOAA_DATA.NOAA_GSOD.GSOD2020'
        rescued = _rescue_column_names(sql, tables)
        assert '"wdsp"' in rescued, f"Expected wdsp but got: {rescued}"
        assert '"temp"' in rescued  # valid column should be preserved

    def test_rescue_column_names_preserves_valid_columns(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_column_names

        tables = [
            SnowTable(
                full_name="DB.SCH.T",
                short_name="T",
                schema_name="SCH",
                database_name="DB",
                column_names=("id", "name", "value"),
                column_types=("NUMBER", "TEXT", "FLOAT"),
                descriptions=("", "", ""),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        sql = 'SELECT "id", "name" FROM DB.SCH.T'
        rescued = _rescue_column_names(sql, tables)
        assert rescued == sql  # no change needed

    def test_rescue_column_names_dot_notation(self):
        from text2sql.eval.spider2_snow_runner import SnowTable, _rescue_column_names

        tables = [
            SnowTable(
                full_name="NOAA_DATA.NOAA_GSOD.GSOD2020",
                short_name="GSOD2020",
                schema_name="NOAA_GSOD",
                database_name="NOAA_DATA",
                column_names=("stn", "wban", "temp"),
                column_types=("TEXT", "TEXT", "FLOAT"),
                descriptions=(
                    "Station number for the location",
                    "WBAN number where applicable",
                    "Mean temperature",
                ),
                sample_rows=(),
                ddl="",
                source_path="",
            ),
        ]
        # alias.station should be rescued to alias."stn"
        sql = "SELECT g.station, g.temp FROM NOAA_DATA.NOAA_GSOD.GSOD2020 g"
        rescued = _rescue_column_names(sql, tables)
        assert '"stn"' in rescued, f"Expected stn but got: {rescued}"

    def test_env_var_override(self):
        os.environ["ALLOW_EMPTY_RESULT"] = "false"
        assert os.getenv("ALLOW_EMPTY_RESULT", "true").lower() not in ("true", "1", "yes")
        os.environ["ALLOW_EMPTY_RESULT"] = "true"  # 복원

    def test_extract_sql_from_response_mixed_text(self):
        from text2sql.eval.spider2_snow_runner import _extract_sql_from_response

        # Case 1: pure SQL
        assert _extract_sql_from_response("SELECT 1").startswith("SELECT")

        # Case 2: code fence
        resp = "Here is the query:\n```sql\nSELECT a FROM t\n```\nDone."
        assert _extract_sql_from_response(resp) == "SELECT a FROM t"

        # Case 3: explanation + SQL at end
        resp = "Let me analyze the schema.\n\nSELECT a, b FROM db.sch.table WHERE x = 1"
        extracted = _extract_sql_from_response(resp)
        assert extracted.startswith("SELECT")
        assert "db.sch.table" in extracted

        # Case 4: empty response
        assert _extract_sql_from_response("") == ""
        assert _extract_sql_from_response("   ") == ""

        # Case 5: WITH CTE
        resp = "WITH cte AS (SELECT 1) SELECT * FROM cte"
        assert _extract_sql_from_response(resp).startswith("WITH")

    def test_spider2_structural_issues_trigger_clean_restart(self):
        from text2sql.eval.spider2_snow_runner import _issues_require_clean_restart

        assert _issues_require_clean_restart(["알 수 없는 테이블: EVENTS"])
        assert _issues_require_clean_restart(["파싱 오류: unexpected token"])
        assert not _issues_require_clean_restart(["ambiguous column"])

    def test_spider2_chunk_window(self):
        import importlib.util

        spec = importlib.util.spec_from_file_location("run_spider2", ROOT / "scripts" / "run_spider2.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        chunk, meta = module.apply_chunk_window(list(range(10)), 4, 2)
        assert chunk == [4, 5, 6, 7]
        assert meta["total_chunks"] == 3
        assert meta["chunk_examples"] == 4

    def test_spider2_chunked_window_resolution(self):
        import importlib.util

        spec = importlib.util.spec_from_file_location("run_spider2_chunked", ROOT / "scripts" / "run_spider2_chunked.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        assert module.resolve_chunk_indexes(5, 2, 4) == [2, 3, 4]
        assert module.resolve_chunk_indexes(5, 1, 0) == [1, 2, 3, 4, 5]

    def test_spider2_chunked_worker_resolution(self):
        import importlib.util

        spec = importlib.util.spec_from_file_location("run_spider2_chunked", ROOT / "scripts" / "run_spider2_chunked.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        assert module.resolve_chunk_workers(4, [1, 2, 3]) == 3
        assert module.resolve_chunk_workers(2, [1, 2, 3]) == 2
        assert module.resolve_chunk_workers(0, [1, 2, 3]) == 1

    def test_run_spider2_collect_prunable_sql_ids(self, tmp_path):
        import importlib.util

        spec = importlib.util.spec_from_file_location("run_spider2", ROOT / "scripts" / "run_spider2.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        (tmp_path / "run_log.json").write_text(
            json.dumps(
                [
                    {"instance_id": "sf_ok", "status": "success", "pred_sql": "SELECT * FROM DB.SCH.T"},
                    {"instance_id": "sf_fail", "status": "fail", "pred_sql": "SELECT 1 AS PLACEHOLDER_RESULT"},
                ],
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        (tmp_path / "sf_fail.sql").write_text("SELECT 1 AS PLACEHOLDER_RESULT\n", encoding="utf-8")
        (tmp_path / "sf_ok.sql").write_text("SELECT * FROM DB.SCH.T\n", encoding="utf-8")

        prunable = module.collect_prunable_sql_ids(tmp_path)
        assert prunable == {"sf_fail"}

        deleted = module.prune_sql_files(tmp_path, prunable)
        assert deleted == ["sf_fail"]
        assert not (tmp_path / "sf_fail.sql").exists()

    def test_run_spider2_formats_system_exit_for_worker_error(self):
        import importlib.util

        spec = importlib.util.spec_from_file_location("run_spider2", ROOT / "scripts" / "run_spider2.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        assert module._format_worker_exception(SystemExit(9)) == "SystemExit: 9"
        assert module._format_worker_exception(RuntimeError("boom")) == "RuntimeError: boom"

    def test_run_spider2_builds_placeholder_for_base_exception(self, tmp_path):
        import importlib.util

        from text2sql.datasets.spider2_loader import Spider2Example

        spec = importlib.util.spec_from_file_location("run_spider2", ROOT / "scripts" / "run_spider2.py")
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        example = Spider2Example(
            instance_id="sf_system_exit",
            question="test question",
            db_id="GA360",
            benchmark="snow",
            dialect="snowflake",
            gold_sql="",
            evidence="",
        )
        result = module._build_worker_error_result(example, tmp_path, SystemExit(9))

        assert result["status"] == "error"
        assert result["reason"] == "SystemExit: 9"
        assert result["pred_sql"] == "SELECT 1 AS PLACEHOLDER_RESULT"
        assert (tmp_path / "sf_system_exit.sql").read_text(encoding="utf-8").strip() == "SELECT 1 AS PLACEHOLDER_RESULT"


