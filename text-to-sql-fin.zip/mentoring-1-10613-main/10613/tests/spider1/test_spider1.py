"""
Spider 1.0 유닛 테스트 — 데이터 로더, 결과 Writer, 평가 경로
═══════════════════════════════════════════════════════════════
LLM 호출 없이 실행 가능한 Spider 1.0 컴포넌트 테스트입니다.

실행:
  pytest tests/spider1/test_spider1.py -v
"""
import os
import sys
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))

SPIDER_DIR = ROOT / "data" / "spider"
SPIDER_DB_DIR = SPIDER_DIR / "database"


# ═══ 1. Spider Loader ═══════════════════════════════════════════
@pytest.mark.unit
class TestSpiderLoader:

    def test_spider_example_dataclass(self):
        from text2sql.datasets.spider_loader import SpiderExample
        ex = SpiderExample(
            question="How many singers are there?",
            db_id="concert_singer",
            gold_sql="SELECT COUNT(*) FROM singer",
        )
        assert ex.question == "How many singers are there?"
        assert ex.db_id == "concert_singer"
        assert ex.gold_sql == "SELECT COUNT(*) FROM singer"
        assert ex.extra == {}

    def test_spider_example_with_extra(self):
        from text2sql.datasets.spider_loader import SpiderExample
        ex = SpiderExample(
            question="Q",
            db_id="db",
            gold_sql="SELECT 1",
            extra={"query_toks": ["SELECT", "1"]},
        )
        assert ex.extra["query_toks"] == ["SELECT", "1"]

    @pytest.mark.skipif(
        not (SPIDER_DIR / "dev.json").exists(),
        reason="Spider dev.json not available",
    )
    def test_load_spider_dev(self):
        from text2sql.datasets.spider_loader import load_spider_dev
        examples = load_spider_dev(limit=5)
        assert len(examples) == 5
        for ex in examples:
            assert ex.question
            assert ex.db_id
            assert ex.gold_sql

    @pytest.mark.skipif(
        not (SPIDER_DIR / "dev.json").exists(),
        reason="Spider dev.json not available",
    )
    def test_load_spider_dev_full(self):
        from text2sql.datasets.spider_loader import load_spider_dev
        examples = load_spider_dev()
        assert len(examples) > 100

    @pytest.mark.skipif(
        not (SPIDER_DIR / "tables.json").exists(),
        reason="Spider tables.json not available",
    )
    def test_load_spider_tables(self):
        from text2sql.datasets.spider_loader import load_spider_tables
        tables = load_spider_tables()
        assert isinstance(tables, dict)
        assert len(tables) > 0
        sample = next(iter(tables.values()))
        assert "table_names" in sample or "table_names_original" in sample

    def test_load_spider_dev_missing_raises(self, tmp_path):
        from text2sql.datasets.spider_loader import load_spider_dev
        with pytest.raises(FileNotFoundError):
            load_spider_dev(spider_dir=tmp_path)

    def test_load_spider_tables_missing_raises(self, tmp_path):
        from text2sql.datasets.spider_loader import load_spider_tables
        with pytest.raises(FileNotFoundError):
            load_spider_tables(spider_dir=tmp_path)


# ═══ 2. Spider Result Writer ═══════════════════════════════════
@pytest.mark.unit
class TestSpiderWriter:

    def test_writer_creates_files(self, tmp_path):
        from text2sql.eval.spider_writer import SpiderResultWriter
        w = SpiderResultWriter(tmp_path)
        w.add("SELECT COUNT(*) FROM singer", "SELECT COUNT(*) FROM singer", "concert_singer")
        w.add("SELECT name FROM stadium", "SELECT name FROM stadium", "concert_singer")
        gold_path, pred_path = w.flush()

        assert gold_path.exists()
        assert pred_path.exists()

        gold_lines = gold_path.read_text(encoding="utf-8").strip().split("\n")
        pred_lines = pred_path.read_text(encoding="utf-8").strip().split("\n")
        assert len(gold_lines) == 2
        assert len(pred_lines) == 2

    def test_writer_gold_format(self, tmp_path):
        from text2sql.eval.spider_writer import SpiderResultWriter
        w = SpiderResultWriter(tmp_path)
        w.add("SELECT id FROM t1", "SELECT id FROM t1", "my_db")
        gold_path, _ = w.flush()

        line = gold_path.read_text(encoding="utf-8").strip()
        assert "\t" in line
        sql, db_id = line.split("\t")
        assert sql == "SELECT id FROM t1"
        assert db_id == "my_db"

    def test_writer_multiline_sql_collapsed(self, tmp_path):
        from text2sql.eval.spider_writer import SpiderResultWriter
        w = SpiderResultWriter(tmp_path)
        w.add("SELECT\n  id\nFROM\n  t1", "SELECT\n  id\nFROM\n  t1", "db")
        _, pred_path = w.flush()

        line = pred_path.read_text(encoding="utf-8").strip()
        assert "\n" not in line
        assert "SELECT id FROM t1" == line

    def test_writer_empty_pred_fallback(self, tmp_path):
        from text2sql.eval.spider_writer import SpiderResultWriter
        w = SpiderResultWriter(tmp_path)
        w.add("SELECT 1", "", "db")
        _, pred_path = w.flush()

        line = pred_path.read_text(encoding="utf-8").strip()
        assert line == "SELECT 1"

    def test_writer_count(self, tmp_path):
        from text2sql.eval.spider_writer import SpiderResultWriter
        w = SpiderResultWriter(tmp_path)
        assert w.count == 0
        w.add("SELECT 1", "SELECT 1", "db")
        w.add("SELECT 2", "SELECT 2", "db")
        assert w.count == 2


# ═══ 3. Spider DB 경로 검증 ═══════════════════════════════════
@pytest.mark.unit
class TestSpiderDBPaths:

    @pytest.mark.skipif(
        not SPIDER_DB_DIR.exists(),
        reason="Spider database directory not available",
    )
    def test_spider_db_directory_has_databases(self):
        db_dirs = [d for d in SPIDER_DB_DIR.iterdir() if d.is_dir()]
        assert len(db_dirs) > 50, f"Expected 50+ databases, got {len(db_dirs)}"

    @pytest.mark.skipif(
        not SPIDER_DB_DIR.exists(),
        reason="Spider database directory not available",
    )
    def test_spider_db_has_sqlite_files(self):
        sqlite_files = list(SPIDER_DB_DIR.rglob("*.sqlite"))
        assert len(sqlite_files) > 50


# ═══ 4. Eval Script 경로 검증 ═════════════════════════════════
@pytest.mark.unit
class TestSpiderEvalScripts:

    def test_run_spider_dev_script_exists(self):
        assert (ROOT / "scripts" / "run_spider_dev.py").exists()

    def test_eval_spider_script_exists(self):
        assert (ROOT / "scripts" / "eval_spider.py").exists()

    def test_eval_spider_script_importable(self):
        """eval_spider.py가 구문 오류 없이 파싱 가능한지 확인"""
        script = ROOT / "scripts" / "eval_spider.py"
        code = script.read_text(encoding="utf-8")
        compile(code, str(script), "exec")
