# Text-to-SQL Assistant

Azure OpenAI 기반 Text-to-SQL 파이프라인입니다. 자연어 질문을 SQL로 변환하며, SQLite와 Snowflake를 지원합니다.

## 프로젝트 구조

```text
├── app.py                          # Streamlit 웹 UI
├── Dockerfile                      # Docker 이미지 빌드
├── docker-compose.yml              # Docker Compose 실행 설정
├── pyproject.toml                  # pytest 설정
├── requirements.txt                # 런타임 의존성
├── requirements-dev.txt            # 개발/테스트 의존성
├── .env.example                    # 환경변수 템플릿
│
├── src/text2sql/                   # 핵심 소스 코드
│   ├── agents/                     # 13-node LangGraph 파이프라인
│   │   ├── decomposer.py          #   질문 분석, 패턴 분류
│   │   ├── schema_nodes.py        #   BM25+LLM 스키마 선택, JOIN 계획
│   │   ├── generation_nodes.py    #   다중 전략 SQL 생성, 후처리
│   │   ├── validation_nodes.py    #   Guardrails, UnitTest, 실행 검증, Judge
│   │   ├── repair_output.py       #   SQL 수리, 결과 출력, SafeFail
│   │   ├── nodes.py               #   노드 re-export
│   │   └── _utils.py              #   공유 유틸리티
│   ├── lg/                         # LangGraph 상태 및 그래프
│   │   ├── state.py               #   GraphState, SQLCandidate, ExecReport
│   │   └── graph.py               #   13-node 컴파일 그래프
│   ├── llm/                        # LLM 클라이언트
│   │   ├── client.py              #   Azure OpenAI 듀얼 모델 클라이언트
│   │   └── prompts.py             #   각 노드별 프롬프트 템플릿
│   ├── rag/                        # 스키마 검색
│   │   ├── schema_rag.py          #   BM25 + Vector 하이브리드 선택
│   │   └── vector_store.py        #   Chroma 벡터 스토어
│   ├── eval/                       # 평가 엔진
│   │   ├── spider2_snow_runner.py #   Spider 2.0 Snowflake SQL 생성/검증
│   │   ├── spider2_support.py     #   Spider 2.0 공식 평가 실행
│   │   ├── kpi_runner.py          #   로컬 KPI 벤치마크
│   │   └── spider_writer.py       #   Spider 1.0 결과 파일 생성
│   ├── tools/                      # SQL 도구
│   │   ├── executor.py            #   SQL 실행, 스키마 조회
│   │   ├── guardrails.py          #   sqlglot AST 기반 안전성 검증
│   │   ├── sql_postprocess.py     #   AST 기반 SQL 후처리
│   │   ├── cli_display.py         #   rich 기반 CLI 콘솔 디스플레이
│   │   ├── date_tools.py          #   날짜 파싱
│   │   ├── audit.py               #   실행 감사 로그
│   │   ├── cache.py               #   요청 캐시
│   │   └── db_registry.py         #   DB 설정 레지스트리
│   ├── config/                     # 설정
│   │   ├── settings.py            #   환경변수 기반 설정 관리
│   │   ├── domain_hints.json      #   DB별 키워드 매핑
│   │   ├── schema_metadata.json   #   스키마 메타데이터
│   │   ├── strategy_hints.json    #   쿼리 패턴별 전략
│   │   └── scenarios.json         #   KPI 테스트 시나리오
│   ├── datasets/                   # 데이터 로더
│   │   ├── spider_loader.py       #   Spider 1.0 dev.json 로더
│   │   └── spider2_loader.py      #   Spider 2.0 JSONL 로더
│   └── memory/                     # 대화 메모리
│       └── conversation.py        #   세션별 메모리 관리
│
├── tests/                          # 테스트 (총 142개)
│   ├── conftest.py                #   공유 fixtures
│   ├── local/                     #   파이프라인 핵심 로직 테스트
│   │   └── test_local.py          #     Settings, Guardrails, Executor 등 (80개)
│   ├── spider1/                   #   Spider 1.0 테스트
│   │   └── test_spider1.py        #     데이터 로더, Result Writer, 경로 검증 (17개)
│   ├── spider2/                   #   Spider 2.0 Snowflake 테스트
│   │   └── test_spider2.py        #     카탈로그, 프롬프트, 후처리, 변환 (45개)
│   └── kpi/                       #   KPI 통합 테스트 (LLM 호출 필요)
│       ├── kpi_config.yaml        #     KPI 임계값, 실행 설정
│       └── query_cases/           #     Chinook/Monitor 질의 케이스
│
├── scripts/                        # 실행 스크립트
│   ├── run_cli.py                 #   CLI 실행 (rich 콘솔 + HITL)
│   ├── run_spider2.py             #   Spider 2.0 SQL 생성 + 평가
│   ├── run_spider2_chunked.py     #   Spider 2.0 분할 실행
│   ├── eval_spider2.py            #   Spider 2.0 평가만 실행
│   ├── run_spider_dev.py          #   Spider 1.0 SQL 생성
│   ├── eval_spider.py             #   Spider 1.0 공식 평가
│   ├── run_kpi_benchmark.py       #   로컬 KPI 벤치마크
│   └── run_all_tests.py           #   전체 통합 테스트
│
├── data/                           # DB 파일, Spider 데이터 (gitignore)
├── docs/                           # 테스트/개선 리포트
└── artifacts/                      # 실행 결과 (gitignore)
```

## Agent 파이프라인

```mermaid
flowchart LR
    A["Question"] --> B["Decomposer"]
    B --> C["Schema Selector"]
    C --> D["Value Retriever"]
    D --> E["Join Planner"]
    E --> F["Candidate Generator"]
    F --> G["SQL PostProcess"]
    G --> H["Guardrails"]
    H --> I["Unit Tester"]
    I --> J["Execute Preview"]
    J --> K["Judge"]
    K --> L["Result Output"]
    H -. retry .-> R["Repair"]
    I -. retry .-> R
    J -. retry .-> R
    K -. retry .-> R
    R --> H
    R -. exhausted .-> M["Safe Fail"]
```

**주요 특징:**
- **Dual-Model Routing**: 정확도 우선 노드(Generation, Repair, Judge)는 gpt-5, 속도 우선 노드(Decomposer, SchemaSelector 등)는 gpt-4.1
- **Snowflake 지원**: Spider 2.0-snow용 전용 생성/검증/후처리 경로
- **BigQuery→Snowflake 자동 변환**: IF→IFF, UNNEST→FLATTEN 등 18+ 함수 패턴 자동 변환
- **Self-Consistency Voting**: 다중 SQL 후보 실행 후 다수결 선택

## 설치

```bash
git clone <repo-url>
cd text-to-sql-assistant-v1.0.0/10613

python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

개발/테스트용:
```bash
pip install -r requirements-dev.txt
```

## 환경 설정

`.env.example`을 복사하여 `.env`를 만들고 값을 채웁니다.

```bash
cp .env.example .env
```

**최소 필수 값:**
- `SKCC_AZURE_ENDPOINT` — Azure OpenAI 엔드포인트
- `SKCC_AZURE_OPENAI_KEY` — API 키
- `SKCC_AZURE_MODEL` — 모델 배포명 (예: gpt-5)

**Spider 2.0 평가 시 추가 필요:**
- `T2SQL_SNOWFLAKE_*` — Snowflake 연결 정보
- `T2SQL_SPIDER2_*` — Spider 2.0 경로 설정

## 필수 데이터

| 데이터 | 경로 | 용도 | 비고 |
|--------|------|------|------|
| Chinook DB | `data/databases/chinook.db` | 로컬 KPI 테스트 | 저장소 포함 |
| Monitor DB | `data/databases/monitor.db` | 로컬 KPI 테스트 | 저장소 포함 |
| Spider 1.0 | `data/spider/` | Spider 1.0 평가 | [공식 다운로드](https://yale-lily.github.io/spider) |
| Spider evaluator | `test-suite-sql-eval/` | Spider 1.0 공식 평가 | `git clone https://github.com/taoyds/test-suite-sql-eval.git` |
| Spider 2.0 | `data/spider2/` | Spider 2.0 평가 | gitignore 제외, [공식 저장소](https://github.com/xlang-ai/Spider2)에서 clone 후 배치 |

## 실행

### 웹 UI
```bash
streamlit run app.py
```

### 테스트
```bash
# 전체 유닛 테스트 (142개, LLM 호출 없음)
pytest tests/local tests/spider1 tests/spider2 -v

# 폴더별 실행
pytest tests/local -v          # 파이프라인 핵심 (80개)
pytest tests/spider1 -v        # Spider 1.0 (17개)
pytest tests/spider2 -v        # Spider 2.0 Snowflake (45개)

# KPI 통합 테스트 (LLM 호출 필요, .env 설정 필수)
pytest tests/kpi -v
```

### Spider 2.0 평가
```bash
# SQL 생성 + 공식 평가 (전체 547건)
python scripts/run_spider2.py --dataset snow --workers 4 --scope all --official-eval

# 일부만 실행
python scripts/run_spider2.py --dataset snow --workers 4 --scope all --limit 10 --official-eval

# 이전 실행 이어서 진행
python scripts/run_spider2.py --dataset snow --workers 4 --scope all --resume --official-eval

# 평가만 실행 (기존 SQL 파일 대상)
python scripts/eval_spider2.py --dataset snow --result-dir artifacts/spider2_runs/cycle2_final
```

### Spider 1.0 평가
```bash
# SQL 생성
python scripts/run_spider_dev.py --output artifacts/spider_runs/latest --workers 20

# 공식 평가 (eval_spider.py 래퍼)
python scripts/eval_spider.py --result-dir artifacts/spider_runs/latest

# 공식 평가 (evaluation.py 직접 실행)
python test-suite-sql-eval/evaluation.py --gold artifacts/spider_runs/latest/gold.txt --pred artifacts/spider_runs/latest/pred.txt --db data/spider/database --table data/spider/tables.json --etype all
```

### KPI 벤치마크
```bash
python scripts/run_kpi_benchmark.py --mode full --warm
```

### 전체 통합 테스트
```bash
python scripts/run_all_tests.py --mode full --warm --spider-workers 20
```

### CLI 실행 (rich 콘솔 디스플레이)

Agent 로그, 프로그레스바, 비용/시간/결과를 콘솔에서 시각적으로 확인할 수 있습니다.

```bash
# 단일 질문 실행 — 각 Agent 노드별 로그, SQL, 비용, 시간 표시
python scripts/run_cli.py --question "전체 고객 수를 구하라"
python scripts/run_cli.py --db monitor --question "서비스별 오류율을 구하라"

# Spider 1.0 배치 — 프로그레스바 + 성공/실패 카운트 + 최종 요약 테이블
python scripts/run_cli.py --spider1 --limit 10

# Spider 2.0 배치 — 프로그레스바 + 최종 요약 테이블
python scripts/run_cli.py --spider2 --limit 10

# 옵션
python scripts/run_cli.py --question "질문" --max-retries 5   # 재시도 횟수 지정

# HITL 모드 — SQL 실행 전 사용자 검토
python scripts/run_cli.py --question "전체 고객 수를 구하라" --hitl
```

`--hitl` 플래그를 추가하면 SQL 생성 후 실행 전에 사용자 검토 단계가 삽입됩니다.

| 입력 | 동작 |
|------|------|
| `y` | SQL 승인 후 실행 |
| `n` | 취소 (실행하지 않음) |
| `e` | SQL을 직접 수정 후 다시 선택 |
| `f` | LLM에 피드백을 주고 SQL 재생성 |

출력 예시:
```
┌──────────────────── Text-to-SQL Pipeline ─────────────────────┐
│ 전체 고객 수를 구하라                                          │
│ Database: chinook                                              │
└────────────────────────────────────────────────────────────────┘
   0.0s [1] Decomposer: 질문 의도 분석 및 분해 시작
   2.8s [1] Decomposer: 의도: 전체 고객의 수를 집계 | 패턴: simple
   6.3s [2] SchemaSelector: 선택된 테이블: ['Customer', 'Invoice']
  12.4s [5] CandidateGenerator: SQL 생성 완료 (2개)
  16.5s [9] ExecutePreview: ✅ 실행 성공 (1행, 1ms)
  17.8s [10] Judge: ✅ 승인 (score=1.0)
┌──────────────────────── Result ───────────────────────────────┐
│   Status   SUCCESS    Time   18.4s                            │
│   Tokens   13,503     Cost   $0.0316                          │
└────────────────────────────────────────────────────────────────┘
```

## Docker

```bash
# 이미지 빌드
docker compose build

# 웹 앱 실행 (http://localhost:8501)
docker compose up app

# 유닛 테스트 (local 80 + spider1 17 + spider2 45 = 142개)
docker compose --profile test run --rm test-unit

# KPI 통합 테스트 (LLM 호출 필요, .env 설정 필수)
docker compose --profile test run --rm test-kpi

# 전체 통합 테스트 (unit + KPI + Spider)
docker compose --profile test run --rm test-all
```

> `data/spider/`, `data/spider2/`, `test-suite-sql-eval/` 등 대용량 데이터는 이미지에 포함되지 않습니다.
> `docker-compose.yml`의 volumes로 호스트 `./data`가 마운트되므로, 호스트에 데이터를 준비하면 컨테이너에서 사용 가능합니다.

## 벤치마크 점수

| 항목 | 점수 |
|------|------|
| Spider 2.0-snow | **178/547 (32.54%)** |
| Spider 1.0 공식 EX | **84.3%** |
| Chinook accuracy | **0.98** |
| Monitor accuracy | **1.0** |
| Safety pass rate | **1.0** |
| TTR p50 (mixed routing) | **52.6s** |

## 관련 문서

- 테스트 및 개선 리포트: `docs/README.md`
