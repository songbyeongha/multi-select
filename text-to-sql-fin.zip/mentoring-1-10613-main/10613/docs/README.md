# Text-to-SQL 고도화 테스트 및 개선 리포트

- 작업 기간: 2026-03-06 ~ 2026-03-19
- 대상: Text-to-SQL 파이프라인 (Spider 1.0, Spider 2.0-snow, 로컬 KPI)

---

## 1. 최종 점수 요약

| 항목 | 초기(Baseline) | 최종 | 개선 |
|------|---------------|------|------|
| **Spider 2.0-snow** | 68/547 (12.43%) | **178/547 (32.54%)** | **+162%** |
| **Spider 1.0 공식 EX** | 65.7% | **84.3%** | +18.6%p |
| **Chinook accuracy** | 0.0 | **0.98** | - |
| **Monitor accuracy** | 0.0 | **1.0** | - |
| **Safety pass rate** | 0.83 | **1.0** | - |
| **Scenario pass rate** | 0.0 | **1.0** | - |
| **TTR p50** | 114.6s (gpt-5 only) | **52.6s** (mixed) | 2.18배 단축 |
| **LLM 비용** | $1.85/6건 (gpt-5 only) | **$0.82/6건** (mixed) | 55.6% 절감 |

---

## 2. Spider 2.0-snow 점수 개선 상세

### 2.1 공식 점수 변화

| 단계 | 점수 | 정답률 | 베이스라인 대비 |
|------|------|--------|----------------|
| 베이스라인 | 68/547 | 12.43% | - |
| Cycle 1 | 146/547 | 26.69% | +78건 (+115%) |
| **Cycle 2** | **178/547** | **32.54%** | **+110건 (+162%)** |

- 신규 정답: +111건, 퇴보: 1건, 순 증가: **+110건**

### 2.2 실패 유형별 변화

| 유형 | 베이스라인 | Cycle 1 | Cycle 2 | 감소율 |
|------|-----------|---------|---------|--------|
| 컴파일/런타임 에러 | 234건 | 127건 | 135건 | -42% |
| 데이터 없음 (0행) | 84건 | 66건 | 54건 | -36% |
| 결과 틀림 | 161건 | 208건 | 180건 | - |
| **총 실패** | **479건** | **401건** | **369건** | **-23%** |

### 2.3 원인 분석

**테이블명은 거의 정확 (TABLE_NOT_FOUND = 4건/479건, 0.8%)**
- 스키마 데이터가 프롬프트에 잘 전달되고 있음
- 3-part 이름(DATABASE.SCHEMA.TABLE) 정규화가 97% 적용됨

**컬럼명 환각이 핵심 문제 (89건, 19%)**
- 평균 테이블 컬럼 수: 66.4개, 200컬럼 초과 테이블: 1,393개 (18%)
- 기존 프롬프트 컬럼 제한(16~50개)으로 인해 LLM이 나머지 컬럼을 추측
- 해결: 컬럼 표시 80개로 확대 + 질문 관련성 기반 우선 정렬
- 무제한(0)은 프롬프트 과다로 역효과 확인됨 (전환율 24% → 12%)

**프롬프트 길이와 정확도의 트레이드오프**

| 컬럼 설정 | 배치 전환율 | 비고 |
|-----------|-----------|------|
| 기본 (50개) | 22.4% | 기본 개선만 |
| 무제한 (0) | 12.0% | 프롬프트 과다로 역효과 |
| **80개 (최적)** | **24.0%** | 질문 관련 우선 정렬 |

### 2.4 적용된 코드 개선 (10가지)

**1. 테이블명 정규화 강화** (`spider2_snow_runner.py`)
- SCHEMA.TABLE 2-part match, 퍼지 매칭(underscore, 복수형), 글로벌 fuzzy fallback
- Guardrails에서 rescue 2회 시도 + 전체 re-qualification

**2. BigQuery→Snowflake 함수 자동 변환 (18+패턴)** (`_fix_bq_to_snowflake()`)

| BigQuery | Snowflake |
|----------|-----------|
| `IF(cond, a, b)` | `IFF(cond, a, b)` |
| `COUNTIF(x)` | `COUNT_IF(x)` |
| `UNNEST(arr)` | `LATERAL FLATTEN(input => arr)` |
| `DATE_SUB(d, INTERVAL n unit)` | `DATEADD('unit', -n, d)` |
| `DATE_ADD(d, INTERVAL n unit)` | `DATEADD('unit', n, d)` |
| `PARSE_DATE('fmt', str)` | `TO_DATE(str, 'fmt')` |
| `FORMAT_DATE('fmt', d)` | `TO_CHAR(d, 'fmt')` |
| `SAFE_CAST(x AS t)` | `TRY_CAST(x AS t)` |
| `SAFE_DIVIDE(a, b)` | `(a) / NULLIF(b, 0)` |
| `ARRAY_LENGTH(x)` | `ARRAY_SIZE(x)` |
| `STRUCT(...)` | `OBJECT_CONSTRUCT(...)` |
| `STRING_AGG(...)` | `LISTAGG(...)` |

**3. Snowflake 전용 구문 postprocess** (`_fix_snowflake_syntax()`)
- INTERVAL 변환, CURRENT_DATE() 괄호 추가, WHERE 1=0 제거
- 기존 SQLite 파이프라인에 영향 없이 Spider 2.0 전용으로만 적용

**4. CTE 이름 충돌 자동 수정** (`_fix_cte_name_conflicts()`)
- `WITH DATABASE.SCHEMA.TABLE AS (...)` → `WITH cte_table AS (...)`

**5. 프롬프트 강화**
- CTE 참조 컬럼 검증 규칙, 컬럼 환각 방지 규칙
- 결과 정확도 규칙 (COUNT/SUM 구분, DISTINCT, 날짜 범위)
- 빈 결과 방지 (ILIKE, 날짜 포맷, 불필요한 WHERE 금지)

**6. 스키마 정보 확대**
- 프롬프트 테이블 컬럼: 50 → 80개 (질문 관련성 우선)
- 스키마 텍스트 컬럼: 16 → 50개
- 테이블 선택 top_k: 8 → 10
- 문서 부스트: 1.5배 강화

**7. 전략 다양화**
- `strict_qualification` 전략 추가 (모든 테이블 3-part, 모든 컬럼 double-quote)

**8. Repair/Retry 강화**
- max_retries: 2 → 3
- REPAIR 프롬프트에 CTE/UNNEST/FLATTEN 규칙 추가

**9. 파티션 테이블 처리 개선**
- YYYYMM 6자리 형식 지원, 월 이름만으로 파티션 키 추론

**10. Compile Preview 관대화**
- 네트워크 에러 무시 패턴 확대 (connection refused, SSL, rate limit 등)

### 2.5 파이프라인 병목 분석

| 단계 | 소요 시간 | 비고 |
|------|----------|------|
| Repair 루프 (최악) | ~25분/건 | 실패 시 4회 LLM 호출 |
| LLM API retry | 수 분 | gpt-5 rate limit |
| Snowflake compile preview | ~30초/건 | 네트워크 왕복 |
| 평균 처리 시간 | 2.7분/건 | |
| 최악 케이스 | 25분/건 | 대형 카탈로그(122 테이블) DB |

### 2.6 남은 과제 (369건)

| 유형 | 건수 | 비율 | 개선 방향 |
|------|------|------|----------|
| 결과 틀림 | 180건 | 49% | 질문 해석/집계 로직 강화, few-shot 확대 |
| 컴파일 에러 | 135건 | 37% | 컬럼명 rescue 강화, 구문 변환 추가 |
| 데이터 없음 | 54건 | 15% | WHERE 조건 완화, 값 매칭(ILIKE) |

---

## 3. Spider 1.0 개선 상세

### 3.1 점수 변화

| 시점 | Spider 1.0 공식 EX | 비고 |
|------|-------------------|------|
| 2026-03-06 | 65.7% | Baseline |
| 2026-03-08 | 80.8% (내부 EX) | 1차 개선 최고점 |
| 2026-03-11 | **84.3%** (공식 EX) | 대표 full run |
| 2026-03-11 | 83.3% | 최신 retained |

### 3.2 개선 내용
- GROUP BY 규칙 보정 (질문에 언급된 컬럼 중심)
- Judge/Repair 루프 보강
- Semantic compare 도입
- SQL 후처리 보완 (불필요한 CAST/alias/LEFT JOIN 제거)
- EXCEPT 체인 AST 기반 차단

---

## 4. 성능 및 비용 최적화

### 4.1 TTR (응답 시간) 비교

| 항목 | gpt-5 only | mixed routing | 개선 |
|------|-----------|--------------|------|
| TTR median | 114.6s | **52.6s** | **2.18배 단축** |
| 총 비용 (6건) | $1.85 | **$0.82** | **55.6% 절감** |

- mixed routing: 속도 우선 노드는 gpt-4.1, 정확도 우선 노드는 gpt-5
- 단순 질의에서 효과 극대화, 복잡 질의의 tail latency는 별도 관리 필요

### 4.2 검색 비교 (BM25 + Vector Hybrid)

| 지표 | vector-only | hybrid | 차이 |
|------|-----------|--------|------|
| 상위 5개 회수율 | 90.97% | **92.14%** | +1.17%p |
| top-1 적중률 | 83.33% | **85.00%** | +1.67%p |
| recall 악화 케이스 | - | **0건** | - |

---

## 5. 보안/가드레일

| 문제 | 원인 | 조치 | 결과 |
|------|------|------|------|
| Safety 83.3% 하락 | `A EXCEPT B EXCEPT C` 우회 | AST 차단 규칙 보강 | **1.0 회복** |
| 미등록 테이블 참조 | LLM 환각 | sqlglot AST + fuzzy match | 차단됨 |
| DML/DDL 혼입 | LLM 생성 오류 | keyword + AST 이중 차단 | 차단됨 |
| LIMIT 누락 | 대량 조회 위험 | 자동 LIMIT 추가 | 적용됨 |

---

## 6. 리팩토링 이력 (2026-03-16)

### 6.1 Spider 2.0 내부 파이프라인 연동
- Decomposer 결과를 agent_plan으로 반영
- SchemaSelector 스타일의 selected columns 추출
- JoinPlanner 스타일의 join condition 추출
- strategy 기반 다중 시도 유지

### 6.2 Smoke 테스트 (4건) → 공식 평가 경로 확보
- 내부 generation: 4/4 성공
- 공식 evaluator: 초기 0/4 → iter8에서 4/4 달성
- 핵심 병목: Snowflake semi-structured JSON path 접근 오류

### 6.3 GA360/GA4 전용 보정
- `EVENT_PARAMS` 접근 패턴 보정
- `trafficSource`, `hits`, `product` VARIANT path 수정
- canonical SQL shortcut (알려진 패턴에 대한 결정론적 SQL)

---

## 7. 실행 결과 디렉토리

| 디렉토리 | 점수 | 설명 |
|----------|------|------|
| `artifacts/spider2_runs/snow_v2_full/` | 68/547 (12.43%) | 베이스라인 |
| `artifacts/spider2_runs/cycle1_improved/` | 146/547 (26.69%) | Cycle 1 |
| `artifacts/spider2_runs/cycle2_final/` | **178/547 (32.54%)** | **최종** |

---

## 8. 수정된 파일 목록

| 파일 | 변경 내용 |
|------|----------|
| `src/text2sql/eval/spider2_snow_runner.py` | 핵심 - 테이블 정규화, 함수 변환, 구문 수정, 프롬프트 강화 |
| `src/text2sql/agents/validation_nodes.py` | Guardrails rescue 강화 |
| `src/text2sql/agents/schema_nodes.py` | 스키마 텍스트 limit 확대 |
| `src/text2sql/llm/prompts.py` | Spider 1.0 프롬프트 개선 |
| `src/text2sql/tools/guardrails.py` | EXCEPT 체인 차단, CTE alias 예외 |
| `src/text2sql/tools/sql_postprocess.py` | SQL 후처리 규칙 보강 |
| `tests/local/test_local.py` | 파이프라인 핵심 로직 테스트 (80개) |
| `tests/spider1/test_spider1.py` | Spider 1.0 로더/Writer 테스트 (17개) |
| `tests/spider2/test_spider2.py` | Spider 2.0 Snowflake 테스트 (45개) |

---

## 9. 시간 순 전체 타임라인

| 시점 | 작업 | 결과 |
|------|------|------|
| 03-06 | Spider 1.0 baseline 측정 | 공식 EX 65.7% |
| 03-08 | 1차 개선 반복 (GROUP BY, 후처리) | 내부 EX 80.8% |
| 03-09 | pytest + KPI + Spider 통합 구조 도입 | 초기 연결 오류 해결 |
| 03-10 | full KPI 검증 시작 | Chinook 0.84, Spider 공식 83.6% |
| 03-11 | guardrail, semantic compare 보강 | Safety 1.0, Spider 공식 84.3% |
| 03-13 | Spider 2.0-snow evaluator 경로 확보 | 공식 evaluator 호출 가능 |
| 03-14 | Spider 2.0 validator/qualification 복구 | 1→46→52/547 |
| 03-15 | schema/documents grounding, chunk 실험 | 72/547 (13.16%) |
| 03-16 | 리팩토링, smoke 4건 공식 통과 | 4/4 smoke 달성 |
| 03-16 | Spider 2.0 전체 full run | **68/547** (12.43%) - 베이스라인 확정 |
| 03-17 | Cycle 1: 퍼지 매칭, 함수 변환 등 10가지 개선 | **146/547** (26.69%) |
| 03-19 | Cycle 2: 컬럼 80개, CTE 규칙, 구문 수정 추가 | **178/547** (32.54%) |

---

## 10. 토큰 비용

| 실행 | 비용 (USD) |
|------|-----------|
| 베이스라인 (547건) | $57.7 |
| Cycle 1 (479건 재생성) | $289.4 |
| Cycle 2 (401건 재생성) | $263.5 |
