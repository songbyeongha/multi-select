"""
SQL 후처리기  ──  sqlglot AST 기반 결정론적 변환
═══════════════════════════════════════════════════════════════
프롬프트 규칙 중 100% 코드로 보장 가능한 변환을 수행합니다.

변환 목록:
  0. 다중 WITH 병합  — WITH a AS (...) WITH b AS (...) → WITH a AS (...), b AS (...)
  1. CAST 제거      — CAST(x AS INT) → x
  2. 컬럼 alias 제거 — SELECT x AS name → SELECT x  (CTE alias 보존)
  3. LEFT → INNER JOIN — LEFT JOIN → JOIN
  4. 방어적 패턴 제거  — JOIN 중복 IS NOT NULL 조건, COALESCE, IFNULL 제거
"""
from __future__ import annotations
import logging

try:
    import sqlglot
    from sqlglot import exp as E
    _HAS_SQLGLOT = True
except ImportError:
    _HAS_SQLGLOT = False

logger = logging.getLogger(__name__)


class SQLPostProcessor:
    """sqlglot AST 기반 SQL 후처리 — 결정론적 변환만 수행"""

    def process(self, sql: str, dialect: str = "sqlite") -> str:
        """모든 변환을 순차 적용. sqlglot 없으면 원본 반환."""
        if not _HAS_SQLGLOT:
            return sql
        try:
            # 0. 다중 WITH 병합 (AST 파싱 전 — 텍스트 + AST 혼합)
            sql = self._merge_multiple_with(sql, dialect)
            tree = sqlglot.parse_one(sql, read=dialect)
            tree = self._remove_casts(tree)
            tree = self._strip_column_aliases(tree)
            tree = self._left_to_inner_join(tree)
            tree = self._remove_defensive(tree)
            return tree.sql(dialect=dialect)
        except Exception as e:
            logger.warning(f"PostProcessor 파싱 실패, 원본 반환: {e}")
            return sql

    # ── 0. 다중 WITH 병합 ──────────────────────────────────────
    @staticmethod
    def _merge_multiple_with(sql: str, dialect: str = "sqlite") -> str:
        """
        두 개 이상의 WITH 구문을 하나의 WITH로 병합한다.

        LLM이 생성하는 잘못된 패턴들:

        패턴 A — 연속 WITH (중간 SELECT 없음):
            WITH cte1 AS (...)
            WITH cte2 AS (...)
            SELECT ...

        패턴 B — 중간 SELECT 포함:
            WITH cte1 AS (...) SELECT ... FROM cte1
            WITH cte2 AS (...) SELECT ... FROM cte2

        두 경우 모두 → WITH cte1 AS (...), cte2 AS (...) SELECT ...
        (마지막 SELECT만 유지)
        """
        # 1. 최상위(괄호 밖) WITH 키워드 위치 탐색
        with_positions = _find_top_level_positions(sql, "WITH")
        if len(with_positions) <= 1:
            return sql

        # 2. 각 WITH 위치 기준으로 세그먼트 분리
        segments: list[str] = []
        for j in range(len(with_positions)):
            start = with_positions[j]
            end = with_positions[j + 1] if j + 1 < len(with_positions) else len(sql)
            segments.append(sql[start:end].strip().rstrip(";").strip())

        # 3. 각 세그먼트를 개별 파싱 → CTE 수집, 마지막 본문 SELECT 유지
        all_ctes: list = []
        final_tree = None
        for seg in segments:
            try:
                tree = sqlglot.parse_one(seg, read=dialect)
            except Exception:
                # 개별 세그먼트 파싱 실패 → 원본 반환
                return sql

            with_clause = tree.find(E.With)
            if with_clause:
                for cte in with_clause.expressions:
                    all_ctes.append(cte.copy())
                with_clause.pop()
            final_tree = tree

        if not all_ctes or final_tree is None:
            return sql

        # 4. 모든 CTE를 마지막 쿼리에 부착
        merged_with = E.With(expressions=all_ctes)
        final_tree.set("with", merged_with)
        merged_sql = final_tree.sql(dialect=dialect)
        logger.info(
            "다중 WITH 병합 완료: %d개 → 1개", len(with_positions)
        )
        return merged_sql

    # ── 1. CAST 제거 ─────────────────────────────────────────
    @staticmethod
    def _remove_casts(tree: E.Expression) -> E.Expression:
        """CAST(x AS type) → x"""
        for cast in list(tree.find_all(E.Cast)):
            inner = cast.this
            if inner is not None:
                cast.replace(inner)
        return tree

    # ── 2. 컬럼 alias 제거 ───────────────────────────────────
    @staticmethod
    def _strip_column_aliases(tree: E.Expression) -> E.Expression:
        """
        SELECT 절의 컬럼 alias 제거.
        CTE 이름(WITH x AS ...)과 테이블 alias는 보존.
        서브쿼리 alias도 보존.

        UNION/UNION ALL/EXCEPT/INTERSECT 쿼리에서는 alias를 보존합니다.
        (ORDER BY 등에서 alias를 참조할 수 있으므로)
        """
        if tree.find(E.Union) or tree.find(E.Except) or tree.find(E.Intersect):
            return tree

        for select in tree.find_all(E.Select):
            for expr in select.expressions:
                if isinstance(expr, E.Alias):
                    # CTE 내부의 SELECT alias도 제거 대상
                    # 단, 서브쿼리 자체의 alias는 보존
                    inner = expr.this
                    if isinstance(inner, E.Subquery):
                        continue
                    expr.replace(inner)
        return tree

    # ── 3. LEFT JOIN → INNER JOIN ────────────────────────────
    @staticmethod
    def _left_to_inner_join(tree: E.Expression) -> E.Expression:
        """LEFT [OUTER] JOIN → JOIN (INNER)"""
        for join in list(tree.find_all(E.Join)):
            side = (join.args.get("side") or "").upper()
            if "LEFT" in side:
                join.set("side", "")
                if join.args.get("kind"):
                    kind = join.args["kind"].upper()
                    if "OUTER" in kind:
                        join.set("kind", "")
        return tree

    # ── 4. 방어적 패턴 제거 ──────────────────────────────────
    @staticmethod
    def _remove_defensive(tree: E.Expression) -> E.Expression:
        """
        - COALESCE(x, default) → x
        - IFNULL(x, default) → x
        - JOIN ON 컬럼과 중복되는 IS NOT NULL 조건만 제거
          (독립 비즈니스 필터인 IS NOT NULL은 보존)
        """
        for coal in list(tree.find_all(E.Coalesce)):
            first_arg = coal.this
            if first_arg is not None:
                coal.replace(first_arg)

        for anon in list(tree.find_all(E.Anonymous)):
            if anon.name.upper() == "IFNULL" and anon.expressions:
                anon.replace(anon.expressions[0])

        join_cols = _collect_join_columns(tree)
        for where in list(tree.find_all(E.Where)):
            cleaned = _remove_redundant_is_not_null(where.this, join_cols)
            if cleaned is None:
                where.pop()
            elif cleaned is not where.this:
                where.set("this", cleaned)

        return tree


def _find_top_level_positions(sql: str, keyword: str) -> list[int]:
    """괄호 밖(최상위)에 위치한 키워드의 시작 인덱스를 반환한다."""
    positions: list[int] = []
    depth = 0
    upper = sql.upper()
    kw_len = len(keyword)
    kw_upper = keyword.upper()
    n = len(sql)
    i = 0
    while i < n:
        ch = sql[i]
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and upper[i : i + kw_len] == kw_upper:
            # 단어 경계 확인
            before_ok = i == 0 or not (upper[i - 1].isalnum() or upper[i - 1] == "_")
            after_ok = (
                i + kw_len >= n
                or not (upper[i + kw_len].isalnum() or upper[i + kw_len] == "_")
            )
            if before_ok and after_ok:
                positions.append(i)
                i += kw_len
                continue
        i += 1
    return positions


def _collect_join_columns(tree: E.Expression) -> set[str]:
    """JOIN ON 절에서 등호(=) 비교에 사용된 컬럼명을 수집한다."""
    cols: set[str] = set()
    for join in tree.find_all(E.Join):
        on_expr = join.args.get("on")
        if on_expr is None:
            continue
        for eq in on_expr.find_all(E.EQ):
            for side in (eq.this, eq.expression):
                if isinstance(side, E.Column):
                    cols.add(side.name.upper())
    return cols


def _remove_redundant_is_not_null(
    expr: E.Expression,
    join_cols: set[str],
) -> E.Expression | None:
    """
    AND 트리에서 JOIN ON 컬럼과 중복되는 IS NOT NULL만 제거.
    JOIN 등호 조건이 이미 NULL을 걸러내므로 중복인 경우에만 안전하게 제거.
    독립 비즈니스 필터(예: error_code_id IS NOT NULL)는 보존.
    """
    if isinstance(expr, E.And):
        left = _remove_redundant_is_not_null(expr.this, join_cols)
        right = _remove_redundant_is_not_null(expr.expression, join_cols)
        if left is None and right is None:
            return None
        if left is None:
            return right
        if right is None:
            return left
        expr.set("this", left)
        expr.set("expression", right)
        return expr

    col_name = _extract_is_not_null_column(expr)
    if col_name and col_name.upper() in join_cols:
        return None

    return expr


def _extract_is_not_null_column(expr: E.Expression) -> str | None:
    """IS NOT NULL 또는 NOT ... IS NULL 패턴에서 컬럼명을 추출한다."""
    if isinstance(expr, E.Not):
        inner = expr.this
        if isinstance(inner, E.Is) and isinstance(inner.expression, E.Null):
            if isinstance(inner.this, E.Column):
                return inner.this.name
    if isinstance(expr, E.Is):
        if isinstance(expr.expression, E.Not) and isinstance(
            expr.expression.this, E.Null
        ):
            if isinstance(expr.this, E.Column):
                return expr.this.name
    return None
