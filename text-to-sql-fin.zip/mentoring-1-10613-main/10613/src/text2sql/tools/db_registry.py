"""
DB Registry  --  db_id -> 실제 파일 경로 해석
==========================================================
탐색 우선순위:
  1. data/databases/{db_id}.db          (기존 Chinook/monitor)
  2. data/spider/database/{db_id}/{db_id}.sqlite  (Spider 1.0)

spider_root 를 지정하면 Spider DB 기본 경로를 변경할 수 있습니다.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, List

# 프로젝트 루트 (src/text2sql/tools/ 에서 3단계 위)
_PROJECT_ROOT = Path(__file__).resolve().parents[3]

# 기본 경로
_FLAT_DB_DIR = _PROJECT_ROOT / "data" / "databases"
_SPIDER_DB_DIR = _PROJECT_ROOT / "data" / "spider" / "database"


class DBNotFoundError(FileNotFoundError):
    """db_id에 해당하는 DB 파일을 찾을 수 없을 때"""


def resolve_db_path(
    db_id: str,
    spider_root: Optional[Path] = None,
) -> str:
    """
    db_id를 실제 SQLite 파일 경로(str)로 변환합니다.

    Args:
        db_id: 데이터베이스 식별자 (예: "chinook", "concert_singer")
        spider_root: Spider database/ 루트 (기본: data/spider/database)

    Returns:
        절대 경로 문자열

    Raises:
        DBNotFoundError: 어떤 경로에서도 DB를 찾지 못한 경우
    """
    # 1) flat 구조: data/databases/{db_id}.db
    flat_path = _FLAT_DB_DIR / f"{db_id}.db"
    if flat_path.exists():
        return str(flat_path)

    # 2) Spider 구조: data/spider/database/{db_id}/{db_id}.sqlite
    spider_base = spider_root or _SPIDER_DB_DIR
    spider_path = spider_base / db_id / f"{db_id}.sqlite"
    if spider_path.exists():
        return str(spider_path)

    raise DBNotFoundError(
        f"DB '{db_id}' not found.\n"
        f"  checked: {flat_path}\n"
        f"  checked: {spider_path}"
    )


def list_flat_dbs() -> dict[str, str]:
    """기존 data/databases/*.db 목록을 {stem: abs_path} 로 반환 (UI 용)"""
    if not _FLAT_DB_DIR.exists():
        return {}
    return {p.stem: str(p) for p in sorted(_FLAT_DB_DIR.glob("*.db"))}


def list_spider_dbs(spider_root: Optional[Path] = None) -> List[str]:
    """Spider database/ 하위의 db_id 목록 반환"""
    base = spider_root or _SPIDER_DB_DIR
    if not base.exists():
        return []
    ids = []
    for d in sorted(base.iterdir()):
        if d.is_dir() and (d / f"{d.name}.sqlite").exists():
            ids.append(d.name)
    return ids
