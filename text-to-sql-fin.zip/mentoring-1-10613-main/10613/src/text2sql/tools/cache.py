"""
캐시 모듈 – 스키마 선택 결과 등을 메모리 캐싱
"""
from __future__ import annotations
import time
from typing import Dict, Any, Optional
from dataclasses import dataclass


@dataclass
class CacheEntry:
    value: Any
    expires_at: float


class SimpleCache:
    """간단한 메모리 캐시 (TTL 지원)"""
    
    def __init__(self):
        self._cache: Dict[str, CacheEntry] = {}
    
    def get(self, key: str) -> Optional[Any]:
        """캐시에서 값 가져오기"""
        entry = self._cache.get(key)
        if entry is None:
            return None
        
        if time.time() > entry.expires_at:
            del self._cache[key]
            return None
        
        return entry.value
    
    def set(self, key: str, value: Any, ttl: int = 300):
        """캐시에 값 저장 (기본 TTL: 5분)"""
        expires_at = time.time() + ttl
        self._cache[key] = CacheEntry(value=value, expires_at=expires_at)
    
    def clear(self):
        """캐시 전체 삭제"""
        self._cache.clear()


# 싱글톤
_instance: Optional[SimpleCache] = None


def get_cache() -> SimpleCache:
    """캐시 싱글톤 가져오기"""
    global _instance
    if _instance is None:
        _instance = SimpleCache()
    return _instance
