"""
SQL 실행기 · SchemaReader  –  에러 타입별 분류 포함
"""
from __future__ import annotations
import sqlite3, time
from typing import Dict, List, Any, Optional
from pathlib import Path

from ..lg.state import ErrorType, ExecReport


class SQLExecutor:
    def __init__(self, preview_limit: int = 50, timeout_ms: int | None = None):
        self.preview_limit = preview_limit
        if timeout_ms is not None:
            self._timeout_ms = timeout_ms
        else:
            from ..config.settings import get_settings
            self._timeout_ms = get_settings().guard.timeout_ms

    def execute(self, db_path: str, sql: str,
                limit: int | None = None) -> ExecReport:
        limit = limit or self.preview_limit
        conn = None
        t0 = time.time()
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row

            timeout_sec = self._timeout_ms / 1000.0
            def _timeout_check():
                if time.time() - t0 > timeout_sec:
                    return 1  # non-zero → 인터럽트
                return 0
            conn.set_progress_handler(_timeout_check, 1000)

            cur = conn.execute(sql)
            rows = [dict(r) for r in cur.fetchmany(limit)]
            remaining = 0
            if len(rows) == limit:
                while True:
                    batch = cur.fetchmany(1000)
                    if not batch:
                        break
                    remaining += len(batch)
            total_rows = len(rows) + remaining
            ms = (time.time() - t0) * 1000
            return ExecReport(ok=True, rows_preview=rows,
                              row_count=total_rows, exec_ms=ms)
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if "no such table" in msg or "no such column" in msg or "ambiguous" in msg:
                etype = ErrorType.SCHEMA
            elif "syntax" in msg:
                etype = ErrorType.SYNTAX
            elif "interrupt" in msg:
                etype = ErrorType.TIMEOUT
            else:
                etype = ErrorType.RUNTIME
            return ExecReport(ok=False, error_type=etype, error_message=str(e))
        except Exception as e:
            return ExecReport(ok=False, error_type=ErrorType.UNKNOWN,
                              error_message=str(e))
        finally:
            if conn:
                conn.close()


class SchemaReader:
    @staticmethod
    def tables(db_path: str) -> List[str]:
        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            return [r[0] for r in rows]
        finally:
            conn.close()

    @staticmethod
    def table_info(db_path: str, table: str) -> Dict[str, Any]:
        conn = sqlite3.connect(db_path)
        try:
            cols = [{"name": r[1], "type": r[2], "notnull": bool(r[3]),
                     "pk": bool(r[5])}
                    for r in conn.execute(f"PRAGMA table_info({table})")]
            fks = [{"from": r[3], "to_table": r[2], "to_column": r[4]}
                   for r in conn.execute(f"PRAGMA foreign_key_list({table})")]
            try:
                cur = conn.execute(f"SELECT * FROM [{table}] LIMIT 3")
                names = [d[0] for d in cur.description]
                samples = [dict(zip(names, row)) for row in cur.fetchall()]
            except Exception:
                samples = []
            return {"table_name": table, "columns": cols,
                    "foreign_keys": fks, "sample_rows": samples}
        finally:
            conn.close()

    @staticmethod
    def full_schema(db_path: str) -> List[Dict[str, Any]]:
        return [SchemaReader.table_info(db_path, t)
                for t in SchemaReader.tables(db_path)]

    @staticmethod
    def format_text(schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None) -> str:
        """스키마를 LLM 프롬프트용 텍스트로 변환 (메타데이터 + 샘플 값 반영)"""
        lines: List[str] = []
        tables_meta = (meta or {}).get("tables", {})

        for tbl in schema:
            name = tbl["table_name"]
            tmeta = tables_meta.get(name, {})
            desc = tmeta.get("description", "")
            lines.append(f"## {name}" + (f"  -- {desc}" if desc else ""))

            col_meta = tmeta.get("columns", {})
            samples = tbl.get("sample_rows", [])

            for c in tbl["columns"]:
                pk = " [PK]" if c.get("pk") else ""
                cdesc = ""
                if isinstance(col_meta, dict):
                    cm = col_meta.get(c["name"], {})
                    if isinstance(cm, dict):
                        cdesc = cm.get("description", "")
                    elif isinstance(cm, str):
                        cdesc = cm
                line = f"  {c['name']}  {c['type']}{pk}"
                if cdesc:
                    line += f"  -- {cdesc}"

                if samples:
                    cname = c["name"]
                    sample_vals = []
                    for row in samples[:3]:
                        val = row.get(cname)
                        if val is not None:
                            sv = str(val)
                            if len(sv) > 30:
                                sv = sv[:27] + "..."
                            sample_vals.append(sv)
                    if sample_vals:
                        unique_vals = list(dict.fromkeys(sample_vals))[:3]
                        line += f"  (예: {', '.join(unique_vals)})"

                lines.append(line)

            for fk in tbl.get("foreign_keys", []):
                lines.append(f"  FK: {fk['from']} → {fk['to_table']}.{fk['to_column']}")

            lines.append("")

        return "\n".join(lines)
