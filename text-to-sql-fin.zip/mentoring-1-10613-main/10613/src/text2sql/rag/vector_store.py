"""
벡터 스토어  ──  Chroma + Azure OpenAI Embeddings 기반 스키마 시맨틱 검색
═══════════════════════════════════════════════════════════════════════════
필수 의존성: chromadb, openai

사용 흐름:
  1. get_vector_store(db_id) 호출 시 인덱스 미빌드면 자동 빌드
  2. SchemaSelector.select() 에서 hybrid_search() 호출
  3. BM25 스코어 + 벡터 유사도 가중합으로 최종 테이블 선택
"""
from __future__ import annotations
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from ..config.settings import get_settings
from ..llm.client import build_azure_openai_client

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Embedding 함수
# ═══════════════════════════════════════════════════════════════
class AzureEmbedder:
    """Azure OpenAI Embeddings 클라이언트"""

    def __init__(self):
        cfg = get_settings().embed
        if not cfg.endpoint or not cfg.api_key:
            raise RuntimeError(
                "Azure OpenAI Embedding 설정 누락 "
                "(SKCC_AZURE_ENDPOINT, SKCC_AZURE_OPENAI_KEY 확인)")
        self._client = build_azure_openai_client(
            azure_endpoint=cfg.endpoint,
            api_key=cfg.api_key,
            api_version=cfg.api_version,
        )
        self._model = cfg.deployment  # Azure는 deployment 이름 사용
        self._cache: Dict[str, List[float]] = {}

    def embed(self, texts: List[str]) -> List[List[float]]:
        """텍스트 리스트 → 임베딩 벡터 리스트"""
        resp = self._client.embeddings.create(input=texts, model=self._model)
        results = [d.embedding for d in resp.data]
        for text, vec in zip(texts, results):
            self._cache[text] = vec
        return results

    def embed_one(self, text: str) -> List[float]:
        """단일 텍스트 임베딩 (캐시 활용)"""
        if text in self._cache:
            return self._cache[text]
        result = self.embed([text])[0]
        return result


# ═══════════════════════════════════════════════════════════════
# Chroma 벡터 스토어
# ═══════════════════════════════════════════════════════════════
_STORE_DIR = Path(__file__).resolve().parents[3] / "data" / "vector_store"


class SchemaVectorStore:
    """
    DB 스키마를 벡터화하여 Chroma에 저장·검색하는 클래스.

    컬렉션명: schema_{db_id}
    문서: 테이블별 텍스트 (테이블명 + 컬럼 + FK + 샘플)
    메타데이터: table_name, column_count, has_fk
    """

    def __init__(self, db_id: str, persist_dir: Path | str | None = None):
        self._db_id = db_id
        self._persist_dir = str(persist_dir or _STORE_DIR)
        self._client = chromadb.PersistentClient(
            path=self._persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection_name = f"schema_{db_id}"
        self._collection = self._client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder: Optional[AzureEmbedder] = None

    @property
    def embedder(self) -> AzureEmbedder:
        if self._embedder is None:
            self._embedder = AzureEmbedder()
        return self._embedder

    # ── 인덱스 빌드 ───────────────────────────────────────
    def build_index(self, schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None):
        """
        스키마 정보로 벡터 인덱스 빌드 (기존 인덱스 덮어쓰기).

        Args:
            schema: SchemaReader.full_schema() 결과
            meta: schema_metadata 딕셔너리 (설명, 샘플값 등)
        """
        try:
            self._client.delete_collection(self._collection_name)
        except Exception:
            pass
        self._collection = self._client.create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )

        tables_meta = (meta or {}).get("tables", {})
        ids, docs, metadatas = [], [], []

        for tbl in schema:
            tname = tbl["table_name"]
            doc = self._table_to_text(tbl, tables_meta.get(tname, {}))
            ids.append(tname)
            docs.append(doc)
            metadatas.append({
                "table_name": tname,
                "column_count": len(tbl.get("columns", [])),
                "has_fk": len(tbl.get("foreign_keys", [])) > 0,
            })

        embeddings = self.embedder.embed(docs)
        self._collection.add(
            ids=ids,
            documents=docs,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        logger.info(f"[{self._db_id}] 벡터 인덱스 빌드 완료: {len(schema)}개 테이블")

    # ── 검색 ──────────────────────────────────────────────
    def search(self, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        질문과 유사한 테이블 검색.

        Returns:
            [{"table_name": str, "score": float, "document": str}, ...]
            score: cosine similarity (0~1, 높을수록 유사)
        """
        if self._collection.count() == 0:
            return []

        query_embedding = self.embedder.embed_one(question)
        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, self._collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        for i, doc_id in enumerate(results["ids"][0]):
            # Chroma cosine distance → similarity
            distance = results["distances"][0][i]
            similarity = 1.0 - distance  # cosine distance → similarity
            hits.append({
                "table_name": doc_id,
                "score": similarity,
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
            })
        return hits

    def is_indexed(self) -> bool:
        """인덱스가 빌드되었는지 확인"""
        return self._collection.count() > 0

    # ── 내부 ──────────────────────────────────────────────
    @staticmethod
    def _table_to_text(tbl: Dict[str, Any],
                       tmeta: Dict[str, Any] | None = None) -> str:
        """테이블 정보를 검색용 텍스트로 변환"""
        tmeta = tmeta or {}
        parts = [f"테이블: {tbl['table_name']}"]

        desc = tmeta.get("description", "")
        if desc:
            parts.append(f"설명: {desc}")

        col_meta = tmeta.get("columns", {})
        col_parts = []
        for c in tbl.get("columns", []):
            cname = c["name"] if isinstance(c, dict) else str(c)
            ctype = c.get("type", "") if isinstance(c, dict) else ""
            cdesc = ""
            if isinstance(col_meta, dict):
                cm = col_meta.get(cname, {})
                cdesc = cm.get("description", "") if isinstance(cm, dict) else str(cm) if cm else ""
            col_str = f"{cname} ({ctype})"
            if cdesc:
                col_str += f" - {cdesc}"
            col_parts.append(col_str)
        parts.append("컬럼: " + ", ".join(col_parts))

        fk_parts = []
        for fk in tbl.get("foreign_keys", []):
            fk_parts.append(f"{fk['from']} → {fk['to_table']}.{fk['to_column']}")
        if fk_parts:
            parts.append("관계: " + ", ".join(fk_parts))

        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════
# 자동 인덱스 빌드
# ═══════════════════════════════════════════════════════════════
def _auto_build_index(store: SchemaVectorStore, db_id: str):
    """인덱스가 없을 때 자동으로 빌드"""
    from ..tools.executor import SchemaReader
    from ..tools.db_registry import resolve_db_path
    from ..config.settings import get_settings

    db_path = resolve_db_path(db_id)
    schema = SchemaReader.full_schema(db_path)
    meta = get_settings().schema_metadata(db_id)
    store.build_index(schema, meta)


# ═══════════════════════════════════════════════════════════════
# 유틸리티
# ═══════════════════════════════════════════════════════════════
_stores: Dict[str, SchemaVectorStore] = {}
_failed_dbs: set = set()


def get_vector_store(db_id: str) -> SchemaVectorStore:
    """벡터 스토어 싱글톤 — 인덱스 미빌드 시 자동 빌드. 실패한 DB는 재시도하지 않음."""
    if db_id in _failed_dbs:
        raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")

    if db_id not in _stores:
        try:
            store = SchemaVectorStore(db_id)
            if not store.is_indexed():
                logger.debug(f"[{db_id}] 벡터 인덱스 없음 — 자동 빌드 시작")
                _auto_build_index(store, db_id)
            _stores[db_id] = store
        except Exception as e:
            _failed_dbs.add(db_id)
            logger.debug(f"[{db_id}] 벡터 스토어 초기화 실패 (BM25로 대체): {e}")
            raise

    return _stores[db_id]


# ═══════════════════════════════════════════════════════════════
# Spider 2.0 Snowflake 스키마 벡터 인덱싱
# ═══════════════════════════════════════════════════════════════
_snow_stores: Dict[str, SchemaVectorStore] = {}


def _snow_table_to_text(table) -> str:
    """SnowTable → 벡터 검색용 텍스트 변환 (컬럼명 + 타입 + 설명 전부 포함)."""
    parts = [f"Table: {table.full_name}"]
    col_parts = []
    for name, col_type, desc in zip(
        table.column_names,
        table.column_types or ("",) * len(table.column_names),
        table.descriptions or ("",) * len(table.column_names),
    ):
        entry = f"{name} ({col_type})"
        if desc:
            entry += f" -- {desc}"
        col_parts.append(entry)
    parts.append("Columns: " + ", ".join(col_parts))
    if table.ddl:
        parts.append(f"DDL: {table.ddl[:300]}")
    return "\n".join(parts)


def build_snow_vector_index(db_id: str, tables, persist_dir: str | Path | None = None) -> SchemaVectorStore:
    """Spider 2.0 SnowTable 리스트로 벡터 인덱스 빌드.

    Args:
        db_id: Snowflake 데이터베이스 ID
        tables: SnowTable 시퀀스
        persist_dir: 벡터 스토어 저장 경로 (None이면 기본 경로)

    Returns:
        빌드된 SchemaVectorStore
    """
    store = SchemaVectorStore(f"snow_{db_id}", persist_dir=persist_dir)
    if store.is_indexed():
        return store

    schema_rows = []
    for table in tables:
        schema_rows.append({
            "table_name": table.full_name,
            "columns": [
                {"name": n, "type": t}
                for n, t in zip(table.column_names, table.column_types or ())
            ],
            "foreign_keys": [],
        })

    ids, docs, metadatas = [], [], []
    for table in tables:
        doc = _snow_table_to_text(table)
        ids.append(table.full_name)
        docs.append(doc)
        metadatas.append({
            "table_name": table.full_name,
            "column_count": len(table.column_names),
            "has_fk": False,
        })

    try:
        embeddings = store.embedder.embed(docs)
        store._collection.add(
            ids=ids,
            documents=docs,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        logger.info(f"[snow_{db_id}] Snowflake 벡터 인덱스 빌드 완료: {len(tables)}개 테이블")
    except Exception as e:
        logger.warning(f"[snow_{db_id}] 벡터 인덱스 빌드 실패: {e}")

    return store


def get_snow_vector_store(db_id: str, tables=None) -> Optional[SchemaVectorStore]:
    """Spider 2.0 Snowflake 벡터 스토어 — 인덱스 있으면 반환, 없으면 빌드 시도."""
    key = f"snow_{db_id}"
    if key not in _snow_stores:
        store = SchemaVectorStore(key)
        if store.is_indexed():
            _snow_stores[key] = store
        elif tables:
            _snow_stores[key] = build_snow_vector_index(db_id, tables)
        else:
            return None
    return _snow_stores.get(key)


def search_snow_columns(db_id: str, question: str, tables=None, top_k: int = 10) -> List[Dict[str, Any]]:
    """Spider 2.0 Snowflake 스키마에서 질문과 유사한 테이블/컬럼 검색.

    Returns:
        [{"table_name": str, "score": float, "document": str}, ...]
    """
    store = get_snow_vector_store(db_id, tables)
    if store is None:
        return []
    return store.search(question, top_k=top_k)
