"""
Spider 1.0 dev 데이터셋 로더
==========================================================
기본 경로: data/spider/dev.json, data/spider/tables.json

사용 예:
    from text2sql.datasets.spider_loader import load_spider_dev
    examples = load_spider_dev()          # 전체 로드
    examples = load_spider_dev(limit=10)  # 앞 10개만
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Dict, Any

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_SPIDER_DIR = _PROJECT_ROOT / "data" / "spider"


@dataclass
class SpiderExample:
    """Spider dev.json의 개별 예제"""
    question: str
    db_id: str
    gold_sql: str
    # 원본 필드 보존 (query_toks, query_toks_no_value 등)
    extra: Dict[str, Any] = field(default_factory=dict)


def load_spider_dev(
    spider_dir: Optional[Path] = None,
    limit: Optional[int] = None,
) -> List[SpiderExample]:
    """
    Spider dev.json을 로드하여 SpiderExample 리스트로 반환합니다.

    Args:
        spider_dir: data/spider 경로 (기본: 프로젝트 루트/data/spider)
        limit: 최대 로드 개수 (None이면 전체)

    Returns:
        SpiderExample 리스트

    Raises:
        FileNotFoundError: dev.json이 없는 경우
    """
    base = spider_dir or _DEFAULT_SPIDER_DIR
    dev_path = base / "dev.json"
    if not dev_path.exists():
        raise FileNotFoundError(
            f"Spider dev.json not found: {dev_path}\n"
            f"데이터를 data/spider/ 에 배치하세요."
        )

    raw: List[Dict[str, Any]] = json.loads(dev_path.read_text("utf-8"))

    examples: List[SpiderExample] = []
    for item in raw:
        ex = SpiderExample(
            question=item["question"],
            db_id=item["db_id"],
            gold_sql=item.get("query", ""),
            extra={k: v for k, v in item.items()
                   if k not in ("question", "db_id", "query")},
        )
        examples.append(ex)
        if limit and len(examples) >= limit:
            break

    return examples


def load_spider_tables(
    spider_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """
    Spider tables.json을 db_id 기준 딕셔너리로 반환합니다.

    Returns:
        {db_id: {table_names, column_names, column_types, ...}}
    """
    base = spider_dir or _DEFAULT_SPIDER_DIR
    tables_path = base / "tables.json"
    if not tables_path.exists():
        raise FileNotFoundError(
            f"Spider tables.json not found: {tables_path}"
        )

    raw: List[Dict[str, Any]] = json.loads(tables_path.read_text("utf-8"))
    return {item["db_id"]: item for item in raw}
