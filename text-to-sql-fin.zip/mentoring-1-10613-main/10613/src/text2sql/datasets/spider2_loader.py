from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class Spider2DatasetSpec:
    name: str
    dataset_file: str
    gold_dir: str
    eval_script: str
    sqlite_db_dir: Optional[str] = None


@dataclass
class Spider2Example:
    instance_id: str
    question: str
    db_id: str
    benchmark: str
    dialect: str
    gold_sql: str = ""
    evidence: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)
    db_path: Optional[Path] = None

    @property
    def is_local_sqlite(self) -> bool:
        return self.benchmark == "lite" and self.instance_id.startswith("local")

    @property
    def prompt(self) -> str:
        if not self.evidence:
            return self.question
        return f"{self.question}\n\nContext:\n{self.evidence}"


SPIDER2_DATASETS: Dict[str, Spider2DatasetSpec] = {
    "lite": Spider2DatasetSpec(
        name="lite",
        dataset_file="spider2-lite/spider2-lite.jsonl",
        gold_dir="spider2-lite/evaluation_suite/gold",
        eval_script="spider2-lite/evaluation_suite/evaluate.py",
        sqlite_db_dir="spider2-lite/resource/databases",
    ),
    "snow": Spider2DatasetSpec(
        name="snow",
        dataset_file="spider2-snow/spider2-snow.jsonl",
        gold_dir="spider2-snow/evaluation_suite/gold",
        eval_script="spider2-snow/evaluation_suite/evaluate.py",
        sqlite_db_dir=None,
    ),
}


def get_spider2_spec(dataset: str) -> Spider2DatasetSpec:
    key = dataset.strip().lower()
    if key not in SPIDER2_DATASETS:
        raise ValueError(f"Unsupported Spider 2.0 dataset: {dataset}")
    return SPIDER2_DATASETS[key]


def is_spider2_root(path: Path) -> bool:
    if not path.exists():
        return False
    return any((path / spec.dataset_file).exists() for spec in SPIDER2_DATASETS.values())


def discover_spider2_root(project_root: Optional[Path] = None, override: Optional[Path] = None) -> Optional[Path]:
    if override:
        candidate = override.resolve()
        return candidate if is_spider2_root(candidate) else None

    root = (project_root or PROJECT_ROOT).resolve()
    candidates = [
        Path.cwd(),
        root / "data" / "spider2",
        root / "Spider2",
        root.parent / "Spider2",
    ]
    for candidate in candidates:
        if is_spider2_root(candidate):
            return candidate.resolve()
    return None


def spider2_dataset_path(spider2_root: Path, dataset: str) -> Path:
    return spider2_root / get_spider2_spec(dataset).dataset_file


def spider2_gold_dir(spider2_root: Path, dataset: str) -> Path:
    return spider2_root / get_spider2_spec(dataset).gold_dir


def spider2_eval_script(spider2_root: Path, dataset: str) -> Path:
    return spider2_root / get_spider2_spec(dataset).eval_script


def spider2_sqlite_db_dir(spider2_root: Path, dataset: str) -> Optional[Path]:
    spec = get_spider2_spec(dataset)
    if not spec.sqlite_db_dir:
        return None
    return spider2_root / spec.sqlite_db_dir


def load_spider2_examples(
    spider2_root: Path,
    dataset: str = "lite",
    *,
    offset: int = 0,
    limit: Optional[int] = None,
    instance_prefixes: Optional[Sequence[str]] = None,
    instance_ids: Optional[Sequence[str]] = None,
) -> List[Spider2Example]:
    dataset_path = spider2_dataset_path(spider2_root, dataset)
    if not dataset_path.exists():
        raise FileNotFoundError(f"Spider 2.0 dataset file not found: {dataset_path}")

    prefixes = tuple(prefix.lower() for prefix in (instance_prefixes or ()))
    requested_ids = {instance_id.strip().lower() for instance_id in (instance_ids or ()) if instance_id and instance_id.strip()}
    raw_lines = dataset_path.read_text(encoding="utf-8-sig").splitlines()
    examples: List[Spider2Example] = []
    sqlite_root = spider2_sqlite_db_dir(spider2_root, dataset)

    for index, raw_line in enumerate(raw_lines):
        if index < offset or not raw_line.strip():
            continue
        record = json.loads(raw_line)
        example = _normalize_spider2_record(record, dataset)
        if prefixes and not example.instance_id.lower().startswith(prefixes):
            continue
        if requested_ids and example.instance_id.lower() not in requested_ids:
            continue
        if sqlite_root is not None:
            example.db_path = _resolve_spider2_sqlite_db_path(sqlite_root, example.db_id)
        examples.append(example)
        if limit is not None and len(examples) >= limit:
            break
    return examples


def _normalize_spider2_record(record: Dict[str, Any], dataset: str) -> Spider2Example:
    instance_id = str(record.get("instance_id") or record.get("id") or "")
    if not instance_id:
        raise ValueError(f"Spider 2.0 record is missing instance_id: {record}")
    question = str(record.get("question") or record.get("instruction") or "").strip()
    db_id = str(record.get("db") or record.get("db_id") or record.get("database_id") or "").strip()
    evidence = str(record.get("evidence") or record.get("external_knowledge") or "").strip()
    gold_sql = str(record.get("query") or record.get("gold_sql") or record.get("sql") or "").strip()
    dialect = "sqlite" if instance_id.startswith("local") else ("snowflake" if dataset == "snow" else "remote")
    extra = {key: value for key, value in record.items() if key not in {"instance_id", "id", "question", "instruction", "db", "db_id", "database_id", "evidence", "external_knowledge", "query", "gold_sql", "sql"}}
    return Spider2Example(
        instance_id=instance_id,
        question=question,
        db_id=db_id,
        benchmark=dataset,
        dialect=dialect,
        gold_sql=gold_sql,
        evidence=evidence,
        extra=extra,
    )


def _resolve_spider2_sqlite_db_path(sqlite_root: Path, db_id: str) -> Optional[Path]:
    if not db_id:
        return None
    candidates = [
        sqlite_root / f"{db_id}.sqlite",
        sqlite_root / f"{db_id}.db",
        sqlite_root / db_id / f"{db_id}.sqlite",
        sqlite_root / db_id / f"{db_id}.db",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()
    return None


def filter_supported_spider2_examples(examples: Iterable[Spider2Example]) -> List[Spider2Example]:
    return [example for example in examples if example.db_path]
