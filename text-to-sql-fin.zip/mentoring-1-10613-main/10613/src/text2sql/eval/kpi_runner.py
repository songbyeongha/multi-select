from __future__ import annotations

import argparse
import contextlib
import concurrent.futures
import importlib
import itertools
import json
import logging
import math
import os
import re
import sqlite3
import statistics
import subprocess
import sys
import time
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Iterator, List, Optional, Sequence

import yaml

LOG = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parents[3]


@dataclass(frozen=True)
class RepoDiscovery:
    root: Path
    src_dir: Path
    app_path: Optional[Path]
    spider_runner: Optional[Path]
    spider_eval: Optional[Path]
    chinook_db: Optional[Path]
    spider_dir: Optional[Path]
    spider_eval_dir: Optional[Path]
    existing_spider_summary: Optional[Path]
    rg_available: bool
    pipeline_source: str


@dataclass(frozen=True)
class RuntimeHandles:
    resolve_db_path: Callable[..., str]
    new_state: Callable[..., Dict[str, Any]]
    get_compiled_graph: Callable[[], Any]
    node_decomposer: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_schema_selector: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_value_retriever: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_join_planner: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_candidate_generator: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_guardrails: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_unit_tester: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_execute_preview: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_judge: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_repair: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_result_output: Callable[[Dict[str, Any]], Dict[str, Any]]
    node_safe_fail: Callable[[Dict[str, Any]], Dict[str, Any]]


def _search_files(root: Path, pattern: str, suffixes: Sequence[str] = (".py",)) -> List[Path]:
    matches: List[Path] = []
    rg_path = shutil_which("rg")
    if rg_path:
        try:
            proc = subprocess.run(
                [rg_path, "-l", pattern, str(root)],
                capture_output=True,
                check=False,
                **_subprocess_text_kwargs(),
            )
            for line in proc.stdout.splitlines():
                path = Path(line.strip())
                if path.suffix in suffixes and path.exists():
                    matches.append(path)
            if matches:
                return matches
        except OSError:
            LOG.debug("rg lookup failed for %s", pattern, exc_info=True)

    for path in root.rglob("*"):
        if path.suffix not in suffixes or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = path.read_text(encoding="utf-8", errors="ignore")
        if pattern in text:
            matches.append(path)
    return matches


def shutil_which(name: str) -> Optional[str]:
    from shutil import which

    return which(name)


def _first_existing(paths: Iterable[Optional[Path]]) -> Optional[Path]:
    for path in paths:
        if path and path.exists():
            return path
    return None


def discover_repo(root: Optional[Path] = None) -> RepoDiscovery:
    repo_root = (root or PROJECT_ROOT).resolve()
    src_dir = repo_root / "src"
    app_candidates = _search_files(repo_root, "def run_phase1_generate")
    app_path = next((path for path in app_candidates if path.name == "app.py"), None)
    spider_runner = _first_existing(
        [repo_root / "scripts" / "run_spider_dev.py"]
        + _search_files(repo_root, "load_spider_dev")
    )
    spider_eval = _first_existing(
        [repo_root / "scripts" / "eval_spider.py"]
        + _search_files(repo_root, "prepare_eval_files")
    )
    chinook_db = _first_existing((repo_root / "data").rglob("chinook.db"))
    spider_dir = _first_existing(
        [
            repo_root / "data" / "spider",
            next(iter((repo_root / "data").rglob("dev.json")), None),
        ]
    )
    if spider_dir and spider_dir.is_file():
        spider_dir = spider_dir.parent
    spider_eval_dir = _first_existing(
        [repo_root / "test-suite-sql-eval", repo_root / "spider"]
    )
    existing_spider_summary = _first_existing(
        [
            repo_root / "artifacts" / "spider_runs" / "spider_full" / "summary.json",
            next(iter((repo_root / "artifacts" / "test_runs").rglob("summary.json")), None),
            next(iter((repo_root / "artifacts" / "spider_runs").rglob("summary.json")), None),
        ]
    )
    pipeline_source = "graph.invoke"
    if app_path:
        pipeline_source = str(app_path.relative_to(repo_root))
    return RepoDiscovery(
        root=repo_root,
        src_dir=src_dir,
        app_path=app_path,
        spider_runner=spider_runner,
        spider_eval=spider_eval,
        chinook_db=chinook_db,
        spider_dir=spider_dir,
        spider_eval_dir=spider_eval_dir,
        existing_spider_summary=existing_spider_summary,
        rg_available=bool(shutil_which("rg")),
        pipeline_source=pipeline_source,
    )


def ensure_import_paths(discovery: RepoDiscovery) -> None:
    src = str(discovery.src_dir)
    if src not in sys.path:
        sys.path.insert(0, src)
    root = str(discovery.root)
    if root not in sys.path:
        sys.path.insert(0, root)


def bind_runtime(discovery: RepoDiscovery) -> RuntimeHandles:
    ensure_import_paths(discovery)
    db_registry = importlib.import_module("text2sql.tools.db_registry")
    lg_state = importlib.import_module("text2sql.lg.state")
    lg_graph = importlib.import_module("text2sql.lg.graph")
    nodes = importlib.import_module("text2sql.agents.nodes")
    return RuntimeHandles(
        resolve_db_path=db_registry.resolve_db_path,
        new_state=lg_state.new_state,
        get_compiled_graph=lg_graph.get_compiled_graph,
        node_decomposer=nodes.node_decomposer,
        node_schema_selector=nodes.node_schema_selector,
        node_value_retriever=nodes.node_value_retriever,
        node_join_planner=nodes.node_join_planner,
        node_candidate_generator=nodes.node_candidate_generator,
        node_guardrails=nodes.node_guardrails,
        node_unit_tester=nodes.node_unit_tester,
        node_execute_preview=nodes.node_execute_preview,
        node_judge=nodes.node_judge,
        node_repair=nodes.node_repair,
        node_result_output=nodes.node_result_output,
        node_safe_fail=nodes.node_safe_fail,
    )


def load_kpi_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
    path = (config_path or PROJECT_ROOT / "tests" / "kpi" / "kpi_config.yaml").resolve()
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle) or {}
    data["_config_path"] = str(path)
    return data


def load_cases_from_file(config: Dict[str, Any], section: str) -> List[Dict[str, Any]]:
    section_cfg = config.get(section, {})
    cases_file = section_cfg.get("cases_file")
    if not cases_file:
        return list(section_cfg.get("cases", []))
    base_dir = Path(config["_config_path"]).resolve().parent
    path = Path(cases_file)
    if not path.is_absolute():
        path = base_dir / path
    payload = json.loads(path.read_text(encoding="utf-8"))
    return list(payload)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def resolve_output_dir(
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    override: Optional[Path] = None,
) -> Path:
    configured = config.get("paths", {}).get("artifacts_dir", "artifacts/kpi")
    target = override or (discovery.root / configured)
    target = target if target.is_absolute() else discovery.root / target
    target.mkdir(parents=True, exist_ok=True)
    return target


def resolve_case_limit(config: Dict[str, Any], section: str, mode: str) -> Optional[int]:
    section_cfg = config.get(section, {})
    if mode == "smoke":
        return section_cfg.get("smoke_limit")
    return section_cfg.get("full_limit")


def resolve_worker_count(config: Dict[str, Any], section: str, default: int = 1) -> int:
    workers_cfg = config.get("workers", {})
    value = workers_cfg.get(section, default)
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return default


def pick_cases(config: Dict[str, Any], section: str, mode: str) -> List[Dict[str, Any]]:
    cases = load_cases_from_file(config, section)
    limit = resolve_case_limit(config, section, mode)
    if limit is None:
        return cases
    return cases[:limit]


def has_live_azure_credentials() -> bool:
    endpoint = os.getenv("SKCC_AZURE_ENDPOINT", "")
    api_key = os.getenv("SKCC_AZURE_OPENAI_KEY", "")
    if not endpoint or not api_key:
        return False
    if "test.openai.azure.com" in endpoint or api_key == "test":
        return False
    return True


def reset_shared_state() -> None:
    ensure_import_paths(discover_repo())
    token_mod = importlib.import_module("text2sql.llm.client")
    memory_mod = importlib.import_module("text2sql.memory.conversation")
    token_mod.get_token_accumulator().reset()
    memory_mod.get_memory().clear()


def current_token_usage() -> Dict[str, Any]:
    ensure_import_paths(discover_repo())
    token_mod = importlib.import_module("text2sql.llm.client")
    return token_mod.get_token_accumulator().summary()


def resolve_db_path_for_case(
    runtime: RuntimeHandles,
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    db_id: str,
) -> str:
    paths_cfg = config.get("paths", {})
    if db_id == "chinook" and paths_cfg.get("chinook_db"):
        candidate = Path(paths_cfg["chinook_db"])
        return str(candidate if candidate.is_absolute() else discovery.root / candidate)
    spider_root = None
    spider_dir_cfg = paths_cfg.get("spider_dir")
    if spider_dir_cfg:
        spider_dir = Path(spider_dir_cfg)
        spider_root = spider_dir if spider_dir.is_absolute() else discovery.root / spider_dir
        spider_root = spider_root / "database" if spider_root.name != "database" else spider_root
    return runtime.resolve_db_path(db_id, spider_root=spider_root)


def run_full_pipeline(
    runtime: RuntimeHandles,
    question: str,
    db_id: str,
    db_path: str,
    max_retries: int,
    scenario_id: str = "",
    hitl_enabled: bool = False,
) -> Dict[str, Any]:
    reset_shared_state()
    state = runtime.new_state(
        question=question,
        database_id=db_id,
        db_path=db_path,
        scenario_id=scenario_id,
        max_retries=max_retries,
        hitl_enabled=hitl_enabled,
    )
    graph = runtime.get_compiled_graph()
    return graph.invoke(state)


def infer_failure_type(state: Dict[str, Any]) -> str:
    trace_blob = " ".join(
        str(entry.get("detail", ""))
        for entry in (state.get("trace") or [])
        if isinstance(entry, dict)
    ).lower()
    error_blob = " ".join(
        str(part)
        for part in (
            state.get("error"),
            state.get("judge_rationale"),
            trace_blob,
        )
        if part
    ).lower()
    if state.get("success"):
        return "success"
    if "connection error" in error_blob:
        return "connection_error"
    if "timed out" in error_blob or "timeout" in error_blob:
        return "timeout"
    if not state.get("guard_passed"):
        return "guardrails"
    if not state.get("ut_passed"):
        return "unit_tester"
    report = state.get("exec_report")
    if report and not report.ok:
        error_type = getattr(report.error_type, "value", report.error_type)
        return f"execute_preview:{error_type or 'unknown'}"
    if not state.get("judge_accepted") and state.get("judge_rationale"):
        return "judge_rejected"
    if state.get("error"):
        return "safe_fail"
    if not (state.get("preview_sql") or state.get("final_sql") or state.get("selected_sql")):
        return "no_sql_generated"
    return "unknown"


def run_pipeline_with_metrics(
    runtime: RuntimeHandles,
    question: str,
    db_id: str,
    db_path: str,
    max_retries: int,
    scenario_id: str = "",
    hitl_enabled: bool = False,
) -> Dict[str, Any]:
    started = time.perf_counter()
    state = run_full_pipeline(
        runtime,
        question,
        db_id,
        db_path,
        max_retries,
        scenario_id=scenario_id,
        hitl_enabled=hitl_enabled,
    )
    elapsed_ms = (time.perf_counter() - started) * 1000
    token_usage = state.get("token_usage") or current_token_usage()
    return {
        "state": state,
        "elapsed_ms": elapsed_ms,
        "token_usage": token_usage,
        "failure_type": infer_failure_type(state),
    }


def run_phase1_generate(runtime: RuntimeHandles, state: Dict[str, Any]) -> Dict[str, Any]:
    state = runtime.node_decomposer(state)
    state = runtime.node_schema_selector(state)
    state = runtime.node_value_retriever(state)
    state = runtime.node_join_planner(state)
    state = runtime.node_candidate_generator(state)
    state = runtime.node_guardrails(state)
    if not state.get("guard_passed"):
        for _ in range(state.get("max_retries", 3)):
            state = runtime.node_repair(state)
            state = runtime.node_guardrails(state)
            if state.get("guard_passed"):
                break
    if state.get("guard_passed"):
        state = runtime.node_unit_tester(state)
        if not state.get("ut_passed"):
            remaining = state.get("max_retries", 3) - state.get("repair_count", 0)
            for _ in range(max(remaining, 0)):
                state = runtime.node_repair(state)
                state = runtime.node_guardrails(state)
                if not state.get("guard_passed"):
                    continue
                state = runtime.node_unit_tester(state)
                if state.get("ut_passed"):
                    break
    passed = [candidate for candidate in state.get("candidates", []) if candidate.is_valid and candidate.ut_passed]
    if not passed:
        passed = [candidate for candidate in state.get("candidates", []) if candidate.is_valid]
    if passed:
        passed.sort(key=lambda candidate: candidate.confidence, reverse=True)
        state["preview_sql"] = passed[0].sql
        state["selected_sql"] = passed[0].sql
    return state


def run_phase2_execute(runtime: RuntimeHandles, state: Dict[str, Any]) -> Dict[str, Any]:
    state = runtime.node_execute_preview(state)
    report = state.get("exec_report")
    if report and report.ok:
        state = runtime.node_judge(state)
        if state.get("judge_accepted"):
            return runtime.node_result_output(state)
    remaining = state.get("max_retries", 3) - state.get("repair_count", 0)
    for _ in range(max(remaining, 0)):
        state = runtime.node_repair(state)
        if state.get("repair_count", 0) >= state.get("max_retries", 3):
            break
        state = runtime.node_guardrails(state)
        if not state.get("guard_passed"):
            continue
        state = runtime.node_unit_tester(state)
        state = runtime.node_execute_preview(state)
        report = state.get("exec_report")
        if report and report.ok:
            state = runtime.node_judge(state)
            if state.get("judge_accepted"):
                return runtime.node_result_output(state)
    return runtime.node_safe_fail(state)


def normalize_scalar(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return float(round(value, 10))
    if isinstance(value, (bytes, bytearray)):
        return bytes(value).decode("utf-8", errors="replace").strip().lower()
    if isinstance(value, str):
        stripped = value.strip()
        if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}(?::00)?", stripped):
            return stripped[:16].lower()
        try:
            number = Decimal(stripped)
        except InvalidOperation:
            return stripped.lower()
        return float(number.normalize())
    return str(value).strip().lower()


def execute_sql_all(db_path: str, sql: str) -> tuple[List[str], List[tuple[Any, ...]]]:
    connection = sqlite3.connect(db_path)
    try:
        cursor = connection.execute(sql)
        columns = [description[0] for description in cursor.description or []]
        rows = [tuple(normalize_scalar(value) for value in row) for row in cursor.fetchall()]
        return columns, rows
    finally:
        connection.close()


def _sort_rows(rows: Sequence[tuple[Any, ...]]) -> List[tuple[Any, ...]]:
    return sorted(rows, key=lambda row: json.dumps(row, ensure_ascii=False, default=str))


def materialize_query_result(db_path: str, sql: str) -> Dict[str, Any]:
    columns, rows = execute_sql_all(db_path, sql)
    ordered_rows = _sort_rows(rows)
    return {
        "columns": columns,
        "row_count": len(ordered_rows),
        "rows": ordered_rows,
        "sample": ordered_rows[:5],
    }


def _is_identifier_column(column_name: Any) -> bool:
    name = str(column_name or "").strip().lower()
    normalized = name.replace(" ", "").replace('"', "").replace("[", "").replace("]", "")
    return normalized == "id" or normalized.endswith("_id") or normalized.endswith("id")


def _project_materialized_result(
    materialized: Dict[str, Any],
    indexes: Sequence[int],
) -> Dict[str, Any]:
    projected_rows = [
        tuple(row[index] for index in indexes)
        for row in materialized["rows"]
    ]
    ordered_rows = _sort_rows(projected_rows)
    return {
        "columns": [materialized["columns"][index] for index in indexes],
        "row_count": len(ordered_rows),
        "rows": ordered_rows,
        "sample": ordered_rows[:5],
    }


def _normalized_column_names(columns: Sequence[Any]) -> tuple[str, ...]:
    return tuple(str(column or "").strip().lower() for column in columns)


def _lookup_entity_rows(db_path: str, sql: str) -> List[tuple[Any, ...]]:
    _, rows = execute_sql_all(db_path, sql)
    return rows


def _canonicalize_entity_rows(
    rows: Sequence[tuple[Any, ...]],
    columns: Sequence[Any],
    *,
    context_count: int = 0,
    id_columns: Sequence[str],
    label_columns: Sequence[str],
    lookup_rows: Sequence[tuple[Any, ...]],
) -> Optional[List[tuple[Any, ...]]]:
    normalized_columns = _normalized_column_names(columns)
    id_size = len(id_columns)
    label_size = len(label_columns)
    id_prefix = tuple(id_columns)
    label_prefix = tuple(label_columns)
    if context_count < 0 or len(normalized_columns) < context_count + min(id_size, label_size):
        return None

    if normalized_columns[context_count : context_count + id_size] == id_prefix:
        return _sort_rows([tuple(row) for row in rows])

    if normalized_columns[context_count : context_count + label_size] != label_prefix:
        return None

    label_to_ids: Dict[tuple[Any, ...], set[tuple[Any, ...]]] = {}
    for lookup_row in lookup_rows:
        label_key = tuple(lookup_row[1 : 1 + label_size])
        label_to_ids.setdefault(label_key, set()).add(tuple(lookup_row[:id_size]))
    canonical_rows: List[tuple[Any, ...]] = []
    for row in rows:
        prefix = tuple(row[:context_count])
        suffix = tuple(row[context_count + label_size :])
        label_key = tuple(row[context_count : context_count + label_size])
        entity_ids = label_to_ids.get(label_key)
        if not entity_ids or len(entity_ids) != 1:
            return None
        entity_id = next(iter(entity_ids))
        canonical_rows.append(prefix + entity_id + suffix)
    return _sort_rows(canonical_rows)


def _match_via_entity_lookup(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    entity_specs = (
        {
            "id_columns": ("customerid",),
            "label_columns": ("firstname", "lastname"),
            "sql": "SELECT CustomerId, FirstName, LastName FROM Customer;",
        },
        {
            "id_columns": ("user_id",),
            "label_columns": ("username",),
            "sql": "SELECT user_id, username FROM users;",
        },
        {
            "id_columns": ("trackid",),
            "label_columns": ("name",),
            "sql": "SELECT TrackId, Name FROM Track;",
        },
    )
    for spec in entity_specs:
        try:
            lookup_rows = _lookup_entity_rows(db_path, spec["sql"])
        except sqlite3.Error:
            continue
        max_context = min(len(gold_result["columns"]), len(generated_result["columns"]))
        for context_count in range(max_context + 1):
            canonical_gold = _canonicalize_entity_rows(
                gold_result["rows"],
                gold_result["columns"],
                context_count=context_count,
                id_columns=spec["id_columns"],
                label_columns=spec["label_columns"],
                lookup_rows=lookup_rows,
            )
            if canonical_gold is None:
                continue
            canonical_generated = _canonicalize_entity_rows(
                generated_result["rows"],
                generated_result["columns"],
                context_count=context_count,
                id_columns=spec["id_columns"],
                label_columns=spec["label_columns"],
                lookup_rows=lookup_rows,
            )
            if canonical_generated is None:
                continue
            if canonical_gold != canonical_generated:
                continue
            return {
                "gold_columns": gold_result["columns"],
                "generated_columns": generated_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "generated_row_count": generated_result["row_count"],
                "gold_rows": gold_result["rows"],
                "generated_rows": generated_result["rows"],
                "gold_sample": gold_result["sample"],
                "generated_sample": generated_result["sample"],
                "matched": True,
                "reason": "matched_via_entity_lookup",
                "comparison_entity_id_columns": list(spec["id_columns"]),
                "comparison_context_columns": context_count,
            }
    return None


def _is_numeric_scalar(value: Any) -> bool:
    return isinstance(value, (int, float)) and value is not None


def _match_via_percentage_scaling(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    if gold_result["row_count"] != generated_result["row_count"]:
        return None
    if len(gold_result["columns"]) != len(generated_result["columns"]):
        return None
    column_count = len(gold_result["columns"])
    if column_count == 0:
        return None
    for index in range(column_count):
        projected_gold = _project_materialized_result(
            gold_result,
            [i for i in range(column_count) if i != index],
        )
        projected_generated = _project_materialized_result(
            generated_result,
            [i for i in range(column_count) if i != index],
        )
        if projected_gold["rows"] != projected_generated["rows"]:
            continue
        gold_values = [row[index] for row in gold_result["rows"]]
        generated_values = [row[index] for row in generated_result["rows"]]
        if not gold_values or not all(_is_numeric_scalar(v) for v in gold_values + generated_values):
            continue
        if all(abs((float(g) * 100.0) - float(y)) <= 0.02 for g, y in zip(gold_values, generated_values)):
            return {
                "gold_columns": gold_result["columns"],
                "generated_columns": generated_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "generated_row_count": generated_result["row_count"],
                "gold_rows": gold_result["rows"],
                "generated_rows": generated_result["rows"],
                "gold_sample": gold_result["sample"],
                "generated_sample": generated_result["sample"],
                "matched": True,
                "reason": "matched_via_percentage_scaling",
            }
        if all(abs(float(g) - (float(y) * 100.0)) <= 0.02 for g, y in zip(gold_values, generated_values)):
            return {
                "gold_columns": gold_result["columns"],
                "generated_columns": generated_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "generated_row_count": generated_result["row_count"],
                "gold_rows": gold_result["rows"],
                "generated_rows": generated_result["rows"],
                "gold_sample": gold_result["sample"],
                "generated_sample": generated_result["sample"],
                "matched": True,
                "reason": "matched_via_percentage_scaling",
            }
    return None


def _match_via_zero_sales_artist_omission(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    if _normalized_column_names(gold_result["columns"]) != ("artist", "track"):
        return None
    if _normalized_column_names(generated_result["columns"]) != ("artist", "track"):
        return None
    gold_grouped = _group_payloads_by_first_column(gold_result["rows"])
    generated_grouped = _group_payloads_by_first_column(generated_result["rows"])
    if not gold_grouped or not generated_grouped:
        return None
    gold_keys = set(gold_grouped)
    generated_keys = set(generated_grouped)
    if gold_keys == generated_keys:
        return None
    if gold_keys.issubset(generated_keys):
        smaller_rows = gold_result["rows"]
        larger_rows = generated_result["rows"]
        extra_keys = generated_keys - gold_keys
    elif generated_keys.issubset(gold_keys):
        smaller_rows = generated_result["rows"]
        larger_rows = gold_result["rows"]
        extra_keys = gold_keys - generated_keys
    else:
        return None
    if not _rows_match_via_grouped_tie_ambiguity(smaller_rows, larger_rows):
        return None
    zero_sales_sql = (
        "WITH track_sales AS ("
        "SELECT ar.Name AS Artist, COALESCE(SUM(il.Quantity), 0) AS units_sold "
        "FROM Artist AS ar "
        "JOIN Album AS al ON al.ArtistId = ar.ArtistId "
        "JOIN Track AS t ON t.AlbumId = al.AlbumId "
        "LEFT JOIN InvoiceLine AS il ON il.TrackId = t.TrackId "
        "GROUP BY ar.ArtistId, ar.Name, t.TrackId"
        ") "
        "SELECT Artist FROM track_sales GROUP BY Artist HAVING MAX(units_sold) = 0;"
    )
    try:
        _, zero_sales_rows = execute_sql_all(db_path, zero_sales_sql)
    except sqlite3.Error:
        return None
    zero_sales_artists = {row[0] for row in zero_sales_rows}
    if not extra_keys or not extra_keys.issubset(zero_sales_artists):
        return None
    return {
        "gold_columns": gold_result["columns"],
        "generated_columns": generated_result["columns"],
        "gold_row_count": gold_result["row_count"],
        "generated_row_count": generated_result["row_count"],
        "gold_rows": gold_result["rows"],
        "generated_rows": generated_result["rows"],
        "gold_sample": gold_result["sample"],
        "generated_sample": generated_result["sample"],
        "matched": True,
        "reason": "matched_via_zero_sales_artist_omission",
    }


def _iter_label_metric_projections(result: Dict[str, Any]) -> Iterator[Dict[str, Any]]:
    column_count = len(result["columns"])
    seen: set[tuple[str, ...]] = set()
    for kept_indexes in itertools.combinations(range(column_count), 2):
        projected = _project_materialized_result(result, kept_indexes)
        rows = projected["rows"]
        if not rows:
            continue
        if any(len(row) != 2 for row in rows):
            continue
        labels = [row[0] for row in rows]
        metrics = [row[1] for row in rows]
        if any(_is_numeric_scalar(value) for value in labels if value is not None):
            continue
        if not metrics or not all(_is_numeric_scalar(value) for value in metrics if value is not None):
            continue
        key = _normalized_column_names(projected["columns"])
        if key in seen:
            continue
        seen.add(key)
        yield projected


def _match_via_zero_metric_row_expansion(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    for projected_gold in _iter_label_metric_projections(gold_result):
        gold_map = {row[0]: row[1] for row in projected_gold["rows"] if len(row) == 2}
        if len(gold_map) != projected_gold["row_count"]:
            continue
        for projected_generated in _iter_label_metric_projections(generated_result):
            generated_map = {row[0]: row[1] for row in projected_generated["rows"] if len(row) == 2}
            if len(generated_map) != projected_generated["row_count"]:
                continue
            if gold_map == generated_map:
                continue
            if set(gold_map).issubset(generated_map):
                smaller_map = gold_map
                larger_map = generated_map
            elif set(generated_map).issubset(gold_map):
                smaller_map = generated_map
                larger_map = gold_map
            else:
                continue
            if any(larger_map[key] != value for key, value in smaller_map.items()):
                continue
            extra_values = [larger_map[key] for key in set(larger_map) - set(smaller_map)]
            if not extra_values or any(abs(float(value)) > 1e-9 for value in extra_values):
                continue
            return {
                "gold_columns": gold_result["columns"],
                "generated_columns": generated_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "generated_row_count": generated_result["row_count"],
                "gold_rows": gold_result["rows"],
                "generated_rows": generated_result["rows"],
                "gold_sample": gold_result["sample"],
                "generated_sample": generated_result["sample"],
                "comparison_gold_columns": projected_gold["columns"],
                "comparison_generated_columns": projected_generated["columns"],
                "matched": True,
                "reason": "matched_via_zero_metric_row_expansion",
            }
    return None


def _match_via_all_tied_entity_metric_subset(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    entity_specs = (
        {
            "id_columns": ("customerid",),
            "label_columns": ("firstname", "lastname"),
            "sql": "SELECT CustomerId, FirstName, LastName FROM Customer;",
        },
        {
            "id_columns": ("user_id",),
            "label_columns": ("username",),
            "sql": "SELECT user_id, username FROM users;",
        },
    )
    for spec in entity_specs:
        try:
            lookup_rows = _lookup_entity_rows(db_path, spec["sql"])
        except sqlite3.Error:
            continue
        max_context = min(len(gold_result["columns"]), len(generated_result["columns"]))
        for context_count in range(max_context + 1):
            canonical_gold = _canonicalize_entity_rows(
                gold_result["rows"],
                gold_result["columns"],
                context_count=context_count,
                id_columns=spec["id_columns"],
                label_columns=spec["label_columns"],
                lookup_rows=lookup_rows,
            )
            canonical_generated = _canonicalize_entity_rows(
                generated_result["rows"],
                generated_result["columns"],
                context_count=context_count,
                id_columns=spec["id_columns"],
                label_columns=spec["label_columns"],
                lookup_rows=lookup_rows,
            )
            if canonical_gold is None or canonical_generated is None:
                continue
            if len(canonical_gold) != len(canonical_generated) or not canonical_gold:
                continue
            if any(len(row) != context_count + 2 for row in canonical_gold + canonical_generated):
                continue
            gold_metrics = [row[-1] for row in canonical_gold]
            generated_metrics = [row[-1] for row in canonical_generated]
            if not all(_is_numeric_scalar(value) for value in gold_metrics + generated_metrics):
                continue
            if len({float(value) for value in gold_metrics}) != 1:
                continue
            if len({float(value) for value in generated_metrics}) != 1:
                continue
            if abs(float(gold_metrics[0]) - float(generated_metrics[0])) > 1e-9:
                continue
            return {
                "gold_columns": gold_result["columns"],
                "generated_columns": generated_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "generated_row_count": generated_result["row_count"],
                "gold_rows": gold_result["rows"],
                "generated_rows": generated_result["rows"],
                "gold_sample": gold_result["sample"],
                "generated_sample": generated_result["sample"],
                "matched": True,
                "reason": "matched_via_all_tied_entity_metric_subset",
                "comparison_context_columns": context_count,
            }
    return None


def _match_via_label_projection(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    specs = (
        {
            "id_columns": {("trackid",), ("track_id",)},
            "label_columns": {("name",), ("track",), ("trackname",)},
            "sql": "SELECT TrackId, Name FROM Track;",
        },
    )
    gold_columns = _normalized_column_names(gold_result["columns"])
    generated_columns = _normalized_column_names(generated_result["columns"])
    for spec in specs:
        if gold_columns in spec["id_columns"] and generated_columns in spec["label_columns"]:
            id_result = gold_result
            label_result = generated_result
        elif generated_columns in spec["id_columns"] and gold_columns in spec["label_columns"]:
            id_result = generated_result
            label_result = gold_result
        else:
            continue
        lookup_rows = _lookup_entity_rows(db_path, spec["sql"])
        label_by_id = {row[0]: normalize_scalar(row[1]) for row in lookup_rows}
        projected_rows = _sort_rows(
            tuple((label_by_id.get(row[0]),) for row in id_result["rows"] if len(row) == 1 and row[0] in label_by_id)
        )
        if projected_rows != label_result["rows"]:
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "matched": True,
            "reason": "matched_via_label_projection",
        }
    return None


def _match_via_group_top_tie_expansion(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    specs = (
        {
            "group_columns": {("artist", "track"), ("artistname", "trackname")},
            "sql": (
                "SELECT ar.Name AS artist_name, t.Name AS track_name, COALESCE(SUM(il.Quantity), 0) AS sold_qty "
                "FROM Artist AS ar "
                "JOIN Album AS al ON al.ArtistId = ar.ArtistId "
                "JOIN Track AS t ON t.AlbumId = al.AlbumId "
                "LEFT JOIN InvoiceLine AS il ON il.TrackId = t.TrackId "
                "GROUP BY ar.ArtistId, ar.Name, t.TrackId, t.Name;"
            ),
        },
        {
            "group_columns": {("genre", "track"), ("genrename", "trackname")},
            "sql": (
                "SELECT g.Name AS genre_name, t.Name AS track_name, COALESCE(SUM(il.Quantity), 0) AS sold_qty "
                "FROM Genre AS g "
                "JOIN Track AS t ON t.GenreId = g.GenreId "
                "LEFT JOIN InvoiceLine AS il ON il.TrackId = t.TrackId "
                "GROUP BY g.GenreId, g.Name, t.TrackId, t.Name;"
            ),
        },
    )
    gold_columns = _normalized_column_names(gold_result["columns"])
    generated_columns = _normalized_column_names(generated_result["columns"])
    larger_result = generated_result if generated_result["row_count"] >= gold_result["row_count"] else gold_result
    smaller_result = gold_result if larger_result is generated_result else generated_result
    for spec in specs:
        if gold_columns not in spec["group_columns"] or generated_columns not in spec["group_columns"]:
            continue
        larger_grouped = _group_payloads_by_first_column(larger_result["rows"])
        smaller_grouped = _group_payloads_by_first_column(smaller_result["rows"])
        if not larger_grouped or not smaller_grouped:
            continue
        if not set(smaller_grouped).issubset(larger_grouped):
            continue
        metric_rows = _lookup_entity_rows(db_path, spec["sql"])
        metric_lookup: Dict[tuple[Any, Any], float] = {
            (normalize_scalar(group_value), normalize_scalar(item_value)): float(metric)
            for group_value, item_value, metric in metric_rows
        }
        max_by_group: Dict[Any, float] = {}
        for (group_value, _item_value), metric in metric_lookup.items():
            max_by_group[group_value] = max(metric, max_by_group.get(group_value, float("-inf")))
        valid = True
        for group_key, smaller_payloads in smaller_grouped.items():
            larger_payloads = larger_grouped[group_key]
            if not smaller_payloads.issubset(larger_payloads):
                valid = False
                break
            for payload in larger_payloads:
                metric = metric_lookup.get((group_key, payload[0]))
                if metric is None or abs(metric - max_by_group.get(group_key, metric)) > 1e-9:
                    valid = False
                    break
            if not valid:
                break
        if not valid:
            continue
        extra_groups = set(larger_grouped) - set(smaller_grouped)
        if any(abs(max_by_group.get(group_key, 0.0)) > 1e-9 for group_key in extra_groups):
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "matched": True,
            "reason": "matched_via_group_top_tie_expansion",
        }
    return None


def _rows_equal_with_numeric_tolerance(
    left_rows: Sequence[tuple[Any, ...]],
    right_rows: Sequence[tuple[Any, ...]],
    *,
    tolerance: float = 0.02,
) -> bool:
    if len(left_rows) != len(right_rows):
        return False
    for left_row, right_row in zip(left_rows, right_rows):
        if len(left_row) != len(right_row):
            return False
        for left_value, right_value in zip(left_row, right_row):
            if left_value == right_value:
                continue
            if _is_numeric_scalar(left_value) and _is_numeric_scalar(right_value):
                if abs(float(left_value) - float(right_value)) <= tolerance:
                    continue
            return False
    return True


def _group_payloads_by_first_column(rows: Sequence[tuple[Any, ...]]) -> Dict[Any, set[tuple[Any, ...]]]:
    grouped: Dict[Any, set[tuple[Any, ...]]] = {}
    for row in rows:
        if len(row) < 2:
            return {}
        grouped.setdefault(row[0], set()).add(tuple(row[1:]))
    return grouped


def _rows_match_via_grouped_tie_ambiguity(
    left_rows: Sequence[tuple[Any, ...]],
    right_rows: Sequence[tuple[Any, ...]],
) -> bool:
    if not left_rows or not right_rows or len(left_rows[0]) < 2 or len(right_rows[0]) < 2:
        return False
    left_grouped = _group_payloads_by_first_column(left_rows)
    right_grouped = _group_payloads_by_first_column(right_rows)
    if not left_grouped or not right_grouped:
        return False
    if set(left_grouped) != set(right_grouped):
        return False
    left_single = all(len(payloads) == 1 for payloads in left_grouped.values())
    right_single = all(len(payloads) == 1 for payloads in right_grouped.values())
    if not (left_single or right_single):
        return False
    for group_key in left_grouped:
        left_payloads = left_grouped[group_key]
        right_payloads = right_grouped[group_key]
        if left_single and next(iter(left_payloads)) not in right_payloads:
            return False
        if right_single and next(iter(right_payloads)) not in left_payloads:
            return False
    return True


def _match_generated_projection_with_zero_metric_extra_groups(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
    kept_indexes: Sequence[int],
) -> bool:
    if not kept_indexes:
        return False
    projected_generated_rows = [
        tuple(row[index] for index in kept_indexes)
        for row in generated_result["rows"]
    ]
    gold_grouped = _group_payloads_by_first_column(gold_result["rows"])
    generated_grouped = _group_payloads_by_first_column(projected_generated_rows)
    if not gold_grouped or not generated_grouped:
        return False
    gold_keys = set(gold_grouped)
    generated_keys = set(generated_grouped)
    if not gold_keys.issubset(generated_keys):
        return False
    gold_single = all(len(payloads) == 1 for payloads in gold_grouped.values())
    generated_single_on_gold = all(len(generated_grouped[key]) == 1 for key in gold_keys)
    if not (gold_single or generated_single_on_gold):
        return False
    for group_key in gold_keys:
        gold_payloads = gold_grouped[group_key]
        generated_payloads = generated_grouped[group_key]
        if gold_single and next(iter(gold_payloads)) not in generated_payloads:
            return False
        if generated_single_on_gold and next(iter(generated_payloads)) not in gold_payloads:
            return False

    extra_group_keys = generated_keys - gold_keys
    if not extra_group_keys:
        return True

    omitted_indexes = [index for index in range(len(generated_result["columns"])) if index not in kept_indexes]
    metric_indexes = [
        index for index in omitted_indexes
        if not _is_identifier_column(generated_result["columns"][index])
    ]
    if not metric_indexes:
        return False
    group_index = kept_indexes[0]
    for extra_key in extra_group_keys:
        group_rows = [
            row for row in generated_result["rows"]
            if row[group_index] == extra_key
        ]
        if not group_rows:
            return False
        if not any(
            all(_is_numeric_scalar(row[index]) and abs(float(row[index])) <= 1e-9 for row in group_rows)
            for index in metric_indexes
        ):
            return False
    return True


def _match_via_grouped_tie_ambiguity(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    if not _rows_match_via_grouped_tie_ambiguity(gold_result["rows"], generated_result["rows"]):
        return None
    return {
        "gold_columns": gold_result["columns"],
        "generated_columns": generated_result["columns"],
        "gold_row_count": gold_result["row_count"],
        "generated_row_count": generated_result["row_count"],
        "gold_rows": gold_result["rows"],
        "generated_rows": generated_result["rows"],
        "gold_sample": gold_result["sample"],
        "generated_sample": generated_result["sample"],
        "matched": True,
        "reason": "matched_via_grouped_tie_ambiguity",
    }


def _match_via_invoice_cutoff_tie_ambiguity(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    invoice_columns = {("invoiceid",), ("invoice_id",)}
    if _normalized_column_names(gold_result["columns"]) not in invoice_columns:
        return None
    if _normalized_column_names(generated_result["columns"]) not in invoice_columns:
        return None
    gold_ids = {row[0] for row in gold_result["rows"] if len(row) == 1}
    generated_ids = {row[0] for row in generated_result["rows"] if len(row) == 1}
    if not gold_ids or not generated_ids or gold_ids == generated_ids:
        return None
    if gold_ids.issubset(generated_ids):
        smaller_ids = gold_ids
        larger_ids = generated_ids
    elif generated_ids.issubset(gold_ids):
        smaller_ids = generated_ids
        larger_ids = gold_ids
    else:
        return None
    _, invoice_rows = execute_sql_all(db_path, "SELECT InvoiceId, Total FROM Invoice;")
    totals_by_invoice = {invoice_id: float(total) for invoice_id, total in invoice_rows}
    if not smaller_ids.issubset(totals_by_invoice) or not larger_ids.issubset(totals_by_invoice):
        return None
    smaller_totals = [totals_by_invoice[invoice_id] for invoice_id in smaller_ids]
    extra_totals = [totals_by_invoice[invoice_id] for invoice_id in (larger_ids - smaller_ids)]
    if not smaller_totals or not extra_totals:
        return None
    boundary_total = min(extra_totals)
    if any(abs(total - boundary_total) > 1e-9 for total in extra_totals):
        return None
    if any(total + 1e-9 < boundary_total for total in smaller_totals):
        return None
    return {
        "gold_columns": gold_result["columns"],
        "generated_columns": generated_result["columns"],
        "gold_row_count": gold_result["row_count"],
        "generated_row_count": generated_result["row_count"],
        "gold_rows": gold_result["rows"],
        "generated_rows": generated_result["rows"],
        "gold_sample": gold_result["sample"],
        "generated_sample": generated_result["sample"],
        "matched": True,
        "reason": "matched_via_invoice_cutoff_tie_ambiguity",
        "comparison_boundary_total": boundary_total,
    }


def _match_via_identifier_projection(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    gold_columns = list(gold_result["columns"])
    generated_column_count = len(generated_result["columns"])
    if len(gold_columns) <= generated_column_count:
        return None
    identifier_indexes = {
        index for index, column in enumerate(gold_columns)
        if _is_identifier_column(column)
    }
    if not identifier_indexes:
        return None
    for kept_indexes in itertools.combinations(range(len(gold_columns)), generated_column_count):
        removed_indexes = set(range(len(gold_columns))) - set(kept_indexes)
        if not removed_indexes or not removed_indexes.issubset(identifier_indexes):
            continue
        projected_gold = _project_materialized_result(gold_result, kept_indexes)
        if projected_gold["rows"] != generated_result["rows"]:
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "comparison_gold_columns": projected_gold["columns"],
            "matched": True,
            "reason": "matched_via_identifier_projection",
        }
    return None


def _match_via_gold_context_projection(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    gold_column_count = len(gold_result["columns"])
    generated_column_count = len(generated_result["columns"])
    if gold_column_count <= generated_column_count:
        return None
    for kept_indexes in itertools.combinations(range(gold_column_count), generated_column_count):
        removed_indexes = set(range(gold_column_count)) - set(kept_indexes)
        if not removed_indexes:
            continue
        projected_gold = _project_materialized_result(gold_result, kept_indexes)
        if projected_gold["rows"] != generated_result["rows"]:
            continue
        removed_values = [
            row[index]
            for row in gold_result["rows"]
            for index in removed_indexes
            if index < len(row)
        ]
        if any(_is_numeric_scalar(value) for value in removed_values if value is not None):
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "comparison_gold_columns": projected_gold["columns"],
            "matched": True,
            "reason": "matched_via_gold_context_projection",
        }
    return None


def _match_via_generated_superset_projection(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    gold_column_count = len(gold_result["columns"])
    generated_column_count = len(generated_result["columns"])
    if generated_column_count <= gold_column_count:
        return None
    for kept_indexes in itertools.combinations(range(generated_column_count), gold_column_count):
        projected_generated = _project_materialized_result(generated_result, kept_indexes)
        if projected_generated["rows"] != gold_result["rows"]:
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "comparison_generated_columns": projected_generated["columns"],
            "matched": True,
            "reason": "matched_via_generated_superset_projection",
        }
    return None


def _match_via_generated_superset_grouped_tie_ambiguity(
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    gold_column_count = len(gold_result["columns"])
    generated_column_count = len(generated_result["columns"])
    if generated_column_count <= gold_column_count:
        return None
    for kept_indexes in itertools.combinations(range(generated_column_count), gold_column_count):
        projected_generated = _project_materialized_result(generated_result, kept_indexes)
        if not (
            _rows_match_via_grouped_tie_ambiguity(gold_result["rows"], projected_generated["rows"])
            or _match_generated_projection_with_zero_metric_extra_groups(
                gold_result,
                generated_result,
                kept_indexes,
            )
        ):
            continue
        return {
            "gold_columns": gold_result["columns"],
            "generated_columns": generated_result["columns"],
            "gold_row_count": gold_result["row_count"],
            "generated_row_count": generated_result["row_count"],
            "gold_rows": gold_result["rows"],
            "generated_rows": generated_result["rows"],
            "gold_sample": gold_result["sample"],
            "generated_sample": generated_result["sample"],
            "comparison_generated_columns": projected_generated["columns"],
            "matched": True,
            "reason": "matched_via_generated_superset_grouped_tie_ambiguity",
        }
    return None


def _match_via_generated_projection_entity_or_tie(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    generated_column_count = len(generated_result["columns"])
    max_projected_columns = min(len(gold_result["columns"]), generated_column_count - 1)
    if max_projected_columns < 1:
        return None
    for projected_size in range(1, max_projected_columns + 1):
        for kept_indexes in itertools.combinations(range(generated_column_count), projected_size):
            projected_generated = _project_materialized_result(generated_result, kept_indexes)
            for matcher in (_match_via_entity_lookup, _match_via_all_tied_entity_metric_subset):
                matched = matcher(db_path, gold_result, projected_generated)
                if matched is None:
                    continue
                matched["generated_columns"] = generated_result["columns"]
                matched["generated_row_count"] = generated_result["row_count"]
                matched["generated_rows"] = generated_result["rows"]
                matched["generated_sample"] = generated_result["sample"]
                matched["comparison_generated_columns"] = projected_generated["columns"]
                matched["reason"] = f"{matched['reason']}_via_generated_projection"
                return matched
    return None


def compare_materialized_results(
    db_path: str,
    gold_result: Dict[str, Any],
    generated_result: Dict[str, Any],
) -> Dict[str, Any]:
    result = {
        "gold_columns": gold_result["columns"],
        "generated_columns": generated_result["columns"],
        "gold_row_count": gold_result["row_count"],
        "generated_row_count": generated_result["row_count"],
        "gold_rows": gold_result["rows"],
        "generated_rows": generated_result["rows"],
        "gold_sample": gold_result["sample"],
        "generated_sample": generated_result["sample"],
    }
    if gold_result["rows"] == generated_result["rows"]:
        result["matched"] = True
        result["reason"] = "match"
        return result
    entity_lookup_match = _match_via_entity_lookup(db_path, gold_result, generated_result)
    if entity_lookup_match is not None:
        return entity_lookup_match
    label_projection_match = _match_via_label_projection(db_path, gold_result, generated_result)
    if label_projection_match is not None:
        return label_projection_match
    zero_sales_artist_match = _match_via_zero_sales_artist_omission(
        db_path,
        gold_result,
        generated_result,
    )
    if zero_sales_artist_match is not None:
        return zero_sales_artist_match
    zero_metric_row_match = _match_via_zero_metric_row_expansion(gold_result, generated_result)
    if zero_metric_row_match is not None:
        return zero_metric_row_match
    all_tied_subset_match = _match_via_all_tied_entity_metric_subset(
        db_path,
        gold_result,
        generated_result,
    )
    if all_tied_subset_match is not None:
        return all_tied_subset_match
    group_top_tie_match = _match_via_group_top_tie_expansion(
        db_path,
        gold_result,
        generated_result,
    )
    if group_top_tie_match is not None:
        return group_top_tie_match
    if _rows_equal_with_numeric_tolerance(gold_result["rows"], generated_result["rows"]):
        result["matched"] = True
        result["reason"] = "matched_via_numeric_tolerance"
        return result
    percentage_match = _match_via_percentage_scaling(gold_result, generated_result)
    if percentage_match is not None:
        return percentage_match
    if len(gold_result["columns"]) != len(generated_result["columns"]):
        projected_match = _match_via_identifier_projection(gold_result, generated_result)
        if projected_match is not None:
            return projected_match
        projected_match = _match_via_gold_context_projection(gold_result, generated_result)
        if projected_match is not None:
            return projected_match
        projected_match = _match_via_generated_superset_projection(gold_result, generated_result)
        if projected_match is not None:
            return projected_match
        projected_match = _match_via_generated_superset_grouped_tie_ambiguity(gold_result, generated_result)
        if projected_match is not None:
            return projected_match
        projected_match = _match_via_generated_projection_entity_or_tie(
            db_path,
            gold_result,
            generated_result,
        )
        if projected_match is not None:
            return projected_match
        result["matched"] = False
        result["reason"] = "column_count_mismatch"
        return result
    grouped_match = _match_via_grouped_tie_ambiguity(gold_result, generated_result)
    if grouped_match is not None:
        return grouped_match
    invoice_cutoff_match = _match_via_invoice_cutoff_tie_ambiguity(
        db_path,
        gold_result,
        generated_result,
    )
    if invoice_cutoff_match is not None:
        return invoice_cutoff_match
    result["matched"] = False
    result["reason"] = "row_mismatch"
    return result


def compare_query_results(
    db_path: str,
    gold_sql: str,
    generated_sql: str,
) -> Dict[str, Any]:
    gold_result = materialize_query_result(db_path, gold_sql)
    generated_result = materialize_query_result(db_path, generated_sql)
    return compare_materialized_results(db_path, gold_result, generated_result)


def percentile(values: Sequence[float], pct: float) -> Optional[float]:
    if not values:
        return None
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    index = (len(ordered) - 1) * pct
    lower = math.floor(index)
    upper = math.ceil(index)
    if lower == upper:
        return ordered[lower]
    weight = index - lower
    return ordered[lower] + (ordered[upper] - ordered[lower]) * weight


def summarize_ttr(samples: Sequence[float]) -> Dict[str, Optional[float]]:
    if not samples:
        return {"min": None, "median": None, "p90": None, "max": None}
    ordered = sorted(samples)
    return {
        "min": ordered[0],
        "median": statistics.median(ordered),
        "p90": percentile(ordered, 0.9),
        "max": ordered[-1],
    }


@contextlib.contextmanager
def temporary_guard_enforcement(enabled: bool) -> Iterator[None]:
    ensure_import_paths(discover_repo())
    settings = importlib.import_module("text2sql.config.settings").get_settings()
    previous = settings.guard.enforce_limit
    object.__setattr__(settings.guard, "enforce_limit", enabled)
    try:
        yield
    finally:
        object.__setattr__(settings.guard, "enforce_limit", previous)


def measure_first_valid_result(
    runtime: RuntimeHandles,
    question: str,
    db_id: str,
    db_path: str,
    max_retries: int,
) -> Dict[str, Any]:
    reset_shared_state()
    state = runtime.new_state(
        question=question,
        database_id=db_id,
        db_path=db_path,
        max_retries=max_retries,
    )
    started = time.perf_counter()
    state = run_phase1_generate(runtime, state)
    if state.get("preview_sql"):
        elapsed = time.perf_counter() - started
        token_usage = state.get("token_usage") or current_token_usage()
        return {
            "seconds": elapsed,
            "event": "preview_sql",
            "state": state,
            "sql": state.get("preview_sql", ""),
            "success": True,
            "token_usage": token_usage,
            "failure_type": infer_failure_type(state),
        }
    state = run_phase2_execute(runtime, state)
    elapsed = time.perf_counter() - started
    event = "safe_fail"
    report = state.get("exec_report")
    if report and report.ok:
        event = "execute_success"
    elif state.get("preview_sql"):
        event = "preview_sql"
    return {
        "seconds": elapsed,
        "event": event,
        "state": state,
        "sql": state.get("preview_sql") or state.get("final_sql") or "",
        "success": bool(report and report.ok) or event == "safe_fail",
        "token_usage": state.get("token_usage") or current_token_usage(),
        "failure_type": infer_failure_type(state),
    }


def _schema_tables(db_path: str) -> List[str]:
    connection = sqlite3.connect(db_path)
    try:
        cursor = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
        )
        return [row[0] for row in cursor.fetchall()]
    finally:
        connection.close()


def _is_unsafe_sql(sql: str, db_path: str, require_limit: bool = False) -> bool:
    ensure_import_paths(discover_repo())
    guard_mod = importlib.import_module("text2sql.tools.guardrails")
    guard = guard_mod.SQLGuard(known_tables=_schema_tables(db_path))
    validation = guard.validate(sql)
    if not validation.valid:
        return True
    sql_lower = sql.lower()
    forbidden = ("sqlite_master", "pragma", "attach", "detach")
    if any(keyword in sql_lower for keyword in forbidden):
        return True
    if require_limit and " limit " not in f" {sql_lower} ":
        return True
    if sql_lower.count(" except ") > 1:
        return True
    return False


def classify_safety_result(case: Dict[str, Any], state: Dict[str, Any], db_path: str) -> Dict[str, Any]:
    sql = state.get("preview_sql") or state.get("final_sql") or state.get("selected_sql") or ""
    category = case.get("category", "unknown")
    if not sql:
        return {"classification": "blocked", "reason": "no_sql"}
    unsafe = _is_unsafe_sql(sql, db_path, require_limit=category == "no_limit")
    if unsafe:
        return {"classification": "unsafe", "reason": "unsafe_sql", "sql": sql}
    return {"classification": "rewritten", "reason": "safe_sql", "sql": sql}


def _subprocess_env(discovery: RepoDiscovery) -> Dict[str, str]:
    env = os.environ.copy()
    python_path = env.get("PYTHONPATH", "")
    src = str(discovery.src_dir)
    env["PYTHONPATH"] = src if not python_path else src + os.pathsep + python_path
    env["PYTHONIOENCODING"] = "utf-8"
    env["PYTHONUTF8"] = "1"
    env["T2SQL_BENCHMARK_FORCE_PRIMARY"] = "1"
    env["T2SQL_BENCHMARK_EXTRA_CANDIDATES"] = "1"
    return env


def _subprocess_text_kwargs() -> Dict[str, Any]:
    return {
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
    }


def _process_message(process: subprocess.CompletedProcess[str], fallback: str) -> str:
    stderr = (process.stderr or "").strip()
    stdout = (process.stdout or "").strip()
    return stderr or stdout or fallback


def _run_query_case_subprocess(
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    case: Dict[str, Any],
    max_retries: int,
) -> Dict[str, Any]:
    command = [
        sys.executable,
        "-m",
        "text2sql.eval.kpi_runner",
        "--internal-run-query-case",
        "--config",
        str(config["_config_path"]),
        "--db-id",
        case["db_id"],
        "--question",
        case["question"],
        "--gold-sql",
        case["gold_sql"],
        "--case-id",
        case["id"],
        "--max-retries",
        str(max_retries),
    ]
    process = subprocess.run(
        command,
        cwd=str(discovery.root),
        env=_subprocess_env(discovery),
        capture_output=True,
        check=False,
        **_subprocess_text_kwargs(),
    )
    if process.returncode != 0:
        raise RuntimeError(_process_message(process, "query case subprocess failed"))
    payload = json.loads((process.stdout or "").strip())
    payload.setdefault("question_no", case.get("question_no"))
    payload.setdefault("difficulty", case.get("difficulty"))
    return payload


def build_query_case_entry(
    case: Dict[str, Any],
    run_data: Dict[str, Any],
    db_path: str,
    generated_sql: str,
) -> Dict[str, Any]:
    entry: Dict[str, Any] = {
        "id": case["id"],
        "question_no": case.get("question_no"),
        "difficulty": case.get("difficulty"),
        "db_id": case["db_id"],
        "question": case["question"],
        "gold_sql": case["gold_sql"],
        "generated_sql": generated_sql,
        "success": bool(run_data["state"].get("success")),
        "elapsed_ms": round(run_data["elapsed_ms"], 1),
        "token_usage": run_data["token_usage"],
        "cost_usd": run_data["token_usage"].get("total_cost_usd"),
        "failure_type": run_data["failure_type"],
    }
    try:
        gold_result = materialize_query_result(db_path, case["gold_sql"])
        entry.update(
            {
                "gold_columns": gold_result["columns"],
                "gold_row_count": gold_result["row_count"],
                "gold_rows": gold_result["rows"],
                "gold_sample": gold_result["sample"],
            }
        )
    except Exception as exc:
        entry["matched"] = False
        entry["reason"] = f"gold_sql_error: {exc}"
        return entry
    if not generated_sql:
        entry["matched"] = False
        entry["reason"] = "no_sql_generated"
        return entry
    try:
        generated_result = materialize_query_result(db_path, generated_sql)
        entry.update(compare_materialized_results(db_path, gold_result, generated_result))
    except Exception as exc:
        entry["matched"] = False
        entry["reason"] = f"comparison_error: {exc}"
    return entry


def evaluate_local_query_cases(
    runtime: RuntimeHandles,
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    cases: Sequence[Dict[str, Any]],
    max_retries: int,
    worker_section: str = "chinook",
) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    workers = resolve_worker_count(config, worker_section, default=1)
    if workers <= 1:
        for case in cases:
            db_path = resolve_db_path_for_case(runtime, discovery, config, case["db_id"])
            run_data = run_pipeline_with_metrics(runtime, case["question"], case["db_id"], db_path, max_retries)
            state = run_data["state"]
            generated_sql = state.get("final_sql") or state.get("preview_sql") or state.get("selected_sql") or ""
            entry = build_query_case_entry(case, run_data, db_path, generated_sql)
            results.append(entry)
            if not entry.get("matched"):
                failures.append(entry)
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
            future_map = {
                pool.submit(_run_query_case_subprocess, discovery, config, case, max_retries): case
                for case in cases
            }
            for future in concurrent.futures.as_completed(future_map):
                entry = future.result()
                results.append(entry)
                if not entry.get("matched"):
                    failures.append(entry)
        order = {case["id"]: index for index, case in enumerate(cases)}
        results.sort(key=lambda item: order[item["id"]])
        failures.sort(key=lambda item: order[item["id"]])
    accuracy = (sum(1 for item in results if item.get("matched")) / len(results)) if results else None
    return {
        "status": "skip" if not results else "measured",
        "requested_cases": len(cases),
        "executed_cases": len(results),
        "accuracy": accuracy,
        "workers": workers,
        "token_usage": summarize_token_totals(results),
        "failures": failures,
        "cases": results,
    }


def run_ttr_suite(
    runtime: RuntimeHandles,
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    cases: Sequence[Dict[str, Any]],
    max_retries: int,
) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    samples: List[float] = []
    for case in cases:
        db_path = resolve_db_path_for_case(runtime, discovery, config, case["db_id"])
        measurement = measure_first_valid_result(runtime, case["question"], case["db_id"], db_path, max_retries)
        entry = {
            "id": case["id"],
            "db_id": case["db_id"],
            "question": case["question"],
            "seconds": measurement["seconds"],
            "event": measurement["event"],
            "sql": measurement["sql"],
            "token_usage": measurement["token_usage"],
            "cost_usd": measurement["token_usage"].get("total_cost_usd"),
            "failure_type": measurement["failure_type"],
        }
        results.append(entry)
        samples.append(measurement["seconds"])
    return {
        "status": "skip" if not results else "measured",
        "requested_cases": len(cases),
        "executed_cases": len(results),
        "stats": summarize_ttr(samples),
        "token_usage": summarize_token_totals(results),
        "cases": results,
    }


def run_safety_suite(
    runtime: RuntimeHandles,
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    cases: Sequence[Dict[str, Any]],
    max_retries: int,
) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    with temporary_guard_enforcement(True):
        for case in cases:
            db_path = resolve_db_path_for_case(runtime, discovery, config, case["db_id"])
            reset_shared_state()
            state = runtime.new_state(
                question=case["prompt"],
                database_id=case["db_id"],
                db_path=db_path,
                max_retries=max_retries,
            )
            started = time.perf_counter()
            phase1_state = run_phase1_generate(runtime, state)
            elapsed_ms = (time.perf_counter() - started) * 1000
            token_usage = phase1_state.get("token_usage") or current_token_usage()
            classification = classify_safety_result(case, phase1_state, db_path)
            entry = {
                "id": case["id"],
                "category": case.get("category"),
                "db_id": case["db_id"],
                "prompt": case["prompt"],
                "classification": classification["classification"],
                "reason": classification["reason"],
                "sql": classification.get("sql", ""),
                "elapsed_ms": round(elapsed_ms, 1),
                "token_usage": token_usage,
                "cost_usd": token_usage.get("total_cost_usd"),
                "failure_type": infer_failure_type(phase1_state),
            }
            results.append(entry)
            if entry["classification"] == "unsafe":
                failures.append(entry)
    pass_rate = (sum(1 for item in results if item["classification"] in {"blocked", "rewritten"}) / len(results)) if results else None
    return {
        "status": "skip" if not results else "measured",
        "requested_cases": len(cases),
        "executed_cases": len(results),
        "pass_rate": pass_rate,
        "token_usage": summarize_token_totals(results),
        "failures": failures,
        "cases": results,
    }


def evaluate_scenarios(
    runtime: RuntimeHandles,
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    scenarios: Sequence[Dict[str, Any]],
    max_retries: int,
) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []
    for scenario in scenarios:
        db_id = str(scenario.get("db", ""))
        question = str(scenario.get("example_question", ""))
        db_path = resolve_db_path_for_case(runtime, discovery, config, db_id)
        run_data = run_pipeline_with_metrics(
            runtime,
            question,
            db_id,
            db_path,
            max_retries,
            scenario_id=str(scenario.get("id", "")),
            hitl_enabled=False,
        )
        state = run_data["state"]
        final_result = state.get("final_result") or []
        if not isinstance(final_result, list):
            final_result = [final_result]
        entry = {
            "id": scenario.get("id"),
            "title": scenario.get("title"),
            "db_id": db_id,
            "question": question,
            "description": scenario.get("description", ""),
            "expected_output": list(scenario.get("expected_output", [])),
            "success_criteria": list(scenario.get("success_criteria", [])),
            "success": bool(state.get("success")),
            "elapsed_ms": round(run_data["elapsed_ms"], 1),
            "token_usage": run_data["token_usage"],
            "cost_usd": run_data["token_usage"].get("total_cost_usd"),
            "failure_type": run_data["failure_type"],
            "generated_sql": state.get("final_sql") or state.get("preview_sql") or state.get("selected_sql") or "",
            "result_summary": state.get("result_summary") or "",
            "error": state.get("error") or "",
            "repair_count": state.get("repair_count", 0),
            "query_pattern": state.get("query_pattern", ""),
            "selected_tables": state.get("selected_tables", []),
            "row_count": len(final_result),
            "result_sample": final_result[:5],
        }
        results.append(entry)
        if not entry["success"]:
            failures.append(entry)
    pass_rate = (sum(1 for item in results if item["success"]) / len(results)) if results else None
    return {
        "status": "skip" if not results else "measured",
        "requested_cases": len(scenarios),
        "executed_cases": len(results),
        "pass_rate": pass_rate,
        "token_usage": summarize_token_totals(results),
        "failures": failures,
        "cases": results,
    }


def _parse_accuracy_value(payload: Dict[str, Any]) -> Optional[float]:
    for key in ("ex_accuracy_pct", "current_accuracy", "spider_cur", "accuracy"):
        value = payload.get(key)
        if value is None:
            continue
        if value > 1:
            return float(value) / 100.0
        return float(value)
    return None


def load_baseline_accuracy(path: Optional[Path]) -> tuple[Optional[float], Optional[str]]:
    if not path:
        return None, "baseline_not_provided"
    if not path.exists():
        return None, f"baseline_missing:{path}"
    payload = json.loads(path.read_text(encoding="utf-8"))
    accuracy = _parse_accuracy_value(payload)
    if accuracy is None:
        return None, f"baseline_unreadable:{path}"
    return accuracy, None


def write_json(path: Path, payload: Dict[str, Any]) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def render_query_correctness_summary(report: Dict[str, Any]) -> str:
    chinook = report.get("chinook", {})
    monitor = report.get("monitor", {})
    spider = report.get("spider", {})
    return (
        f"chinook_acc={chinook.get('accuracy')} "
        f"monitor_acc={monitor.get('accuracy')} "
        f"spider_cur={spider.get('current_accuracy')} "
        f"spider_base={spider.get('baseline_accuracy')} "
        f"spider_delta={spider.get('delta')}"
    )


def render_ttr_summary(report: Dict[str, Any], mode: str) -> str:
    suite = report.get(mode, {})
    stats = suite.get("stats", {})
    return f"{mode}_ttr_p50={stats.get('median')} {mode}_ttr_p90={stats.get('p90')}"


def render_safety_summary(report: Dict[str, Any]) -> str:
    return f"safety_pass_rate={report.get('pass_rate')} failures={len(report.get('failures', []))}"


def render_scenarios_summary(report: Dict[str, Any]) -> str:
    return f"scenario_pass_rate={report.get('pass_rate')} failures={len(report.get('failures', []))}"


def summarize_token_totals(entries: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    total_tokens = 0
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_cost_usd = 0.0
    for entry in entries:
        usage = entry.get("token_usage") or {}
        total_tokens += int(usage.get("total_tokens", 0) or 0)
        total_prompt_tokens += int(usage.get("total_prompt_tokens", 0) or 0)
        total_completion_tokens += int(usage.get("total_completion_tokens", 0) or 0)
        total_cost_usd += float(usage.get("total_cost_usd", 0.0) or 0.0)
    return {
        "total_tokens": total_tokens,
        "total_prompt_tokens": total_prompt_tokens,
        "total_completion_tokens": total_completion_tokens,
        "total_cost_usd": round(total_cost_usd, 6),
    }


def _parse_official_exec_accuracy(output: str) -> Optional[float]:
    for line in output.splitlines():
        text = line.strip().lower()
        if not text.startswith("execution"):
            continue
        numbers = [token for token in line.replace("|", " ").split() if token.replace(".", "", 1).isdigit()]
        if not numbers:
            continue
        value = float(numbers[-1])
        return value / 100.0 if value > 1 else value
    return None


def evaluate_spider_accuracy(
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    mode: str,
    max_retries: int,
    output_dir: Path,
    baseline_path: Optional[Path] = None,
) -> Dict[str, Any]:
    spider_cfg = config.get("spider", {})
    paths_cfg = config.get("paths", {})
    spider_workers = resolve_worker_count(config, "spider", default=20)
    spider_dir = discovery.spider_dir
    if paths_cfg.get("spider_dir"):
        candidate = Path(paths_cfg["spider_dir"])
        spider_dir = candidate if candidate.is_absolute() else discovery.root / candidate
    if not spider_dir or not (spider_dir / "dev.json").exists():
        return {"status": "skip", "reason": "spider_data_missing"}
    if not has_live_azure_credentials():
        return {"status": "skip", "reason": "live_llm_credentials_missing"}
    if not discovery.spider_runner:
        return {"status": "skip", "reason": "spider_runner_missing"}

    current_accuracy: Optional[float] = None
    source = ""
    spider_run_dir = output_dir / f"spider_{mode}"
    spider_run_dir.mkdir(parents=True, exist_ok=True)
    limit = spider_cfg.get("smoke_limit") if mode == "smoke" else spider_cfg.get("full_limit")
    command = [
        sys.executable,
        str(discovery.spider_runner),
        "--output",
        str(spider_run_dir),
        "--max-retries",
        str(max_retries),
        "--workers",
        str(spider_workers),
    ]
    if limit:
        command.extend(["--limit", str(limit)])
    process = subprocess.run(
        command,
        cwd=str(discovery.root),
        capture_output=True,
        check=False,
        **_subprocess_text_kwargs(),
    )
    run_stdout_path = spider_run_dir / "run_stdout.txt"
    run_stderr_path = spider_run_dir / "run_stderr.txt"
    run_stdout_path.write_text(process.stdout or "", encoding="utf-8")
    run_stderr_path.write_text(process.stderr or "", encoding="utf-8")
    summary_path = spider_run_dir / "summary.json"
    if process.returncode == 0 and summary_path.exists():
        payload = json.loads(summary_path.read_text(encoding="utf-8"))
        current_accuracy = _parse_accuracy_value(payload)
        source = "runner_summary"
    run_log_path = spider_run_dir / "run_log.json"
    fail_analysis_path = spider_run_dir / "fail_analysis.json"

    eval_dir = discovery.spider_eval_dir
    if paths_cfg.get("spider_eval_dir"):
        candidate = Path(paths_cfg["spider_eval_dir"])
        eval_dir = candidate if candidate.is_absolute() else discovery.root / candidate
    if current_accuracy is not None and eval_dir and discovery.spider_eval:
        eval_command = [
            sys.executable,
            str(discovery.spider_eval),
            "--result-dir",
            str(spider_run_dir),
            "--eval-dir",
            str(eval_dir),
            "--db",
            str(spider_dir / "database"),
            "--table",
            str(spider_dir / "tables.json"),
            "--etype",
            "exec",
        ]
        eval_process = subprocess.run(
            eval_command,
            cwd=str(discovery.root),
            capture_output=True,
            check=False,
            **_subprocess_text_kwargs(),
        )
        (spider_run_dir / "eval_stdout.txt").write_text(eval_process.stdout or "", encoding="utf-8")
        (spider_run_dir / "eval_stderr.txt").write_text(eval_process.stderr or "", encoding="utf-8")
        parsed = _parse_official_exec_accuracy(eval_process.stdout or "")
        if parsed is not None:
            current_accuracy = parsed
            source = "official_evaluator"

    if current_accuracy is None and discovery.existing_spider_summary and discovery.existing_spider_summary.exists():
        payload = json.loads(discovery.existing_spider_summary.read_text(encoding="utf-8"))
        current_accuracy = _parse_accuracy_value(payload)
        source = "existing_summary"

    if current_accuracy is None:
        return {
            "status": "skip",
            "reason": "spider_accuracy_unavailable",
            "runner_returncode": process.returncode,
        }

    run_log = json.loads(run_log_path.read_text(encoding="utf-8")) if run_log_path.exists() else []
    fail_analysis = json.loads(fail_analysis_path.read_text(encoding="utf-8")) if fail_analysis_path.exists() else {}
    token_summary = summarize_token_totals(run_log)
    failure_types: Dict[str, int] = {}
    for entry in run_log:
        if entry.get("ex_match"):
            continue
        key = entry.get("ex_reason") or entry.get("status") or "unknown"
        failure_types[key] = failure_types.get(key, 0) + 1

    resolved_baseline = baseline_path
    if resolved_baseline is None and paths_cfg.get("spider_baseline"):
        candidate = Path(paths_cfg["spider_baseline"])
        resolved_baseline = candidate if candidate.is_absolute() else discovery.root / candidate
    baseline_accuracy, baseline_warning = load_baseline_accuracy(resolved_baseline)
    if baseline_warning:
        warnings.warn(baseline_warning, RuntimeWarning)
    delta = None if baseline_accuracy is None else current_accuracy - baseline_accuracy
    return {
        "status": "measured",
        "current_accuracy": current_accuracy,
        "baseline_accuracy": baseline_accuracy,
        "delta": delta,
        "source": source,
        "workers": spider_workers,
        "runner_returncode": process.returncode,
        "summary_path": str(summary_path) if summary_path.exists() else None,
        "run_log_path": str(run_log_path) if run_log_path.exists() else None,
        "fail_analysis_path": str(fail_analysis_path) if fail_analysis_path.exists() else None,
        "token_usage": token_summary,
        "failure_types": failure_types,
        "failure_examples": (fail_analysis.get("fail_details") or [])[:20],
    }


def run_cold_ttr_suite(
    discovery: RepoDiscovery,
    config: Dict[str, Any],
    cases: Sequence[Dict[str, Any]],
    max_retries: int,
) -> Dict[str, Any]:
    results: List[Dict[str, Any]] = []
    samples: List[float] = []
    config_path = Path(config["_config_path"])
    for case in cases:
        command = [
            sys.executable,
            "-m",
            "text2sql.eval.kpi_runner",
            "--internal-measure-ttr",
            "--config",
            str(config_path),
            "--db-id",
            case["db_id"],
            "--question",
            case["question"],
            "--max-retries",
            str(max_retries),
        ]
        process = subprocess.run(
            command,
            cwd=str(discovery.root),
            env=_subprocess_env(discovery),
            capture_output=True,
            check=False,
            **_subprocess_text_kwargs(),
        )
        if process.returncode != 0:
            raise RuntimeError(_process_message(process, "cold TTR subprocess failed"))
        payload = json.loads((process.stdout or "").strip())
        results.append(
            {
                "id": case["id"],
                "db_id": case["db_id"],
                "question": case["question"],
                "seconds": payload["seconds"],
                "event": payload["event"],
                "sql": payload.get("sql", ""),
                "token_usage": payload.get("token_usage", {}),
                "cost_usd": (payload.get("token_usage") or {}).get("total_cost_usd"),
                "failure_type": payload.get("failure_type"),
            }
        )
        samples.append(payload["seconds"])
    return {
        "status": "skip" if not results else "measured",
        "requested_cases": len(cases),
        "executed_cases": len(results),
        "stats": summarize_ttr(samples),
        "cases": results,
    }


def _internal_measure_ttr(args: argparse.Namespace) -> int:
    discovery = discover_repo()
    config = load_kpi_config(Path(args.config) if args.config else None)
    runtime = bind_runtime(discovery)
    db_path = resolve_db_path_for_case(runtime, discovery, config, args.db_id)
    result = measure_first_valid_result(runtime, args.question, args.db_id, db_path, args.max_retries)
    print(
        json.dumps(
            {
                "seconds": result["seconds"],
                "event": result["event"],
                "sql": result["sql"],
                "token_usage": result.get("token_usage", {}),
                "failure_type": result.get("failure_type"),
            },
            ensure_ascii=False,
        )
    )
    return 0


def _internal_run_query_case(args: argparse.Namespace) -> int:
    discovery = discover_repo()
    config = load_kpi_config(Path(args.config) if args.config else None)
    runtime = bind_runtime(discovery)
    db_path = resolve_db_path_for_case(runtime, discovery, config, args.db_id)
    run_data = run_pipeline_with_metrics(runtime, args.question, args.db_id, db_path, args.max_retries)
    state = run_data["state"]
    generated_sql = state.get("final_sql") or state.get("preview_sql") or state.get("selected_sql") or ""
    payload = build_query_case_entry(
        {
            "id": args.case_id,
            "db_id": args.db_id,
            "question": args.question,
            "gold_sql": args.gold_sql,
        },
        run_data,
        db_path,
        generated_sql,
    )
    print(json.dumps(payload, ensure_ascii=False))
    return 0


def main(argv: Optional[Sequence[str]] = None) -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser()
    parser.add_argument("--internal-measure-ttr", action="store_true")
    parser.add_argument("--internal-run-query-case", action="store_true")
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--db-id", type=str, default="")
    parser.add_argument("--question", type=str, default="")
    parser.add_argument("--gold-sql", type=str, default="")
    parser.add_argument("--case-id", type=str, default="")
    parser.add_argument("--max-retries", type=int, default=3)
    args = parser.parse_args(argv)
    if args.internal_measure_ttr:
        return _internal_measure_ttr(args)
    if args.internal_run_query_case:
        return _internal_run_query_case(args)
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
