"""
Spider 평가 파일 Writer
==========================================================
Spider 공식 evaluator (evaluation.py) 가 요구하는 형식:

gold 파일 (gold.txt):
    gold_sql\tdb_id          # 탭 구분, 줄 단위

pred 파일 (pred.txt):
    predicted_sql            # 줄 단위 (gold와 1:1 대응)

사용 예:
    from text2sql.eval.spider_writer import SpiderResultWriter
    w = SpiderResultWriter("artifacts/spider_runs/run_001")
    w.add("SELECT ...", "SELECT ...", "concert_singer")
    w.flush()
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import List


@dataclass
class _Row:
    gold_sql: str
    pred_sql: str
    db_id: str


class SpiderResultWriter:
    """gold / pred 파일 쌍을 생성합니다."""

    def __init__(self, output_dir: str | Path):
        self._dir = Path(output_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._rows: List[_Row] = []

    # ── 누적 ──────────────────────────────────────────────
    def add(self, gold_sql: str, pred_sql: str, db_id: str) -> None:
        """결과 1건 추가"""
        # SQL 내 줄바꿈을 공백으로 치환 (평가기 호환)
        gold = " ".join(gold_sql.strip().split())
        pred = " ".join(pred_sql.strip().split()) if pred_sql else "SELECT 1"
        self._rows.append(_Row(gold_sql=gold, pred_sql=pred, db_id=db_id))

    # ── 저장 ──────────────────────────────────────────────
    def flush(self) -> tuple[Path, Path]:
        """
        gold.txt, pred.txt 를 output_dir에 저장합니다.

        Returns:
            (gold_path, pred_path)
        """
        gold_path = self._dir / "gold.txt"
        pred_path = self._dir / "pred.txt"

        with gold_path.open("w", encoding="utf-8") as gf, \
             pred_path.open("w", encoding="utf-8") as pf:
            for r in self._rows:
                gf.write(f"{r.gold_sql}\t{r.db_id}\n")
                pf.write(f"{r.pred_sql}\n")

        return gold_path, pred_path

    @property
    def count(self) -> int:
        return len(self._rows)
