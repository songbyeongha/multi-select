from __future__ import annotations

import json
import os
import re
import sqlite3
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from text2sql.config.settings import get_settings
from text2sql.datasets.spider2_loader import (
    Spider2Example,
    discover_spider2_root,
    spider2_eval_script,
    spider2_gold_dir,
)

_PROXY_ENV_KEYS = (
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "ALL_PROXY",
    "http_proxy",
    "https_proxy",
    "all_proxy",
)


def subprocess_text_kwargs() -> Dict[str, Any]:
    return {
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
    }


def _looks_like_programmatic_token(secret: str) -> bool:
    trimmed = (secret or "").strip()
    return trimmed.startswith("eyJ") and trimmed.count(".") == 2 and len(trimmed) >= 80


def ensure_spider2_env(sqlite_root: Optional[Path], temp_root: Optional[Path] = None) -> Dict[str, str]:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    for key in _PROXY_ENV_KEYS:
        env.pop(key, None)
    no_proxy_values = [value.strip() for value in env.get("NO_PROXY", "").split(",") if value.strip()]
    for host in ("snowflakecomputing.com", ".snowflakecomputing.com"):
        if host not in no_proxy_values:
            no_proxy_values.append(host)
    if no_proxy_values:
        env["NO_PROXY"] = ",".join(no_proxy_values)
    settings = get_settings()
    if settings.spider2.root and not env.get("T2SQL_SPIDER2_ROOT"):
        env["T2SQL_SPIDER2_ROOT"] = settings.spider2.root
    if settings.spider2.dataset and not env.get("T2SQL_SPIDER2_DATASET"):
        env["T2SQL_SPIDER2_DATASET"] = settings.spider2.dataset
    if sqlite_root:
        env["T2SQL_SPIDER2_SQLITE_ROOT"] = str(sqlite_root)
    if temp_root:
        temp_root.mkdir(parents=True, exist_ok=True)
        env["TMPDIR"] = str(temp_root)
        env["TEMP"] = str(temp_root)
        env["TMP"] = str(temp_root)
    env.update(settings.snowflake.as_env())
    return env


def write_spider2_sql(result_dir: Path, example: Spider2Example, sql: str) -> Path:
    result_dir.mkdir(parents=True, exist_ok=True)
    sql_path = result_dir / f"{example.instance_id}.sql"
    text = (sql or "SELECT 1").strip()
    sql_path.write_text(text + "\n", encoding="utf-8")
    return sql_path


def sync_spider2_snow_credentials(spider2_root: Path) -> Optional[Path]:
    settings = get_settings()
    if not settings.snowflake.account or not settings.snowflake.user:
        return None
    credential_path = spider2_root / "spider2-snow" / "evaluation_suite" / "snowflake_credential.json"
    payload: Dict[str, Any] = {
        "account": settings.snowflake.account,
        "user": settings.snowflake.user,
    }
    if settings.snowflake.password:
        payload["password"] = settings.snowflake.password
    if settings.snowflake.warehouse:
        payload["warehouse"] = settings.snowflake.warehouse
    if settings.snowflake.database:
        payload["database"] = settings.snowflake.database
    if settings.snowflake.schema:
        payload["schema"] = settings.snowflake.schema
    if settings.snowflake.role:
        payload["role"] = settings.snowflake.role
    if settings.snowflake.authenticator and not _looks_like_programmatic_token(settings.snowflake.password):
        payload["authenticator"] = settings.snowflake.authenticator
    credential_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return credential_path


def materialize_sqlite_query_to_csv(db_path: Path, sql: str, output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(db_path))
    try:
        cursor = connection.execute(sql)
        columns = [description[0] for description in cursor.description or []]
        rows = cursor.fetchall()
    finally:
        connection.close()
    lines = []
    if columns:
        lines.append(",".join(_csv_escape(column) for column in columns))
    for row in rows:
        lines.append(",".join(_csv_escape(value) for value in row))
    output_path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
    return output_path


def _csv_escape(value: Any) -> str:
    text = "" if value is None else str(value)
    if any(char in text for char in [",", "\"", "\n"]):
        text = "\"" + text.replace("\"", "\"\"") + "\""
    return text


def build_spider2_eval_command(
    *,
    spider2_root: Path,
    dataset: str,
    result_dir: Path,
    mode: str,
    gold_dir: Optional[Path] = None,
    max_workers: int = 1,
    timeout: int = 180,
    python_executable: Optional[str] = None,
    temp_dir: Optional[Path] = None,
) -> list[str]:
    eval_script = spider2_eval_script(spider2_root, dataset)
    resolved_gold_dir = gold_dir or spider2_gold_dir(spider2_root, dataset)
    command = [
        python_executable or os.sys.executable,
        str(eval_script),
        "--result_dir",
        str(result_dir),
        "--gold_dir",
        str(resolved_gold_dir),
        "--mode",
        mode,
        "--max_workers",
        str(max_workers),
        "--timeout",
        str(timeout),
    ]
    if temp_dir:
        command.extend(["--temp_dir", str(temp_dir)])
    return command


def parse_spider2_eval_stdout(stdout: str) -> Dict[str, Any]:
    patterns = {
        "final": re.compile(
            r"Final score:\s*(?P<score>[0-9.]+),\s*Correct examples:\s*(?P<correct>\d+),\s*Total examples:\s*(?P<total>\d+)",
            re.IGNORECASE,
        ),
        "real": re.compile(
            r"Real score:\s*(?P<score>[0-9.]+),\s*Correct examples:\s*(?P<correct>\d+),\s*Total examples:\s*(?P<total>\d+)",
            re.IGNORECASE,
        ),
    }
    parsed: Dict[str, Any] = {}
    for key, pattern in patterns.items():
        match = pattern.search(stdout or "")
        if not match:
            continue
        parsed[f"{key}_score"] = float(match.group("score"))
        parsed[f"{key}_correct"] = int(match.group("correct"))
        parsed[f"{key}_total"] = int(match.group("total"))
    return parsed


def discover_and_validate_spider2_root(project_root: Path, override: Optional[Path]) -> Path:
    root = discover_spider2_root(project_root=project_root, override=override)
    if root is None:
        raise FileNotFoundError(
            "Spider 2.0 root not found. Clone the official Spider2 repository and pass --spider2-root."
        )
    return root


def run_spider2_evaluator(
    *,
    spider2_root: Path,
    dataset: str,
    result_dir: Path,
    mode: str,
    gold_dir: Optional[Path] = None,
    max_workers: int = 1,
    timeout: int = 180,
    cwd: Optional[Path] = None,
) -> Dict[str, Any]:
    if dataset == "snow":
        sync_spider2_snow_credentials(spider2_root)
    effective_workers = 1 if dataset == "snow" and sys.platform.startswith("win") else max_workers
    eval_script = spider2_eval_script(spider2_root, dataset)
    temp_root = result_dir / "_eval_tmp"
    temp_work_dir = temp_root / "work"
    temp_work_dir.mkdir(parents=True, exist_ok=True)
    command = build_spider2_eval_command(
        spider2_root=spider2_root,
        dataset=dataset,
        result_dir=result_dir,
        mode=mode,
        gold_dir=gold_dir,
        max_workers=effective_workers,
        timeout=timeout,
        temp_dir=temp_work_dir,
    )
    process = subprocess.run(
        command,
        cwd=str(cwd or eval_script.parent),
        env=ensure_spider2_env(sqlite_root=None, temp_root=temp_root),
        capture_output=True,
        check=False,
        **subprocess_text_kwargs(),
    )
    parsed = parse_spider2_eval_stdout(process.stdout or "")
    return {
        "command": command,
        "returncode": process.returncode,
        "stdout": process.stdout or "",
        "stderr": process.stderr or "",
        "parsed": parsed,
    }


def write_spider2_summary(path: Path, payload: Dict[str, Any]) -> Path:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path
