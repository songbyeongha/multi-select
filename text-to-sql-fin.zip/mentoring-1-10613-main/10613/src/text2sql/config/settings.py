"""Environment-backed application settings."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[3] / ".env")

_CFG_DIR = Path(__file__).parent


def _bool_env(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).lower() in ("true", "1", "yes")


@dataclass(frozen=True)
class AzureLLMCfg:
    endpoint: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT", ""))
    api_key: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY", ""))
    deployment: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_MODEL", "gpt-5"))
    api_version: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview"))
    temperature: float = 0.0
    max_tokens: int = 4096


@dataclass(frozen=True)
class AzureLLMFastCfg:
    endpoint: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT_FAST", os.getenv("SKCC_AZURE_ENDPOINT", "")))
    api_key: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY_FAST", os.getenv("SKCC_AZURE_OPENAI_KEY", "")))
    deployment: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_MODEL_FAST", os.getenv("SKCC_AZURE_MODEL", "gpt-4.1")))
    api_version: str = field(
        default_factory=lambda: os.getenv(
            "SKCC_AZURE_API_VERSION_FAST",
            os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview"),
        )
    )
    temperature: float = 0.0
    max_tokens: int = 4096


@dataclass(frozen=True)
class EmbedCfg:
    model: str = field(default_factory=lambda: os.getenv("T2SQL_EMBED_MODEL", "text-embedding-3-large"))
    deployment: str = field(
        default_factory=lambda: os.getenv(
            "T2SQL_EMBED_DEPLOYMENT",
            os.getenv("T2SQL_EMBED_MODEL", "text-embedding-3-large"),
        )
    )
    endpoint: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT", ""))
    api_key: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY", ""))
    api_version: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview"))


@dataclass(frozen=True)
class GuardrailsCfg:
    allowed_statements: tuple[str, ...] = ("SELECT",)
    max_rows: int = 50_000
    timeout_ms: int = 15_000
    forbidden_kw: tuple[str, ...] = (
        "DROP",
        "TRUNCATE",
        "ALTER",
        "GRANT",
        "REVOKE",
        "EXECUTE",
        "EXEC",
        "ATTACH",
        "DETACH",
    )
    enforce_limit: bool = field(default_factory=lambda: _bool_env("T2SQL_ENFORCE_LIMIT", "true"))


@dataclass(frozen=True)
class PipelineCfg:
    max_retries: int = field(default_factory=lambda: int(os.getenv("T2SQL_MAX_RETRIES", "3")))
    num_candidates: int = 3
    preview_limit: int = 50
    allow_empty_result: bool = field(default_factory=lambda: _bool_env("ALLOW_EMPTY_RESULT", "true"))
    execution_mode: str = field(default_factory=lambda: os.getenv("T2SQL_EXECUTION_MODE", "production"))


@dataclass(frozen=True)
class Spider2Cfg:
    root: str = field(default_factory=lambda: os.getenv("T2SQL_SPIDER2_ROOT", ""))
    dataset: str = field(default_factory=lambda: os.getenv("T2SQL_SPIDER2_DATASET", "snow"))
    result_dir: str = field(default_factory=lambda: os.getenv("T2SQL_SPIDER2_RESULT_DIR", ""))
    gold_dir: str = field(default_factory=lambda: os.getenv("T2SQL_SPIDER2_GOLD_DIR", ""))
    eval_mode: str = field(default_factory=lambda: os.getenv("T2SQL_SPIDER2_EVAL_MODE", "sql"))
    eval_max_workers: int = field(default_factory=lambda: int(os.getenv("T2SQL_SPIDER2_EVAL_MAX_WORKERS", "1")))
    eval_timeout_sec: int = field(default_factory=lambda: int(os.getenv("T2SQL_SPIDER2_EVAL_TIMEOUT_SEC", "180")))


@dataclass(frozen=True)
class SnowflakeCfg:
    account: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_ACCOUNT", ""))
    user: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_USER", ""))
    password: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_PASSWORD", ""))
    warehouse: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_WAREHOUSE", ""))
    database: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_DATABASE", ""))
    schema: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_SCHEMA", ""))
    role: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_ROLE", ""))
    authenticator: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_AUTHENTICATOR", ""))
    host: str = field(default_factory=lambda: os.getenv("T2SQL_SNOWFLAKE_HOST", ""))

    def as_env(self) -> Dict[str, str]:
        payload = {
            "T2SQL_SNOWFLAKE_ACCOUNT": self.account,
            "T2SQL_SNOWFLAKE_USER": self.user,
            "T2SQL_SNOWFLAKE_PASSWORD": self.password,
            "T2SQL_SNOWFLAKE_WAREHOUSE": self.warehouse,
            "T2SQL_SNOWFLAKE_DATABASE": self.database,
            "T2SQL_SNOWFLAKE_SCHEMA": self.schema,
            "T2SQL_SNOWFLAKE_ROLE": self.role,
            "T2SQL_SNOWFLAKE_AUTHENTICATOR": self.authenticator,
            "T2SQL_SNOWFLAKE_HOST": self.host,
            "SNOWFLAKE_ACCOUNT": self.account,
            "SNOWFLAKE_USER": self.user,
            "SNOWFLAKE_PASSWORD": self.password,
            "SNOWFLAKE_WAREHOUSE": self.warehouse,
            "SNOWFLAKE_DATABASE": self.database,
            "SNOWFLAKE_SCHEMA": self.schema,
            "SNOWFLAKE_ROLE": self.role,
            "SNOWFLAKE_AUTHENTICATOR": self.authenticator,
            "SNOWFLAKE_HOST": self.host,
        }
        return {key: value for key, value in payload.items() if value}

    def is_configured(self) -> bool:
        return bool(self.account and self.user)


@dataclass
class Settings:
    llm: AzureLLMCfg = field(default_factory=AzureLLMCfg)
    llm_fast: AzureLLMFastCfg = field(default_factory=AzureLLMFastCfg)
    embed: EmbedCfg = field(default_factory=EmbedCfg)
    guard: GuardrailsCfg = field(default_factory=GuardrailsCfg)
    pipeline: PipelineCfg = field(default_factory=PipelineCfg)
    spider2: Spider2Cfg = field(default_factory=Spider2Cfg)
    snowflake: SnowflakeCfg = field(default_factory=SnowflakeCfg)
    cfg_dir: Path = _CFG_DIR

    def is_dual_model(self) -> bool:
        return bool(os.getenv("SKCC_AZURE_MODEL_FAST", ""))

    def load_json(self, name: str) -> Dict[str, Any]:
        path = self.cfg_dir / name
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}

    def schema_metadata(self, db_id: str) -> Dict[str, Any]:
        return self.load_json("schema_metadata.json").get("databases", {}).get(db_id, {})

    def domain_hints(self, db_id: str) -> Dict[str, Any]:
        return self.load_json("domain_hints.json").get("databases", {}).get(db_id, {})

    def scenarios(self) -> List[Dict[str, Any]]:
        return self.load_json("scenarios.json").get("scenarios", [])

    def spider2_root_path(self) -> Optional[Path]:
        if not self.spider2.root:
            return None
        return Path(self.spider2.root).expanduser().resolve()


_inst: Optional[Settings] = None


def get_settings() -> Settings:
    global _inst
    if _inst is None:
        _inst = Settings()
    return _inst


def reset_settings() -> None:
    global _inst
    _inst = None
