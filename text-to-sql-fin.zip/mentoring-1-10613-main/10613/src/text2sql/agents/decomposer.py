"""
Decomposer · ValueRetriever 노드
─────────────────────────────────
1. Decomposer: 질문 의도 분석, 패턴 분류, 상대 날짜 해석
3. ValueRetriever: 추출값의 DB 실제 값 검증·보정
"""
from __future__ import annotations
import os
import sqlite3
import time as _time
from typing import Dict

from ..lg.state import GraphState
from ..llm.client import get_llm_fast
from ..llm import prompts as P
from ..tools.executor import SchemaReader
from ..tools.date_tools import get_date_tool, parse_relative_dates
from ._utils import trace, safe_json


# ═══════════════════════════════════════════════════════════════
# 1. Decomposer / QueryInterpreter
# ═══════════════════════════════════════════════════════════════
def node_decomposer(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "Decomposer", "질문 의도 분석 및 분해 시작")

    llm = get_llm_fast()  # 속도 우선: 질문 의도 분석
    db_id = state["database_id"]
    db_path = state["db_path"]

    is_snowflake = state.get("dialect") == "snowflake"

    date_tool = get_date_tool()
    current_date = date_tool.reference_date.isoformat()
    current_year = date_tool.reference_date.year
    current_month = date_tool.reference_date.month

    question = state["question"]

    relative_dates = parse_relative_dates(question)
    date_context = ""
    if relative_dates:
        date_parts = []
        for rd in relative_dates:
            date_parts.append(f"- '{rd.original_expression}' → {rd.description}")
        date_context = "\n".join(date_parts)
        trace(state, "Decomposer",
              f"상대적 시간 표현 감지됨 (기준: {current_date})",
              {"detected_dates": [rd.to_dict() for rd in relative_dates]})

    if is_snowflake:
        # Snowflake: snow_catalog에서 테이블명 추출 (SQLite SchemaReader 사용 불가)
        snow_catalog = state.get("snow_catalog") or ()
        tables = [t.full_name for t in snow_catalog[:20]]
        table_summary = ", ".join(tables) if tables else db_id
    else:
        tables = SchemaReader.tables(db_path)
        table_summary = ", ".join(tables)

    from ..memory.conversation import get_memory
    memory = get_memory()
    conversation_context = memory.get_context_string(db_id=db_id, n=3)

    enhanced_prompt = P.DECOMPOSER_USR.format(
        current_date=current_date,
        question=question,
        database_id=db_id,
        table_summary=table_summary,
    )

    if date_context:
        enhanced_prompt += (
            f"\n\n[날짜 해석 결과 - 현재 날짜 {current_date} 기준]\n"
            f"{date_context}\n"
            "위 해석을 참고하여 날짜 관련 조건을 정확히 반영하세요."
        )

    if conversation_context:
        enhanced_prompt += (
            f"\n\n{conversation_context}\n"
            "위 이전 대화를 참고하여 후속 질문의 컨텍스트를 이해하세요."
        )

    result = safe_json(llm, enhanced_prompt, system=P.DECOMPOSER_SYS,
                       node_name="Decomposer",
                       fallback={"intent": question,
                                 "query_pattern": "simple",
                                 "sub_questions": [question],
                                 "extracted_values": {},
                                 "reasoning": "파싱 실패 – 원문 그대로 사용"})

    query_pattern = result.get("query_pattern", "simple")

    extracted_values = result.get("extracted_values") or {}
    if relative_dates:
        extracted_values["resolved_dates"] = [rd.to_dict() for rd in relative_dates]

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "Decomposer",
          f"의도: {result.get('intent', '')} | 패턴: {query_pattern} (기준 날짜: {current_date})",
          {"sub_questions": result.get("sub_questions", []),
           "extracted_values": extracted_values,
           "query_pattern": query_pattern,
           "reasoning": result.get("reasoning", ""),
           "current_date": current_date,
           "relative_dates_detected": len(relative_dates) > 0,
           "elapsed_ms": _elapsed,
           "model": llm.model_label})

    from ..config.settings import get_settings
    benchmark_force_primary = os.getenv("T2SQL_BENCHMARK_FORCE_PRIMARY", "").strip().lower() in ("1", "true", "yes", "on")
    use_fast_only = (
        get_settings().is_dual_model()
        and query_pattern == "simple"
        and not benchmark_force_primary
    )

    trace(state, "Decomposer",
          f"LLM 라우팅: {'fast-only' if use_fast_only else 'dual'}",
          {"use_fast_only": use_fast_only})

    return {
        **state,
        "intent": result.get("intent", question),
        "query_pattern": query_pattern,
        "sub_questions": result.get("sub_questions", [question]),
        "extracted_values": extracted_values,
        "current_date": current_date,
        "current_year": current_year,
        "current_month": current_month,
        "use_fast_only": use_fast_only,
    }


# ═══════════════════════════════════════════════════════════════
# 3. ValueRetriever (IR)
# ═══════════════════════════════════════════════════════════════
def node_value_retriever(state: GraphState) -> GraphState:
    """추출값에서 실제 DB 값 확인 · 보정 (SchemaSelector 이후 실행)"""
    _t0 = _time.time()

    # Snowflake: SQLite DB가 없으므로 값 보정 스킵
    if state.get("dialect") == "snowflake":
        trace(state, "ValueRetriever", "Snowflake 모드 — 값 보정 스킵")
        return state

    trace(state, "ValueRetriever", "추출된 값과 DB 실제 값 매칭 시작")

    ev = state.get("extracted_values") or {}
    db_path = state["db_path"]
    filters = ev.get("filters") or {}

    corrections: Dict[str, str] = {}

    selected_tables = state.get("selected_tables", [])
    if not selected_tables:
        selected_tables = SchemaReader.tables(db_path)  # fallback

    for key, val in filters.items():
        if not isinstance(val, str) or not val:
            continue
        found = False
        for tbl in selected_tables:
            if found:
                break
            cols = SchemaReader.table_info(db_path, tbl).get("columns", [])
            for c in cols:
                cname = c["name"] if isinstance(c, dict) else c
                cname_lower = cname.lower()
                key_lower = key.lower()
                if key_lower != cname_lower and key_lower not in cname_lower.replace("_", " ").split():
                    continue
                check_sql = (f"SELECT DISTINCT [{cname}] FROM [{tbl}] "
                             f"WHERE [{cname}] LIKE ? LIMIT 5")
                conn = None
                try:
                    conn = sqlite3.connect(db_path)
                    cur = conn.execute(check_sql, (f"%{val}%",))
                    rows = cur.fetchall()
                    if rows:
                        actual = str(rows[0][0])
                        if actual.lower() != val.lower():
                            corrections[key] = actual
                        found = True
                        break
                except Exception:
                    pass
                finally:
                    if conn:
                        conn.close()

    _elapsed = round((_time.time() - _t0) * 1000)
    if corrections:
        for k, v in corrections.items():
            filters[k] = v
        ev["filters"] = filters
        trace(state, "ValueRetriever",
              f"값 보정: {corrections}",
              {"corrections": corrections, "elapsed_ms": _elapsed})
    else:
        trace(state, "ValueRetriever", "추출값 확인 완료 – 보정 없음",
              {"elapsed_ms": _elapsed})

    return {**state, "extracted_values": ev}
