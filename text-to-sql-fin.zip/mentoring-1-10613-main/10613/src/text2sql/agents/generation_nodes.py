"""Candidate generation node."""
from __future__ import annotations
import json
import os
import re
import time as _time
from typing import Dict, List, Tuple
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..lg.state import GraphState, SQLCandidate, ErrorType
from ..llm.client import get_llm
from ..llm import prompts as P
from ..memory.conversation import get_memory
from ._utils import trace, get_reference_sql

_HINTS_PATH = Path(__file__).resolve().parents[1] / "config" / "strategy_hints.json"

def _load_strategies() -> Dict[str, List[Tuple[str, str]]]:
    with open(_HINTS_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: [tuple(pair) for pair in v] for k, v in raw.items()}

_STRATEGIES = _load_strategies()


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[0-9a-z가-힣_]+", (text or "").lower()) if len(token) > 1}


def _select_few_shots(question: str, few_shots: List[Dict[str, str]], limit: int = 5) -> List[Dict[str, str]]:
    question_tokens = _tokenize(question)
    if not few_shots:
        return []
    if not question_tokens:
        return few_shots[:limit]

    def _score(item: Dict[str, str]) -> tuple[int, int, int]:
        tokens = _tokenize(item.get("question", ""))
        overlap = len(question_tokens & tokens)
        contains_exact_phrase = int(item.get("question", "") in question)
        contains_group_keyword = int(any(token in item.get("question", "") for token in ("별", "상위", "하위", "전년", "월별", "5분")))
        return (contains_exact_phrase, overlap, contains_group_keyword)

    ranked = sorted(few_shots, key=_score, reverse=True)
    return ranked[:limit]


# ═══════════════════════════════════════════════════════════════
# 5. CandidateGenerator ×N  (전략 분기)
# ═══════════════════════════════════════════════════════════════
def node_candidate_generator(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "CandidateGenerator", "SQL 후보 생성 시작")

    # Snowflake: spider2_snow_runner의 생성 로직 사용
    if state.get("dialect") == "snowflake":
        return _node_candidate_generator_snowflake(state, _t0)

    candidates: List[SQLCandidate] = []

    query_pattern = state.get("query_pattern", "simple")
    strategies = list(_STRATEGIES.get(query_pattern, _STRATEGIES["simple"]))

    if query_pattern != "set_operation":
        q_lower = state["question"].lower()
        _negation = (
            bool(re.search(r'\b(not|never|does not|did not|do not|have not|without)\b', q_lower))
            or any(kw in q_lower for kw in ['없는', '않는', '않은', '아닌', '제외', '빼고'])
        )
        _intersection = (
            bool(re.search(r'\b(both|and also)\b', q_lower))
            or any(kw in q_lower for kw in ['모두', '동시에', '이면서'])
        )
        if _negation:
            strategies.append(("except_bonus",
                "반드시 EXCEPT를 사용하세요. SELECT ... EXCEPT SELECT ... 형태로 작성. "
                "NOT IN/NOT EXISTS 사용 금지."))
        elif _intersection:
            strategies.append(("intersect_bonus",
                "반드시 INTERSECT를 사용하세요. SELECT ... INTERSECT SELECT ... 형태로 작성."))

    from ..config.settings import get_settings
    max_candidates = get_settings().pipeline.num_candidates
    benchmark_extra_candidates = os.getenv("T2SQL_BENCHMARK_EXTRA_CANDIDATES", "").strip().lower() in ("1", "true", "yes", "on")
    if query_pattern == "simple" and max_candidates > 2 and not benchmark_extra_candidates:
        max_candidates = 2
    strategies = strategies[:max_candidates]

    reference_sql = get_reference_sql(state["database_id"], query_pattern)

    from ..config.settings import get_settings as _gs
    _domain = _gs().domain_hints(state["database_id"])
    _few_shots = _domain.get("few_shot_examples", [])
    few_shot_text = ""
    if _few_shots:
        parts = []
        for fs in _select_few_shots(state["question"], _few_shots, limit=5):
            parts.append(f"-- Q: {fs['question']}\n{fs['sql']}")
        few_shot_text = "\n\n".join(parts)

    memory = get_memory()
    similar = memory.find_similar(
        state["question"], db_id=state["database_id"], threshold=0.5
    )
    if similar:
        memory_ref = (
            f"\n-- 이전 유사 질문의 성공 SQL 참고:\n"
            f"-- Q: {similar.question}\n"
            f"{similar.sql}"
        )
        reference_sql = (f"{reference_sql}\n\n{memory_ref}"
                         if reference_sql != "없음" else memory_ref)
        trace(state, "CandidateGenerator",
              f"메모리 유사 질문 발견: '{similar.question[:50]}...'")

    _use_fast = state.get("use_fast_only", False)

    def _generate_one(strategy_name: str, hint: str) -> SQLCandidate | None:
        prompt = P.COMPOSER_USR.format(
            current_date=state.get("current_date", "2024-01-01"),
            current_year=state.get("current_year", 2024),
            current_month=state.get("current_month", 1),
            question=state["question"],
            intent=state.get("intent", ""),
            strategy=f"{strategy_name}: {hint}",
            query_pattern=query_pattern,
            reference_sql=reference_sql,
            few_shot_sql=few_shot_text,
            sub_questions=json.dumps(state.get("sub_questions", []),
                                     ensure_ascii=False),
            schema_text=state["schema_text"],
            join_plan="\n".join(state.get("join_plan", [])),
            extracted_values=json.dumps(state.get("extracted_values", {}),
                                        ensure_ascii=False),
        )
        try:
            from ..llm.client import get_llm_fast as _get_fast
            _llm = _get_fast() if _use_fast else get_llm()
            res = _llm.generate_json(prompt, system=P.COMPOSER_SYS,
                                       node_name="CandidateGenerator")
            sql = res.get("sql", "")
            if sql:
                return SQLCandidate(
                    sql=sql,
                    strategy=strategy_name,
                    confidence=res.get("confidence", 0.8),
                    rationale=res.get("reasoning", ""),
                )
        except Exception:
            pass
        return None

    with ThreadPoolExecutor(max_workers=len(strategies)) as executor:
        futures = {
            executor.submit(_generate_one, name, hint): name
            for name, hint in strategies
        }
        for future in as_completed(futures):
            strategy_name = futures[future]
            try:
                candidate = future.result()
                if candidate:
                    candidates.append(candidate)
                    trace(state, "CandidateGenerator",
                          f"[{strategy_name}] SQL 생성 완료 (패턴: {query_pattern})",
                          {"sql": candidate.sql[:300],
                           "confidence": candidate.confidence})
            except Exception as e:
                trace(state, "CandidateGenerator",
                      f"[{strategy_name}] 생성 실패: {e}")

    _elapsed = round((_time.time() - _t0) * 1000)
    from ..llm.client import get_llm_fast as _gf
    _gen_model = (_gf() if _use_fast else get_llm()).model_label
    trace(state, "CandidateGenerator",
          f"후보 {len(candidates)}개 생성 완료",
          {"elapsed_ms": _elapsed, "model": _gen_model})

    return {**state, "candidates": candidates}


def _node_candidate_generator_snowflake(state: GraphState, _t0: float) -> GraphState:
    """Snowflake 전용 CandidateGenerator — spider2_snow_runner의 전략 기반 생성."""
    from ..eval.spider2_snow_runner import (
        _generate_spider2_strategy_candidates,
    )

    snow_selected = state.get("snow_selected_tables") or []
    all_tables = state.get("snow_catalog") or ()
    helper_aliases = state.get("helper_aliases") or []
    external_knowledge = state.get("external_knowledge") or ""
    document_hints = state.get("document_hints") or []
    agent_plan = state.get("snow_agent_plan")
    known_tables = state.get("known_tables") or []

    class _FakeExample:
        def __init__(self, q, db):
            self.question = q
            self.db_id = db
            self.instance_id = state.get("scenario_id", "")
            self.evidence = ""
            self.prompt = q

    example = _FakeExample(state["question"], state["database_id"])

    candidates: List[SQLCandidate] = []
    generation_issues: List[str] = []

    try:
        strategy_candidates, generation_issues = _generate_spider2_strategy_candidates(
            example=example,
            all_tables=all_tables,
            selected_tables=snow_selected,
            helper_aliases=helper_aliases,
            external_knowledge=external_knowledge,
            document_hints=document_hints,
            agent_plan=agent_plan,
            known_tables=known_tables,
            compact=False,
            prefer_fast=False,
        )
        for rank, generated in enumerate(strategy_candidates[:3]):
            if not generated.sql or not generated.sql.strip():
                continue
            candidates.append(SQLCandidate(
                sql=generated.sql,
                strategy=f"snowflake_{generated.strategy_name}",
                confidence=max(0.2, 0.92 - rank * 0.12) if generated.valid else max(0.1, 0.45 - rank * 0.08),
                rationale="; ".join(generated.issues) if generated.issues else generated.strategy_hint,
                is_valid=generated.valid,
                validation_errors=list(generated.issues),
            ))
            trace(state, "CandidateGenerator",
                  f"[snowflake_{generated.strategy_name}] SQL 생성 완료",
                  {"sql": generated.sql[:300], "valid": generated.valid, "penalty": generated.penalty})
    except Exception as exc:
        trace(state, "CandidateGenerator",
              f"[snowflake_primary] 생성 실패: {exc}")
        generation_issues = [str(exc)]

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "CandidateGenerator",
          f"Snowflake 후보 {len(candidates)}개 생성 완료",
          {"elapsed_ms": _elapsed})

    if candidates:
        return {**state, "candidates": candidates}
    return {
        **state,
        "candidates": candidates,
        "last_error_type": ErrorType.UNKNOWN,
        "last_error_msg": "; ".join(generation_issues) if generation_issues else "Snowflake candidate generation failed",
    }


# ═══════════════════════════════════════════════════════════════
# 6. SQLPostProcess — AST 기반 결정론적 후처리
# ═══════════════════════════════════════════════════════════════
def node_sql_postprocess(state: GraphState) -> GraphState:
    """
    CandidateGenerator가 생성한 SQL 후보에 결정론적 AST 변환을 적용.
    SQLite: CAST 제거, alias 제거, LEFT→INNER JOIN, 방어적 패턴 제거.
    Snowflake: spider2_snow_runner의 후처리 (qualification, BQ→SF 변환 등).
    """
    candidates = state.get("candidates", [])
    changed = 0

    if state.get("dialect") == "snowflake":
        from ..eval.spider2_snow_runner import _postprocess_spider2_sql
        snow_selected = state.get("snow_selected_tables") or []
        all_tables = state.get("snow_catalog") or ()
        helper_aliases = state.get("helper_aliases") or []
        question = state["question"]

        for candidate in candidates:
            original = candidate.sql
            candidate.sql = _postprocess_spider2_sql(
                original,
                question=question,
                all_tables=all_tables,
                selected_tables=snow_selected,
                helper_aliases=helper_aliases,
            )
            if candidate.sql != original:
                changed += 1
    else:
        from ..tools.sql_postprocess import SQLPostProcessor
        processor = SQLPostProcessor()
        for candidate in candidates:
            original = candidate.sql
            candidate.sql = processor.process(candidate.sql)
            if candidate.sql != original:
                changed += 1

    if changed:
        trace(state, "SQLPostProcess",
              f"후보 {changed}/{len(candidates)}개 SQL 후처리 적용")
    else:
        trace(state, "SQLPostProcess", "변환 대상 없음")

    return {**state, "candidates": candidates}
