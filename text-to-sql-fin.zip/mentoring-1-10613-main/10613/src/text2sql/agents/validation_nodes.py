"""Validation nodes for guardrails, static review, preview execution, and judging."""
from __future__ import annotations
import json
import re
import time as _time
from ..lg.state import GraphState, SQLCandidate, ErrorType, ExecReport
from ..llm.client import get_llm_fast
from ..llm import prompts as P
from ..tools.executor import SQLExecutor
from ..tools.guardrails import SQLGuard
from ..config.settings import get_settings
from ._utils import trace, get_llm_for_node


_EXPLICIT_TEMPORAL_PHRASE_RE = re.compile(
    r"("
    r"\b(today|yesterday|tomorrow|current year|current month|this year|this month|last \d+ (day|days|week|weeks|month|months|year|years)|next \d+ (day|days|week|weeks|month|months|year|years)|between|from|until|before|after|during)\b"
    r"|오늘|어제|내일|올해|이번 달|이번달|최근|지난|전년도|전년|다음 해|다음해|올해의"
    r"|\d{4}년|\d{1,2}월|\d{1,2}일|부터|까지|이후|이전"
    r")",
    re.IGNORECASE,
)


def _question_has_explicit_temporal_filter(question: str) -> bool:
    return bool(_EXPLICIT_TEMPORAL_PHRASE_RE.search(question or ""))


def _sql_uses_implicit_current_date_filter(state: GraphState, sql: str) -> bool:
    sql_lower = (sql or "").lower()
    if "where" not in sql_lower:
        return False
    current_date = str(state.get("current_date") or "")[:10]
    current_year = str(state.get("current_year") or "")[:4]
    current_month_value = state.get("current_month")
    try:
        current_month = f"{int(current_month_value):02d}" if current_month_value is not None else ""
    except (TypeError, ValueError):
        current_month = ""
    current_year_month = f"{current_year}-{current_month}" if current_year and current_month else ""
    dateish = any(
        token in sql_lower
        for token in (
            "date(",
            "datetime(",
            "strftime(",
            "current_date",
            "current_timestamp",
            "created_at",
            "updated_at",
            "invoicedate",
        )
    )
    if not dateish:
        return False
    if any(
        token in sql_lower
        for token in (
            "date('now'",
            'date("now"',
            "datetime('now'",
            'datetime("now"',
            "strftime('%y', 'now'",
            'strftime("%y", "now"',
            "strftime('%Y', 'now'",
            'strftime("%Y", "now"',
            "strftime('%y-%m', 'now'",
            'strftime("%y-%m", "now"',
            "strftime('%Y-%m', 'now'",
            'strftime("%Y-%m", "now"',
            "strftime('%y-%m-%d', 'now'",
            'strftime("%y-%m-%d", "now"',
            "strftime('%Y-%m-%d', 'now'",
            'strftime("%Y-%m-%d", "now"',
            "current_date",
            "current_timestamp",
        )
    ):
        return True
    literal_markers = tuple(
        marker.lower()
        for marker in (current_date, current_year_month, current_year)
        if marker
    )
    return any(marker in sql_lower for marker in literal_markers)


def _uses_cume_dist_for_grouped_percentile_membership(question: str, sql: str) -> bool:
    question_lower = (question or "").lower()
    sql_lower = (sql or "").lower()
    if "%" not in question_lower:
        return False
    if not any(token in question_lower for token in ("상위", "하위", "top", "bottom")):
        return False
    if not any(token in question_lower for token in ("고객", "사용자", "customer", "user")):
        return False
    if "cume_dist()" not in sql_lower:
        return False
    return any(token in sql_lower for token in ("count(", "sum(", "avg(", "count (", "sum (", "avg ("))


_GROUP_LABEL_HINTS = (
    (("아티스트별", "artist별", "artist", "artist별로"), ("artist", "artistname")),
    (("장르별", "genre별", "genre", "genre별로"), ("genre", "genrename")),
    (("고객별", "customer별", "customer", "사용자별", "user별"), ("customer", "customerid", "customername", "username", "user")),
    (("국가별", "country별", "country", "국가별로"), ("country", "billingcountry")),
    (("서비스별", "service별", "service", "서비스별로"), ("service", "servicename")),
    (("연도별", "year별", "year", "연도별로"), ("year",)),
)


def _extract_final_select_clause(sql: str) -> str:
    matches = list(re.finditer(r"\bselect\b", sql or "", re.IGNORECASE))
    if not matches:
        return ""
    start = matches[-1].end()
    from_match = re.search(r"\bfrom\b", (sql or "")[start:], re.IGNORECASE)
    if not from_match:
        return (sql or "")[start:].lower()
    end = start + from_match.start()
    return (sql or "")[start:end].lower()


def _missing_required_group_label(question: str, sql: str) -> bool:
    question_lower = (question or "").lower()
    if "별" not in question_lower and not any(token in question_lower for token in (" per ", " for each ")):
        return False
    final_select = _extract_final_select_clause(sql)
    if not final_select:
        return False
    for question_tokens, sql_tokens in _GROUP_LABEL_HINTS:
        if not any(token.lower() in question_lower for token in question_tokens):
            continue
        if any(token in final_select for token in sql_tokens):
            return False
        return True
    return False


def _uses_sparse_lag_for_yoy_growth(question: str, sql: str) -> bool:
    question_lower = (question or "").lower()
    sql_lower = (sql or "").lower()
    if not any(token in question_lower for token in ("전년 대비", "전년도 대비", "year-over-year", "yoy")):
        return False
    if "lag(" not in sql_lower:
        return False
    adjacency_markers = ("- 1", "-1", "prev_year", "previous_year")
    if any(marker in sql_lower for marker in adjacency_markers):
        return False
    return "year" in sql_lower


def _uses_string_year_for_yoy_arithmetic(question: str, sql: str) -> bool:
    question_lower = (question or "").lower()
    sql_lower = (sql or "").lower()
    if not any(token in question_lower for token in ("전년 대비", "전년도 대비", "year-over-year", "yoy")):
        return False
    uses_strftime_year = "strftime('%y'" in sql_lower or "strftime('%Y'" in sql_lower
    if not uses_strftime_year:
        return False
    if "cast(strftime('%y'" in sql_lower or "cast(strftime('%Y'" in sql_lower:
        return False
    return "- 1" in sql_lower or "-1" in sql_lower


def _keeps_zero_sales_entities_for_sales_question(question: str, sql: str) -> bool:
    question_lower = (question or "").lower()
    sql_lower = (sql or "").lower()
    sales_tokens = ("판매", "팔린", "매출", "구매", "sold", "purchased", "revenue", "spent")
    zero_tokens = ("한 번도", "구매되지 않은", "판매되지 않은", "unsold", "zero", "0건")
    if not any(token in question_lower for token in sales_tokens):
        return False
    if any(token in question_lower for token in zero_tokens):
        return False
    if "left join" not in sql_lower:
        return False
    if not any(token in sql_lower for token in ("invoiceline", "invoice line", "invoice_items", "invoiceitem")):
        return False
    # GROUP BY가 있으면 집계 쿼리 → zero-sales 엔티티가 포함되어도 0으로 집계되므로 허용
    if "group by" in sql_lower:
        return False
    positive_filters = (
        "is not null",
        "> 0",
        ">0",
        "having sum(",
        "having count(",
    )
    return not any(token in sql_lower for token in positive_filters)


# ═══════════════════════════════════════════════════════════════
# 7. Guardrails (Safety Gate)
# ═══════════════════════════════════════════════════════════════
def node_guardrails(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "Guardrails", "SQL 안전성 검증 시작")

    # Snowflake: spider2_snow_runner의 _validate_snow_sql 사용
    if state.get("dialect") == "snowflake":
        return _node_guardrails_snowflake(state, _t0)

    # Use the full schema when available so valid joins are not blocked early.
    all_tables = [t["table_name"] for t in state.get("full_schema", [])]
    guard = SQLGuard(known_tables=all_tables or state.get("selected_tables"))
    candidates = state.get("candidates", [])
    passed_any = False

    for c in candidates:
        vr = guard.validate(c.sql)
        c.is_valid = vr.valid
        c.validation_errors = vr.issues
        if (
            c.is_valid
            and not _question_has_explicit_temporal_filter(state.get("question", ""))
            and _sql_uses_implicit_current_date_filter(state, c.sql)
        ):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "질문에 명시적 기간 조건이 없는데 SQL이 현재 날짜 기반 필터를 사용합니다.",
            ]
        if c.is_valid and _uses_cume_dist_for_grouped_percentile_membership(state.get("question", ""), c.sql):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "고객/사용자 percentile 필터는 grouped metric 기준에서 PERCENT_RANK를 사용해야 합니다.",
            ]
        if c.is_valid and _uses_sparse_lag_for_yoy_growth(state.get("question", ""), c.sql):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "전년 대비 성장률은 이전 연도가 현재 연도 - 1인 경우만 비교해야 합니다.",
            ]
        if c.is_valid and _uses_string_year_for_yoy_arithmetic(state.get("question", ""), c.sql):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "연도 산술 비교에 사용하는 STRFTIME('%Y') 값은 CAST(... AS INTEGER)로 정수 변환해야 합니다.",
            ]
        if c.is_valid and _keeps_zero_sales_entities_for_sales_question(state.get("question", ""), c.sql):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "판매/구매 기준 질문은 실제 거래 행만 대상으로 해야 하며 zero-sales 엔티티를 LEFT JOIN으로 유지하면 안 됩니다.",
            ]
        if c.is_valid and _missing_required_group_label(state.get("question", ""), c.sql):
            c.is_valid = False
            c.validation_errors = list(c.validation_errors) + [
                "그룹별 질문은 최종 SELECT에 그룹 라벨 컬럼을 포함해야 합니다.",
            ]
        if c.is_valid:
            c.sql = vr.sql  # LIMIT 추가된 SQL
            passed_any = True
            trace(state, "Guardrails",
                  f"[{c.strategy}] ✅ 통과")
        else:
            trace(state, "Guardrails",
                  f"[{c.strategy}] ❌ 차단: {c.validation_errors}",
                  {"issues": c.validation_errors})

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "Guardrails",
          f"검증 완료 ({'통과' if passed_any else '차단'})",
          {"elapsed_ms": _elapsed})

    result = {**state, "candidates": candidates, "guard_passed": passed_any}

    if not passed_any:
        all_issues = []
        for c in candidates:
            if c.validation_errors:
                all_issues.extend(c.validation_errors)
        error_msg = "; ".join(all_issues) if all_issues else "SQL 안전성 검증 실패"
        only_temporal_filter_issues = bool(all_issues) and all(
            "현재 날짜 기반 필터" in issue for issue in all_issues
        )
        only_grouped_percentile_issues = bool(all_issues) and all(
            "PERCENT_RANK" in issue for issue in all_issues
        )
        only_group_label_issues = bool(all_issues) and all(
            "그룹 라벨 컬럼" in issue for issue in all_issues
        )
        only_yoy_adjacency_issues = bool(all_issues) and all(
            "현재 연도 - 1" in issue for issue in all_issues
        )
        only_year_cast_issues = bool(all_issues) and all(
            "STRFTIME('%Y') 값은 CAST" in issue for issue in all_issues
        )
        only_zero_sales_issues = bool(all_issues) and all(
            "zero-sales 엔티티" in issue for issue in all_issues
        )
        result["last_error_type"] = (
            ErrorType.SEMANTIC
            if only_temporal_filter_issues or only_grouped_percentile_issues or only_group_label_issues or only_yoy_adjacency_issues or only_year_cast_issues or only_zero_sales_issues
            else ErrorType.SAFETY
        )
        result["last_error_msg"] = error_msg

    return result


def _node_guardrails_snowflake(state: GraphState, _t0: float) -> GraphState:
    """Snowflake 전용 Guardrails — _validate_snow_sql + _rescue_unknown_tables."""
    from ..eval.spider2_snow_runner import (
        _validate_snow_sql,
        _rescue_unknown_tables,
        _auto_qualify_table_names,
        _fix_bq_to_snowflake,
        _normalize_sql,
    )

    known_tables = state.get("known_tables") or []
    snow_selected = state.get("snow_selected_tables") or []
    all_tables = state.get("snow_catalog") or ()
    db_id = state["database_id"]
    candidates = state.get("candidates", [])
    passed_any = False

    for c in candidates:
        valid, issues = _validate_snow_sql(c.sql, known_tables)

        # 알 수 없는 테이블 자동 복구 시도 (최대 2회)
        for rescue_attempt in range(2):
            if valid or not any("알 수 없는 테이블" in i for i in issues):
                break
            rescued = _rescue_unknown_tables(
                c.sql, issues, all_tables, db_id,
                selected_tables=snow_selected,
            )
            if rescued != c.sql:
                c.sql = rescued
                valid, issues = _validate_snow_sql(c.sql, known_tables)
            else:
                # Try aggressive re-qualification as last resort
                c.sql = _auto_qualify_table_names(
                    c.sql, all_tables,
                    preferred_tables=snow_selected,
                )
                valid, issues = _validate_snow_sql(c.sql, known_tables)

        # Also apply BQ→Snowflake fixes on the final SQL
        if valid:
            c.sql = _fix_bq_to_snowflake(c.sql)

        c.is_valid = valid
        c.validation_errors = issues
        if valid:
            passed_any = True
            trace(state, "Guardrails", f"[{c.strategy}] 통과")
        else:
            trace(state, "Guardrails",
                  f"[{c.strategy}] 차단: {issues}",
                  {"issues": issues})

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "Guardrails",
          f"Snowflake 검증 완료 ({'통과' if passed_any else '차단'})",
          {"elapsed_ms": _elapsed})

    result = {**state, "candidates": candidates, "guard_passed": passed_any}
    if not passed_any:
        all_issues = []
        for c in candidates:
            if c.validation_errors:
                all_issues.extend(c.validation_errors)
        result["last_error_type"] = ErrorType.SCHEMA
        result["last_error_msg"] = "; ".join(all_issues) if all_issues else "Snowflake SQL 검증 실패"
    return result


# ═══════════════════════════════════════════════════════════════
# 8. SQLUnitTester (UT) – query_pattern 전달
# ═══════════════════════════════════════════════════════════════
def node_unit_tester(state: GraphState) -> GraphState:
    _t0 = _time.time()

    # Snowflake: LLM UnitTester가 Snowflake 전용 구문(UNION ALL BY NAME 등)을
    # 잘못 blocker로 판정하므로, Snowflake에서는 스킵하고 전체 통과 처리
    if state.get("dialect") == "snowflake":
        trace(state, "SQLUnitTester", "Snowflake 모드 — 스킵 (guardrails에서 검증 완료)")
        candidates = [c for c in state.get("candidates", []) if c.is_valid]
        for c in candidates:
            c.ut_passed = True
            c.ut_detail = "Snowflake 모드 — auto pass"
        return {**state, "candidates": state.get("candidates", []),
                "ut_passed": bool(candidates)}

    trace(state, "SQLUnitTester", "SQL 정적 검증 시작")

    llm = get_llm_fast()  # 속도 우선: 정적 검증
    candidates = [c for c in state.get("candidates", []) if c.is_valid]
    passed_any = False

    query_pattern = state.get("query_pattern", "simple")

    for c in candidates:
        prompt = P.UT_USR.format(
            sql=c.sql,
            question=state["question"],
            intent=state.get("intent", ""),
            query_pattern=query_pattern,
            schema_text=state["schema_text"],
        )
        try:
            res = llm.generate_json(prompt, system=P.UT_SYS,
                                    node_name="UnitTester")
            severity = res.get("severity", "")
            issues = res.get("issues", [])

            # Severity-based execution policy:
            #   blocker → hard stop (schema error, syntax error, DML/DDL)
            #   high/medium/low → allow execution (Judge will evaluate result)
            if severity in ("blocker",):
                c.ut_passed = False
                c.ut_detail = f"[{severity}] {res.get('reasoning', '')}"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ❌ blocker: {issues}",
                      {"severity": severity, "issues": issues,
                       "reasoning": c.ut_detail})
            elif severity in ("high", "medium", "low"):
                c.ut_passed = True
                c.ut_detail = f"[{severity}] {res.get('reasoning', '')}"
                passed_any = True
                _icon = "⚠️" if severity == "high" else "✅"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] {_icon} {severity}",
                      {"severity": severity, "issues": issues,
                       "reasoning": c.ut_detail})
            else:
                # Fallback: severity 미반환 시 passed 필드 사용
                c.ut_passed = res.get("passed", False)
                c.ut_detail = res.get("reasoning", "")
                if c.ut_passed:
                    passed_any = True
                _icon = "✅" if c.ut_passed else "❌"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] {_icon} {'통과' if c.ut_passed else '실패'}",
                      {"issues": issues, "reasoning": c.ut_detail})
        except Exception as e:
            try:
                res = llm.generate_json(prompt, system=P.UT_SYS,
                                        node_name="UnitTester")
                severity = res.get("severity", "")
                if severity in ("blocker",):
                    c.ut_passed = False
                elif severity:
                    c.ut_passed = True
                else:
                    c.ut_passed = res.get("passed", False)
                c.ut_detail = f"[{severity or 'retry'}] {res.get('reasoning', '')}"
                if c.ut_passed:
                    passed_any = True
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ⚠️ 재시도 → {'통과' if c.ut_passed else '실패'}",
                      {"severity": severity, "reasoning": c.ut_detail})
            except Exception as e2:
                c.ut_passed = False
                c.ut_detail = f"LLM 검증 2회 실패: {e} / {e2}"
                trace(state, "SQLUnitTester",
                      f"[{c.strategy}] ❌ LLM 검증 실패(2회): {e2}")

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "SQLUnitTester",
          f"정적 검증 완료 ({'통과' if passed_any else '실패'})",
          {"elapsed_ms": _elapsed, "model": llm.model_label})

    result = {**state, "candidates": state.get("candidates", []),
              "ut_passed": passed_any}

    # UT 실패 시 last_error_type/last_error_msg 설정 (Repair에서 올바른 템플릿 선택용)
    if not passed_any:
        failed_issues = []
        for c in candidates:
            if not c.ut_passed and c.ut_detail:
                failed_issues.append(c.ut_detail)
        error_msg = "; ".join(failed_issues) if failed_issues else "SQL 정적 검증 실패"
        result["last_error_type"] = ErrorType.SEMANTIC
        result["last_error_msg"] = error_msg

    return result


# ═══════════════════════════════════════════════════════════════
# 9. ExecutePreview (DB) — Self-Consistency Voting
# ═══════════════════════════════════════════════════════════════
def _result_fingerprint(rows) -> str:
    """실행 결과를 multiset of tuples로 변환하여 비교용 fingerprint 생성.
    Spider EX 평가와 동일한 방식: 행 순서 무시, 컬럼 순서 유지."""
    if not rows:
        return "EMPTY"
    try:
        # 컬럼 순서 유지 (행 내부 정렬 금지 — Spider EX가 컬럼 순서 비교)
        tuples = [tuple(r.values()) for r in rows]
        tuples.sort()  # 행 순서만 정렬 (multiset 비교)
        return str(tuples)
    except Exception:
        return str(rows)


def node_execute_preview(state: GraphState) -> GraphState:
    """Self-Consistency Voting: 모든 후보를 실행하고 다수결로 최선 선택."""
    _t0 = _time.time()

    # Snowflake: compile preview를 skip하고 guardrails 통과된 SQL을 바로 사용
    # (Snowflake compile preview는 연결 ~30s로 벤치마크 성능 저하,
    #  guardrails + postprocess에서 이미 검증 완료)
    if state.get("dialect") == "snowflake":
        passed = [c for c in state.get("candidates", [])
                  if c.is_valid and c.ut_passed]
        if not passed:
            passed = [c for c in state.get("candidates", []) if c.is_valid]
        if not passed:
            passed = [c for c in state.get("candidates", []) if c.sql]
        if passed:
            best = passed[0]
            trace(state, "ExecutePreview",
                  f"Snowflake 모드 — compile skip, guardrails 통과 SQL 사용")
            return {**state,
                    "exec_report": ExecReport(ok=True, rows_preview=[], row_count=0, exec_ms=0.0),
                    "preview_sql": best.sql,
                    "selected_sql": best.sql}
        trace(state, "ExecutePreview", "Snowflake — 유효한 SQL 없음")
        return {**state,
                "exec_report": ExecReport(ok=False, error_type=ErrorType.SAFETY,
                                          error_message="실행 가능한 SQL 후보 없음"),
                "preview_sql": "", "selected_sql": ""}

    passed = [c for c in state.get("candidates", [])
              if c.is_valid and c.ut_passed]

    if not passed:
        fallback = [c for c in state.get("candidates", []) if c.is_valid]
        if fallback:
            trace(state, "ExecutePreview",
                  "⚠️ UT 전체 블로커 — is_valid 후보로 fallback 실행")
            passed = fallback

    if not passed:
        trace(state, "ExecutePreview", "❌ 실행 가능한 SQL 없음")
        return {
            **state,
            "exec_report": ExecReport(ok=False, error_type=ErrorType.SAFETY,
                                      error_message="실행 가능한 SQL 후보 없음"),
            "preview_sql": "",
            "last_error_type": state.get("last_error_type") or ErrorType.SAFETY,
            "last_error_msg": state.get("last_error_msg") or "실행 가능한 SQL 후보 없음",
        }

    settings = get_settings()
    executor = SQLExecutor(preview_limit=settings.pipeline.preview_limit)

    # 모든 후보 실행 및 결과 수집
    exec_results = []  # (candidate, report, fingerprint)
    first_failure = None

    for c in passed:
        trace(state, "ExecutePreview",
              f"[{c.strategy}] SQL 실행",
              {"sql": c.sql})
        r = executor.execute(state["db_path"], c.sql)
        if r.ok:
            fp = _result_fingerprint(r.rows_preview)
            exec_results.append((c, r, fp))
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] ✅ ({r.row_count}행)")
        else:
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] ❌ [{r.error_type}] {r.error_message}")
            if first_failure is None:
                first_failure = (c, r)

    # 실행 성공한 후보가 없으면 실패 반환
    if not exec_results:
        best = first_failure[0] if first_failure else passed[0]
        report = first_failure[1] if first_failure else ExecReport(
            ok=False, error_type=ErrorType.UNKNOWN,
            error_message="모든 후보 실행 실패")
        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "ExecutePreview",
              f"❌ 모든 후보 실행 실패",
              {"elapsed_ms": _elapsed})
        return {**state, "exec_report": report, "preview_sql": best.sql,
                "selected_sql": best.sql}

    # Self-Consistency Voting: 동일 결과 다수결
    if len(exec_results) > 1:
        from collections import Counter
        fp_counts = Counter(fp for _, _, fp in exec_results)
        majority_fp = fp_counts.most_common(1)[0][0]
        majority_count = fp_counts[majority_fp]

        # 다수결 결과 중 신뢰도 높은 후보 선택
        majority_candidates = [(c, r) for c, r, fp in exec_results
                               if fp == majority_fp]
        majority_candidates.sort(key=lambda x: x[0].confidence, reverse=True)
        best, report = majority_candidates[0]

        trace(state, "ExecutePreview",
              f"🗳️ Voting: {len(exec_results)}개 후보 중 {majority_count}개 동일 결과 → [{best.strategy}] 선택",
              {"total_exec": len(exec_results),
               "majority_count": majority_count,
               "unique_results": len(fp_counts)})
    else:
        best, report, _ = exec_results[0]

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "ExecutePreview",
          f"✅ 실행 성공: [{best.strategy}] ({report.row_count}행, {report.exec_ms:.0f}ms)",
          {"elapsed_ms": _elapsed})

    return {**state, "exec_report": report, "preview_sql": best.sql,
            "selected_sql": best.sql}


def _node_execute_preview_snowflake(state: GraphState, _t0: float) -> GraphState:
    """Snowflake 전용 ExecutePreview — compile preview로 SQL 유효성 검증."""
    from pathlib import Path
    from ..eval.spider2_snow_runner import (
        _snowflake_compile_preview,
        _should_ignore_compile_preview,
    )

    passed = [c for c in state.get("candidates", [])
              if c.is_valid and c.ut_passed]
    if not passed:
        fallback = [c for c in state.get("candidates", []) if c.is_valid]
        if fallback:
            trace(state, "ExecutePreview",
                  "UT 전체 블로커 — is_valid 후보로 fallback")
            passed = fallback

    if not passed:
        trace(state, "ExecutePreview", "실행 가능한 SQL 없음")
        return {
            **state,
            "exec_report": ExecReport(ok=False, error_type=ErrorType.SAFETY,
                                      error_message="실행 가능한 SQL 후보 없음"),
            "preview_sql": "",
            "last_error_type": state.get("last_error_type") or ErrorType.SAFETY,
            "last_error_msg": state.get("last_error_msg") or "실행 가능한 SQL 후보 없음",
        }

    spider2_root = Path(state.get("spider2_root") or "")
    db_id = state["database_id"]
    selected_column_tokens = {
        str(column).strip().strip('"').lower()
        for columns in (state.get("selected_columns") or {}).values()
        for column in columns
        if str(column).strip()
    }

    def _selected_column_coverage(sql: str) -> float:
        if not selected_column_tokens:
            return 0.0
        normalized_sql = (sql or "").lower()
        hits = 0
        for token in selected_column_tokens:
            pattern = rf'(?<![A-Za-z0-9_])"?{re.escape(token)}"?(?![A-Za-z0-9_])'
            if re.search(pattern, normalized_sql, flags=re.IGNORECASE):
                hits += 1
        return hits / max(1, len(selected_column_tokens))

    def _candidate_score(candidate: SQLCandidate, *, compile_ok: bool, ignored_error: bool) -> float:
        score = float(candidate.confidence or 0.0) * 10.0
        score += 6.0 if compile_ok else 3.0 if ignored_error else 0.0
        score += _selected_column_coverage(candidate.sql) * 4.0
        score -= float(len(candidate.validation_errors or [])) * 1.5
        score -= min(len(candidate.sql or "") / 6000.0, 1.0)
        return score

    success_candidates = []
    failed_candidates = []

    for c in passed:
        compile_ok, compile_error = _snowflake_compile_preview(spider2_root, db_id, c.sql)
        ignored_error = _should_ignore_compile_preview(compile_error)
        score = _candidate_score(c, compile_ok=compile_ok, ignored_error=ignored_error)
        if compile_ok or ignored_error:
            report = ExecReport(ok=True, rows_preview=[], row_count=0, exec_ms=0.0)
            success_candidates.append((score, compile_ok, c, report))
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] Snowflake compile 통과",
                  {"score": round(score, 4), "ignored_error": bool(ignored_error and not compile_ok)})
        else:
            trace(state, "ExecutePreview",
                  f"[{c.strategy}] compile 실패: {compile_error}")
            failed_candidates.append((
                score,
                c,
                ExecReport(
                    ok=False,
                    error_type=ErrorType.SYNTAX,
                    error_message=compile_error or "Snowflake compile 실패",
                ),
            ))

    if success_candidates:
        success_candidates.sort(key=lambda item: (item[0], item[1], item[2].confidence), reverse=True)
        _, _, best, best_report = success_candidates[0]
    elif failed_candidates:
        failed_candidates.sort(key=lambda item: (item[0], item[1].confidence), reverse=True)
        _, best, best_report = failed_candidates[0]
    else:
        best = passed[0]
        best_report = ExecReport(ok=False, error_type=ErrorType.UNKNOWN,
                                 error_message="모든 후보 compile 실패")

    _elapsed = round((_time.time() - _t0) * 1000)
    status = "통과" if best_report.ok else "실패"
    trace(state, "ExecutePreview",
          f"Snowflake compile preview {status}",
          {"elapsed_ms": _elapsed})
    result = {**state, "exec_report": best_report, "preview_sql": best.sql,
              "selected_sql": best.sql}
    if not best_report.ok:
        result["last_error_type"] = best_report.error_type or ErrorType.UNKNOWN
        result["last_error_msg"] = best_report.error_message or "모든 후보 compile 실패"
    return result


# ═══════════════════════════════════════════════════════════════
# 10. Judge / Voter
# ═══════════════════════════════════════════════════════════════
def node_judge(state: GraphState) -> GraphState:
    _t0 = _time.time()
    report = state.get("exec_report")

    # Snowflake: compile preview 통과 시 자동 승인 (실제 실행 결과 없음)
    if state.get("dialect") == "snowflake":
        if report and report.ok:
            trace(state, "Judge", "Snowflake compile 통과 → 자동 승인")
            return {
                **state,
                "judge_accepted": True,
                "judge_rationale": "Snowflake compile preview 통과 — 자동 승인",
            }
        else:
            trace(state, "Judge", "Snowflake compile 실패 → reject")
            return {
                **state,
                "judge_accepted": False,
                "judge_rationale": report.error_message if report else "compile 실패",
                "last_error_type": report.error_type if report else ErrorType.UNKNOWN,
                "last_error_msg": report.error_message if report else "compile 실패",
            }

    if not report or not report.ok:
        trace(state, "Judge", "실행 실패 → reject")
        return {**state, "judge_accepted": False,
                "judge_rationale": "SQL 실행 실패",
                "last_error_type": report.error_type if report else ErrorType.UNKNOWN,
                "last_error_msg": report.error_message if report else "실행 불가"}

    settings = get_settings()
    allow_empty = settings.pipeline.allow_empty_result

    if report.row_count == 0 and allow_empty:
        trace(state, "Judge",
              "ℹ️ 결과 0행이지만 ALLOW_EMPTY_RESULT=true → LLM 판단 위임")

    trace(state, "Judge", "결과 품질 판단 시작")

    llm = get_llm_for_node(state, prefer_primary=True)
    preview = json.dumps(report.rows_preview[:10], ensure_ascii=False, default=str) \
              if report.rows_preview else "[]"

    empty_policy_hint = ""
    if report.row_count == 0 and allow_empty:
        empty_policy_hint = (
            "\n\n[빈 결과 정책]\n"
            "결과가 0행이지만, SQL과 필터/시간 조건이 질문 의도에 부합하면 "
            "accepted=true로 판단하세요. 데이터 자체가 없는 것은 SQL 오류가 아닙니다."
        )

    prompt = P.JUDGE_USR.format(
        question=state["question"],
        intent=state.get("intent", ""),
        sql=state.get("selected_sql", ""),
        result_preview=preview[:3000],
        row_count=report.row_count,
        limit=min(10, report.row_count),
    ) + empty_policy_hint

    try:
        res = llm.generate_json(prompt, system=P.JUDGE_SYS,
                                    node_name="Judge")
        accepted = res.get("accepted", False)
        reasoning = res.get("reasoning", "")
        score = res.get("score", 0.0)
        issues = res.get("issues", [])

        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "Judge",
              f"{'✅ 승인' if accepted else '❌ 거부'} (score={score})",
              {"reasoning": reasoning,
               "issues": issues,
               "elapsed_ms": _elapsed,
               "model": llm.model_label})

        if not accepted:
            failure_cat = res.get("failure_category", "")
            enriched_msg = reasoning
            if failure_cat and failure_cat != "none":
                enriched_msg = f"[{failure_cat}] {reasoning}"
            return {
                **state,
                "judge_accepted": False,
                "judge_rationale": reasoning,
                "last_error_type": ErrorType.SEMANTIC,
                "last_error_msg": enriched_msg,
            }

        return {
            **state,
            "judge_accepted": True,
            "judge_rationale": reasoning,
        }
    except Exception as e:
        # Judge 실패 시 실행 성공이면 accept
        trace(state, "Judge", f"⚠️ 판단 오류(실행 성공이므로 승인): {e}")
        return {**state, "judge_accepted": True,
                "judge_rationale": "Judge 오류 – 실행 성공으로 자동 승인"}
