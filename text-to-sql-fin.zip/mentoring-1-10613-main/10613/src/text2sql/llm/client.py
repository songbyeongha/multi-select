"""
Azure OpenAI 클라이언트 – 듀얼 모델 지원
═══════════════════════════════════════════
메인 : SQL 생성·수정·판단 — 정확도 최우선
보조 : 분석·선택·검증·요약 — 속도 우선

사용법:
    from ..llm.client import get_llm, get_llm_fast

    llm = get_llm()            # 메인 (CandidateGenerator, Repair, Judge)
    llm_fast = get_llm_fast()  # 보조 (Decomposer, Schema, UT, Summarizer)
"""
from __future__ import annotations
import json, os, re, logging, threading, time as _time
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass
import httpx
from openai import AzureOpenAI
from ..config.settings import get_settings, AzureLLMCfg, AzureLLMFastCfg

logger = logging.getLogger(__name__)


def use_environment_proxy() -> bool:
    value = os.getenv("T2SQL_USE_ENV_PROXY", "").strip().lower()
    return value in ("1", "true", "yes", "on")


def build_azure_openai_client(*, api_key: str, api_version: str, azure_endpoint: str) -> AzureOpenAI:
    http_client = httpx.Client(
        trust_env=use_environment_proxy(),
        timeout=httpx.Timeout(60.0, connect=15.0),
    )
    return AzureOpenAI(
        api_key=api_key,
        api_version=api_version,
        azure_endpoint=azure_endpoint,
        http_client=http_client,
    )


# ═══════════════════════════════════════════════════════════════
# 토큰 사용량 추적
# ═══════════════════════════════════════════════════════════════
@dataclass
class TokenRecord:
    """단일 LLM 호출 토큰 사용 기록"""
    node: str
    model: str
    label: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class TokenAccumulator:
    """스레드 안전 토큰 누적기 — 파이프라인 실행 단위로 reset/summary"""

    def __init__(self):
        self._lock = threading.Lock()
        self._records: List[TokenRecord] = []

    def record(self, rec: TokenRecord):
        with self._lock:
            self._records.append(rec)

    def reset(self):
        with self._lock:
            self._records.clear()

    def summary(self) -> Dict[str, Any]:
        with self._lock:
            total_prompt = sum(r.prompt_tokens for r in self._records)
            total_completion = sum(r.completion_tokens for r in self._records)
            by_model: Dict[str, Dict[str, Any]] = {}
            for r in self._records:
                key = r.model
                if key not in by_model:
                    by_model[key] = {"prompt_tokens": 0, "completion_tokens": 0,
                                     "total_tokens": 0, "calls": 0}
                by_model[key]["prompt_tokens"] += r.prompt_tokens
                by_model[key]["completion_tokens"] += r.completion_tokens
                by_model[key]["total_tokens"] += r.total_tokens
                by_model[key]["calls"] += 1
            total_cost = sum(
                _calculate_cost(r.model, r.prompt_tokens, r.completion_tokens)
                for r in self._records
            )
            for mk, mv in by_model.items():
                mv["cost_usd"] = _calculate_cost(
                    mk, mv["prompt_tokens"], mv["completion_tokens"])
            return {
                "total_prompt_tokens": total_prompt,
                "total_completion_tokens": total_completion,
                "total_tokens": total_prompt + total_completion,
                "total_calls": len(self._records),
                "total_cost_usd": total_cost,
                "by_model": by_model,
            }


# 비용 계산 (USD / 1M 토큰: input, output)
_MODEL_PRICING = {
    "gpt-5":        (10.00, 30.00),
    "gpt-4.1":      (2.00,  8.00),
    "gpt-4.1-mini": (0.40,  1.60),
    "gpt-4.1-nano": (0.10,  0.40),
    "gpt-4o":       (2.50,  10.00),
    "gpt-4o-mini":  (0.15,  0.60),
    "o1":           (15.00, 60.00),
    "o3":           (10.00, 40.00),
    "o4-mini":      (1.10,  4.40),
}


def _calculate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    model_lower = model.lower()
    pricing = None
    for key in sorted(_MODEL_PRICING, key=len, reverse=True):
        if key in model_lower:
            pricing = _MODEL_PRICING[key]
            break
    if pricing is None:
        pricing = (2.50, 10.00)   # fallback: gpt-4o
    return (prompt_tokens / 1_000_000) * pricing[0] + \
           (completion_tokens / 1_000_000) * pricing[1]


_token_local = threading.local()


def get_token_accumulator() -> TokenAccumulator:
    accumulator = getattr(_token_local, "accumulator", None)
    if accumulator is None:
        accumulator = TokenAccumulator()
        _token_local.accumulator = accumulator
    return accumulator


class LLMClient:
    """Azure OpenAI Chat Completions wrapper"""

    def __init__(self, cfg: Optional[Union[AzureLLMCfg, AzureLLMFastCfg]] = None,
                 *, label: str = "primary"):
        c = cfg or get_settings().llm
        self._client = build_azure_openai_client(
            api_key=c.api_key,
            api_version=c.api_version,
            azure_endpoint=c.endpoint,
        )
        self._deploy = c.deployment
        self._temp = c.temperature
        self._max_tok = c.max_tokens
        self._label = label  # "primary" or "fast" — 로깅·추적용

        # GPT-5, GPT-4.1, GPT-4o 등 신규 모델은 max_completion_tokens 사용
        deploy_lower = self._deploy.lower()
        self._use_completion_tokens = any(
            k in deploy_lower for k in ("gpt-5", "gpt-4.1", "gpt-4o", "o1", "o3", "o4")
        )

        # GPT-5, o1, o3, o4 계열은 temperature 미지원 (기본값 1만 허용)
        self._supports_temperature = not any(
            k in deploy_lower for k in ("gpt-5", "o1", "o3", "o4")
        )

    @property
    def model_label(self) -> str:
        """현재 사용 중인 모델 배포명 (추적 로그용)"""
        return f"{self._label}({self._deploy})"

    # ── 텍스트 생성 ──────────────────────────────────────────
    def generate(self, prompt: str, *, system: str = "",
                 temperature: float | None = None,
                 max_tokens: int | None = None,
                 node_name: str = "") -> str:
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        msgs.append({"role": "user", "content": prompt})

        tok_value = max_tokens or self._max_tok

        params: Dict[str, Any] = {
            "model": self._deploy,
            "messages": msgs,
        }

        # GPT-5, o1, o3, o4 계열은 temperature 미지원 → 파라미터 제외
        if self._supports_temperature:
            params["temperature"] = (
                temperature if temperature is not None else self._temp
            )

        if self._use_completion_tokens:
            params["max_completion_tokens"] = tok_value
        else:
            params["max_tokens"] = tok_value

        resp = self._client.chat.completions.create(**params)

        if resp.usage:
            get_token_accumulator().record(TokenRecord(
                node=node_name,
                model=self._deploy,
                label=self._label,
                prompt_tokens=resp.usage.prompt_tokens or 0,
                completion_tokens=resp.usage.completion_tokens or 0,
                total_tokens=resp.usage.total_tokens or 0,
            ))

        return resp.choices[0].message.content.strip()

    # ── JSON 생성 ────────────────────────────────────────────
    def generate_json(self, prompt: str, *, system: str = "",
                      node_name: str = "") -> Dict[str, Any]:
        sys_msg = (system + "\n\n" if system else "") + (
            "반드시 유효한 JSON만 출력하세요. "
            "코드블록(```)이나 추가 설명 없이 순수 JSON만 출력하세요."
        )
        raw = self.generate(prompt, system=sys_msg, node_name=node_name)
        return self._parse_json(raw)

    @staticmethod
    def _parse_json(text: str) -> Dict[str, Any]:
        text = text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        result = json.loads(text)
        if not isinstance(result, dict):
            raise ValueError(f"Expected JSON object, got {type(result).__name__}")
        return result


# ═══════════════════════════════════════════════════════════════
# 스레드 안전 싱글톤 (Primary / Fast 각각)
# ═══════════════════════════════════════════════════════════════
_llm_local = threading.local()


def get_llm() -> LLMClient:
    """메인 모델 — 정확도 최우선 노드용
    사용처: CandidateGenerator, Repair, Judge
    """
    if not hasattr(_llm_local, "client"):
        _llm_local.client = LLMClient(
            get_settings().llm, label="메인"
        )
    return _llm_local.client


def get_llm_fast() -> LLMClient:
    """보조 모델 — 속도 우선 노드용
    사용처: Decomposer, SchemaSelector, JoinPlanner, UnitTester, ResultSummarizer
    """
    if not hasattr(_llm_local, "client_fast"):
        _llm_local.client_fast = LLMClient(
            get_settings().llm_fast, label="보조"
        )
    return _llm_local.client_fast
