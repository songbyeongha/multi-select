"""
LangGraph 그래프
═══════════════════════════════════════════════════════════════════════════════
START → Decomposer → SchemaSelector → ValueRetriever
      → JoinPlanner → CandidateGenerator×3 → SQLPostProcess(AST후처리)
      → Guardrails ─┬─ pass → SQLUnitTester ─┬─ pass → ExecutePreview ─┬─ exec_ok → Judge ─┬─ accept → ResultSummarizer+AuditLogger
                    └─ fail → Repair          ├─ fail (is_valid) → ExecutePreview (fallback)  └─ exec_error → Repair  └─ reject → Repair
                                              └─ fail (no valid) → Repair
      Repair → retry_count < MAX? ─┬─ yes → Guardrails
                                   └─ no  → SAFE FAIL
"""
from __future__ import annotations
from langgraph.graph import StateGraph, START, END

from .state import GraphState
from ..agents.nodes import (
    node_decomposer,
    node_value_retriever,
    node_schema_selector,
    node_join_planner,
    node_candidate_generator,
    node_sql_postprocess,
    node_guardrails,
    node_unit_tester,
    node_execute_preview,
    node_judge,
    node_repair,
    node_result_output,
    node_safe_fail,
)


def build_graph() -> StateGraph:
    g = StateGraph(GraphState)

    # ── 노드 등록 ────────────────────────────────────────
    g.add_node("decomposer",       node_decomposer)
    g.add_node("value_retriever",  node_value_retriever)
    g.add_node("schema_selector",  node_schema_selector)
    g.add_node("join_planner",     node_join_planner)
    g.add_node("candidate_gen",    node_candidate_generator)
    g.add_node("sql_postprocess",  node_sql_postprocess)
    g.add_node("guardrails",       node_guardrails)
    g.add_node("unit_tester",      node_unit_tester)
    g.add_node("execute_preview",  node_execute_preview)
    g.add_node("judge",            node_judge)
    g.add_node("repair",           node_repair)
    g.add_node("result_output",    node_result_output)
    g.add_node("safe_fail",        node_safe_fail)

    # ── 엣지: 직선 구간 ──────────────────────────────────
    g.add_edge(START,               "decomposer")
    g.add_edge("decomposer",       "schema_selector")
    g.add_edge("schema_selector",   "value_retriever")
    g.add_edge("value_retriever",   "join_planner")
    g.add_edge("join_planner",      "candidate_gen")

    # ── SQLPostProcess (AST 후처리) ─────────────────────
    g.add_edge("candidate_gen", "sql_postprocess")

    # ── Guardrails 분기 ──────────────────────────────────
    g.add_edge("sql_postprocess", "guardrails")

    def after_guard(s: GraphState) -> str:
        return "unit_tester" if s.get("guard_passed") else "repair"

    g.add_conditional_edges("guardrails", after_guard,
                            {"unit_tester": "unit_tester",
                             "repair":      "repair"})

    # ── UnitTester 분기 ──────────────────────────────────
    def after_ut(s: GraphState) -> str:
        if s.get("ut_passed"):
            return "execute_preview"
        # UT 전체 블로커여도 is_valid 후보가 있으면 fallback 실행 허용
        # → ExecutePreview에서 fallback 로직이 처리
        candidates = s.get("candidates", [])
        if any(c.is_valid for c in candidates):
            return "execute_preview"
        return "repair"

    g.add_conditional_edges("unit_tester", after_ut,
                            {"execute_preview": "execute_preview",
                             "repair":          "repair"})

    # ── ExecutePreview 분기 ──────────────────────────────
    def after_exec(s: GraphState) -> str:
        r = s.get("exec_report")
        return "judge" if (r and r.ok) else "repair"

    g.add_conditional_edges("execute_preview", after_exec,
                            {"judge":  "judge",
                             "repair": "repair"})

    # ── Judge 분기 ───────────────────────────────────────
    def after_judge(s: GraphState) -> str:
        return "result_output" if s.get("judge_accepted") else "repair"

    g.add_conditional_edges("judge", after_judge,
                            {"result_output": "result_output",
                             "repair":        "repair"})

    def after_repair(s: GraphState) -> str:
        return ("guardrails"
                if s.get("repair_count", 0) < s.get("max_retries", 3)
                else "safe_fail")

    g.add_conditional_edges("repair", after_repair,
                            {"guardrails":    "guardrails",
                             "safe_fail":     "safe_fail"})

    # ── 종료 ─────────────────────────────────────────────
    g.add_edge("result_output", END)
    g.add_edge("safe_fail",     END)

    return g


_compiled = None

def get_compiled_graph():
    global _compiled
    if _compiled is None:
        _compiled = build_graph().compile()
    return _compiled
