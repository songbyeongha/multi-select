#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.eval.kpi_runner import discover_repo, load_kpi_config, resolve_output_dir, utc_now_iso


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Text-to-SQL KPI benchmarks")
    parser.add_argument("--mode", choices=("smoke", "full"), default=None)
    parser.add_argument("--warm", action="store_true", default=False)
    parser.add_argument("--cold", action="store_true", default=False)
    parser.add_argument("--spider-baseline", type=str, default=None)
    parser.add_argument("--output", type=str, default=None)
    parser.add_argument("--config", type=str, default=None)
    return parser.parse_args()


def run_kpi_pytest(args: argparse.Namespace, output_dir: Path) -> int:
    command = [
        sys.executable,
        "-m",
        "pytest",
        str(ROOT / "tests" / "kpi"),
        "-m",
        "kpi",
        "-q",
        "-p",
        "no:cacheprovider",
        "--kpi-output",
        str(output_dir),
    ]
    if args.mode:
        command.extend(["--kpi-mode", args.mode])
    if args.config:
        command.extend(["--kpi-config", args.config])
    if args.spider_baseline:
        command.extend(["--spider-baseline", args.spider_baseline])
    if args.warm:
        command.append("--warm")
    if args.cold:
        command.append("--cold")
    process = subprocess.run(command, cwd=str(ROOT), check=False)
    return process.returncode


def read_json(path: Path):
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def aggregate_reports(output_dir: Path) -> Dict[str, object]:
    qc = read_json(output_dir / "query_correctness.json") or {}
    ttr = read_json(output_dir / "ttr.json") or {}
    safety = read_json(output_dir / "safety_rules.json") or {}
    scenarios = read_json(output_dir / "scenarios.json") or {}
    summary = {
        "generated_at": utc_now_iso(),
        "mode": qc.get("mode") or ttr.get("mode") or safety.get("mode") or scenarios.get("mode"),
        "chinook_acc": qc.get("chinook", {}).get("accuracy"),
        "monitor_acc": qc.get("monitor", {}).get("accuracy"),
        "spider_cur": qc.get("spider", {}).get("current_accuracy"),
        "spider_base": qc.get("spider", {}).get("baseline_accuracy"),
        "spider_delta": qc.get("spider", {}).get("delta"),
        "ttr_p50_sec": None,
        "ttr_p90_sec": None,
        "safety_pass_rate": safety.get("pass_rate"),
        "scenario_pass_rate": scenarios.get("pass_rate"),
        "failures": [],
        "suites": {
            "query_correctness": qc,
            "ttr": ttr,
            "safety_rules": safety,
            "scenarios": scenarios,
        },
    }
    assert_mode = ttr.get("assert_mode")
    if assert_mode and ttr.get(assert_mode):
        stats = ttr[assert_mode].get("stats", {})
        summary["ttr_p50_sec"] = stats.get("median")
        summary["ttr_p90_sec"] = stats.get("p90")

    chinook_failures = qc.get("chinook", {}).get("failures", [])
    monitor_failures = qc.get("monitor", {}).get("failures", [])
    spider_status = qc.get("spider", {}).get("status")
    safety_failures = safety.get("failures", [])
    scenario_failures = scenarios.get("failures", [])
    if chinook_failures:
        summary["failures"].append({"suite": "query_correctness", "count": len(chinook_failures)})
    if monitor_failures:
        summary["failures"].append({"suite": "query_correctness_monitor", "count": len(monitor_failures)})
    if spider_status not in (None, "measured", "skip"):
        summary["failures"].append({"suite": "query_correctness", "reason": spider_status})
    if safety_failures:
        summary["failures"].append({"suite": "safety_rules", "count": len(safety_failures)})
    if scenario_failures:
        summary["failures"].append({"suite": "scenarios", "count": len(scenario_failures)})
    return summary


def determine_exit_code(summary: Dict[str, object], return_codes: List[int]) -> int:
    suite_payloads = [payload for payload in summary["suites"].values() if payload]
    measured = False
    for payload in suite_payloads:
        if payload.get("suite") == "query_correctness":
            measured = measured or payload.get("chinook", {}).get("status") == "measured"
        else:
            measured = measured or payload.get("status") == "measured" or any(
                sub.get("status") == "measured" for sub in payload.values() if isinstance(sub, dict)
            )
    if not measured:
        return 5
    if summary.get("mode") == "smoke":
        return 0 if all(code in (0, 5) for code in return_codes) else 2
    if any(code not in (0, 5) for code in return_codes):
        return 2
    if summary.get("failures"):
        return 2
    return 0


def main() -> int:
    args = parse_args()
    discovery = discover_repo(ROOT)
    config = load_kpi_config(Path(args.config) if args.config else None)
    output_override = Path(args.output) if args.output else None
    if output_override and not output_override.is_absolute():
        output_override = ROOT / output_override
    output_dir = resolve_output_dir(discovery, config, output_override)
    return_codes = [run_kpi_pytest(args, output_dir)]
    summary = aggregate_reports(output_dir)
    summary_path = output_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    print(f"chinook_acc={summary['chinook_acc']}")
    print(f"monitor_acc={summary['monitor_acc']}")
    print(f"spider_cur={summary['spider_cur']} spider_base={summary['spider_base']} spider_delta={summary['spider_delta']}")
    print(f"ttr_p50_sec={summary['ttr_p50_sec']} ttr_p90_sec={summary['ttr_p90_sec']}")
    print(f"safety_pass_rate={summary['safety_pass_rate']}")
    print(f"scenario_pass_rate={summary['scenario_pass_rate']}")
    print(f"summary_json={summary_path}")
    return determine_exit_code(summary, return_codes)


if __name__ == "__main__":
    raise SystemExit(main())
