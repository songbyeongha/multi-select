#!/usr/bin/env python
"""
CLI에서 Text-to-SQL 파이프라인을 실행하고 rich 콘솔로 결과를 표시합니다.

사용 예:
    # 단일 질문 실행 (SQLite)
    python scripts/run_cli.py --db chinook --question "전체 고객 수를 구하라"

    # Spider 1.0 배치 실행
    python scripts/run_cli.py --spider1 --limit 10

    # Spider 2.0 배치 실행
    python scripts/run_cli.py --spider2 --limit 10 --workers 2
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.tools.cli_display import (
    console, PipelineDisplay, BatchDisplay,
    print_pipeline_banner, print_score_comparison,
)
from rich.panel import Panel


def _run_hitl_review(state: dict, db_path: str, display) -> dict:
    """HITL: SQL 실행 전 사용자 검토 루프."""
    from text2sql.agents.repair_output import node_repair, node_result_output
    from text2sql.agents.validation_nodes import (
        node_guardrails, node_unit_tester, node_execute_preview, node_judge,
    )
    from text2sql.lg.state import ErrorType
    from text2sql.tools.executor import SQLExecutor

    sql = state.get("selected_sql") or state.get("preview_sql") or ""
    if not sql:
        candidates = [c for c in state.get("candidates", []) if c.sql]
        if candidates:
            sql = candidates[0].sql

    while True:
        console.print()
        console.print(Panel(sql, title="[bold yellow]Generated SQL[/bold yellow]", border_style="yellow"))
        console.print()
        console.print("[bold]Select action:[/bold]")
        console.print("  [green]y[/green] - Execute this SQL")
        console.print("  [red]n[/red] - Cancel (do not execute)")
        console.print("  [yellow]e[/yellow] - Edit SQL manually")
        console.print("  [cyan]f[/cyan] - Give feedback and let LLM repair")
        console.print()

        try:
            choice = input("  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "n"

        if choice == "y":
            # 승인 — 실행 진행
            console.print("  [green]Approved. Executing...[/green]")
            state["selected_sql"] = sql
            state["preview_sql"] = sql
            state = node_execute_preview(state)
            report = state.get("exec_report")
            if report and report.ok:
                state = node_judge(state)
                if state.get("judge_accepted"):
                    state = node_result_output(state)
            elif report:
                display.print_step("ExecutePreview", f"Error: {report.error_message}")
            return state

        elif choice == "n":
            console.print("  [red]Cancelled.[/red]")
            state["success"] = False
            state["error"] = "User cancelled"
            return state

        elif choice == "e":
            # 직접 수정
            console.print("  [yellow]Enter modified SQL (end with empty line):[/yellow]")
            lines = []
            while True:
                try:
                    line = input("  sql> ")
                except (EOFError, KeyboardInterrupt):
                    break
                if line.strip() == "":
                    break
                lines.append(line)
            if lines:
                sql = "\n".join(lines)
                console.print(f"  [yellow]SQL updated ({len(lines)} lines)[/yellow]")
            else:
                console.print("  [dim]No changes[/dim]")

        elif choice == "f":
            # LLM 피드백 기반 repair
            console.print("  [cyan]Enter feedback for LLM:[/cyan]")
            try:
                feedback = input("  feedback> ").strip()
            except (EOFError, KeyboardInterrupt):
                feedback = ""
            if feedback:
                console.print(f"  [cyan]Repairing with feedback: {feedback[:60]}...[/cyan]")
                state["judge_accepted"] = False
                state["judge_rationale"] = f"[User feedback] {feedback}"
                state["last_error_type"] = ErrorType.SEMANTIC
                state["last_error_msg"] = feedback
                state["selected_sql"] = sql
                state = node_repair(state)
                # 새 SQL 추출
                new_candidates = [c for c in state.get("candidates", []) if c.sql]
                if new_candidates:
                    sql = new_candidates[0].sql
                    console.print(f"  [cyan]LLM generated new SQL[/cyan]")
                else:
                    console.print("  [red]Repair failed — keeping current SQL[/red]")
            else:
                console.print("  [dim]No feedback[/dim]")
        else:
            console.print(f"  [dim]Unknown option: {choice}[/dim]")


def run_single_query(db_id: str, question: str, db_path: str, max_retries: int,
                     hitl: bool = False):
    """단일 질문 파이프라인 실행."""
    from text2sql.agents._utils import set_cli_display
    from text2sql.lg.state import new_state
    from text2sql.lg.graph import get_compiled_graph
    from text2sql.llm.client import get_token_accumulator

    display = PipelineDisplay()
    display.set_question(question, db_id)
    set_cli_display(display)

    display.print_header()
    if hitl:
        console.print("  [yellow]HITL mode ON — SQL execution requires your approval[/yellow]")
        console.print()

    get_token_accumulator().reset()
    state = new_state(
        question=question,
        database_id=db_id,
        db_path=db_path,
        max_retries=max_retries,
        hitl_enabled=hitl,
    )

    if hitl:
        # HITL: 그래프를 ExecutePreview 직전까지만 실행 후 사용자 검토
        from text2sql.agents.nodes import (
            node_decomposer, node_schema_selector, node_value_retriever,
            node_join_planner, node_candidate_generator, node_sql_postprocess,
            node_guardrails, node_unit_tester,
        )
        for node_fn in [
            node_decomposer, node_schema_selector, node_value_retriever,
            node_join_planner, node_candidate_generator, node_sql_postprocess,
            node_guardrails, node_unit_tester,
        ]:
            state = node_fn(state)

        # 사용자 검토
        final_state = _run_hitl_review(state, db_path, display)
    else:
        graph = get_compiled_graph()
        final_state = graph.invoke(state)

    token_usage = get_token_accumulator().summary()
    success = final_state.get("success", False)
    sql = final_state.get("final_sql", "") or final_state.get("selected_sql", "")
    summary = final_state.get("result_summary", "")

    display.set_result(success, sql, summary, token_usage)
    display.print_result()
    set_cli_display(None)


def run_spider1_batch(limit: int, workers: int, max_retries: int):
    """Spider 1.0 배치 실행."""
    from text2sql.datasets.spider_loader import load_spider_dev
    from text2sql.eval.kpi_runner import bind_runtime, discover_repo, run_pipeline_with_metrics

    console.print(Panel("[bold]Spider 1.0 Batch Run[/bold]", border_style="blue"))

    examples = load_spider_dev(limit=limit)
    console.print(f"  Loaded {len(examples)} examples")

    discovery = discover_repo(ROOT)
    runtime = bind_runtime(discovery)

    batch = BatchDisplay(len(examples), "Spider 1.0")
    for i, ex in enumerate(examples):
        db_path = str(ROOT / "data" / "spider" / "database" / ex.db_id / f"{ex.db_id}.sqlite")
        start = time.perf_counter()
        try:
            m = run_pipeline_with_metrics(runtime, ex.question, ex.db_id, db_path, max_retries)
            success = m["state"].get("success", False)
            elapsed_ms = m["elapsed_ms"]
            token_usage = m["token_usage"]
        except Exception as e:
            success = False
            elapsed_ms = (time.perf_counter() - start) * 1000
            token_usage = {}
            console.print(f"  [red]Error: {ex.db_id} — {e}[/red]")

        batch.update(ex.db_id, success, elapsed_ms, token_usage)
        batch.print_progress()

    batch.print_summary()


def run_spider2_batch(limit: int, workers: int, max_retries: int):
    """Spider 2.0 배치 실행."""
    from text2sql.datasets.spider2_loader import discover_spider2_root, load_spider2_examples
    from text2sql.eval.spider2_snow_runner import generate_spider2_snow_sql

    console.print(Panel("[bold]Spider 2.0-snow Batch Run[/bold]", border_style="blue"))

    spider2_root = discover_spider2_root(project_root=ROOT)
    if not spider2_root:
        console.print("[red]Spider 2.0 root not found[/red]")
        return

    examples = load_spider2_examples(spider2_root, dataset="snow", limit=limit)
    console.print(f"  Loaded {len(examples)} examples")

    batch = BatchDisplay(len(examples), "Spider 2.0-snow")
    for ex in examples:
        result = generate_spider2_snow_sql(
            spider2_root=spider2_root,
            example=ex,
            max_retries=max_retries,
        )
        success = result.get("status") == "success"
        elapsed_ms = result.get("elapsed_ms", 0)
        token_usage = result.get("token_usage", {})

        batch.update(ex.instance_id, success, elapsed_ms, token_usage)
        batch.print_progress()

    batch.print_summary()


def parse_args():
    p = argparse.ArgumentParser(description="Text-to-SQL CLI with rich console display")
    p.add_argument("--db", type=str, default="chinook", help="Database ID (default: chinook)")
    p.add_argument("--question", "-q", type=str, default=None, help="질문 (단일 실행)")
    p.add_argument("--spider1", action="store_true", help="Spider 1.0 배치 실행")
    p.add_argument("--spider2", action="store_true", help="Spider 2.0 배치 실행")
    p.add_argument("--limit", "-n", type=int, default=None, help="최대 실행 건수")
    p.add_argument("--workers", "-w", type=int, default=2, help="병렬 워커 수")
    p.add_argument("--max-retries", type=int, default=3, help="최대 재시도 횟수")
    p.add_argument("--hitl", action="store_true", help="HITL 모드: SQL 실행 전 사용자 검토")
    return p.parse_args()


def main():
    from rich.panel import Panel
    args = parse_args()

    print_pipeline_banner()

    if args.question:
        from text2sql.tools.db_registry import resolve_db_path
        db_path = resolve_db_path(args.db)
        run_single_query(args.db, args.question, db_path, args.max_retries, hitl=args.hitl)
    elif args.spider1:
        run_spider1_batch(args.limit, args.workers, args.max_retries)
    elif args.spider2:
        run_spider2_batch(args.limit, args.workers, args.max_retries)
    else:
        console.print("[yellow]--question, --spider1, 또는 --spider2 중 하나를 지정하세요[/yellow]")
        console.print()
        console.print("예시:")
        console.print('  python scripts/run_cli.py --question "전체 고객 수를 구하라"')
        console.print("  python scripts/run_cli.py --spider1 --limit 5")
        console.print("  python scripts/run_cli.py --spider2 --limit 5")


if __name__ == "__main__":
    main()
