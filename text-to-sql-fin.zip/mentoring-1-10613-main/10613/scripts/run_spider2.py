#!/usr/bin/env python
from __future__ import annotations

import argparse
import math
import json
import logging
import os
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.config.settings import get_settings
from text2sql.datasets.spider2_loader import (
    discover_spider2_root,
    load_spider2_examples,
    spider2_sqlite_db_dir,
)
from text2sql.eval.kpi_runner import (
    discover_repo,
    has_live_azure_credentials,
    summarize_token_totals,
    utc_now_iso,
)
from text2sql.eval.spider2_support import (
    run_spider2_evaluator,
    write_spider2_sql,
    write_spider2_summary,
)

LOG = logging.getLogger("spider2")
PLACEHOLDER_SQL = "SELECT 1 AS PLACEHOLDER_RESULT"


def parse_args() -> argparse.Namespace:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Run Spider 2.0 benchmark generation with the existing pipeline")
    parser.add_argument("--dataset", choices=("lite", "snow"), default=settings.spider2.dataset or "snow")
    parser.add_argument("--spider2-root", type=Path, default=Path(settings.spider2.root) if settings.spider2.root else None)
    parser.add_argument("--output", "-o", type=Path, default=Path(settings.spider2.result_dir) if settings.spider2.result_dir else None)
    parser.add_argument("--limit", "-n", type=int, default=None)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--workers", "-w", type=int, default=4)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--scope", choices=("local", "all"), default="local")
    parser.add_argument("--instance-id", action="append", default=None)
    parser.add_argument("--official-eval", action="store_true", default=False)
    parser.add_argument("--eval-mode", choices=("sql", "exec_result"), default=settings.spider2.eval_mode or "sql")
    parser.add_argument("--eval-max-workers", type=int, default=settings.spider2.eval_max_workers)
    parser.add_argument("--eval-timeout", type=int, default=settings.spider2.eval_timeout_sec)
    parser.add_argument("--resume", action="store_true", default=False)
    parser.add_argument(
        "--prune-invalid-sql",
        action="store_true",
        default=False,
        help="Delete placeholder/failed SQL files in the output dir before resume.",
    )
    parser.add_argument("--fill-missing", action="store_true", default=False)
    parser.add_argument("--skip-generation", action="store_true", default=False)
    parser.add_argument("--status-every", type=int, default=25)
    parser.add_argument("--chunk-size", type=int, default=0)
    parser.add_argument("--chunk-index", type=int, default=0, help="1-based chunk index when chunk-size is set")
    return parser.parse_args()


def make_output_dir(args: argparse.Namespace) -> Path:
    if args.output:
        output_dir = args.output
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = ROOT / "artifacts" / "spider2_runs" / f"{args.dataset}_{timestamp}"
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir


def existing_sql_ids(output_dir: Path) -> set[str]:
    return {path.stem for path in output_dir.glob("*.sql")}


def is_placeholder_sql_text(text: str) -> bool:
    normalized = (text or "").strip().rstrip(";").upper()
    return normalized == PLACEHOLDER_SQL


def collect_prunable_sql_ids(output_dir: Path) -> set[str]:
    ids: set[str] = set()
    run_log_path = output_dir / "run_log.json"
    if run_log_path.exists():
        try:
            payload = json.loads(run_log_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            payload = []
        if isinstance(payload, list):
            for item in payload:
                if not isinstance(item, dict):
                    continue
                instance_id = str(item.get("instance_id") or "").strip()
                if not instance_id:
                    continue
                status = str(item.get("status") or "").lower()
                pred_sql = str(item.get("pred_sql") or "")
                if status != "success" or is_placeholder_sql_text(pred_sql):
                    ids.add(instance_id)

    for path in output_dir.glob("*.sql"):
        try:
            if is_placeholder_sql_text(path.read_text(encoding="utf-8")):
                ids.add(path.stem)
        except OSError:
            continue
    return ids


def prune_sql_files(output_dir: Path, instance_ids: set[str]) -> list[str]:
    deleted: list[str] = []
    for instance_id in sorted(instance_ids):
        sql_path = output_dir / f"{instance_id}.sql"
        if not sql_path.exists():
            continue
        sql_path.unlink()
        deleted.append(instance_id)
    return deleted


def write_progress(output_dir: Path, payload: dict) -> Path:
    path = output_dir / "progress.json"
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def _format_worker_exception(exc: BaseException) -> str:
    message = str(exc).strip()
    if message:
        return f"{type(exc).__name__}: {message}"
    return type(exc).__name__


def _build_worker_error_result(example, output_dir: Path, exc: BaseException) -> dict:
    sql_path = write_spider2_sql(output_dir, example, PLACEHOLDER_SQL)
    return {
        "instance_id": example.instance_id,
        "db_id": example.db_id,
        "dialect": example.dialect,
        "status": "error",
        "reason": _format_worker_exception(exc),
        "pred_sql": PLACEHOLDER_SQL,
        "sql_path": str(sql_path),
    }


def apply_chunk_window(examples, chunk_size: int, chunk_index: int):
    if chunk_size <= 0:
        return list(examples), None
    total = len(examples)
    total_chunks = max(1, math.ceil(total / chunk_size))
    if chunk_index <= 0:
        raise ValueError("--chunk-index must be >= 1 when --chunk-size is set")
    if chunk_index > total_chunks:
        raise ValueError(f"--chunk-index {chunk_index} exceeds total chunks {total_chunks}")
    start = (chunk_index - 1) * chunk_size
    end = min(total, start + chunk_size)
    return list(examples[start:end]), {
        "chunk_size": chunk_size,
        "chunk_index": chunk_index,
        "chunk_start": start,
        "chunk_end": end,
        "total_chunks": total_chunks,
        "chunk_examples": end - start,
    }


def _run_sqlite_example(runtime, example, max_retries: int, output_dir: Path) -> dict:
    from text2sql.eval.kpi_runner import run_pipeline_with_metrics

    if not example.db_path:
        return {
            "instance_id": example.instance_id,
            "db_id": example.db_id,
            "dialect": example.dialect,
            "status": "skip",
            "reason": "sqlite_db_missing_or_unsupported",
        }

    measurement = run_pipeline_with_metrics(
        runtime,
        example.prompt,
        example.db_id,
        str(example.db_path),
        max_retries,
    )
    state = measurement["state"]
    sql = state.get("final_sql") or state.get("preview_sql") or state.get("selected_sql") or "SELECT 1"
    sql_path = write_spider2_sql(output_dir, example, sql)
    return {
        "instance_id": example.instance_id,
        "db_id": example.db_id,
        "dialect": example.dialect,
        "question": example.question,
        "status": "success" if state.get("success") else "fail",
        "reason": None,
        "elapsed_ms": round(float(measurement["elapsed_ms"]), 3),
        "failure_type": measurement["failure_type"],
        "sql_path": str(sql_path),
        "pred_sql": sql,
        "preview_sql": state.get("preview_sql"),
        "final_sql": state.get("final_sql"),
        "error": state.get("error"),
        "token_usage": measurement["token_usage"],
    }


def _run_snow_example(spider2_root: Path, example, max_retries: int, output_dir: Path) -> dict:
    """Spider 2.0-snow: 내부 LangGraph 파이프라인을 통해 Snowflake SQL 생성."""
    import time as _time
    from text2sql.eval.spider2_snow_runner import (
        load_spider2_snow_catalog,
        load_spider2_snow_document,
        select_spider2_snow_tables,
        build_helper_aliases,
        _document_excerpt,
        _document_table_hints,
        _build_spider2_agent_plan,
    )
    from text2sql.lg.state import new_state
    from text2sql.lg.graph import get_compiled_graph
    from text2sql.llm.client import get_token_accumulator

    started = _time.perf_counter()
    get_token_accumulator().reset()

    # 1) Snowflake 전용 데이터 준비 (그래프 진입 전)
    external_doc = load_spider2_snow_document(str(spider2_root), example.evidence)
    external_excerpt = _document_excerpt(example.question, external_doc)
    all_tables = list(load_spider2_snow_catalog(str(spider2_root), example.db_id))
    selected_tables = select_spider2_snow_tables(
        example.question, all_tables, top_k=8, external_knowledge=external_doc,
    )
    document_hints = _document_table_hints(external_doc, all_tables)
    helper_aliases = build_helper_aliases(example.question, selected_tables, all_tables)
    agent_plan = _build_spider2_agent_plan(example, selected_tables)
    known_tables = [t.full_name for t in all_tables]

    # 2) LangGraph 상태 생성 (Snowflake 모드)
    state = new_state(
        question=example.prompt,
        database_id=example.db_id,
        db_path="",  # Snowflake는 SQLite DB 없음
        scenario_id=example.instance_id,
        max_retries=max_retries,
        dialect="snowflake",
    )
    # Snowflake 전용 필드 설정
    state["snow_catalog"] = tuple(all_tables)
    state["snow_selected_tables"] = selected_tables
    state["helper_aliases"] = helper_aliases
    state["external_knowledge"] = external_excerpt
    state["document_hints"] = document_hints
    state["spider2_root"] = str(spider2_root)
    state["known_tables"] = known_tables
    state["snow_agent_plan"] = agent_plan

    # 3) LangGraph 파이프라인 실행
    try:
        graph = get_compiled_graph()
        final_state = graph.invoke(state)
    except Exception as exc:
        LOG.error("Pipeline error for %s: %s", example.instance_id, exc)
        final_state = {**state, "success": False, "error": str(exc),
                       "final_sql": "", "selected_sql": ""}

    elapsed_ms = (_time.perf_counter() - started) * 1000
    sql = (final_state.get("final_sql")
           or final_state.get("selected_sql")
           or final_state.get("preview_sql")
           or "SELECT 1 AS PLACEHOLDER_RESULT")

    sql_path = write_spider2_sql(output_dir, example, sql)
    token_usage = get_token_accumulator().summary()

    return {
        "instance_id": example.instance_id,
        "db_id": example.db_id,
        "dialect": example.dialect,
        "question": example.question,
        "status": "success" if final_state.get("success") else "fail",
        "reason": final_state.get("error"),
        "elapsed_ms": round(elapsed_ms, 3),
        "sql_path": str(sql_path),
        "pred_sql": sql,
        "preview_sql": final_state.get("preview_sql"),
        "final_sql": final_state.get("final_sql"),
        "error": final_state.get("error"),
        "token_usage": token_usage,
    }


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    args = parse_args()
    if args.dataset == "snow" and args.status_every == 25:
        args.status_every = 1
    output_dir = make_output_dir(args)

    spider2_root = discover_spider2_root(project_root=ROOT, override=args.spider2_root)
    if spider2_root is None:
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "spider2_root_missing",
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    sqlite_root = spider2_sqlite_db_dir(spider2_root, args.dataset)
    if sqlite_root:
        os.environ["T2SQL_SPIDER2_SQLITE_ROOT"] = str(sqlite_root)

    prefixes = ("local",) if args.scope == "local" else ()
    loaded_examples = load_spider2_examples(
        spider2_root,
        dataset=args.dataset,
        offset=args.offset,
        limit=args.limit,
        instance_prefixes=prefixes,
        instance_ids=args.instance_id,
    )
    all_examples, chunk_meta = apply_chunk_window(loaded_examples, args.chunk_size, args.chunk_index)
    if not all_examples:
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "no_examples_after_filter",
            "scope": args.scope,
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    if not has_live_azure_credentials():
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "live_llm_credentials_missing",
            "scope": args.scope,
            "total_examples": len(all_examples),
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    pruned_ids: list[str] = []
    if args.prune_invalid_sql:
        pruned_ids = prune_sql_files(output_dir, collect_prunable_sql_ids(output_dir))

    completed_before = existing_sql_ids(output_dir) if args.resume else set()
    if args.resume:
        examples = [example for example in all_examples if example.instance_id not in completed_before]
    else:
        examples = list(all_examples)
    if args.skip_generation:
        examples = []

    runtime = None
    if args.dataset != "snow":
        from text2sql.eval.kpi_runner import bind_runtime

        discovery = discover_repo(ROOT)
        runtime = bind_runtime(discovery)

    LOG.info(
        "Spider 2.0-%s examples=%s pending=%s scope=%s resume=%s",
        args.dataset,
        len(all_examples),
        len(examples),
        args.scope,
        args.resume,
    )
    if pruned_ids:
        print(f"pruned_invalid_sql count={len(pruned_ids)}")
    print(
        f"start dataset={args.dataset} total_examples={len(all_examples)} "
        f"pending_examples={len(examples)} output_dir={output_dir}"
    )
    if chunk_meta:
        print(
            f"chunk chunk_index={chunk_meta['chunk_index']}/{chunk_meta['total_chunks']} "
            f"chunk_examples={chunk_meta['chunk_examples']} range=[{chunk_meta['chunk_start']},{chunk_meta['chunk_end']})"
        )
    results = [None] * len(examples)
    if examples:
        with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor:
            future_map = {
                executor.submit(
                    _run_snow_example if args.dataset == "snow" else _run_sqlite_example,
                    spider2_root if args.dataset == "snow" else runtime,
                    example,
                    args.max_retries,
                    output_dir,
                ): index
                for index, example in enumerate(examples)
            }
            completed = 0
            for future in as_completed(future_map):
                index = future_map[future]
                example = examples[index]
                try:
                    results[index] = future.result()
                except KeyboardInterrupt:  # pragma: no cover - user interrupt
                    raise
                except BaseException as exc:  # pragma: no cover - defensive
                    LOG.error("Worker crashed for %s: %s", example.instance_id, _format_worker_exception(exc))
                    results[index] = _build_worker_error_result(example, output_dir, exc)
                completed += 1
                if args.status_every > 0 and (completed % args.status_every == 0 or completed == len(examples)):
                    progress_payload = {
                        "generated_at": utc_now_iso(),
                        "dataset": args.dataset,
                        "scope": args.scope,
                        "resume": args.resume,
                        "chunk": chunk_meta,
                        "completed_before": len(completed_before),
                        "completed_now": completed,
                        "pending_total": len(examples),
                        "written_sql_files": len(existing_sql_ids(output_dir)),
                    }
                    write_progress(output_dir, progress_payload)
                    print(
                        f"progress completed_now={completed} pending_total={len(examples)} "
                        f"written_sql_files={progress_payload['written_sql_files']}"
                    )

    run_log = [result for result in results if result is not None]
    if args.fill_missing:
        existing_ids = existing_sql_ids(output_dir)
        for example in all_examples:
            if example.instance_id not in existing_ids:
                write_spider2_sql(output_dir, example, "SELECT 1 AS PLACEHOLDER_RESULT")

    run_log_path = output_dir / "run_log.json"
    run_log_path.write_text(json.dumps(run_log, indent=2, ensure_ascii=False), encoding="utf-8")

    status_counts = Counter(entry.get("status", "unknown") for entry in run_log)
    token_usage = summarize_token_totals(run_log)
    summary = {
        "generated_at": utc_now_iso(),
        "dataset": args.dataset,
        "status": "measured",
        "spider2_root": str(spider2_root),
        "scope": args.scope,
        "workers": args.workers,
        "max_retries": args.max_retries,
        "total_examples": len(all_examples),
        "completed_before": len(completed_before),
        "completed_now": len(run_log),
        "success": status_counts.get("success", 0),
        "fail": status_counts.get("fail", 0),
        "skip": status_counts.get("skip", 0),
        "error": status_counts.get("error", 0),
        "attempted_examples": status_counts.get("success", 0) + status_counts.get("fail", 0),
        "written_sql_files": len(list(output_dir.glob("*.sql"))),
        "token_usage": token_usage,
        "run_log_path": str(run_log_path),
        "resume": args.resume,
        "prune_invalid_sql": args.prune_invalid_sql,
        "pruned_invalid_sql_count": len(pruned_ids),
        "skip_generation": args.skip_generation,
        "fill_missing": args.fill_missing,
        "chunk": chunk_meta,
    }

    if args.official_eval:
        print(
            f"official_eval_start sql_files={len(list(output_dir.glob('*.sql')))} "
            f"mode={args.eval_mode}"
        )
        evaluation = run_spider2_evaluator(
            spider2_root=spider2_root,
            dataset=args.dataset,
            result_dir=output_dir,
            mode=args.eval_mode,
            max_workers=args.eval_max_workers,
            timeout=args.eval_timeout,
        )
        stdout_path = output_dir / "eval_stdout.txt"
        stderr_path = output_dir / "eval_stderr.txt"
        stdout_path.write_text(evaluation["stdout"], encoding="utf-8")
        stderr_path.write_text(evaluation["stderr"], encoding="utf-8")
        summary["official_eval"] = {
            "returncode": evaluation["returncode"],
            "final_score": evaluation["parsed"].get("final_score"),
            "final_correct": evaluation["parsed"].get("final_correct"),
            "final_total": evaluation["parsed"].get("final_total"),
            "real_score": evaluation["parsed"].get("real_score"),
            "real_correct": evaluation["parsed"].get("real_correct"),
            "real_total": evaluation["parsed"].get("real_total"),
            "stdout_path": str(stdout_path),
            "stderr_path": str(stderr_path),
        }

    summary_path = write_spider2_summary(output_dir / "summary.json", summary)
    print(f"dataset={args.dataset}")
    print(f"scope={args.scope}")
    print(f"attempted_examples={summary['attempted_examples']}")
    print(f"written_sql_files={summary['written_sql_files']}")
    if summary.get("official_eval"):
        print(f"official_real_score={summary['official_eval'].get('real_score')}")
    print(f"summary_json={summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
