#!/usr/bin/env python
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.eval.kpi_runner import discover_repo, load_kpi_config, resolve_output_dir, utc_now_iso


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the simplified full test suite")
    parser.add_argument("--mode", choices=("smoke", "full"), default=None)
    parser.add_argument("--warm", action="store_true", default=False)
    parser.add_argument("--cold", action="store_true", default=False)
    parser.add_argument("--output", type=str, default=None)
    parser.add_argument("--config", type=str, default=None)
    parser.add_argument("--spider-baseline", type=str, default=None)
    parser.add_argument("--skip-spider", action="store_true", default=False)
    parser.add_argument("--skip-pytest", action="store_true", default=False)
    parser.add_argument("--spider-workers", type=int, default=None)
    return parser.parse_args()


def make_run_dir(base: Path) -> Path:
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = base / "test_runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    return run_dir


def has_pytest_json_report() -> bool:
    return importlib.util.find_spec("pytest_jsonreport") is not None


def subprocess_text_kwargs() -> Dict[str, Any]:
    return {
        "text": True,
        "encoding": "utf-8",
        "errors": "replace",
    }


def run_pytest(args: argparse.Namespace, run_dir: Path) -> Dict[str, Any]:
    json_report = run_dir / "pytest_report.json"
    junit_report = run_dir / "pytest_junit.xml"
    kpi_output = run_dir / "kpi"
    env = os.environ.copy()
    env["T2SQL_KPI_SKIP_SPIDER"] = "1"
    command = [
        sys.executable,
        "-m",
        "pytest",
        str(ROOT / "tests" / "test_unit.py"),
        str(ROOT / "tests" / "kpi"),
        "-m",
        "unit or kpi",
        "-q",
        "-p",
        "no:cacheprovider",
        "--kpi-output",
        str(kpi_output),
    ]
    report_format = "junit"
    if has_pytest_json_report():
        command.extend(
            [
                "-p",
                "pytest_jsonreport",
                "--json-report",
                f"--json-report-file={json_report}",
            ]
        )
        report_format = "json"
    else:
        command.append(f"--junitxml={junit_report}")
    if args.mode:
        command.extend(["--kpi-mode", args.mode])
    if args.config:
        command.extend(["--kpi-config", args.config])
    if args.warm:
        command.append("--warm")
    if args.cold:
        command.append("--cold")
    process = subprocess.run(command, cwd=str(ROOT), env=env, check=False)
    return {
        "returncode": process.returncode,
        "report_format": report_format,
        "json_report": str(json_report) if report_format == "json" else None,
        "junit_report": str(junit_report) if report_format == "junit" else None,
        "kpi_output_dir": str(kpi_output),
    }


def run_spider(args: argparse.Namespace, run_dir: Path, config: Dict[str, Any]) -> Dict[str, Any]:
    spider_dir = run_dir / "spider"
    spider_dir.mkdir(parents=True, exist_ok=True)
    mode = args.mode or config.get("run", {}).get("mode", "full")
    limit = config.get("spider", {}).get("smoke_limit") if mode == "smoke" else config.get("spider", {}).get("full_limit")
    workers = args.spider_workers or config.get("workers", {}).get("spider", 50)
    run_command = [
        sys.executable,
        str(ROOT / "scripts" / "run_spider_dev.py"),
        "--output",
        str(spider_dir),
        "--workers",
        str(workers),
        "--max-retries",
        str(config.get("run", {}).get("max_retries", 3)),
    ]
    if limit:
        run_command.extend(["--limit", str(limit)])
    run_process = subprocess.run(
        run_command,
        cwd=str(ROOT),
        capture_output=True,
        check=False,
        **subprocess_text_kwargs(),
    )
    (spider_dir / "run_stdout.txt").write_text(run_process.stdout or "", encoding="utf-8")
    (spider_dir / "run_stderr.txt").write_text(run_process.stderr or "", encoding="utf-8")

    eval_command = [
        sys.executable,
        str(ROOT / "scripts" / "eval_spider.py"),
        "--result-dir",
        str(spider_dir),
        "--eval-dir",
        str(ROOT / config.get("paths", {}).get("spider_eval_dir", "test-suite-sql-eval")),
        "--db",
        str(ROOT / config.get("paths", {}).get("spider_dir", "data/spider") / "database"),
        "--table",
        str(ROOT / config.get("paths", {}).get("spider_dir", "data/spider") / "tables.json"),
        "--etype",
        "exec",
    ]
    eval_process = subprocess.run(
        eval_command,
        cwd=str(ROOT),
        capture_output=True,
        check=False,
        **subprocess_text_kwargs(),
    )
    (spider_dir / "eval_stdout.txt").write_text(eval_process.stdout or "", encoding="utf-8")
    (spider_dir / "eval_stderr.txt").write_text(eval_process.stderr or "", encoding="utf-8")
    return {
        "run_returncode": run_process.returncode,
        "eval_returncode": eval_process.returncode,
        "summary_path": str(spider_dir / "summary.json"),
        "run_log_path": str(spider_dir / "run_log.json"),
        "fail_analysis_path": str(spider_dir / "fail_analysis.json"),
        "stdout_path": str(spider_dir / "run_stdout.txt"),
        "eval_stdout_path": str(spider_dir / "eval_stdout.txt"),
    }


def read_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def parse_spider_eval_stdout(stdout_path: Path) -> Dict[str, Any]:
    if not stdout_path.exists():
        return {}
    text = stdout_path.read_text(encoding="utf-8", errors="replace")
    headers: List[str] | None = None
    execution: Dict[str, float] = {}
    counts: Dict[str, int] = {}

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        normalized = re.sub(r"\s+", " ", line)
        parts = normalized.split(" ")
        if parts == ["easy", "medium", "hard", "extra", "all"]:
            headers = parts
            continue
        if headers and parts and parts[0] == "count" and len(parts) == len(headers) + 1:
            counts = {
                header: int(value)
                for header, value in zip(headers, parts[1:])
                if value.isdigit()
            }
            continue
        if headers and parts and parts[0].lower() == "execution" and len(parts) == len(headers) + 1:
            execution = {
                header: round(float(value) * 100.0, 1)
                for header, value in zip(headers, parts[1:])
            }
            break

    if not execution:
        return {}
    return {
        "counts": counts,
        "execution_accuracy_pct": execution,
        "all_exec_accuracy_pct": execution.get("all"),
    }


def extract_failure_type(test_entry: Dict[str, Any]) -> str:
    call = test_entry.get("call", {})
    crash = call.get("crash") or {}
    message = crash.get("message") or call.get("longrepr") or ""
    if not message:
        return "unknown"
    text = str(message)
    if "AssertionError" in text:
        return "assertion"
    if "Timeout" in text or "timed out" in text:
        return "timeout"
    return text.split(":")[0][:80]


def summarize_pytest_report(report: Dict[str, Any]) -> Dict[str, Any]:
    tests = report.get("tests", [])
    by_suite: Dict[str, List[Dict[str, Any]]] = {"unit": [], "kpi": []}
    for entry in tests:
        nodeid = entry.get("nodeid", "")
        target = "kpi" if "tests/kpi/" in nodeid.replace("\\", "/") else "unit"
        by_suite[target].append(entry)

    summary: Dict[str, Any] = {}
    for suite, entries in by_suite.items():
        outcomes = Counter(entry.get("outcome", "unknown") for entry in entries)
        failures = []
        for entry in entries:
            if entry.get("outcome") == "passed":
                continue
            failures.append(
                {
                    "nodeid": entry.get("nodeid"),
                    "outcome": entry.get("outcome"),
                    "duration_sec": (entry.get("call") or {}).get("duration"),
                    "failure_type": extract_failure_type(entry),
                }
            )
        summary[suite] = {
            "total": len(entries),
            "passed": outcomes.get("passed", 0),
            "failed": outcomes.get("failed", 0),
            "skipped": outcomes.get("skipped", 0),
            "duration_sec": round(sum(float((entry.get("call") or {}).get("duration", 0.0) or 0.0) for entry in entries), 3),
            "failures": failures,
        }
    return summary


def summarize_junit_report(report_path: Path) -> Dict[str, Any]:
    if not report_path.exists():
        return {}
    tree = ET.parse(report_path)
    root = tree.getroot()
    by_suite: Dict[str, List[Dict[str, Any]]] = {"unit": [], "kpi": []}

    for testcase in root.iter("testcase"):
        classname = testcase.attrib.get("classname", "")
        name = testcase.attrib.get("name", "")
        suite = "kpi" if "tests.kpi" in classname or ".kpi." in classname else "unit"
        outcome = "passed"
        failure_node = testcase.find("failure")
        error_node = testcase.find("error")
        skipped_node = testcase.find("skipped")
        if skipped_node is not None:
            outcome = "skipped"
        elif failure_node is not None or error_node is not None:
            outcome = "failed"
        message = ""
        if failure_node is not None:
            message = failure_node.attrib.get("message", "") or (failure_node.text or "")
        elif error_node is not None:
            message = error_node.attrib.get("message", "") or (error_node.text or "")
        by_suite[suite].append(
            {
                "nodeid": f"{classname}::{name}" if classname else name,
                "outcome": outcome,
                "call": {
                    "duration": float(testcase.attrib.get("time", 0.0) or 0.0),
                    "longrepr": message.strip(),
                },
            }
        )

    return summarize_pytest_report({"tests": by_suite["unit"] + by_suite["kpi"]})


def aggregate(run_dir: Path, pytest_meta: Dict[str, Any], spider_meta: Dict[str, Any] | None) -> Dict[str, Any]:
    pytest_report = {}
    pytest_summary = {}
    if pytest_meta:
        report_format = pytest_meta.get("report_format")
        if report_format == "json" and pytest_meta.get("json_report"):
            pytest_report = read_json(Path(pytest_meta["json_report"]))
            pytest_summary = summarize_pytest_report(pytest_report) if pytest_report else {}
        elif report_format == "junit" and pytest_meta.get("junit_report"):
            pytest_summary = summarize_junit_report(Path(pytest_meta["junit_report"]))
    kpi_dir = Path(pytest_meta["kpi_output_dir"]) if pytest_meta else run_dir / "kpi"
    query_correctness = read_json(kpi_dir / "query_correctness.json")
    ttr = read_json(kpi_dir / "ttr.json")
    safety = read_json(kpi_dir / "safety_rules.json")
    scenarios = read_json(kpi_dir / "scenarios.json")

    spider_summary = {}
    if spider_meta:
        spider_summary = read_json(Path(spider_meta["summary_path"]))
        spider_summary["failure_analysis"] = read_json(Path(spider_meta["fail_analysis_path"]))
        spider_summary["meta"] = spider_meta
        official_eval = parse_spider_eval_stdout(Path(spider_meta["eval_stdout_path"]))
        if official_eval:
            spider_summary["runner_ex_accuracy_pct"] = spider_summary.get("ex_accuracy_pct")
            spider_summary["official_eval"] = official_eval
            spider_summary["official_exec_accuracy_pct"] = official_eval.get("all_exec_accuracy_pct")
            spider_summary["ex_accuracy_pct"] = official_eval.get("all_exec_accuracy_pct")

    total_cost = 0.0
    total_tokens = 0
    for payload in (
        query_correctness.get("chinook", {}).get("token_usage", {}),
        query_correctness.get("monitor", {}).get("token_usage", {}),
        ttr.get("warm", {}).get("token_usage", {}),
        ttr.get("cold", {}).get("token_usage", {}),
        safety.get("token_usage", {}),
        scenarios.get("token_usage", {}),
        spider_summary.get("token_usage", {}),
    ):
        total_cost += float(payload.get("total_cost_usd", 0.0) or 0.0)
        total_tokens += int(payload.get("total_tokens", 0) or 0)
    if spider_summary and not spider_summary.get("token_usage"):
        total_cost += float(spider_summary.get("total_cost_usd", 0.0) or 0.0)
        total_tokens += int(spider_summary.get("total_tokens", 0) or 0)

    summary = {
        "generated_at": utc_now_iso(),
        "run_dir": str(run_dir),
        "pytest": {
            "returncode": pytest_meta.get("returncode") if pytest_meta else None,
            "json_report": pytest_meta.get("json_report") if pytest_meta else None,
            "junit_report": pytest_meta.get("junit_report") if pytest_meta else None,
            "report_format": pytest_meta.get("report_format") if pytest_meta else None,
            "summary": pytest_summary,
        },
        "kpi": {
            "query_correctness": query_correctness,
            "ttr": ttr,
            "safety_rules": safety,
            "scenarios": scenarios,
        },
        "spider": spider_summary,
        "overall": {
            "total_cost_usd": round(total_cost, 6),
            "total_tokens": total_tokens,
        },
    }
    return summary


def determine_exit_code(summary: Dict[str, Any], config: Dict[str, Any], mode: str) -> int:
    pytest_rc = summary.get("pytest", {}).get("returncode")
    if pytest_rc not in (None, 0, 5):
        return 2
    spider_meta = summary.get("spider", {}).get("meta")
    if spider_meta and (spider_meta.get("run_returncode") not in (0, None) or spider_meta.get("eval_returncode") not in (0, None)):
        return 2
    if not summary.get("pytest", {}).get("summary") and not summary.get("spider"):
        return 5
    if mode == "full":
        spider_acc = summary.get("spider", {}).get("ex_accuracy_pct")
        spider_min = float(config.get("kpi", {}).get("spider_min", 0.0))
        if spider_acc is not None:
            spider_value = float(spider_acc)
            if spider_value > 1:
                spider_value /= 100.0
            if spider_value < spider_min:
                return 2
    return 0


def main() -> int:
    args = parse_args()
    discovery = discover_repo(ROOT)
    config = load_kpi_config(Path(args.config) if args.config else None)
    mode = args.mode or config.get("run", {}).get("mode", "full")
    base_artifacts = resolve_output_dir(discovery, config, Path(args.output) if args.output else None).parent
    run_dir = make_run_dir(base_artifacts)

    pytest_meta: Dict[str, Any] | None = None
    spider_meta: Dict[str, Any] | None = None
    if not args.skip_pytest:
        pytest_meta = run_pytest(args, run_dir)
    if not args.skip_spider:
        spider_meta = run_spider(args, run_dir, config)

    summary = aggregate(run_dir, pytest_meta or {}, spider_meta)
    summary_path = run_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    unit = summary.get("pytest", {}).get("summary", {}).get("unit", {})
    kpi = summary.get("pytest", {}).get("summary", {}).get("kpi", {})
    spider = summary.get("spider", {})
    official_spider = spider.get("official_exec_accuracy_pct")
    runner_spider = spider.get("runner_ex_accuracy_pct")
    print(f"unit passed={unit.get('passed', 0)} failed={unit.get('failed', 0)}")
    print(f"kpi passed={kpi.get('passed', 0)} failed={kpi.get('failed', 0)}")
    print(f"chinook_acc={summary.get('kpi', {}).get('query_correctness', {}).get('chinook', {}).get('accuracy')}")
    print(f"monitor_acc={summary.get('kpi', {}).get('query_correctness', {}).get('monitor', {}).get('accuracy')}")
    print(f"scenario_pass_rate={summary.get('kpi', {}).get('scenarios', {}).get('pass_rate')}")
    print(f"spider_exec_accuracy={spider.get('ex_accuracy_pct')}")
    if official_spider is not None:
        print(f"spider_exec_accuracy_official={official_spider}")
    if runner_spider is not None:
        print(f"spider_exec_accuracy_runner={runner_spider}")
    print(f"total_cost_usd={summary['overall']['total_cost_usd']} total_tokens={summary['overall']['total_tokens']}")
    print(f"summary_json={summary_path}")
    return determine_exit_code(summary, config, mode)


if __name__ == "__main__":
    raise SystemExit(main())
