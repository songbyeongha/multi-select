#!/usr/bin/env python
"""
Spider 1.0 dev 배치 실행 스크립트
==========================================================
Spider dev.json 예제를 순회하며 LangGraph 파이프라인을 호출하고
공식 evaluator 형식의 gold/pred 파일을 생성합니다.

사용 예:
    # 처음 5개만 실행
    python scripts/run_spider_dev.py --limit 5

    # 전체 실행, 출력 디렉토리 지정
    python scripts/run_spider_dev.py --output artifacts/spider_runs/spider_full

    # 특정 Spider 데이터 경로
    python scripts/run_spider_dev.py --spider-dir data/spider --limit 10

    # 최대 재시도 횟수 조정
    python scripts/run_spider_dev.py --limit 5 --max-retries 2

    # 빠른 테스트: 후보 1개 + 4워커 병렬 + 재시도 1회
    python scripts/run_spider_dev.py --limit 50 -c 1 -w 4 --max-retries 1

    # 전체 실행 (8워커 병렬)
    python scripts/run_spider_dev.py -w 8
"""
from __future__ import annotations

import argparse
import json
import logging
import sqlite3
import sys
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

# 프로젝트 src를 PYTHONPATH에 추가
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.datasets.spider_loader import load_spider_dev
from text2sql.eval.spider_writer import SpiderResultWriter
from text2sql.tools.db_registry import resolve_db_path, DBNotFoundError
from text2sql.lg.state import new_state
from text2sql.lg.graph import get_compiled_graph
from text2sql.llm.client import get_token_accumulator
from text2sql.memory.conversation import get_memory

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("spider_dev")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Spider 1.0 dev 배치 실행")
    p.add_argument("--spider-dir", type=Path, default=None,
                   help="Spider 데이터 루트 (기본: data/spider)")
    p.add_argument("--output", "-o", type=str, default=None,
                   help="결과 출력 디렉터리 (기본: artifacts/spider_runs/spider_dev_YYYYMMDD_HHMMSS)")
    p.add_argument("--limit", "-n", type=int, default=None,
                   help="실행할 최대 예제 수")
    p.add_argument("--max-retries", type=int, default=3,
                   help="파이프라인 최대 재시도 횟수 (기본: 3)")
    p.add_argument("--offset", type=int, default=0,
                   help="건너뛸 예제 수 (0부터 시작)")
    p.add_argument("--workers", "-w", type=int, default=1,
                   help="병렬 실행 워커 수 (기본: 1, 권장: 4~8)")
    p.add_argument("--num-candidates", "-c", type=int, default=None,
                   help="후보 SQL 수 (기본: settings 값 3, 빠른 테스트: 1)")
    return p.parse_args()


def _exec_sql(db_path: str, sql: str, limit: int = 50) -> dict:
    """SQL을 실행하고 결과를 반환 (EX 비교용)"""
    if not sql or sql.strip().upper() == "SELECT 1":
        return {"ok": False, "error": "empty/fallback SQL", "rows": [], "count": 0}
    conn = None
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.execute(sql)
        rows = [dict(r) for r in cur.fetchmany(limit)]
        # 총 행 수 카운트
        remaining = 0
        if len(rows) == limit:
            while True:
                batch = cur.fetchmany(1000)
                if not batch:
                    break
                remaining += len(batch)
        total = len(rows) + remaining
        return {"ok": True, "rows": rows, "count": total}
    except Exception as e:
        return {"ok": False, "error": str(e), "rows": [], "count": 0}
    finally:
        if conn:
            conn.close()


def _compare_results(gold_res: dict, pred_res: dict) -> dict:
    """Gold와 Pred 실행 결과를 비교하여 EX match 여부 판단"""
    if not gold_res["ok"] or not pred_res["ok"]:
        return {
            "ex_match": False,
            "reason": f"exec_fail: gold_ok={gold_res['ok']}, pred_ok={pred_res['ok']}",
            "gold_error": gold_res.get("error"),
            "pred_error": pred_res.get("error"),
        }

    g_rows = gold_res["rows"]
    p_rows = pred_res["rows"]

    # 행 수 비교
    if gold_res["count"] != pred_res["count"]:
        return {
            "ex_match": False,
            "reason": f"row_count: gold={gold_res['count']}, pred={pred_res['count']}",
        }

    # 빈 결과 동일
    if not g_rows and not p_rows:
        return {"ex_match": True, "reason": "both_empty"}

    # 컬럼 수 비교
    if g_rows and p_rows:
        g_ncols = len(g_rows[0])
        p_ncols = len(p_rows[0])
        if g_ncols != p_ncols:
            return {
                "ex_match": False,
                "reason": f"col_count: gold={g_ncols}, pred={p_ncols}",
                "gold_cols": list(g_rows[0].keys()),
                "pred_cols": list(p_rows[0].keys()),
            }

    # 값 비교 (multiset)
    def _row_to_tuple(row):
        return tuple(str(v) for v in row.values())

    g_tuples = sorted(_row_to_tuple(r) for r in g_rows)
    p_tuples = sorted(_row_to_tuple(r) for r in p_rows)

    if g_tuples == p_tuples:
        return {"ex_match": True, "reason": "exact_match"}

    # 부분 일치 여부 확인
    g_set = set(g_tuples)
    p_set = set(p_tuples)
    overlap = len(g_set & p_set)
    return {
        "ex_match": False,
        "reason": f"value_mismatch: overlap={overlap}/{len(g_set)}",
        "gold_sample": g_tuples[:3],
        "pred_sample": p_tuples[:3],
    }


def _extract_trace_summary(trace: list) -> list:
    """파이프라인 trace를 요약 (노드명 + 핵심 정보만)"""
    summary = []
    for entry in (trace or []):
        node = entry.get("node", "")
        detail = entry.get("detail", "")
        # 긴 detail은 잘라내기
        if len(detail) > 120:
            detail = detail[:117] + "..."
        summary.append(f"{node}: {detail}")
    return summary


def _extract_candidate_info(candidates) -> list:
    """후보 SQL 정보를 요약"""
    info = []
    for i, c in enumerate(candidates or []):
        info.append({
            "idx": i,
            "strategy": c.strategy if hasattr(c, "strategy") else "?",
            "is_valid": c.is_valid if hasattr(c, "is_valid") else None,
            "ut_passed": c.ut_passed if hasattr(c, "ut_passed") else None,
            "sql_preview": (c.sql[:100] + "...") if hasattr(c, "sql") and len(c.sql) > 100 else (c.sql if hasattr(c, "sql") else ""),
            "validation_errors": c.validation_errors if hasattr(c, "validation_errors") else [],
        })
    return info


def _infer_failure_type(result: dict) -> str:
    trace_blob = " ".join(
        str(entry.get("detail", ""))
        for entry in (result.get("trace") or [])
        if isinstance(entry, dict)
    ).lower()
    error_blob = " ".join(
        str(part)
        for part in (
            result.get("error"),
            result.get("judge_rationale"),
            trace_blob,
        )
        if part
    ).lower()
    if result.get("success"):
        return "success"
    if "connection error" in error_blob:
        return "connection_error"
    if "timed out" in error_blob or "timeout" in error_blob:
        return "timeout"
    if not result.get("guard_passed"):
        return "guardrails"
    if not result.get("ut_passed"):
        return "unit_tester"
    exec_report = result.get("exec_report")
    if exec_report and not getattr(exec_report, "ok", False):
        error_type = getattr(getattr(exec_report, "error_type", None), "value", None) or getattr(exec_report, "error_type", None)
        return f"execute_preview:{error_type or 'unknown'}"
    if not result.get("judge_accepted") and result.get("judge_rationale"):
        return "judge_rejected"
    if result.get("error"):
        return "safe_fail"
    if not (result.get("final_sql") or result.get("preview_sql") or result.get("selected_sql")):
        return "no_sql_generated"
    return "unknown"


def _run_one(graph, ex, idx, total, max_retries):
    """단일 예제 실행 → (idx, gold_sql, pred_sql, db_id, log_entry) 반환"""
    log.info(f"[{idx+1}/{total}] db={ex.db_id} | {ex.question[:60]}...")
    get_token_accumulator().reset()
    get_memory().clear()

    # DB 경로 해석
    try:
        db_path = resolve_db_path(ex.db_id)
    except DBNotFoundError as e:
        log.warning(f"  SKIP: {e}")
        return (idx, ex.gold_sql, "SELECT 1", ex.db_id, {
            "index": idx, "db_id": ex.db_id,
            "question": ex.question, "status": "skip_no_db",
            "error": str(e),
            "failure_type": "db_not_found",
        })

    # 파이프라인 실행
    state = new_state(
        question=ex.question,
        database_id=ex.db_id,
        db_path=db_path,
        max_retries=max_retries,
    )

    t0 = time.time()
    try:
        result = graph.invoke(state)
        elapsed_ms = (time.time() - t0) * 1000
    except Exception as e:
        elapsed_ms = (time.time() - t0) * 1000
        log.error(f"  ERROR ({elapsed_ms:.0f}ms): {e}")
        return (idx, ex.gold_sql, "SELECT 1", ex.db_id, {
            "index": idx, "db_id": ex.db_id,
            "question": ex.question, "status": "error",
            "error": str(e), "elapsed_ms": elapsed_ms,
            "failure_type": "exception",
        })

    pred_sql = result.get("final_sql", "") or ""
    ok = result.get("success", False)
    status = "success" if ok else "fail"
    token_usage = result.get("token_usage") or get_token_accumulator().summary()
    failure_type = _infer_failure_type(result)

    pred_display = f"{pred_sql[:80]}..." if len(pred_sql) > 80 else pred_sql
    log.info(f"  {status.upper()} ({elapsed_ms:.0f}ms) | pred: {pred_display}")

    # ── EX 비교 (gold vs pred 실행 결과) ──
    gold_res = _exec_sql(db_path, ex.gold_sql)
    pred_res = _exec_sql(db_path, pred_sql)
    ex_cmp = _compare_results(gold_res, pred_res)

    # ── 진단 정보 추출 ──
    candidate_info = _extract_candidate_info(result.get("candidates"))
    trace_summary = _extract_trace_summary(result.get("trace"))

    log_entry = {
        "index": idx,
        "db_id": ex.db_id,
        "question": ex.question,
        "status": status,
        "gold_sql": ex.gold_sql,
        "pred_sql": pred_sql,
        "elapsed_ms": elapsed_ms,
        "error": result.get("error"),
        "failure_type": failure_type,
        # ── 진단 필드 (신규) ──
        "ex_match": ex_cmp.get("ex_match"),
        "ex_reason": ex_cmp.get("reason"),
        "ex_detail": {k: v for k, v in ex_cmp.items()
                      if k not in ("ex_match", "reason")},
        "gold_row_count": gold_res.get("count", 0),
        "pred_row_count": pred_res.get("count", 0),
        "gold_sample": gold_res.get("rows", [])[:3],
        "pred_sample": pred_res.get("rows", [])[:3],
        "query_pattern": result.get("query_pattern", ""),
        "selected_tables": result.get("selected_tables", []),
        "repair_count": result.get("repair_count", 0),
        "judge_accepted": result.get("judge_accepted"),
        "judge_rationale": (result.get("judge_rationale", "") or "")[:200],
        "token_usage": token_usage,
        "cost_usd": token_usage.get("total_cost_usd", 0.0),
        "total_tokens": token_usage.get("total_tokens", 0),
        "candidates_summary": candidate_info,
        "trace_summary": trace_summary,
    }

    return (idx, ex.gold_sql, pred_sql, ex.db_id, log_entry)


def main():
    args = parse_args()

    # num_candidates 오버라이드 (설정 싱글턴 패치)
    if args.num_candidates is not None:
        from text2sql.config.settings import get_settings
        settings = get_settings()
        # frozen이 아닌 PipelineCfg이므로 object.__setattr__ 사용
        object.__setattr__(settings.pipeline, "num_candidates", args.num_candidates)
        log.info(f"num_candidates 오버라이드: {args.num_candidates}")

    # 출력 디렉토리
    if args.output:
        out_dir = Path(args.output)
    else:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_dir = ROOT / "artifacts" / "spider_runs" / f"spider_dev_{ts}"
    out_dir.mkdir(parents=True, exist_ok=True)

    # Spider dev 로드
    log.info("Spider dev.json 로드 중...")
    examples = load_spider_dev(spider_dir=args.spider_dir)
    total = len(examples)
    log.info(f"전체 {total}개 예제 로드 완료")

    # offset / limit 적용
    examples = examples[args.offset:]
    if args.limit:
        examples = examples[:args.limit]
    log.info(f"실행 대상: {len(examples)}개 (offset={args.offset}, limit={args.limit})")

    workers = args.workers
    log.info(f"워커 수: {workers}, 최대 재시도: {args.max_retries}")

    # 그래프 컴파일 (1회)
    graph = get_compiled_graph()

    t_start = time.time()

    if workers <= 1:
        # ── 순차 실행 (기존 로직) ──
        results = []
        for i, ex in enumerate(examples):
            idx = args.offset + i
            result = _run_one(graph, ex, idx, total, args.max_retries)
            results.append(result)
    else:
        # ── 병렬 실행 ──
        log.info(f"병렬 모드: {workers} 워커로 실행")
        results = [None] * len(examples)

        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_to_i = {}
            for i, ex in enumerate(examples):
                idx = args.offset + i
                future = executor.submit(
                    _run_one, graph, ex, idx, total, args.max_retries
                )
                future_to_i[future] = i

            done_count = 0
            for future in as_completed(future_to_i):
                i = future_to_i[future]
                try:
                    results[i] = future.result()
                except Exception as e:
                    idx = args.offset + i
                    ex = examples[i]
                    log.error(f"  워커 예외 [{idx}]: {e}")
                    results[i] = (idx, ex.gold_sql, "SELECT 1", ex.db_id, {
                        "index": idx, "db_id": ex.db_id,
                        "question": ex.question, "status": "error",
                        "error": str(e),
                        "failure_type": "worker_exception",
                    })
                done_count += 1
                if done_count % 50 == 0:
                    log.info(f"  진행: {done_count}/{len(examples)}")

    # ── 결과 집계 (순서 보장) ──
    writer = SpiderResultWriter(out_dir)
    run_log = []
    success_count = 0
    fail_count = 0
    skip_count = 0

    ex_match_count = 0
    ex_fail_reasons = Counter()
    failure_types = Counter()
    pattern_stats = Counter()
    pattern_ex_match = Counter()
    total_cost_usd = 0.0
    total_tokens = 0

    for (idx, gold_sql, pred_sql, db_id, log_entry) in results:
        writer.add(gold_sql, pred_sql, db_id)
        run_log.append(log_entry)
        status = log_entry["status"]
        if status == "success":
            success_count += 1
        elif status == "skip_no_db":
            skip_count += 1
        else:
            fail_count += 1

        # EX 통계
        if log_entry.get("ex_match"):
            ex_match_count += 1
        elif log_entry.get("ex_reason"):
            ex_fail_reasons[log_entry["ex_reason"][:50]] += 1
        failure_types[log_entry.get("failure_type") or "unknown"] += 1

        # query_pattern 별 통계
        qp = log_entry.get("query_pattern", "unknown")
        pattern_stats[qp] += 1
        if log_entry.get("ex_match"):
            pattern_ex_match[qp] += 1
        total_cost_usd += float(log_entry.get("cost_usd", 0.0) or 0.0)
        total_tokens += int(log_entry.get("total_tokens", 0) or 0)

    total_elapsed = time.time() - t_start
    total_run = len(examples) - skip_count

    # 결과 저장
    gold_path, pred_path = writer.flush()

    # 실행 로그 JSON
    log_path = out_dir / "run_log.json"
    log_path.write_text(json.dumps(run_log, ensure_ascii=False, indent=2), encoding="utf-8")

    # ── 실패 분석 리포트 ──
    fail_entries = [e for e in run_log if not e.get("ex_match")]
    fail_report = {
        "total": len(examples),
        "ex_match": ex_match_count,
        "ex_fail": total_run - ex_match_count,
        "ex_accuracy": round(ex_match_count / total_run * 100, 1) if total_run else 0,
        "pipeline_fail": fail_count,
        "pipeline_success_but_ex_fail": sum(
            1 for e in run_log
            if e.get("status") == "success" and not e.get("ex_match")
        ),
        "failure_type_distribution": dict(failure_types.most_common(20)),
        "fail_reason_distribution": dict(ex_fail_reasons.most_common(20)),
        "pattern_accuracy": {
            p: {
                "total": pattern_stats[p],
                "ex_match": pattern_ex_match.get(p, 0),
                "accuracy": round(pattern_ex_match.get(p, 0) / pattern_stats[p] * 100, 1)
                if pattern_stats[p] else 0,
            }
            for p in sorted(pattern_stats.keys())
        },
        "fail_details": [
            {
                "index": e["index"],
                "db_id": e["db_id"],
                "question": e["question"][:100],
                "status": e["status"],
                "failure_type": e.get("failure_type"),
                "ex_reason": e.get("ex_reason", ""),
                "query_pattern": e.get("query_pattern", ""),
                "repair_count": e.get("repair_count", 0),
                "gold_sql": e.get("gold_sql", "")[:200],
                "pred_sql": e.get("pred_sql", "")[:200],
                "gold_sample": e.get("gold_sample", [])[:2],
                "pred_sample": e.get("pred_sample", [])[:2],
            }
            for e in fail_entries[:100]  # 최대 100건
        ],
    }
    fail_report_path = out_dir / "fail_analysis.json"
    fail_report_path.write_text(
        json.dumps(fail_report, ensure_ascii=False, indent=2), encoding="utf-8")

    # 요약
    summary = {
        "total_examples": len(examples),
        "success": success_count,
        "fail": fail_count,
        "skip": skip_count,
        "ex_match": ex_match_count,
        "ex_accuracy_pct": round(ex_match_count / total_run * 100, 1) if total_run else 0,
        "gold_file": str(gold_path),
        "pred_file": str(pred_path),
        "log_file": str(log_path),
        "fail_analysis_file": str(fail_report_path),
        "elapsed_sec": round(total_elapsed, 1),
        "workers": workers,
        "failure_type_distribution": dict(failure_types.most_common(20)),
        "token_usage": {
            "total_tokens": total_tokens,
            "total_cost_usd": round(total_cost_usd, 6),
        },
        "total_cost_usd": round(total_cost_usd, 6),
        "total_tokens": total_tokens,
    }
    summary_path = out_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    log.info("=" * 60)
    log.info(f"완료: {success_count} 성공 / {fail_count} 실패 / {skip_count} 건너뜀"
             f" ({total_elapsed:.0f}초)")
    log.info(f"EX accuracy (자체 측정): {ex_match_count}/{total_run}"
             f" = {ex_match_count/total_run*100:.1f}%" if total_run else "")
    log.info(f"  파이프라인 실패: {fail_count}")
    log.info(f"  파이프라인 성공 but EX 불일치: "
             f"{sum(1 for e in run_log if e.get('status') == 'success' and not e.get('ex_match'))}")
    log.info(f"gold : {gold_path}")
    log.info(f"pred : {pred_path}")
    log.info(f"log  : {log_path}")
    log.info(f"분석 : {fail_report_path}")
    log.info(f"요약 : {summary_path}")

    # query_pattern별 정확도 출력
    log.info("-" * 40)
    log.info("query_pattern별 EX accuracy:")
    for p in sorted(pattern_stats.keys()):
        cnt = pattern_stats[p]
        ok = pattern_ex_match.get(p, 0)
        pct = ok / cnt * 100 if cnt else 0
        log.info(f"  {p:25s}: {ok:4d}/{cnt:4d} = {pct:5.1f}%")

    # 주요 실패 원인 Top 10
    log.info("-" * 40)
    log.info("EX 실패 원인 Top 10:")
    for reason, cnt in ex_fail_reasons.most_common(10):
        log.info(f"  {reason}: {cnt}건")

    log.info("=" * 60)
    log.info(
        "Spider 공식 평가:\n"
        f"  python evaluation.py --gold {gold_path} --pred {pred_path} "
        f"--db data/spider/database --table data/spider/tables.json --etype all"
    )


if __name__ == "__main__":
    main()
