#!/usr/bin/env python
"""
Spider 공식 평가 연결 스크립트
==========================================================
run_spider_dev.py 출력물 → Spider evaluator 형식으로 변환 + 평가 실행

기능:
  1. pred.txt에서 guardrails가 추가한 LIMIT 50000 제거
  2. Spider evaluator 형식(gold/pred)으로 정리
  3. 공식 evaluator 자동 실행 (--eval-dir 지정 시)

사용 예:
    # 1) 파일 정리만 (LIMIT 제거 + 형식 맞춤)
    python scripts/eval_spider.py --result-dir artifacts/spider_runs/spider_full

    # 2) 공식 evaluator까지 자동 실행
    python scripts/eval_spider.py \
        --result-dir artifacts/spider_runs/spider_full \
        --eval-dir /path/to/test-suite-sql-eval \
        --db data/spider/database \
        --table data/spider/tables.json

    # 3) original Spider evaluator 사용 (test-suite 아님)
    python scripts/eval_spider.py \
        --result-dir artifacts/spider_runs/spider_full \
        --eval-dir /path/to/spider \
        --evaluator original \
        --db data/spider/database \
        --table data/spider/tables.json
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def strip_guardrail_limit(sql: str) -> str:
    """
    guardrails가 추가한 LIMIT 50000 (또는 LIMIT 50000;)을 제거합니다.
    사용자가 명시적으로 작성한 LIMIT (예: LIMIT 1, LIMIT 10)은 유지합니다.
    """
    sql = sql.strip().rstrip(";").strip()
    # LIMIT 50000 (정확히 50000만 제거, 다른 숫자는 유지)
    sql = re.sub(r"\s+LIMIT\s+50000\s*$", "", sql, flags=re.IGNORECASE)
    return sql


def prepare_eval_files(result_dir: Path) -> tuple[Path, Path]:
    """
    result_dir/pred.txt, gold.txt를 정리하여
    result_dir/eval_gold.txt, eval_pred.txt를 생성합니다.

    Returns:
        (eval_gold_path, eval_pred_path)
    """
    gold_src = result_dir / "gold.txt"
    pred_src = result_dir / "pred.txt"

    if not gold_src.exists():
        raise FileNotFoundError(f"gold.txt not found: {gold_src}")
    if not pred_src.exists():
        raise FileNotFoundError(f"pred.txt not found: {pred_src}")

    gold_lines = gold_src.read_text("utf-8").strip().split("\n")
    pred_lines = pred_src.read_text("utf-8").strip().split("\n")

    if len(gold_lines) != len(pred_lines):
        raise ValueError(
            f"gold/pred 줄 수 불일치: gold={len(gold_lines)}, pred={len(pred_lines)}"
        )

    # ── gold 정리 (형식 유지: sql\tdb_id) ──
    eval_gold = result_dir / "eval_gold.txt"

    # ── pred 정리 (LIMIT 제거) ──
    eval_pred = result_dir / "eval_pred.txt"

    cleaned_pred_lines = []
    cleaned_gold_lines = []
    removed_count = 0

    for i, (g, p) in enumerate(zip(gold_lines, pred_lines)):
        # gold: 그대로 유지
        cleaned_gold_lines.append(g)

        # pred: LIMIT 50000 제거
        original = p.strip()
        cleaned = strip_guardrail_limit(original)
        if cleaned != original.rstrip(";").strip():
            removed_count += 1
        cleaned_pred_lines.append(cleaned)

    eval_gold.write_text("\n".join(cleaned_gold_lines) + "\n", encoding="utf-8")
    eval_pred.write_text("\n".join(cleaned_pred_lines) + "\n", encoding="utf-8")

    print(f"[준비 완료]")
    print(f"  총 {len(gold_lines)}개 예제")
    print(f"  LIMIT 50000 제거: {removed_count}건")
    print(f"  eval_gold: {eval_gold}")
    print(f"  eval_pred: {eval_pred}")

    return eval_gold, eval_pred


def run_official_evaluator(
    eval_dir: Path,
    gold_path: Path,
    pred_path: Path,
    db_dir: Path,
    table_path: Path,
    etype: str = "all",
    evaluator: str = "test-suite",
) -> None:
    """Spider 공식 evaluator를 subprocess로 실행합니다."""

    if evaluator == "test-suite":
        # test-suite-sql-eval
        eval_script = eval_dir / "evaluation.py"
        if not eval_script.exists():
            raise FileNotFoundError(
                f"evaluation.py not found in {eval_dir}\n"
                f"test-suite-sql-eval을 다음에서 클론하세요:\n"
                f"  git clone https://github.com/taoyds/test-suite-sql-eval.git"
            )
        cmd = [
            sys.executable, str(eval_script),
            "--gold", str(gold_path),
            "--pred", str(pred_path),
            "--db", str(db_dir),
            "--table", str(table_path),
            "--etype", etype,
        ]
    elif evaluator == "original":
        # Original Spider evaluator
        eval_script = eval_dir / "evaluation.py"
        if not eval_script.exists():
            raise FileNotFoundError(
                f"evaluation.py not found in {eval_dir}"
            )
        cmd = [
            sys.executable, str(eval_script),
            "--gold", str(gold_path),
            "--pred", str(pred_path),
            "--db", str(db_dir),
            "--table", str(table_path),
            "--etype", etype,
        ]
    else:
        raise ValueError(f"Unknown evaluator: {evaluator}")

    print(f"\n[평가 실행]")
    print(f"  명령어: {' '.join(cmd)}\n")

    result = subprocess.run(cmd, capture_output=False, text=True)
    sys.exit(result.returncode)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="Spider 평가 연결: LIMIT 제거 + 공식 evaluator 실행"
    )
    p.add_argument(
        "--result-dir", "-r", type=Path, required=True,
        help="run_spider_dev.py 출력 디렉토리 (gold.txt, pred.txt 포함)"
    )
    p.add_argument(
        "--eval-dir", "-e", type=Path, default=ROOT / "test-suite-sql-eval",
        help="Spider evaluator 디렉토리 (evaluation.py 위치)"
    )
    p.add_argument(
        "--db", type=Path, default=ROOT / "data" / "spider" / "database",
        help="Spider database/ 디렉토리 경로"
    )
    p.add_argument(
        "--table", type=Path, default=ROOT / "data" / "spider" / "tables.json",
        help="Spider tables.json 경로"
    )
    p.add_argument(
        "--etype", choices=["all", "match", "exec"], default="all",
        help="평가 유형: all(전체), match(exact match), exec(execution accuracy)"
    )
    p.add_argument(
        "--evaluator", choices=["test-suite", "original"], default="test-suite",
        help="사용할 evaluator 종류 (기본: test-suite)"
    )
    return p.parse_args()


def main():
    args = parse_args()

    # 1) 파일 정리
    eval_gold, eval_pred = prepare_eval_files(args.result_dir)

    # 2) evaluator 실행 (지정된 경우)
    run_official_evaluator(
        eval_dir=args.eval_dir,
        gold_path=eval_gold,
        pred_path=eval_pred,
        db_dir=args.db,
        table_path=args.table,
        etype=args.etype,
        evaluator=args.evaluator,
    )


if __name__ == "__main__":
    main()
