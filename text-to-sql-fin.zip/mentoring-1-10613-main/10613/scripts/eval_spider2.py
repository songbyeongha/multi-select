#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.config.settings import get_settings
from text2sql.eval.spider2_support import (
    discover_and_validate_spider2_root,
    run_spider2_evaluator,
    write_spider2_summary,
)


def parse_args() -> argparse.Namespace:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Run the official Spider 2.0 evaluator")
    parser.add_argument("--dataset", choices=("lite", "snow"), default=settings.spider2.dataset or "snow")
    parser.add_argument("--spider2-root", type=Path, default=Path(settings.spider2.root) if settings.spider2.root else None)
    parser.add_argument("--result-dir", "-r", type=Path, default=Path(settings.spider2.result_dir) if settings.spider2.result_dir else None)
    parser.add_argument("--gold-dir", type=Path, default=Path(settings.spider2.gold_dir) if settings.spider2.gold_dir else None)
    parser.add_argument("--mode", choices=("sql", "exec_result"), default=settings.spider2.eval_mode or "sql")
    parser.add_argument("--max-workers", type=int, default=settings.spider2.eval_max_workers)
    parser.add_argument("--timeout", type=int, default=settings.spider2.eval_timeout_sec)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    settings = get_settings()
    if args.result_dir is None:
        raise SystemExit("result directory is required. Set --result-dir or T2SQL_SPIDER2_RESULT_DIR.")
    result_dir = args.result_dir.resolve()
    result_dir.mkdir(parents=True, exist_ok=True)
    spider2_root = discover_and_validate_spider2_root(ROOT, args.spider2_root)
    print(
        f"official_eval_start dataset={args.dataset} mode={args.mode} "
        f"result_dir={result_dir}"
    )
    evaluation = run_spider2_evaluator(
        spider2_root=spider2_root,
        dataset=args.dataset,
        result_dir=result_dir,
        mode=args.mode,
        gold_dir=args.gold_dir.resolve() if args.gold_dir else None,
        max_workers=args.max_workers,
        timeout=args.timeout,
    )

    stdout_path = result_dir / "eval_stdout.txt"
    stderr_path = result_dir / "eval_stderr.txt"
    stdout_path.write_text(evaluation["stdout"], encoding="utf-8")
    stderr_path.write_text(evaluation["stderr"], encoding="utf-8")

    summary = {
        "dataset": args.dataset,
        "mode": args.mode,
        "spider2_root": str(spider2_root),
        "result_dir": str(result_dir),
        "snowflake_configured": settings.snowflake.is_configured(),
        "returncode": evaluation["returncode"],
        "command": evaluation["command"],
        "final_score": evaluation["parsed"].get("final_score"),
        "final_correct": evaluation["parsed"].get("final_correct"),
        "final_total": evaluation["parsed"].get("final_total"),
        "real_score": evaluation["parsed"].get("real_score"),
        "real_correct": evaluation["parsed"].get("real_correct"),
        "real_total": evaluation["parsed"].get("real_total"),
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
    }
    summary_path = write_spider2_summary(result_dir / "official_summary.json", summary)
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    print(f"summary_json={summary_path}")
    return int(evaluation["returncode"])


if __name__ == "__main__":
    raise SystemExit(main())
