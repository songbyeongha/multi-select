# 스크립트 가이드

`scripts/`는 `pytest` 바깥에서 직접 실행하는 스크립트 모음입니다.

## CLI 실행 (rich 콘솔 디스플레이)

```bash
# 단일 질문 — Agent 로그, SQL, 비용, 시간 표시
python scripts/run_cli.py --question "전체 고객 수를 구하라"
python scripts/run_cli.py --db monitor --question "서비스별 오류율을 구하라"

# Spider 1.0 배치 — 프로그레스바 + 최종 요약
python scripts/run_cli.py --spider1 --limit 10

# Spider 2.0 배치 — 프로그레스바 + 최종 요약
python scripts/run_cli.py --spider2 --limit 10
```

## 자주 쓰는 명령

### KPI 벤치마크
```bash
python scripts/run_kpi_benchmark.py --mode full --warm
```

### 전체 통합 테스트
```bash
python scripts/run_all_tests.py --mode full --warm --spider-workers 20
```

### 빠른 smoke
```bash
python scripts/run_all_tests.py --mode smoke --warm --spider-workers 20
```

## Spider 1.0

SQL 생성:
```bash
python scripts/run_spider_dev.py --output artifacts/spider_runs/latest --workers 20 --max-retries 5
```

공식 평가 (래퍼):
```bash
python scripts/eval_spider.py --result-dir artifacts/spider_runs/latest
```

공식 평가 (evaluation.py 직접 실행):
```bash
python test-suite-sql-eval/evaluation.py --gold artifacts/spider_runs/latest/gold.txt --pred artifacts/spider_runs/latest/pred.txt --db data/spider/database --table data/spider/tables.json --etype all
```

## Spider 2.0-snow

SQL 생성 + 공식 평가:
```bash
python scripts/run_spider2.py --dataset snow --workers 4 --scope all --max-retries 3 --official-eval
```

공식 평가만 실행:
```bash
python scripts/eval_spider2.py --dataset snow --result-dir artifacts/spider2_runs/cycle2_final
```

분할 실행 (대량 처리 시):
```bash
python scripts/run_spider2_chunked.py --dataset snow --chunk-size 100 --chunk-index 1
```

주요 옵션:
- `--resume`: 이전 실행 이어서 진행
- `--prune-invalid-sql`: 실패한 SQL 삭제 후 재생성
- `--instance-id <id>`: 특정 문제만 실행

## 결과 저장 위치

| 스크립트 | 결과 경로 |
|----------|----------|
| `run_kpi_benchmark.py` | `artifacts/kpi/` |
| `run_all_tests.py` | `artifacts/test_runs/<run_id>/` |
| `run_spider_dev.py` | `artifacts/spider_runs/<name>/` |
| `run_spider2.py` | `artifacts/spider2_runs/<name>/` |

## 종료 코드

| 코드 | 의미 |
|------|------|
| `0` | 성공 |
| `2` | 테스트 실패 또는 점수 미달 |
| `5` | 전부 skip (데이터 또는 credentials 없음) |
