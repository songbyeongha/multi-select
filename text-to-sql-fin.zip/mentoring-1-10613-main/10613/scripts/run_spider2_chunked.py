#!/usr/bin/env python
from __future__ import annotations

import argparse
import json
import logging
import math
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.config.settings import get_settings
from text2sql.datasets.spider2_loader import discover_spider2_root, load_spider2_examples
from text2sql.eval.kpi_runner import has_live_azure_credentials, utc_now_iso
from text2sql.eval.spider2_support import run_spider2_evaluator, write_spider2_summary

LOG = logging.getLogger("spider2_chunked")


def parse_args() -> argparse.Namespace:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Run Spider 2.0 in smaller chunks and aggregate for official evaluation")
    parser.add_argument("--dataset", choices=("lite", "snow"), default=settings.spider2.dataset or "snow")
    parser.add_argument("--spider2-root", type=Path, default=Path(settings.spider2.root) if settings.spider2.root else None)
    parser.add_argument("--output", "-o", type=Path, default=None)
    parser.add_argument("--scope", choices=("local", "all"), default="all")
    parser.add_argument("--chunk-size", type=int, default=25)
    parser.add_argument("--chunk-workers", type=int, default=1, help="How many chunks to execute concurrently")
    parser.add_argument("--chunk-start", type=int, default=1, help="1-based chunk index to start from")
    parser.add_argument("--chunk-stop", type=int, default=0, help="1-based chunk index to stop at, 0 means last chunk")
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--max-retries", type=int, default=3)
    parser.add_argument("--status-every", type=int, default=1)
    parser.add_argument("--official-eval", action="store_true", default=False)
    parser.add_argument("--eval-mode", choices=("sql", "exec_result"), default=settings.spider2.eval_mode or "sql")
    parser.add_argument("--eval-max-workers", type=int, default=settings.spider2.eval_max_workers)
    parser.add_argument("--eval-timeout", type=int, default=settings.spider2.eval_timeout_sec)
    return parser.parse_args()


def make_output_dir(args: argparse.Namespace) -> Path:
    if args.output:
        output_dir = args.output
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = ROOT / "artifacts" / "spider2_runs" / f"{args.dataset}_chunked_{timestamp}"
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "chunks").mkdir(parents=True, exist_ok=True)
    (output_dir / "merged").mkdir(parents=True, exist_ok=True)
    return output_dir


def chunk_count_for(total_examples: int, chunk_size: int) -> int:
    return max(1, math.ceil(total_examples / max(1, chunk_size)))


def resolve_chunk_indexes(total_chunks: int, chunk_start: int, chunk_stop: int) -> list[int]:
    start = max(1, chunk_start)
    stop = chunk_stop if chunk_stop > 0 else total_chunks
    if start > total_chunks or stop > total_chunks or start > stop:
        raise ValueError(f"invalid chunk window: start={start}, stop={stop}, total_chunks={total_chunks}")
    return list(range(start, stop + 1))


def resolve_chunk_workers(requested_workers: int, chunk_indexes: list[int]) -> int:
    return max(1, min(max(1, requested_workers), len(chunk_indexes)))


def build_chunk_command(args: argparse.Namespace, chunk_dir: Path, chunk_index: int) -> list[str]:
    command = [
        sys.executable,
        str(ROOT / "scripts" / "run_spider2.py"),
        "--dataset",
        args.dataset,
        "--scope",
        args.scope,
        "--output",
        str(chunk_dir),
        "--workers",
        str(args.workers),
        "--max-retries",
        str(args.max_retries),
        "--status-every",
        str(args.status_every),
        "--chunk-size",
        str(args.chunk_size),
        "--chunk-index",
        str(chunk_index),
        "--offset",
        str(args.offset),
    ]
    if args.limit is not None:
        command.extend(["--limit", str(args.limit)])
    if args.spider2_root:
        command.extend(["--spider2-root", str(args.spider2_root)])
    return command


def copy_chunk_sql(chunk_dir: Path, merged_dir: Path) -> int:
    copied = 0
    for sql_path in chunk_dir.glob("*.sql"):
        shutil.copy2(sql_path, merged_dir / sql_path.name)
        copied += 1
    return copied


def run_chunk_command(command: list[str], chunk_dir: Path, chunk_index: int) -> dict[str, object]:
    process = subprocess.run(command, cwd=str(ROOT), capture_output=True, text=True, encoding="utf-8")
    stdout_path = chunk_dir / "stdout.txt"
    stderr_path = chunk_dir / "stderr.txt"
    stdout_path.write_text(process.stdout, encoding="utf-8")
    stderr_path.write_text(process.stderr, encoding="utf-8")
    return {
        "chunk_index": chunk_index,
        "returncode": process.returncode,
        "chunk_dir": str(chunk_dir),
        "stdout_path": str(stdout_path),
        "stderr_path": str(stderr_path),
        "summary_path": str(chunk_dir / "summary.json"),
    }


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    args = parse_args()
    output_dir = make_output_dir(args)

    spider2_root = discover_spider2_root(project_root=ROOT, override=args.spider2_root)
    if spider2_root is None:
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "spider2_root_missing",
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    if not has_live_azure_credentials():
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "live_llm_credentials_missing",
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    prefixes = ("local",) if args.scope == "local" else ()
    filtered_examples = load_spider2_examples(
        spider2_root,
        dataset=args.dataset,
        offset=args.offset,
        limit=args.limit,
        instance_prefixes=prefixes,
    )
    total_examples = len(filtered_examples)
    if total_examples == 0:
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "skip",
            "reason": "no_examples_after_filter",
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 5

    total_chunks = chunk_count_for(total_examples, args.chunk_size)
    try:
        chunk_indexes = resolve_chunk_indexes(total_chunks, args.chunk_start, args.chunk_stop)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    chunk_workers = resolve_chunk_workers(args.chunk_workers, chunk_indexes)

    print(
        f"chunked_start dataset={args.dataset} total_examples={total_examples} "
        f"chunk_size={args.chunk_size} chunks={total_chunks} "
        f"run_window={chunk_indexes[0]}-{chunk_indexes[-1]} chunk_workers={chunk_workers}"
    )

    chunk_results: list[dict] = []
    merged_dir = output_dir / "merged"
    future_map = {}
    with ThreadPoolExecutor(max_workers=chunk_workers) as executor:
        for chunk_index in chunk_indexes:
            chunk_dir = output_dir / "chunks" / f"chunk_{chunk_index:03d}"
            chunk_dir.mkdir(parents=True, exist_ok=True)
            command = build_chunk_command(args, chunk_dir, chunk_index)
            print(f"chunk_start index={chunk_index}/{total_chunks} output={chunk_dir}")
            future = executor.submit(run_chunk_command, command, chunk_dir, chunk_index)
            future_map[future] = chunk_dir

        chunk_failed = False
        for future in as_completed(future_map):
            result = future.result()
            chunk_dir = Path(str(result["chunk_dir"]))
            copied = copy_chunk_sql(chunk_dir, merged_dir) if int(result["returncode"]) == 0 else 0
            result["sql_files_copied"] = copied
            chunk_results.append(result)
            print(
                f"chunk_done index={result['chunk_index']}/{total_chunks} "
                f"returncode={result['returncode']} sql_files_copied={copied}"
            )
            if int(result["returncode"]) != 0:
                chunk_failed = True

    chunk_results.sort(key=lambda item: int(item["chunk_index"]))
    if chunk_failed:
        summary = {
            "generated_at": utc_now_iso(),
            "dataset": args.dataset,
            "status": "fail",
            "reason": "chunk_failed",
            "chunk_results": chunk_results,
            "total_examples": total_examples,
            "total_chunks": total_chunks,
            "chunk_size": args.chunk_size,
            "chunk_window": {"start": chunk_indexes[0], "stop": chunk_indexes[-1]},
            "chunk_workers": chunk_workers,
        }
        write_spider2_summary(output_dir / "summary.json", summary)
        print(json.dumps(summary, ensure_ascii=False))
        return 1

    summary: dict[str, object] = {
        "generated_at": utc_now_iso(),
        "dataset": args.dataset,
        "status": "measured",
        "total_examples": total_examples,
        "total_chunks": total_chunks,
        "chunk_size": args.chunk_size,
        "chunk_window": {"start": chunk_indexes[0], "stop": chunk_indexes[-1]},
        "chunk_workers": chunk_workers,
        "merged_dir": str(merged_dir),
        "merged_sql_files": len(list(merged_dir.glob("*.sql"))),
        "chunk_results": chunk_results,
    }

    if args.official_eval:
        evaluation = run_spider2_evaluator(
            spider2_root=spider2_root,
            dataset=args.dataset,
            result_dir=merged_dir,
            mode=args.eval_mode,
            max_workers=args.eval_max_workers,
            timeout=args.eval_timeout,
        )
        stdout_path = output_dir / "eval_stdout.txt"
        stderr_path = output_dir / "eval_stderr.txt"
        stdout_path.write_text(evaluation["stdout"], encoding="utf-8")
        stderr_path.write_text(evaluation["stderr"], encoding="utf-8")
        summary["official_eval"] = {
            "returncode": evaluation["returncode"],
            "final_score": evaluation["parsed"].get("final_score"),
            "final_correct": evaluation["parsed"].get("final_correct"),
            "final_total": evaluation["parsed"].get("final_total"),
            "real_score": evaluation["parsed"].get("real_score"),
            "real_correct": evaluation["parsed"].get("real_correct"),
            "real_total": evaluation["parsed"].get("real_total"),
            "stdout_path": str(stdout_path),
            "stderr_path": str(stderr_path),
        }

    summary_path = write_spider2_summary(output_dir / "summary.json", summary)
    print(f"merged_sql_files={summary['merged_sql_files']}")
    if summary.get("official_eval"):
        print(f"official_real_score={summary['official_eval']['real_score']}")
    print(f"summary_json={summary_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
