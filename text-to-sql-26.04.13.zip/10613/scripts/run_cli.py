#!/usr/bin/env python3
"""Run a single Text-to-SQL query from the terminal."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from rich.panel import Panel

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
load_dotenv(ROOT / ".env")

from text2sql.tools.cli_display import PipelineDisplay, console, print_pipeline_banner


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


def _run_hitl_review(state: dict, display: PipelineDisplay) -> dict:
    """Review SQL before execution in HITL mode."""
    from text2sql.agents.repair_output import node_repair, node_result_output
    from text2sql.agents.validation_nodes import node_execute_preview, node_judge
    from text2sql.lg.state import ErrorType

    sql = state.get("selected_sql") or state.get("preview_sql") or ""
    if not sql:
        candidates = [candidate for candidate in state.get("candidates", []) if candidate.sql]
        if candidates:
            sql = candidates[0].sql

    while True:
        console.print()
        console.print(Panel(sql, title="[bold yellow]Generated SQL[/bold yellow]", border_style="yellow"))
        console.print()
        console.print("[bold]Select action:[/bold]")
        console.print("  [green]y[/green] - Execute this SQL")
        console.print("  [red]n[/red] - Cancel")
        console.print("  [yellow]e[/yellow] - Edit SQL manually")
        console.print("  [cyan]f[/cyan] - Repair with feedback")
        console.print()

        try:
            choice = input("  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "n"

        if choice == "y":
            console.print("  [green]Approved. Executing...[/green]")
            state["selected_sql"] = sql
            state["preview_sql"] = sql
            state = node_execute_preview(state)
            report = state.get("exec_report")
            if report and report.ok:
                state = node_judge(state)
                if state.get("judge_accepted"):
                    state = node_result_output(state)
            elif report:
                display.print_step("ExecutePreview", f"Error: {report.error_message}")
            return state

        if choice == "n":
            console.print("  [red]Cancelled.[/red]")
            state["success"] = False
            state["error"] = "User cancelled"
            return state

        if choice == "e":
            console.print("  [yellow]Enter modified SQL. Finish with an empty line.[/yellow]")
            lines: list[str] = []
            while True:
                try:
                    line = input("  sql> ")
                except (EOFError, KeyboardInterrupt):
                    break
                if not line.strip():
                    break
                lines.append(line)
            if lines:
                sql = "\n".join(lines)
                console.print(f"  [yellow]SQL updated ({len(lines)} lines)[/yellow]")
            else:
                console.print("  [dim]No changes[/dim]")
            continue

        if choice == "f":
            console.print("  [cyan]Enter repair feedback for the model.[/cyan]")
            try:
                feedback = input("  feedback> ").strip()
            except (EOFError, KeyboardInterrupt):
                feedback = ""
            if not feedback:
                console.print("  [dim]No feedback[/dim]")
                continue
            console.print(f"  [cyan]Repairing with feedback: {feedback[:80]}[/cyan]")
            state["judge_accepted"] = False
            state["judge_rationale"] = f"[User feedback] {feedback}"
            state["last_error_type"] = ErrorType.SEMANTIC
            state["last_error_msg"] = feedback
            state["selected_sql"] = sql
            state = node_repair(state)
            new_candidates = [candidate for candidate in state.get("candidates", []) if candidate.sql]
            if new_candidates:
                sql = new_candidates[0].sql
                console.print("  [cyan]LLM generated new SQL[/cyan]")
            else:
                console.print("  [red]Repair failed. Keeping current SQL.[/red]")
            continue

        console.print(f"  [dim]Unknown option: {choice}[/dim]")


def run_single_query(db_id: str, question: str, db_path: str, max_retries: int, *, hitl: bool = False) -> None:
    """Execute a single question through the pipeline."""
    from text2sql.agents._utils import set_cli_display
    from text2sql.lg.graph import get_compiled_graph
    from text2sql.lg.state import new_state
    from text2sql.llm.client import get_token_accumulator

    display = PipelineDisplay()
    display.set_question(question, db_id)
    set_cli_display(display)

    display.print_header()
    if hitl:
        console.print("  [yellow]HITL mode ON: SQL execution requires your approval[/yellow]")
        console.print()

    get_token_accumulator().reset()
    state = new_state(
        question=question,
        database_id=db_id,
        db_path=db_path,
        max_retries=max_retries,
        hitl_enabled=hitl,
    )

    if hitl:
        from text2sql.agents.nodes import (
            node_candidate_generator,
            node_decomposer,
            node_join_planner,
            node_schema_selector,
            node_sql_postprocess,
            node_value_retriever,
        )
        from text2sql.agents.validation_nodes import node_guardrails, node_unit_tester

        for node_fn in [
            node_decomposer,
            node_schema_selector,
            node_value_retriever,
            node_join_planner,
            node_candidate_generator,
            node_sql_postprocess,
            node_guardrails,
            node_unit_tester,
        ]:
            state = node_fn(state)
        final_state = _run_hitl_review(state, display)
    else:
        final_state = get_compiled_graph().invoke(state)

    token_usage = get_token_accumulator().summary()
    success = final_state.get("success", False)
    sql = final_state.get("final_sql", "") or final_state.get("selected_sql", "")
    summary = final_state.get("result_summary", "")

    display.set_result(success, sql, summary, token_usage)
    display.print_result()
    set_cli_display(None)
    _collect_cli_feedback(question, sql, db_id, final_state)


def _collect_cli_feedback(question: str, sql: str, db_id: str, state: dict) -> None:
    """Collect a simple 1-5 feedback score from the CLI user."""
    from text2sql.feedback import FeedbackRecord, FeedbackScore, get_feedback_store, get_learner

    console.print()
    console.print("[bold]결과 피드백 (1~5)[/bold]")
    console.print("  [green]5[/green]=매우좋음  [green]4[/green]=좋음  [yellow]3[/yellow]=보통  [red]2[/red]=나쁨  [red]1[/red]=매우나쁨  [dim]s[/dim]=건너뛰기")

    try:
        choice = input("  피드백 > ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        choice = "s"

    if choice in {"", "s"}:
        console.print("  [dim]건너뜀[/dim]")
        return

    try:
        score = int(choice)
        if score < 1 or score > 5:
            raise ValueError
    except ValueError:
        console.print("  [dim]잘못된 입력으로 건너뜀[/dim]")
        return

    comment = ""
    if score <= 2:
        try:
            comment = input("  코멘트 (무엇이 잘못됐는지) > ").strip()
        except (EOFError, KeyboardInterrupt):
            comment = ""

    feedback_score = FeedbackScore(score)
    record = FeedbackRecord(
        question=question,
        sql=sql,
        database_id=db_id,
        score=score,
        user_comment=comment,
        query_pattern=state.get("query_pattern", ""),
        dialect=state.get("dialect", "sqlite"),
        tables_used=state.get("selected_tables", []),
    )
    get_feedback_store().add(record)
    try:
        learn_result = get_learner().learn(db_id)
    except Exception as e:
        console.print(f"  [yellow]도메인 정보 갱신 중 오류 (피드백은 저장됨): {e}[/yellow]")
        return

    console.print(f"  {feedback_score.emoji} 피드백 저장 완료 ({feedback_score.label_ko})")
    if learn_result.get("few_shots_added", 0) > 0:
        console.print(f"  [green]좋은 SQL을 자동 학습 데이터에 반영했습니다 (+{learn_result['few_shots_added']})[/green]")
    if learn_result.get("keywords_added", 0) > 0:
        console.print(f"  [green]키워드 매핑을 자동 확장했습니다 (+{learn_result['keywords_added']})[/green]")
    if learn_result.get("errors_logged", 0) > 0:
        console.print("  [yellow]오류 패턴을 기록해 다음 질문에 반영합니다[/yellow]")


def parse_args() -> argparse.Namespace:
    default_db = os.getenv("T2SQL_DB_ID", "").strip() or "oracle_db"
    parser = argparse.ArgumentParser(description="Text-to-SQL CLI with rich console display")
    parser.add_argument("--db", type=str, default=default_db, help=f"Database ID (default: {default_db})")
    parser.add_argument("--question", "-q", type=str, default=None, help="질문")
    parser.add_argument("--max-retries", type=int, default=3, help="최대 재시도 횟수")
    parser.add_argument("--hitl", action="store_true", help="HITL 모드: SQL 실행 전 사용자 검토")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    print_pipeline_banner()

    if not args.question:
        console.print("[yellow]--question 옵션을 지정해 주세요[/yellow]")
        console.print()
        console.print("예시:")
        console.print('  python scripts/run_cli.py --db mfg_oracle_demo -q "안전재고보다 현재고가 낮은 품목을 보여줘"')
        console.print('  python scripts/run_cli.py --db mfg_oracle_demo -q "공장별 진행 중인 생산오더 수를 보여줘" --hitl')
        return

    from text2sql.config.settings import get_settings

    settings = get_settings()
    if settings.db.dialect == "oracle":
        db_path = "__oracle__"
    else:
        from text2sql.tools.db_registry import resolve_db_path

        db_path = resolve_db_path(args.db)

    run_single_query(args.db, args.question, db_path, args.max_retries, hitl=args.hitl)


if __name__ == "__main__":
    main()
