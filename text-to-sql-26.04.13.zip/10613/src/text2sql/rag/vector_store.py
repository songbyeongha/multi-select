"""
벡터 스토어  ──  Chroma + Embeddings 기반 스키마 시맨틱 검색
═══════════════════════════════════════════════════════════════
필수 의존성: chromadb, openai

사용 흐름:
  1. get_vector_store(db_id) 호출 시 인덱스 미빌드면 자동 빌드
  2. SchemaSelector.select() 에서 hybrid_search() 호출
  3. BM25 스코어 + 벡터 유사도 가중합으로 최종 테이블 선택
"""
from __future__ import annotations
import logging
import json
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from ..config.metadata_utils import payload_fingerprint
from ..config.settings import get_settings
from ..llm.client import build_azure_openai_client, build_openai_compatible_client

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Embedding 함수 — Provider-agnostic
# ═══════════════════════════════════════════════════════════════
class Embedder:
    """Provider-agnostic Embeddings 클라이언트.

    지원 provider:
      - azure_openai: AzureOpenAI 클라이언트
      - openai_compatible: OpenAI(base_url=...) 클라이언트
    """

    def __init__(self):
        cfg = get_settings().embed

        if cfg.provider == "azure_openai":
            if not cfg.endpoint or not cfg.azure_api_key:
                raise RuntimeError(
                    "Embedding 설정 누락 (azure_openai: SKCC_AZURE_ENDPOINT/KEY, "
                    "openai_compatible: T2SQL_EMBED_BASE_URL/API_KEY 확인)")
            self._client = build_azure_openai_client(
                azure_endpoint=cfg.endpoint,
                api_key=cfg.azure_api_key,
                api_version=cfg.api_version,
            )
            self._model = cfg.deployment
        else:
            if not cfg.base_url or not cfg.api_key:
                raise RuntimeError(
                    "OpenAI-compatible Embedding 설정 누락 "
                    "(T2SQL_EMBED_BASE_URL, T2SQL_EMBED_API_KEY 확인)")
            self._client = build_openai_compatible_client(
                base_url=cfg.base_url,
                api_key=cfg.api_key,
            )
            self._model = cfg.model

        self._cache: Dict[str, List[float]] = {}

    def embed(self, texts: List[str]) -> List[List[float]]:
        """텍스트 리스트 → 임베딩 벡터 리스트"""
        resp = self._client.embeddings.create(input=texts, model=self._model)
        results = [d.embedding for d in resp.data]
        for text, vec in zip(texts, results):
            self._cache[text] = vec
        return results

    def embed_one(self, text: str) -> List[float]:
        """단일 텍스트 임베딩 (캐시 활용)"""
        if text in self._cache:
            return self._cache[text]
        result = self.embed([text])[0]
        return result


# ═══════════════════════════════════════════════════════════════
# Chroma 벡터 스토어
# ═══════════════════════════════════════════════════════════════
_STORE_DIR = Path(__file__).resolve().parents[3] / "data" / "vector_store"
_MANIFEST_PATH = _STORE_DIR / "manifest.json"

# 경로별 PersistentClient 싱글톤 — 같은 경로에 여러 인스턴스 생성 방지
_chroma_clients: Dict[str, "chromadb.PersistentClient"] = {}
_chroma_client_lock = threading.Lock()


def _get_chroma_client(persist_dir: str) -> "chromadb.PersistentClient":
    """같은 persist_dir에 대해 PersistentClient를 단 하나만 생성한다."""
    with _chroma_client_lock:
        if persist_dir not in _chroma_clients:
            _chroma_clients[persist_dir] = chromadb.PersistentClient(
                path=persist_dir,
                settings=ChromaSettings(anonymized_telemetry=False),
            )
        return _chroma_clients[persist_dir]


class SchemaVectorStore:
    """
    DB 스키마를 벡터화하여 Chroma에 저장·검색하는 클래스.

    컬렉션명: schema_{db_id}
    문서: 테이블별 텍스트 (테이블명 + 컬럼 + FK + 샘플)
    메타데이터: table_name, column_count, has_fk
    """

    def __init__(self, db_id: str, persist_dir: Path | str | None = None):
        self._db_id = db_id
        self._persist_dir = str(persist_dir or _STORE_DIR)
        # 같은 경로에 여러 PersistentClient 생성 방지 (SQLite lock 충돌)
        self._client = _get_chroma_client(self._persist_dir)
        self._collection_name = f"schema_{db_id}"
        self._collection = self._client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder: Optional[Embedder] = None

    @property
    def embedder(self) -> Embedder:
        if self._embedder is None:
            self._embedder = Embedder()
        return self._embedder

    # ── 인덱스 빌드 ───────────────────────────────────────
    def build_index(self, schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None):
        """
        스키마 정보로 벡터 인덱스 빌드 (기존 인덱스 덮어쓰기).

        Args:
            schema: SchemaReader.full_schema() 결과
            meta: schema_metadata 딕셔너리 (설명, 샘플값 등)
        """
        try:
            self._client.delete_collection(self._collection_name)
        except Exception:
            pass
        self._collection = self._client.create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )

        tables_meta = (meta or {}).get("tables", {})
        ids, docs, metadatas = [], [], []

        for tbl in schema:
            tname = tbl["table_name"]
            doc = self._table_to_text(tbl, tables_meta.get(tname, {}))
            ids.append(tname)
            docs.append(doc)
            metadatas.append({
                "table_name": tname,
                "column_count": len(tbl.get("columns", [])),
                "has_fk": len(tbl.get("foreign_keys", [])) > 0,
            })

        embeddings = self.embedder.embed(docs)
        self._collection.add(
            ids=ids,
            documents=docs,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        logger.info(f"[{self._db_id}] 벡터 인덱스 빌드 완료: {len(schema)}개 테이블")

    # ── 검색 ──────────────────────────────────────────────
    def search(self, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        질문과 유사한 테이블 검색.

        Returns:
            [{"table_name": str, "score": float, "document": str}, ...]
            score: cosine similarity (0~1, 높을수록 유사)
        """
        if self._collection.count() == 0:
            return []

        query_embedding = self.embedder.embed_one(question)
        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, self._collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        for i, doc_id in enumerate(results["ids"][0]):
            # Chroma cosine distance → similarity
            distance = results["distances"][0][i]
            similarity = 1.0 - distance  # cosine distance → similarity
            hits.append({
                "table_name": doc_id,
                "score": similarity,
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
            })
        return hits

    def is_indexed(self) -> bool:
        """인덱스가 빌드되었는지 확인"""
        return self._collection.count() > 0

    # ── 내부 ──────────────────────────────────────────────
    @staticmethod
    def _table_to_text(tbl: Dict[str, Any],
                       tmeta: Dict[str, Any] | None = None) -> str:
        """테이블 정보를 검색용 텍스트로 변환"""
        tmeta = tmeta or {}
        parts = [f"테이블: {tbl['table_name']}"]
        aliases = tbl.get("table_aliases") or tmeta.get("aliases") or tmeta.get("table_aliases") or []
        if aliases:
            parts.append("별칭: " + ", ".join(str(a) for a in aliases[:8]))

        desc = tmeta.get("description", "")
        if desc:
            parts.append(f"설명: {desc}")

        col_meta = tmeta.get("columns", {})
        col_parts = []
        for c in tbl.get("columns", []):
            cname = c["name"] if isinstance(c, dict) else str(c)
            ctype = c.get("type", "") if isinstance(c, dict) else ""
            cdesc = ""
            if isinstance(col_meta, dict):
                cm = col_meta.get(cname, {})
                cdesc = cm.get("description", "") if isinstance(cm, dict) else str(cm) if cm else ""
            col_str = f"{cname} ({ctype})"
            if cdesc:
                col_str += f" - {cdesc}"
            col_parts.append(col_str)
        parts.append("컬럼: " + ", ".join(col_parts))

        fk_parts = []
        for fk in tbl.get("foreign_keys", []):
            fk_parts.append(f"{fk['from']} → {fk['to_table']}.{fk['to_column']}")
        if fk_parts:
            parts.append("관계: " + ", ".join(fk_parts))

        # 컬럼 레벨 sample_values만 사용 (값이 없는 컬럼 제외)
        sample_text = tbl.get("sample_text") or tmeta.get("sample_text") or ""
        if sample_text:
            parts.append(f"예시: {sample_text}")
        else:
            rendered = []
            for c in tbl.get("columns", []):
                if not isinstance(c, dict):
                    continue
                col_sv = c.get("sample_values") or []
                if col_sv:
                    cname = c["name"]
                    rendered.append(f"{cname}={', '.join(str(v) for v in col_sv[:3])}")
            if rendered:
                parts.append("예시: " + "; ".join(rendered[:8]))

        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════
# 자동 인덱스 빌드
# ═══════════════════════════════════════════════════════════════
def _load_schema_and_meta(db_id: str) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    인덱스 구축/검증에 필요한 schema + metadata 로드.

    우선순위:
      1. schema_metadata에 tables 정의 있으면 → metadata-first (DB 연결 불필요)
      2. 없으면 → DB 직접 조회 (Oracle: '__oracle__' sentinel, SQLite: 파일 경로)
    """
    from ..tools.executor import SchemaReader
    from ..config.settings import get_settings

    settings = get_settings()
    meta = settings.schema_metadata(db_id)

    if meta.get("tables"):
        schema = SchemaReader.from_meta(meta)
    else:
        if settings.db.dialect == "oracle":
            db_path = "__oracle__"
        else:
            from ..tools.db_registry import resolve_db_path
            db_path = resolve_db_path(db_id)
        schema = SchemaReader.full_schema(db_path)

    return schema, meta


def _schema_fingerprint(schema: List[Dict[str, Any]], meta: Dict[str, Any]) -> str:
    payload = meta if meta.get("tables") else {"schema": schema}
    return payload_fingerprint(payload)


def _load_manifest() -> Dict[str, Any]:
    if not _MANIFEST_PATH.exists():
        return {}
    try:
        return json.loads(_MANIFEST_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save_manifest(manifest: Dict[str, Any]) -> None:
    _MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    _MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _ensure_index(store: SchemaVectorStore, db_id: str, *, force: bool = False) -> None:
    schema, meta = _load_schema_and_meta(db_id)
    fingerprint = _schema_fingerprint(schema, meta)
    manifest = _load_manifest()
    current = manifest.get(db_id, {})
    has_index = store.is_indexed()
    known_fingerprint = current.get("fingerprint")
    is_stale = known_fingerprint not in (None, fingerprint)

    if has_index and known_fingerprint is None and not force:
        manifest[db_id] = {
            "fingerprint": fingerprint,
            "table_count": len(schema),
        }
        _save_manifest(manifest)
        return

    if force or not has_index or is_stale:
        reason = "force rebuild" if force else "stale metadata" if is_stale else "missing index"
        logger.debug(f"[{db_id}] 벡터 인덱스 재구축 시작 ({reason})")
        store.build_index(schema, meta)
        manifest[db_id] = {
            "fingerprint": fingerprint,
            "table_count": len(schema),
        }
        _save_manifest(manifest)


# ═══════════════════════════════════════════════════════════════
# 유틸리티
# ═══════════════════════════════════════════════════════════════
_stores: Dict[str, SchemaVectorStore] = {}
_failed_dbs: set = set()
_store_lock = threading.Lock()


def get_vector_store(db_id: str) -> SchemaVectorStore:
    """벡터 스토어 싱글톤 — 인덱스 미빌드/오래된 경우 자동 재구축.

    멀티스레드 환경(Streamlit 등)에서 동시 호출 시 중복 초기화·SQLite lock 충돌 방지.
    """
    # 빠른 경로: 이미 캐시된 경우 lock 없이 반환
    if db_id in _failed_dbs:
        raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")
    if db_id in _stores:
        return _stores[db_id]

    with _store_lock:
        # lock 획득 후 재확인 (double-checked locking)
        if db_id in _failed_dbs:
            raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")
        if db_id in _stores:
            return _stores[db_id]
        try:
            store = SchemaVectorStore(db_id)
            _ensure_index(store, db_id)
            _stores[db_id] = store
        except Exception as e:
            _failed_dbs.add(db_id)
            logger.debug(f"[{db_id}] 벡터 스토어 초기화 실패 (BM25로 대체): {e}")
            raise

    return _stores[db_id]


def rebuild_vector_store(db_id: str) -> SchemaVectorStore:
    """최신 metadata/schema 기준으로 벡터 인덱스를 강제 재구축."""
    with _store_lock:
        store = _stores.get(db_id) or SchemaVectorStore(db_id)
        _stores[db_id] = store
        _failed_dbs.discard(db_id)
        _ensure_index(store, db_id, force=True)
    return store
