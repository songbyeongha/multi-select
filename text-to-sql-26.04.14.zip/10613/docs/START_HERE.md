# 처음 시작하는 분께

Oracle DB에 Text-to-SQL을 처음 연결하는 분을 위한 가이드입니다.
**이 문서만 읽어도 첫 연결까지 완료할 수 있습니다.**

---

## 1단계 — 환경 설치

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Python 3.10 이상을 권장합니다.

---

## 2단계 — .env 설정

```powershell
copy .env.example .env
```

`.env` 파일을 열어 아래 항목을 실제 값으로 수정합니다.

```env
T2SQL_DB_HOST=<Oracle 호스트>
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=<서비스명>
T2SQL_DB_USER=<계정>
T2SQL_DB_PASSWORD=<비밀번호>
T2SQL_DB_SCHEMA=<스키마>
```

LLM은 기본값이 **로컬 Ollama (qwen3:8b)** 입니다.
Azure OpenAI를 사용하려면 `.env.example` 주석을 참고하세요.

---

## 3단계 — Oracle 연결 확인

```powershell
.venv\Scripts\python.exe scripts\run_ops.py doctor
```

`[OK]` 메시지가 나오면 연결 성공입니다.
오류가 나오면 [operations/ORACLE_DB_QUICKSTART.md](operations/ORACLE_DB_QUICKSTART.md)를 확인하세요.

---

## 4단계 — 메타데이터 준비

```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id oracle_prod
```

이 명령은:
1. Oracle 스키마에서 테이블/컬럼 메타데이터를 추출합니다.
2. LLM으로 컬럼 설명, 도메인 힌트를 자동 생성합니다.
3. 결과를 `src/text2sql/config/generated/` 에 저장합니다.

처음 실행 시 테이블 수에 따라 수 분이 걸릴 수 있습니다.

---

## 5단계 — 첫 질문 실행

```powershell
.venv\Scripts\python.exe scripts\run_cli.py -q "최근 한 달 생산량을 보여줘"
```

SQL이 생성되고 결과 미리보기가 출력되면 성공입니다.

---

## 6단계 — Web UI 실행 (선택)

```powershell
.venv\Scripts\python.exe -m streamlit run app.py
```

브라우저에서 `http://localhost:8501`을 열면 채팅 UI를 사용할 수 있습니다.

---

## 한 번에 실행 (first-run)

위 3~5단계를 한 번에 실행하는 단축 명령입니다.

```powershell
.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id oracle_prod
```

E2E 테스트 카탈로그가 있으면:

```powershell
.venv\Scripts\python.exe scripts\run_ops.py first-run ^
    --db-id oracle_prod ^
    --smoke-question "최근 한 달 생산량은?" ^
    --run-e2e --catalog data/catalog.json
```

---

## 다음 단계

| 하고 싶은 것 | 참고 문서 |
|-------------|-----------|
| Oracle 설치/설정 문제 | [operations/ORACLE_DB_QUICKSTART.md](operations/ORACLE_DB_QUICKSTART.md) |
| 첫 연결 단계 상세 | [operations/FIRST_PRODUCTION_ATTACH.md](operations/FIRST_PRODUCTION_ATTACH.md) |
| 자주 쓰는 명령 한눈에 | [operations/OPERATOR_ONE_PAGE.md](operations/OPERATOR_ONE_PAGE.md) |
| 어떤 스크립트를 써야 할지 | [operations/SCRIPT_SELECTION_GUIDE.md](operations/SCRIPT_SELECTION_GUIDE.md) |
| 메타데이터 품질 개선 | [metadata/SQL_METADATA_ENRICHMENT.md](metadata/SQL_METADATA_ENRICHMENT.md) |
| 코드 구조 이해 | [CODEBASE_GUIDE.md](CODEBASE_GUIDE.md) |
