# Oracle DB 빠른 설치 / 설정 가이드

Oracle DB에 처음 연결할 때 발생하는 일반적인 설정 문제를 정리합니다.

---

## python-oracledb 연결 모드

이 시스템은 `python-oracledb` 라이브러리를 사용합니다. 두 가지 모드가 있습니다.

| 모드 | 설명 | Oracle Instant Client 필요 |
|------|------|---------------------------|
| **Thin mode** (기본) | 순수 Python 드라이버. 대부분의 환경에서 작동 | 불필요 |
| **Thick mode** | OCI 기반. 일부 기업 환경에서 필요 | 필요 |

### Thin mode 설정 (기본 — 추가 설치 없음)

```env
# .env — thick mode 관련 항목 없음(주석 처리)
# T2SQL_DB_THICK_MODE=true
# T2SQL_DB_LIB_DIR=...
```

### Thick mode 설정

Oracle Instant Client가 필요한 경우:

1. [Oracle Instant Client 다운로드](https://www.oracle.com/database/technologies/instant-client/downloads.html) (Basic 패키지)
2. 압축 해제 후 경로 확인 (예: `C:\oracle\instantclient_21_13`)
3. `.env`에 추가:

```env
T2SQL_DB_THICK_MODE=true
T2SQL_DB_LIB_DIR=C:\oracle\instantclient_21_13
```

---

## 연결 오류 해결

### ORA-12541: TNS:no listener

Oracle 리스너가 실행되지 않거나 HOST/PORT가 틀린 경우.

```env
# .env 확인
T2SQL_DB_HOST=<정확한 호스트 주소>
T2SQL_DB_PORT=1521
```

로컬 Oracle의 경우 리스너 시작:
```bash
lsnrctl start
```

---

### ORA-01017: invalid username/password

```env
T2SQL_DB_USER=<정확한 계정>
T2SQL_DB_PASSWORD=<정확한 비밀번호>
```

비밀번호에 특수문자(`@`, `#`, `!`)가 있으면 `.env` 값에 따옴표 불필요 — 그대로 입력합니다.

---

### ORA-12514: TNS:listener does not currently know of service

서비스명이 틀린 경우.

```env
T2SQL_DB_SERVICE_NAME=<정확한 서비스명>
```

서비스명 확인 방법 (DBA 문의 또는):
```sql
SELECT VALUE FROM V$PARAMETER WHERE NAME = 'service_names';
-- 또는
SELECT NAME FROM V$SERVICES;
```

Oracle 23c Free / XE 기본값: `FREEPDB1`, `XEPDB1`

---

### DPY-6001: thick mode required

일부 Oracle 환경(구버전 또는 기업 망)에서 thin mode가 거부되는 경우.

```env
T2SQL_DB_THICK_MODE=true
T2SQL_DB_LIB_DIR=/path/to/instantclient
```

---

### DPY-4011: init_oracle_client 미지원

`python-oracledb` 버전이 낮은 경우:

```powershell
pip install "oracledb>=1.0"
```

---

## 메타뷰 접근 권한

`run_ops.py doctor` 실행 시 아래 뷰에 SELECT 권한이 필요합니다.

| 뷰 | 용도 |
|----|------|
| `ALL_TABLES` | 접근 가능 테이블 목록 |
| `ALL_COLUMNS` | 컬럼 정보 |
| `ALL_CONSTRAINTS` | FK / PK 정보 |
| `ALL_COL_COMMENTS` | 컬럼 주석 |
| `ALL_TAB_COMMENTS` | 테이블 주석 |

권한 부여 (DBA 계정으로):
```sql
GRANT SELECT ON ALL_TABLES TO <your_user>;
GRANT SELECT ON ALL_COLUMNS TO <your_user>;
GRANT SELECT ON ALL_CONSTRAINTS TO <your_user>;
GRANT SELECT ON ALL_COL_COMMENTS TO <your_user>;
GRANT SELECT ON ALL_TAB_COMMENTS TO <your_user>;
```

---

## Oracle 23c Free 로컬 설치 (데모용)

빠른 로컬 테스트 환경이 필요할 때:

```bash
# Docker 사용
docker run -d \
  --name oracle23c \
  -p 1521:1521 \
  -e ORACLE_PASSWORD=yourpassword \
  container-registry.oracle.com/database/free:latest
```

```env
T2SQL_DB_HOST=localhost
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=FREEPDB1
T2SQL_DB_USER=system
T2SQL_DB_PASSWORD=yourpassword
T2SQL_DB_SCHEMA=system
```

데모 스키마(제조업)를 한 번에 구축하려면:
```powershell
.venv\Scripts\python.exe scripts\run_ops.py demo ^
    --admin-user system ^
    --admin-password yourpassword ^
    --service-name FREEPDB1 ^
    --schema-user t2sql_demo ^
    --schema-password demo123
```

---

## 연결 확인

```powershell
.venv\Scripts\python.exe scripts\run_ops.py doctor
```

모든 항목이 `[OK]`면 정상입니다.
