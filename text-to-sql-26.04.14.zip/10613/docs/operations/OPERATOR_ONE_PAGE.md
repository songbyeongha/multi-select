# 운영자 한 장 참조 카드

---

## 진입점 3가지

| 진입점 | 용도 |
|--------|------|
| `scripts/run_ops.py` | 운영 작업 (연결 확인, 메타데이터, 배포) |
| `scripts/run_cli.py` | 단건 질문 → SQL 실행 |
| `app.py` (Streamlit) | 채팅 UI |

---

## run_ops.py 워크플로

```
처음 도입:  doctor → prepare → test → release
매일 운영:  daily  (또는 maintain)
```

### 자주 쓰는 명령

```powershell
# 연결 확인
.venv\Scripts\python.exe scripts\run_ops.py doctor

# 메타데이터 준비 (처음 또는 DB 변경 시)
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id oracle_prod

# 단건 질문
.venv\Scripts\python.exe scripts\run_cli.py -q "최근 한 달 생산량은?"

# 매일 유지보수
.venv\Scripts\python.exe scripts\run_ops.py daily --db-id oracle_prod

# Web UI 실행
.venv\Scripts\python.exe -m streamlit run app.py

# 워크플로 전체 보기
.venv\Scripts\python.exe scripts\run_ops.py usage
```

---

## run_ops.py 서브커맨드 일람

| 명령 | 단계 | 설명 |
|------|------|------|
| `usage` | — | 전체 운영 가이드 출력 |
| `doctor` | 1 | Oracle 연결 + 메타뷰 접근 확인 |
| `first-run` | 통합 | doctor + prepare + (선택) smoke/E2E |
| `prepare` | 2 | 메타데이터 추출 + LLM 자동 강화 |
| `test` | 3 | E2E 회귀 테스트 |
| `release` | 4 | 배포 게이트 (E2E + pytest + vulture) |
| `daily` | 매일 | doctor + maintain 일괄 실행 |
| `maintain` | 정기 | 메타데이터 갱신 + 벡터 재구축 + 학습 |
| `demo` | 선택 | 제조업 데모 스키마 구축 |

---

## .env 핵심 항목

```env
T2SQL_DB_HOST=<호스트>
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=<서비스명>
T2SQL_DB_USER=<계정>
T2SQL_DB_PASSWORD=<비밀번호>
T2SQL_DB_SCHEMA=<스키마>
T2SQL_DB_READ_ONLY=true

T2SQL_LLM_PROVIDER=openai_compatible
T2SQL_LLM_BASE_URL=http://localhost:11434/v1
T2SQL_LLM_MODEL_PRIMARY=qwen3:8b
```

---

## 생성 파일 위치

| 파일 | 내용 |
|------|------|
| `src/text2sql/config/generated/schema_metadata_oracle.json` | 자동 추출 메타데이터 |
| `src/text2sql/config/generated/domain_hints_oracle.json` | LLM 생성 도메인 힌트 |
| `src/text2sql/config/generated/schema_metadata_oracle_manual.json` | 수동 편집 오버레이 |
| `data/feedback/` | 피드백 저장 |
| `data/vector_store/` | ChromaDB 벡터 인덱스 |

---

## 도움말

```powershell
# 전체 서브커맨드 목록
.venv\Scripts\python.exe scripts\run_ops.py --help

# 특정 서브커맨드 옵션
.venv\Scripts\python.exe scripts\run_ops.py prepare --help

# 실행 없이 명령어만 확인 (dry-run)
.venv\Scripts\python.exe scripts\run_ops.py --dry-run prepare --db-id oracle_prod
```
