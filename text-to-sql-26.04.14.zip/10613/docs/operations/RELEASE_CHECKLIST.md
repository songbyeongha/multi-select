# 배포 체크리스트

코드 또는 설정 변경 후 운영 배포 전에 확인하는 항목입니다.

---

## 자동 배포 게이트

아래 명령 하나로 E2E + pytest + 데드코드 검사를 순서대로 실행합니다.

```powershell
.venv\Scripts\python.exe scripts\run_ops.py release ^
    --db-id oracle_prod ^
    --catalog data/catalog.json
```

모든 단계가 통과해야 배포합니다.

---

## 수동 체크리스트

### 1. 환경 / 연결

- [ ] `.env` 운영 DB 정보가 정확한지 확인
- [ ] `run_ops.py doctor` — `[OK]` 확인
- [ ] LLM 엔드포인트 응답 확인

### 2. 메타데이터

- [ ] 스키마 변경이 있었다면 `run_ops.py prepare` 실행 완료
- [ ] `src/text2sql/config/generated/` 파일이 최신인지 확인
- [ ] 수동 오버레이(`_manual.json`)가 최신 업무 용어를 반영하는지 확인

### 3. E2E 테스트

```powershell
.venv\Scripts\python.exe scripts\run_ops.py test ^
    --db-id oracle_prod ^
    --catalog data/catalog.json ^
    --report data/release_e2e_report.json
```

- [ ] 카탈로그 전체 케이스 통과율 확인
- [ ] 실패한 케이스 원인 분석 완료

### 4. 단위 테스트

```powershell
.venv\Scripts\python.exe -m pytest tests/ -v
```

- [ ] 모든 테스트 통과

### 5. 코드 품질

```powershell
# 데드코드 검사
.venv\Scripts\python.exe -m vulture src/ --min-confidence 80
```

- [ ] 심각한 데드코드 없음

### 6. 보안

- [ ] `.env` 파일이 git에 커밋되지 않았는지 확인 (`.gitignore` 확인)
- [ ] `T2SQL_DB_READ_ONLY=true` 유지 확인
- [ ] 비밀번호/키가 코드에 하드코딩되지 않았는지 확인

---

## release 서브커맨드 옵션

```powershell
# E2E 건너뜀 (기존 결과 재사용)
release --db-id oracle_prod --skip-e2e

# pytest 건너뜀
release --db-id oracle_prod --catalog data/catalog.json --skip-pytest

# 결과 저장
release --db-id oracle_prod --catalog data/catalog.json ^
    --report data/release_report.json
```

---

## 배포 후 확인

배포 직후:

```powershell
# 연결 + 유지보수
.venv\Scripts\python.exe scripts\run_ops.py daily --db-id oracle_prod

# 스모크 질문
.venv\Scripts\python.exe scripts\run_cli.py -q "테스트 질문"
```

- [ ] 스모크 질문 SQL 생성 및 결과 정상 확인
- [ ] Web UI (`app.py`) 접속 확인
