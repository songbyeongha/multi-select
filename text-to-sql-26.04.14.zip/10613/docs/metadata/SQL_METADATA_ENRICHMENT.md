# 스키마 메타데이터 강화 가이드

Text-to-SQL 품질은 메타데이터 품질에 직결됩니다.
이 문서는 자동 추출된 메타데이터를 업무 맥락에 맞게 보완하는 방법을 설명합니다.

---

## 메타데이터 파일 구조

```
src/text2sql/config/generated/
  schema_metadata_oracle.json        ← [자동] Oracle 메타뷰에서 추출
  schema_metadata_oracle_manual.json ← [수동] 오버레이 (여기를 편집)
  domain_hints_oracle.json           ← [자동] LLM이 생성한 도메인 힌트
  domain_hints_oracle_manual.json    ← [수동] 도메인 힌트 오버레이
```

**자동 파일은 `prepare` 실행 시 덮어써집니다.** 수동 편집은 반드시 `_manual.json` 파일에 하세요.

---

## 1단계 — 자동 추출 실행

```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id oracle_prod
```

완료 후 `schema_metadata_oracle.json`에 모든 테이블·컬럼 정보가 저장됩니다.

---

## 2단계 — 자동 생성 결과 확인

`schema_metadata_oracle.json` 을 열어 LLM이 생성한 설명을 검토합니다.

```json
{
  "tables": {
    "PROD_RESULT": {
      "description": "생산 실적 테이블",
      "columns": {
        "PROD_QTY": {
          "description": "생산 수량",
          "domain_hint": "실적 집계 시 SUM 사용"
        }
      }
    }
  }
}
```

---

## 3단계 — 수동 오버레이 편집

자동 생성 내용이 틀리거나 부족하면 `schema_metadata_oracle_manual.json` 에 덮어쓸 내용을 추가합니다.

### 오버레이 형식

```json
{
  "tables": {
    "PROD_RESULT": {
      "description": "일별 공장별 생산 실적. 주문 대비 실적 분석에 사용.",
      "columns": {
        "PROD_DATE": {
          "description": "생산 날짜 (YYYYMMDD 문자열)",
          "domain_hint": "날짜 필터 시 TO_DATE(PROD_DATE, 'YYYYMMDD') 사용"
        },
        "PROD_QTY": {
          "description": "생산 수량 (단위: EA)",
          "domain_hint": "공장별 합계는 SUM(PROD_QTY) GROUP BY FACTORY_CD"
        }
      }
    }
  }
}
```

`_manual.json`에 있는 항목이 자동 파일의 동일 항목을 덮어씁니다.

---

## 4단계 — 도메인 힌트 강화

`domain_hints_oracle_manual.json`에 업무 도메인 용어 매핑을 추가합니다.

```json
{
  "term_mappings": {
    "안전재고": "SAFETY_STOCK_QTY",
    "현재고": "CURR_STOCK_QTY",
    "LOT": "LOT_NO",
    "공정": "PROCESS_CD"
  },
  "query_patterns": {
    "재고 부족": "WHERE CURR_STOCK_QTY < SAFETY_STOCK_QTY",
    "이번 달": "TRUNC(SYSDATE, 'MM') <= 날짜컬럼 AND 날짜컬럼 < ADD_MONTHS(TRUNC(SYSDATE, 'MM'), 1)"
  }
}
```

---

## 5단계 — 변경 후 벡터 재구축

메타데이터를 수정한 후에는 벡터 인덱스를 재구축해야 반영됩니다.

```powershell
.venv\Scripts\python.exe scripts\run_ops.py maintain ^
    --db-id oracle_prod ^
    --no-metadata ^
    --no-enrich
```

`--no-metadata` / `--no-enrich` 는 추출/강화를 건너뛰고 벡터 재구축만 실행합니다.

---

## 품질 개선 전략

### 컬럼 설명이 부정확한 경우

자동 생성 설명은 컬럼명을 기반으로 추측합니다.
실제 업무 의미와 다르면 `_manual.json`에서 정확한 설명으로 교체하세요.

```json
{
  "columns": {
    "CD": {
      "description": "공장 코드. F01=1공장, F02=2공장, F03=3공장"
    }
  }
}
```

### 날짜 컬럼 형식이 문자열인 경우

Oracle에서 날짜를 `VARCHAR2(8)` ('YYYYMMDD')로 저장하는 경우가 많습니다.
`domain_hint`에 변환 방법을 명시하면 SQL 오류가 줄어듭니다.

```json
{
  "domain_hint": "날짜 비교 시 TO_DATE(컬럼명, 'YYYYMMDD') 사용"
}
```

### 테이블 간 조인 관계를 LLM이 모르는 경우

`domain_hints_oracle_manual.json`의 `join_hints` 에 명시합니다.

```json
{
  "join_hints": [
    "PROD_ORDER와 PROD_RESULT는 ORDER_NO로 조인",
    "ITEM_MASTER와 WIP_LOT는 ITEM_CD로 조인"
  ]
}
```

---

## 메타데이터 초기화

처음부터 다시 추출하려면:

```powershell
# generated/ 폴더 삭제 후 재생성
rd /s /q src\text2sql\config\generated\
mkdir src\text2sql\config\generated\
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id oracle_prod
```

> **주의**: `_manual.json` 파일도 삭제됩니다. 백업 후 진행하세요.

---

## 참고

- 자동 추출 로직: `src/text2sql/tools/` 내 메타데이터 관련 도구
- 벡터 인덱스: `data/vector_store/`에 저장된 ChromaDB
- RAG 검색: BM25 + 벡터 하이브리드 검색으로 관련 테이블 선택
