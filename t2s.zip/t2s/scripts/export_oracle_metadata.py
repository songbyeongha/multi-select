#!/usr/bin/env python3
"""
Oracle 메타데이터 추출 스크립트
================================
Oracle DB에서 테이블/컬럼/PK/FK/코멘트/샘플 값을 추출하여
schema_metadata.json 호환 형식으로 저장합니다.

실행:
  python scripts/export_oracle_metadata.py
  python scripts/export_oracle_metadata.py --output config/oracle_meta.json
  python scripts/export_oracle_metadata.py --include TABLE_A,TABLE_B
  python scripts/export_oracle_metadata.py --exclude SYS_LOG --no-views
  python scripts/export_oracle_metadata.py --samples 5

옵션:
  --output PATH     출력 파일 경로 (기본: src/text2sql/config/schema_metadata_oracle.json)
  --include TABLES   포함할 테이블 (쉼표 구분)
  --exclude TABLES   제외할 테이블 (쉼표 구분)
  --no-views         뷰 제외
  --samples N        샘플 값 수 (기본: 3)
  --db-id ID         데이터베이스 식별자 (기본: 환경변수 T2SQL_DB_ID)
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")


def main():
    parser = argparse.ArgumentParser(description="Oracle 메타데이터 추출")
    parser.add_argument("--output", "-o", default="src/text2sql/config/schema_metadata_oracle.json")
    parser.add_argument("--include", default="", help="포함할 테이블 (쉼표 구분)")
    parser.add_argument("--exclude", default="", help="제외할 테이블 (쉼표 구분)")
    parser.add_argument("--no-views", action="store_true", help="뷰 제외")
    parser.add_argument("--samples", type=int, default=3, help="샘플 행 수")
    parser.add_argument("--db-id", default="", help="DB 식별자")
    args = parser.parse_args()

    from text2sql.config.settings import get_settings

    settings = get_settings()
    db_cfg = settings.db

    if db_cfg.dialect != "oracle":
        print("[ERROR] T2SQL_DB_DIALECT=oracle 이 아닙니다.")
        sys.exit(1)

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError:
        print("[ERROR] oracledb 미설치: pip install oracledb")
        sys.exit(1)

    adapter = OracleAdapter(
        host=db_cfg.host,
        port=db_cfg.port,
        service_name=db_cfg.service_name,
        dsn=db_cfg.dsn,
        user=db_cfg.user,
        password=db_cfg.password,
        schema=db_cfg.schema,
        connect_timeout_sec=db_cfg.connect_timeout_sec,
    )

    info = adapter.test_connection()
    if not info["ok"]:
        print(f"[ERROR] 연결 실패: {info['message']}")
        sys.exit(1)
    print(f"[OK] Oracle 연결 성공: {info['message']}")

    # 테이블 목록
    all_tables = adapter.list_tables()
    include = set(t.strip().upper() for t in args.include.split(",") if t.strip())
    exclude = set(t.strip().upper() for t in args.exclude.split(",") if t.strip())

    # 환경변수 include/exclude 도 병합
    for t in db_cfg.include_table_list():
        include.add(t.upper())
    for t in db_cfg.exclude_table_list():
        exclude.add(t.upper())

    if include:
        all_tables = [t for t in all_tables if t.upper() in include]
    if exclude:
        all_tables = [t for t in all_tables if t.upper() not in exclude]

    print(f"[INFO] 대상 테이블: {len(all_tables)}개")

    # 메타데이터 추출
    db_id = args.db_id or db_cfg.db_id or "oracle_db"
    tables_meta = {}

    for i, tname in enumerate(all_tables, 1):
        print(f"  [{i}/{len(all_tables)}] {tname}...", end=" ", flush=True)
        try:
            tmeta = adapter.table_info(tname)
            columns = {}
            for c in tmeta.columns:
                col_entry = {
                    "type": c.type,
                    "description": c.comment or "",
                }
                if c.is_pk:
                    col_entry["is_pk"] = True
                columns[c.name] = col_entry

            # FK 정보
            for fk in tmeta.foreign_keys:
                if fk.from_column in columns:
                    columns[fk.from_column]["is_fk"] = True
                    columns[fk.from_column]["references"] = f"{fk.to_table}.{fk.to_column}"

            # 샘플 값 (선택적)
            sample_values = {}
            if args.samples > 0 and tmeta.sample_rows:
                for col in tmeta.columns[:20]:  # 최대 20 컬럼
                    vals = []
                    for row in tmeta.sample_rows[:args.samples]:
                        v = row.get(col.name)
                        if v is not None:
                            sv = str(v)
                            if len(sv) > 50:
                                sv = sv[:47] + "..."
                            vals.append(sv)
                    if vals:
                        sample_values[col.name] = list(dict.fromkeys(vals))

            table_entry = {
                "description": tmeta.comment or "",
                "columns": columns,
            }
            if sample_values:
                table_entry["sample_values"] = sample_values

            tables_meta[tname] = table_entry
            print(f"✅ ({len(tmeta.columns)}cols, {len(tmeta.foreign_keys)}fks)")
        except Exception as e:
            print(f"❌ {e}")

    # 관계 추출
    relationships = []
    for tname, tdata in tables_meta.items():
        for cname, cdata in tdata.get("columns", {}).items():
            if cdata.get("is_fk") and cdata.get("references"):
                relationships.append({
                    "from": f"{tname}.{cname}",
                    "to": cdata["references"],
                    "type": "many-to-one",
                })

    # 출력
    output = {
        "databases": {
            db_id: {
                "name": db_id,
                "description": f"Oracle DB: {db_cfg.schema or db_cfg.user}@{db_cfg.host}",
                "dialect": "oracle",
                "tables": tables_meta,
                "relationships": relationships,
            }
        }
    }

    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[OK] 메타데이터 저장 완료: {output_path}")
    print(f"  테이블: {len(tables_meta)}개")
    print(f"  관계: {len(relationships)}개")

    # manual metadata overlay 안내
    print("""
[NEXT STEPS]
1. 생성된 파일을 확인하고 description을 보강하세요.
2. 수동 메타데이터를 별도 파일로 관리하려면:
   - schema_metadata_oracle_manual.json 파일을 만들고
   - tables → TABLE_NAME → columns → COL_NAME → description 에 업무 설명 추가
   - export 다시 실행해도 manual 파일은 유지됩니다.
3. .env에 T2SQL_METADATA_PATH 를 설정하면 이 파일을 자동으로 사용합니다.
""")

    adapter.close()


if __name__ == "__main__":
    main()
