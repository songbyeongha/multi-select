#!/usr/bin/env python
"""
CLI에서 Text-to-SQL 파이프라인을 실행하고 rich 콘솔로 결과를 표시합니다.

사용 예:
    # 단일 질문 실행
    python scripts/run_cli.py --db chinook --question "전체 고객 수를 구하라"
    python scripts/run_cli.py --db chinook -q "국가별 매출 현황" --hitl
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.tools.cli_display import (
    console, PipelineDisplay, BatchDisplay,
    print_pipeline_banner, print_score_comparison,
)
from rich.panel import Panel


def _run_hitl_review(state: dict, db_path: str, display) -> dict:
    """HITL: SQL 실행 전 사용자 검토 루프."""
    from text2sql.agents.repair_output import node_repair, node_result_output
    from text2sql.agents.validation_nodes import (
        node_guardrails, node_unit_tester, node_execute_preview, node_judge,
    )
    from text2sql.lg.state import ErrorType
    from text2sql.tools.executor import SQLExecutor

    sql = state.get("selected_sql") or state.get("preview_sql") or ""
    if not sql:
        candidates = [c for c in state.get("candidates", []) if c.sql]
        if candidates:
            sql = candidates[0].sql

    while True:
        console.print()
        console.print(Panel(sql, title="[bold yellow]Generated SQL[/bold yellow]", border_style="yellow"))
        console.print()
        console.print("[bold]Select action:[/bold]")
        console.print("  [green]y[/green] - Execute this SQL")
        console.print("  [red]n[/red] - Cancel (do not execute)")
        console.print("  [yellow]e[/yellow] - Edit SQL manually")
        console.print("  [cyan]f[/cyan] - Give feedback and let LLM repair")
        console.print()

        try:
            choice = input("  > ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "n"

        if choice == "y":
            # 승인 — 실행 진행
            console.print("  [green]Approved. Executing...[/green]")
            state["selected_sql"] = sql
            state["preview_sql"] = sql
            state = node_execute_preview(state)
            report = state.get("exec_report")
            if report and report.ok:
                state = node_judge(state)
                if state.get("judge_accepted"):
                    state = node_result_output(state)
            elif report:
                display.print_step("ExecutePreview", f"Error: {report.error_message}")
            return state

        elif choice == "n":
            console.print("  [red]Cancelled.[/red]")
            state["success"] = False
            state["error"] = "User cancelled"
            return state

        elif choice == "e":
            # 직접 수정
            console.print("  [yellow]Enter modified SQL (end with empty line):[/yellow]")
            lines = []
            while True:
                try:
                    line = input("  sql> ")
                except (EOFError, KeyboardInterrupt):
                    break
                if line.strip() == "":
                    break
                lines.append(line)
            if lines:
                sql = "\n".join(lines)
                console.print(f"  [yellow]SQL updated ({len(lines)} lines)[/yellow]")
            else:
                console.print("  [dim]No changes[/dim]")

        elif choice == "f":
            # LLM 피드백 기반 repair
            console.print("  [cyan]Enter feedback for LLM:[/cyan]")
            try:
                feedback = input("  feedback> ").strip()
            except (EOFError, KeyboardInterrupt):
                feedback = ""
            if feedback:
                console.print(f"  [cyan]Repairing with feedback: {feedback[:60]}...[/cyan]")
                state["judge_accepted"] = False
                state["judge_rationale"] = f"[User feedback] {feedback}"
                state["last_error_type"] = ErrorType.SEMANTIC
                state["last_error_msg"] = feedback
                state["selected_sql"] = sql
                state = node_repair(state)
                # 새 SQL 추출
                new_candidates = [c for c in state.get("candidates", []) if c.sql]
                if new_candidates:
                    sql = new_candidates[0].sql
                    console.print(f"  [cyan]LLM generated new SQL[/cyan]")
                else:
                    console.print("  [red]Repair failed — keeping current SQL[/red]")
            else:
                console.print("  [dim]No feedback[/dim]")
        else:
            console.print(f"  [dim]Unknown option: {choice}[/dim]")


def run_single_query(db_id: str, question: str, db_path: str, max_retries: int,
                     hitl: bool = False):
    """단일 질문 파이프라인 실행."""
    from text2sql.agents._utils import set_cli_display
    from text2sql.lg.state import new_state
    from text2sql.lg.graph import get_compiled_graph
    from text2sql.llm.client import get_token_accumulator

    display = PipelineDisplay()
    display.set_question(question, db_id)
    set_cli_display(display)

    display.print_header()
    if hitl:
        console.print("  [yellow]HITL mode ON — SQL execution requires your approval[/yellow]")
        console.print()

    get_token_accumulator().reset()
    state = new_state(
        question=question,
        database_id=db_id,
        db_path=db_path,
        max_retries=max_retries,
        hitl_enabled=hitl,
    )

    if hitl:
        # HITL: 그래프를 ExecutePreview 직전까지만 실행 후 사용자 검토
        from text2sql.agents.nodes import (
            node_decomposer, node_schema_selector, node_value_retriever,
            node_join_planner, node_candidate_generator, node_sql_postprocess,
            node_guardrails, node_unit_tester,
        )
        for node_fn in [
            node_decomposer, node_schema_selector, node_value_retriever,
            node_join_planner, node_candidate_generator, node_sql_postprocess,
            node_guardrails, node_unit_tester,
        ]:
            state = node_fn(state)

        # 사용자 검토
        final_state = _run_hitl_review(state, db_path, display)
    else:
        graph = get_compiled_graph()
        final_state = graph.invoke(state)

    token_usage = get_token_accumulator().summary()
    success = final_state.get("success", False)
    sql = final_state.get("final_sql", "") or final_state.get("selected_sql", "")
    summary = final_state.get("result_summary", "")

    display.set_result(success, sql, summary, token_usage)
    display.print_result()
    set_cli_display(None)

    # 피드백 수집
    _collect_cli_feedback(question, sql, db_id, final_state)


def _collect_cli_feedback(question: str, sql: str, db_id: str, state: dict):
    """CLI에서 5단계 피드백 수집."""
    from text2sql.feedback import FeedbackRecord, FeedbackScore, get_feedback_store, get_learner

    console.print()
    console.print("[bold]결과 피드백 (1~5)[/bold]")
    console.print("  [green]5[/green]=매우좋음  [green]4[/green]=좋음  [yellow]3[/yellow]=보통  [red]2[/red]=나쁨  [red]1[/red]=매우나쁨  [dim]s[/dim]=건너뛰기")

    try:
        choice = input("  피드백> ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        choice = "s"

    if choice == "s" or not choice:
        console.print("  [dim]건너뜀[/dim]")
        return

    try:
        score = int(choice)
        if score < 1 or score > 5:
            raise ValueError
    except ValueError:
        console.print("  [dim]잘못된 입력 — 건너뜀[/dim]")
        return

    comment = ""
    if score <= 2:
        try:
            comment = input("  코멘트 (뭐가 잘못됐나요?)> ").strip()
        except (EOFError, KeyboardInterrupt):
            pass

    fs = FeedbackScore(score)
    record = FeedbackRecord(
        question=question,
        sql=sql,
        database_id=db_id,
        score=score,
        user_comment=comment,
        query_pattern=state.get("query_pattern", ""),
        dialect=state.get("dialect", "sqlite"),
        tables_used=state.get("selected_tables", []),
    )
    get_feedback_store().add(record)

    learn_result = get_learner().learn(db_id)
    console.print(f"  {fs.emoji} 피드백 저장 완료 ({fs.label_ko})")

    if learn_result.get("few_shots_added", 0) > 0:
        console.print(f"  [green]좋��� SQL이 학습 데이터에 자동 등록됨 (+{learn_result['few_shots_added']})[/green]")
    if learn_result.get("keywords_added", 0) > 0:
        console.print(f"  [green]키워드 매핑 자동 확장됨 (+{learn_result['keywords_added']})[/green]")
    if learn_result.get("errors_logged", 0) > 0:
        console.print(f"  [yellow]오류 패턴이 기록되어 다음 질문에 반영됩니다[/yellow]")


def parse_args():
    p = argparse.ArgumentParser(description="Text-to-SQL CLI with rich console display")
    p.add_argument("--db", type=str, default="chinook", help="Database ID (default: chinook)")
    p.add_argument("--question", "-q", type=str, default=None, help="질문")
    p.add_argument("--max-retries", type=int, default=3, help="최대 재시도 횟수")
    p.add_argument("--hitl", action="store_true", help="HITL 모드: SQL 실행 전 사용자 검토")
    return p.parse_args()


def main():
    from rich.panel import Panel
    args = parse_args()

    print_pipeline_banner()

    if args.question:
        from text2sql.tools.db_registry import resolve_db_path
        db_path = resolve_db_path(args.db)
        run_single_query(args.db, args.question, db_path, args.max_retries, hitl=args.hitl)
    else:
        console.print("[yellow]--question 옵션을 지정하세요[/yellow]")
        console.print()
        console.print("예시:")
        console.print('  python scripts/run_cli.py --question "전체 고객 수를 구하라"')
        console.print('  python scripts/run_cli.py --db chinook -q "국가별 매출 현황" --hitl')


if __name__ == "__main__":
    main()
