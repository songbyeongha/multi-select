#!/usr/bin/env python3
"""
Oracle 연결 확인 스크립트
========================
환경변수(.env)에서 Oracle 연결 정보를 읽고 다음을 확인합니다:
  1. 연결 성공 여부
  2. 현재 사용자 / owner / schema
  3. 읽기 가능한 테이블 수
  4. 메타데이터 introspection 가능 여부
  5. 샘플 SELECT preview

실행:
  python scripts/check_oracle_connection.py
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")


def main():
    from text2sql.config.settings import get_settings

    settings = get_settings()
    db_cfg = settings.db

    print("=" * 60)
    print("Oracle 연결 확인")
    print("=" * 60)

    if db_cfg.dialect != "oracle":
        print(f"[INFO] 현재 dialect: {db_cfg.dialect} (oracle 아님)")
        print("[INFO] T2SQL_DB_DIALECT=oracle 로 설정하세요.")
        return

    print(f"  Host:         {db_cfg.host}")
    print(f"  Port:         {db_cfg.port}")
    print(f"  Service:      {db_cfg.service_name}")
    print(f"  User:         {db_cfg.user}")
    print(f"  Schema:       {db_cfg.schema or '(user default)'}")
    print(f"  Read-only:    {db_cfg.read_only}")
    print()

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError as e:
        print(f"[ERROR] oracledb 패키지 미설치: {e}")
        print("  설치: pip install oracledb")
        return

    try:
        adapter = OracleAdapter(
            host=db_cfg.host,
            port=db_cfg.port,
            service_name=db_cfg.service_name,
            dsn=db_cfg.dsn,
            user=db_cfg.user,
            password=db_cfg.password,
            schema=db_cfg.schema,
            connect_timeout_sec=db_cfg.connect_timeout_sec,
        )
    except Exception as e:
        print(f"[ERROR] Adapter 생성 실패: {e}")
        return

    # 1. 연결 테스트
    print("[1/5] 연결 테스트...")
    info = adapter.test_connection()
    if not info["ok"]:
        print(f"  ❌ 실패: {info['message']}")
        return
    print(f"  ✅ {info['message']}")
    print()

    # 2. 사용자/스키마
    print(f"[2/5] User: {info.get('user')}, Schema: {info.get('schema')}")
    print()

    # 3. 테이블 목록
    print("[3/5] 읽기 가능 테이블 목록...")
    tables = adapter.list_tables()
    print(f"  테이블 수: {len(tables)}")
    if tables:
        for t in tables[:20]:
            print(f"    - {t}")
        if len(tables) > 20:
            print(f"    ... 외 {len(tables) - 20}개")
    print()

    # 4. 메타데이터 introspection
    print("[4/5] 메타데이터 접근 확인...")
    meta_ok = info.get("metadata_accessible", False)
    print(f"  ALL_TAB_COLUMNS 접근: {'✅' if meta_ok else '❌ (USER_* 사용 가능)'}")

    if tables:
        sample_table = tables[0]
        tmeta = adapter.table_info(sample_table)
        print(f"  테이블 '{sample_table}' 메타데이터:")
        print(f"    컬럼 수: {len(tmeta.columns)}")
        for c in tmeta.columns[:5]:
            pk = " [PK]" if c.is_pk else ""
            comment = f" -- {c.comment}" if c.comment else ""
            print(f"      {c.name}  {c.type}{pk}{comment}")
        if len(tmeta.columns) > 5:
            print(f"      ... 외 {len(tmeta.columns) - 5}개 컬럼")
        print(f"    FK 수: {len(tmeta.foreign_keys)}")
    print()

    # 5. 샘플 SELECT
    print("[5/5] 샘플 SELECT...")
    if tables:
        sample_table = tables[0]
        owner = adapter.owner
        sql = f'SELECT * FROM "{owner}"."{sample_table}" WHERE ROWNUM <= 3'
        result = adapter.execute(sql, limit=3)
        if result["ok"]:
            print(f"  ✅ '{sample_table}' 조회 성공 ({result['row_count']}행)")
            for row in result["rows"][:3]:
                cols = list(row.items())[:5]
                print(f"    {dict(cols)}")
        else:
            print(f"  ❌ 조회 실패: {result['error_message']}")
    print()

    adapter.close()
    print("=" * 60)
    print("Oracle 연결 확인 완료")
    print("=" * 60)


if __name__ == "__main__":
    main()
