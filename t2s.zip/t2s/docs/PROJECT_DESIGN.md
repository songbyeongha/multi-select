# 프로젝트 기획/설계 문서

---

# 1. 문제 정의 및 서비스 기획

### 프로젝트 명

Text-to-SQL Assistant

### 배경 및 문제 정의

* 현재 상황 (As-Is):

장애, 성능 저하, 데이터 이상 등 **긴급 상황 발생 시**, 운영 및 개발자는 다음과 같은 프로세스로 원인 분석을 수행한다.

1. 모니터링 알람 또는 장애 발생

2. 당직 개발자 또는 숙련 개발자에게 메신저/전화로 분석 요청

3. 관련 로그 테이블 및 운영 DB 접속

4. 첫 번째 SQL 작성 (기간/조건/조인 포함)

5. 결과 검증 및 조건 수정 반복

6. 결과 공유 및 원인/영향 범위 보고

이 과정에서 특히

* **4~5단계(SQL 작성 및 검증 반복)** 에서 시간이 가장 많이 소요되며

* 기간 조건 누락, 잘못된 JOIN, 집계 기준 불일치 등의 **실수가 빈번히 발생**한다.

또한 SQL 숙련도가 높은 개발자에게 분석 요청이 집중되어 **대응 속도와 결과 품질이 개인 역량에 의존하는 구조**가 형성되어 있다.

* Pain Point:

**시간 측면**

* 긴급 상황에서도 복잡한 SQL 작성이 필요하여 첫 결과 도출까지 시간이 지연됨

* 숙련도가 낮을수록 쿼리 수정 및 재실행이 반복됨

**비용 측면**

* 숙련된 개발자에게 질의 및 분석 업무가 집중됨

* 동일하거나 유사한 SQL을 매번 새로 작성해야 함

* 야간·비상 대응 시 특정 인력 의존도가 높아짐

**품질 측면**

* 임시로 작성된 쿼리로 인해 조건 누락 또는 잘못된 JOIN 발생 가능

* 개발자별 쿼리 기준 차이로 결과 해석의 일관성이 저하됨

* 데이터 기반 의사결정의 신뢰도가 낮아질 위험 존재

* 기회 요인:

Text-to-SQL 기반 AI는 **개발자 간 SQL 숙련도 차이를 흡수하는 중간 계층**으로 작동할 수 있다.

운영 개발자가 자연어로 질문을 정의하면, AI가 일관된 구조의 SQL을 생성하여 숙련도와 관계없이 **유사한 속도와 품질의 데이터 조회 결과**를 제공할 수 있다.

이를 통해

* 긴급 상황에서의 데이터 확인 속도 단축

* 특정 인력 의존도 완화

* 반복적인 SQL 작성 작업 감소

* 운영 데이터 질의 기준의 표준화

등을 기대할 수 있으며, **운영 안정성과 대응 효율을 동시에 개선할 수 있는 기회 요인**으로 작용한다.

### 목표 사용자 (Target User)

누가 이 서비스를 사용할 것인가? 역할, 업무 특성 기술

**1차 타겟 사용자**

* 야간/비상 대응 당직 개발자

* SQL 사용은 가능하나, 복잡한 운영 쿼리에 즉각 대응하기 어려운 중급 이하 숙련도

* 장애 발생 시 빠르게 데이터 기반 판단이 필요한 역할

**2차 타겟 사용자**

* SQL 숙련 개발자

* 생성된 SQL 결과 검증

* 자주 사용하는 질의 패턴 정의 및 가이드 역할 수행

1차 타겟 사용자가 **숙련 개발자의 도움 없이도 긴급 분석을 수행**할 수 있도록 지원하며, 2차 타겟 사용자는 결과 검증과 질의 품질 표준화를 담당한다.

### 프로젝트 목표

* 정성적 목표

  * 목표 1: 긴급 상황에서 데이터 조회 속도의 개인 편차를 최소화한다.

  * 목표 2: 운영 데이터 질의 결과의 품질과 기준을 표준화한다.

  * 목표 3: 특정 숙련 개발자에게 집중되는 분석 업무를 완화한다.

- 정량적 목표 (KPI)

|                       |           |                            |           |
| --------------------- | --------- | -------------------------- | --------- |
| **성과 지표**             | **목표 수치** | **측정 방법**                  | **현재 수준** |
| 도메인 테스트셋 기준 실행 결과 일치율 | 80% 이상    | 테스트셋 기준 실행 SQL 결과와 일치율     | 기준 없음     |
| TTR (Time to Result)  | 중앙값 3분 이내 | 질문 입력 ~ 첫 유효 결과 출력까지 시간 측정 | 10~15분    |
| Safety Rule 통과율       | 100%      | 금지 쿼리 차단 여부(DML/무제한 조회 등)  | 수동 검증     |

### 핵심 기능 정의

1. 자연어 기반 운영 데이터 질의\
   - 사용자가 자연어로 질문을 입력하면 운영 DB 조회 목적의 SQL을 자동 생성

2. SQL 안전성 검증 및 제어\
   - 읽기 전용 SQL만 허용(SELECT/WITH 및 UNION/EXCEPT/INTERSECT)\
   - 스키마/테이블 화이트리스트 적용\
   - LIMIT 강제, 질문에 없는 임의 현재시점 필터 금지, 금지 키워드(DML/DDL) 차단

3. 실행 전 검증 및 감사 로그\
   - 생성 SQL 미리보기 제공\
   - 위험 경고 표시 (예: 기간 조건 없음)\
   - 질문, SQL, 실행 시간, 결과 row 수 로그 저장

### 기대 효과

* 업무 효율화:

  * 긴급 상황에서 데이터 질의 소요 시간 평균 70% 이상 단축

  * 반복적인 SQL 작성 업무 제거

* 품질 향상:

  * 동일 질문에 대한 결과 일관성 확보

  * 조건 누락 및 쿼리 오류 발생률 감소

* 비용 절감:

  * 숙련 개발자 의존도 감소

  * 야간 및 비상 대응 시 인력 투입 최소화

### 범위 및 제약사항

* In Scope:

  * 운영 로그 / 트랜잭션 / 집계 테이블 2~4개

  * SELECT 기반 조회 및 집계

  * 기간 필터, GROUP BY, COUNT/SUM 등 기본 집계

  * 결과 테이블 출력

* Out of Scope:

  * INSERT / UPDATE / DELETE

  * 다중 데이터베이스 간 조인

  * 자동 대시보드 생성 및 시각화

* 제약사항:

  * 운영 DB는 Read-only 권한으로만 접근

  * 사전 정의된 스키마 및 컬럼 정보 필요

  * 복잡한 비즈니스 로직 해석은 제한

---

# 2. 상세 설계 및 개발 환경 구축

### Agent 페르소나 및 시스템 프롬프트 (Identity)

|              |                                                                                                                                           |
| ------------ | ----------------------------------------------------------------------------------------------------------------------------------------- |
| **항목**       | **정의 내용**                                                                                                                                 |
| **Agent 이름** | Text-to-SQL Assistant                                                                                                                     |
| **주요 역할**    | 운영·장애 상황에서 사용자의 자연어 질문을 **읽기 전용 SQL(SELECT/WITH/UNION/EXCEPT/INTERSECT)**&#xB85C; 변환하고, **스키마·보안·성능 가드레일을 통과한 쿼리만 실행**하여 신뢰 가능한 조회 결과를 제공 |
| **핵심 목표**    | 긴급 상황에서도 **개인 SQL 숙련도에 의존하지 않고**, 재현 가능하고 감사 가능한 방식으로 빠른 데이터 조회를 가능하게 함                                                                   |
| **톤앤매너**     | 운영 분석가 스타일. 간결·단정·사실 중심. 가설이나 추측은 명시적으로 차단                                                                                                |
| **제약 사항**    | 읽기 전용 SQL 외 구문 금지, 스키마에 없는 테이블·컬럼 사용 금지, LIMIT 없는 대량 조회 금지, 추측 기반 응답 금지                                                                   |

### 워크플로우 및 오케스트레이션 (Workflow & Logic)

**2.1 처리 로직**

* **Step 1 (Input Analysis):**

사용자 의도 파악 — Decomposer + ValueRetriever 사용자 자연어 질문을 구조화된 Query Intent로 변환한다.

* 추출 항목

  * query_pattern: group_top_n / group_aggregate / period_comparison / threshold_filter / ratio_calculation / running_calc / set_operation / nested_condition / simple

  * time_range

    * 명시적: `2024-09-01 ~ 2024-09-02` (LLM 프롬프트로 추출 유도)

    * 상대적: 오늘 / 어제 / 올해 / 이번 달 → `date_tools.py`가 시스템 기준 시각으로 절대값 변환

  * sub_questions: CTE 단계별 분해 (1~5개)

  * extracted_values:

    * time_range, group_by, target_metric, filters, aggregation, sort, limit, threshold

  * 대화 메모리 컨텍스트: 동일 DB의 최근 3건 이전 대화를 프롬프트에 주입

* ValueRetriever (후속 처리)

  * `extracted_values.filters`의 값을 DB 실제 값과 LIKE 매칭으로 보정

  * 대소문자 불일치 자동 교정 (예: "usa" → "USA")

* 처리 정책

  * 이 단계에서는 절대 SQL 생성 금지

  * LLM JSON 파싱 실패 시 fallback으로 원문 질문을 그대로 다음 단계로 전달

* **Step 2 (Tool Selection):**

  * **SchemaRAG 도구 호출**

    * 질문과 intent를 기반으로 **관련 테이블/컬럼만 선택**

    * 사전 정의된 스키마 메타데이터(JSON) 사용

  * **Guardrails 도구 호출**

    * 검증 항목:

      * DML / DDL 키워드 존재 여부

      * 읽기 전용 SQL 여부(SELECT/WITH/UNION/EXCEPT/INTERSECT)

      * LIMIT 적용 여부

      * 스키마 불일치 여부

    * 결과 분기

      * 통과 → SQLUnitTester(LLM 정적 검증) 진입

      * 실패 → Repair 경로 진입

* **Step 3 (Execution & Response):**

  * Execute Preview

    * 검증 통과한 후보 중 신뢰도(confidence) 최고를 선택하여 실제 DB 실행

      * preview_limit 적용 (기본 50행)

      * 타임아웃: set_progress_handler로 15초 초과 시 인터럽트

      * 에러 유형 자동 분류: SCHEMA / SYNTAX / TIMEOUT / RUNTIME / UNKNOWN

    * 실행 시간 측정

  * Judge

    * SQL 문법/스키마/시간 조건이 유효하면

      * 0 row 결과도 성공 가능 (ALLOW_EMPTY_RESULT=true)

    * 실행 오류 또는 스키마 불일치 → 실패

  * Final Response

    * 성공 시:

      * 상태 (✅ 성공)

      * 처리 시간

      * Repair 횟수

      * 선택된 테이블 수

      * 생성된 SQL

      * 결과 요약 (순수 텍스트, 200자 이내, 마크다운 금지)

      * 실행 결과 테이블 (DataFrame)

      * 파이프라인 추적 로그 (노드별 상세)

    * 실패 시:

      * 상태 (❌ 실패)

      * 최종 실패 사유 (마지막 에러 유형 + 메시지)

      * 최대 재시도 초과 안내

      * 질문 수정 가이드

      * JSONL 감사 로그 기록

      * 대화 메모리에 실패 기록 저장 (향후 Repair 시 회피용)

**2.2 상태 관리**

* 대화 턴(Turn) 관리를 위한 상태 정의 (LangGraph State)

  * question

  * intent + query_pattern + sub_questions

  * selected_tables + selected_columns + schema_text

  * candidates (List[SQLCandidate])

  * guard_passed + ut_passed (bool)

  * exec_report (ExecReport)

  * last_error_type + last_error_msg

  * repair_count

* LangGraph Node / Edge 흐름

  * Input\
    → Decomposer\
    → SchemaSelector\
    → ValueRetriever\
    → JoinPlanner\
    → CandidateGenerator\
    → SQLPostProcess\
    → Guardrails\
    → UnitTester\
    → ExecutePreview\
    → Judge\
    ├─ Guardrails / UnitTester / ExecutePreview / Judge 실패 → Repair → Guardrails (재진입)\
    ├─ retry_count 초과 → SAFE_FAIL\
    └─ Judge 승인 → ResultOutput(ResultSummarizer + AuditLogger + MemorySave) → Output

* retry_count 초과 시 SAFE_FAIL

* Guardrails 우회 경로 없음

### 도구(Tools) 및 함수 명세 (Capability)

|                         |                                             |                                    |                                                |
| ----------------------- | ------------------------------------------- | ---------------------------------- | ---------------------------------------------- |
| **도구명 (Function Name)** | **기능 설명 (Description)**                     | **입력 파라미터 (Input Schema)**         | **출력 데이터 (Output)**                            |
| SchemaSelector          | BM25+LLM 하이브리드 테이블·컬럼 선택                    | question, intent, full_schema      | selected_tables, selected_columns, schema_text |
| JoinPlanner             | FK 기반 JOIN 경로 계획                            | selected_tables, full_schema       | join_plan, join_rationale                      |
| CandidateGenerator      | 패턴별 전략 기반 SQL 후보 최대 3개 병렬 생성(simple은 기본 2개) | intent, schema_text, query_pattern | candidates (List[SQLCandidate])                |
| SQLGuard                | AST 기반 안전성 검증 + LIMIT 강제                    | sql, known_tables                  | is_valid, issues, safe_sql                     |
| SQLUnitTester           | LLM 기반 정적 검증                                | sql, question, schema_text         | ut_passed, reasoning                           |
| SQLExecutor             | DB 실행 + 미리보기                                | db_path, sql                       | ExecReport (ok, rows, row_count, exec_ms)      |
| Repair                  | 에러 타입별 SQL 수정 (해시 중복 차단)                    | sql, error_type, error_msg         | new_sql, changes                               |

### 지식 베이스 및 메모리 전략 (Context & Memory)

**4.1 RAG (검색 증강 생성) 전략**

* **참조 데이터 소스:**

  * 스키마 메타데이터 (JSON)

  * 테이블 설명, 컬럼 의미, JOIN 관계

* **청킹(Chunking) 방식:**

  * 테이블 단위

  * 컬럼은 의미 요약 단위

* **임베딩 모델:**

  * Azure OpenAI text-embedding-3-large (벡터 검색 활성화 시)

* **Vector DB:**

  * Chroma PersistentClient (optional, 미설치 시 BM25 100% 전용)

**4.2 대화 메모리 (Conversation History)**

* **메모리 유형:**

  * 단기 윈도우 메모리 + SQL Memory

* **저장 전략:**

  * 성공/실패 모두 저장 (실패 패턴은 Repair 시 회피 목적)

  * 유사 질문 검색: Jaccard 단어 유사도 (threshold 0.5)

  * 최대 20건 유지, 세션 종료 시 폐기

  * 활용: Decomposer(이전 컨텍스트), CandidateGenerator(유사 성공SQL), Repair(실패 패턴 회피)

### 핵심 에이전트 기술 스택

|                     |                                            |                               |
| ------------------- | ------------------------------------------ | ----------------------------- |
| **구분**              | **선정 전략/기술**                               | **선정 사유 (논리적 근거)**            |
| **LLM Model**       | primary `gpt-4.1`, fast `gpt-4.1-mini`     | 생성·판단은 정확도, 분석·선택은 속도 중심으로 분리 |
| **Agent Framework** | LangGraph                                  | 상태 기반 제어, 무한 루프 방지            |
| **Prompt Strategy** | 노드별 System/User Prompt + Constraint Prompt | 사고/도구/제약 분리                   |
| **Output Parsing**  | SQL-only Structured Output                 | 실행 안정성                        |
| **Monitoring**      | Console + SQL Audit Log                    | 장애 추적, 감사 대응                  |

---

# 3. 시나리오 수립

### 핵심 사용자 시나리오

**시나리오 1 :&#x20;**&#xC7A5;애 발생 시 영향 범위 즉시 파악

* ID : SC-001

* 상황 :

  * 운영 중 주요 API 에러율 급증 알람 발생

  * 개발자가 즉시 영향 범위를 파악해야 하는 상황

* 목표 :

  * 장애 발생 시간대 동안 에러 영향을 받은 사용자 수와 에러 유형별 발생 현황을 빠르게 확인한다.

* 사전 조건 :

  * 운영 DB(Read-only) 접근 가능

  * 로그 및 트랜잭션 테이블이 사전에 등록되어 있음

  * SQL 안전 정책(읽기 전용 SQL만 허용, LIMIT 강제, 질문에 없는 임의 현재시점 필터 금지) 적용 완료

* 상세 흐름

|    |                  |                          |                         |
| -- | ---------------- | ------------------------ | ----------------------- |
| 단계 | 사용자 행동           | 시스템 동작                   | 비고                      |
| 1  | 자연어로 장애 상황 질문 입력 | 질문 수신 및 의도 분석            |                         |
| 2  |                  | 관련 테이블/컬럼 식별             | 스키마 RAG                 |
| 3  |                  | 안전 정책을 만족하는 SQL 생성       | 질문의 시간 조건 반영 및 LIMIT 강제 |
| 4  | 생성된 SQL 확인       | SQL 안전성 검증 및 자동 수정(필요 시) | Guardrails / Repair     |
| 5  | 실행 버튼 클릭         | 안전 검증을 통과한 SQL만 실행       |                         |
| 6  | 결과 테이블 확인        | 결과 요약 및 로그 저장            | 감사 로그                   |

* 입력 예시

오늘(2026년 2월 9일) 14시부터 14시 30분까지 API 에러가 발생한 사용자 수와 에러 타입별 발생 횟수를 알려줘

* 기대 출력

  * 에러 타입별 발생 횟수 테이블

  * 에러 영향을 받은 고유 사용자 수

  * 생성된 SQL 및 실행 시간 정보

* 성공 기준

  * 기준 1: 질문 입력 후 첫 유효 결과가 3분 이내 출력된다.

  * 기준 2: 생성된 SQL이 안전 정책을 모두 통과한다.

  * 기준 3: 안전 정책을 위반하는 질의는 실행되지 않고 명확한 사유와 함께 차단된다.

**시나리오 2 :****&#x20;**&#xC7A5;애 전후 시계열 비교 분석

* ID : SC-002

* 상황 :

  * 장애 발생 후 원인 분석 단계

  * 장애 전후의 에러율 변화를 비교해야 하는 상황

* 목표 :

  * 특정 시간대의 에러율이 평상시 대비 얼마나 증가했는지 정량적으로 파악한다.

* 사전 조건 :

  * 동일 API의 과거 로그 데이터 존재

  * 비교 기준 시간대 정의 가능

* 상세 흐름

|    |              |                       |          |
| -- | ------------ | --------------------- | -------- |
| 단계 | 사용자 행동       | 시스템 동작                | 비고       |
| 1  | 시계열 비교 질문 입력 | 질문 의도 파악(비교)          |          |
| 2  |              | 기준 시간대 및 비교 대상 시간대 분리 |          |
| 3  |              | 시계열 비교 SQL 생성         | GROUP BY |
| 4  | 생성 SQL 확인    | 기간/조건 검증              |          |
| 5  | 실행           | 결과 테이블 및 증감률 계산       |          |
| 6  | 결과 확인        | 요약 및 로그 저장            |          |

* 입력 예시

오늘(2026년 2월 9일) 14시~15시 에러율이 어제 같은 시간대 대비 얼마나 증가했어?

* 기대 출력

  * 오늘/어제 동일 시간대 에러율 비교 테이블

  * 증감률(%) 표시 (SQL 집계 결과 기반 단순 계산)

  * 생성된 SQL

* 성공 기준

  * 기준 1: 비교 기준 시간대가 정확히 반영된다.

  * 기준 2: 결과 값이 테스트셋 기준 정답과 일치한다.

**시나리오 3 :****&#x20;**&#xD310;매 데이터 기반 Top 앨범 분석

* ID : SC-003

* 상황 :

  * 마케팅/비즈니스 분석 단계

  * 특정 기간 동안 가장 성과가 좋았던 콘텐츠를 빠르게 파악해야 하는 상황

* 목표 :

  * 연도 기준으로 가장 많이 판매된 앨범을 정확히 식별한다.

* 사전 조건 :

  * 앨범, 아티스트, 판매(Invoice/InvoiceLine) 테이블이 사전에 등록되어 있음

  * 판매 수량 또는 매출 기준 집계 가능

  * SQL 안전 정책(읽기 전용 SQL만 허용, LIMIT 강제, 질문에 없는 임의 현재시점 필터 금지) 적용 완료

* 상세 흐름

|    |              |                         |            |
| -- | ------------ | ----------------------- | ---------- |
| 단계 | 사용자 행동       | 시스템 동작                  | 비고         |
| 1  | 자연어 분석 질문 입력 | 질문 의도 파악 (Top-K, 연도 필터) |            |
| 2  |              | 판매·앨범·아티스트 테이블 매핑       | 스키마 RAG    |
| 3  |              | 연도 필터 및 집계 SQL 생성       | GROUP BY   |
| 4  | 생성 SQL 확인    | LIMIT / 기간 조건 검증        | Guardrails |
| 5  | 실행           | 안전 검증 통과 SQL만 실행        |            |
| 6  | 결과 확인        | 결과 요약 및 로그 저장           |            |

* 입력 예시

2025년 미국에서 가장 많이 판매된 앨범은 뭐야?

* 기대 출력

  * 앨범명 / 아티스트명 / 총 판매 수량(또는 매출)

  * Top 1 결과 (LIMIT 1)

  * 생성된 SQL 및 실행 시간

* 성공 기준

  * 기준 1: 연도 및 국가 필터가 정확히 반영된다.

  * 기준 2: ORDER BY + LIMIT 조건이 누락되지 않는다.

  * 기준 3: SQL이 단일 실행으로 결과를 반환한다.

**시나리오 4 :****&#x20;**&#xC7A5;르·아티스트 조건 기반 앨범 탐색

* ID : SC-004

* 상황 :

  * 콘텐츠 탐색 또는 데이터 품질 분석 단계

  * 특정 조건(장르, 아티스트)에 해당하는 데이터만 선별해야 하는 상황

* 목표 :

  * 특정 장르 또는 특정 아티스트가 만든 앨범 목록을 정확히 조회한다.

  * 판매량 기준 최저/전체 목록 등 다양한 조건을 자연어로 처리한다.

* 사전 조건 :

  * Genre, Artist, Album, Sales 테이블 관계 정의 완료

  * 장르-트랙-앨범 연결 구조가 스키마에 명시됨

  * SQL 안전 정책 적용 완료

* 상세 흐름

|    |              |                       |              |
| -- | ------------ | --------------------- | ------------ |
| 단계 | 사용자 행동       | 시스템 동작                | 비고           |
| 1  | 자연어 분석 질문 입력 | 장르/아티스트/집계 의도 파악      |              |
| 2  |              | 관련 테이블 및 조인 경로 추론     | 스키마 RAG      |
| 3  |              | 조건 기반 SQL 생성          | WHERE / JOIN |
| 4  | 생성 SQL 확인    | 불필요한 컬럼 제거 및 LIMIT 검증 | Repair       |
| 5  | 실행           | SQL 실행                |              |
| 6  | 결과 확인        | 결과 요약 및 로그 저장         |              |

* 입력 예시 1

rock 음악 중에서 가장 적게 판매된 앨범은 뭐야?

* 입력 예시 2

AAA라는 가수가 만든 앨범 리스트 보여줘.

* 기대 출력

  * 앨범명 / 아티스트명 / 장르 / 판매 수량

  * 조건에 맞는 결과 테이블

  * 생성된 SQL

* 성공 기준

  * 기준 1: 장르 또는 아티스트 조건이 정확히 반영된다.

  * 기준 2: 집계 기준(최소/전체)이 자연어 의도와 일치한다.

  * 기준 3: 불필요한 전체 스캔 없이 조건 필터가 적용된다.

**시나리오 5 :****&#x20;**&#xD3C9;균 대비 이상치(Outlier) 콘텐츠 탐지

* ID : SC-005

* 상황 :

  * 분기/월간 비즈니스 리뷰 단계

  * 단순 Top-N이 아니라 **“평균 대비 비정상적으로 성과가 낮거나 높은 항목”**&#xC744; 찾아야 하는 상황

  * 기준이 자연어로만 주어지고, SQL로는 명시되어 있지 않은 상태

* 목표 :

  * 특정 조건(장르, 기간) 내에서\
    **평균 판매량보다 현저히 많은 앨범**을 식별한다.

  * “평균”이라는 개념을 SQL 집계로 정확히 풀어낸다.

* 사전 조건 :

  * 앨범, 트랙, 장르, 판매(Invoice/InvoiceLine) 데이터 존재

  * 평균값 계산이 가능한 충분한 데이터 수 확보

  * SQL 안전 정책 적용 완료\
    (읽기 전용 SQL만 허용, LIMIT 강제, 질문에 없는 임의 현재시점 필터 금지)

  * SQL 안전 정책 적용 완료

* 상세 흐름

|    |                 |                     |            |
| -- | --------------- | ------------------- | ---------- |
| 단계 | 사용자 행동          | 시스템 동작              | 비고         |
| 1  | 모호한 기준 포함 질문 입력 | 질문 의도 파악 (평균 대비 비교) |            |
| 2  |                 | 비교 기준 정의 (평균 판매량)   | 파생 조건      |
| 3  |                 | 기준값 계산용 Subquery 생성 | CTE + AVG  |
| 4  | 생성 SQL 확인       | Subquery 안전성 검증     | Guardrails |
| 5  | 실행              | SQL 실행 및 결과 반환      |            |
| 6  | 결과 확인           | 평균값 및 결과 요약 제공      |            |

* 입력 예시

2025년 rock 장르 앨범 중에서 평균 판매량보다 훨씬 많이 팔린 앨범들은 뭐야?

(※ “훨씬”은 시스템이 명시적 임계값으로 정규화하며, 구체 기준은 프롬프트/도메인 규칙에 따라 조정됩니다.)

* 기대 출력

  * 앨범명

  * 아티스트명

  * 총 판매량

  * 해당 장르 평균 판매량

  * 평균 대비 비율 (%)

  * 생성된 SQL (AVG + Subquery 포함)

* 성공 기준

  * 기준 1: “평균”이 SQL 집계로 정확히 계산된다.

  * 기준 2: 파생 기준(평균 대비 비율)이 설명 가능하다.

  * 기준 3: Subquery가 포함된 SQL도 안전 정책을 통과한다.

  * 기준 4: 자연어의 모호성(“훨씬”)이 명시적 기준으로 정규화된다.

### 시나리오 우선순위 매트릭스

|        |         |        |        |
| ------ | ------- | ------ | ------ |
| 시나리오   | 비즈니스 가치 | 구현 난이도 | PoC 포함 |
| SC-001 | 높음      | 중간     | 네      |
| SC-002 | 중간      | 중간     | 네      |
| SC-003 | 중간      | 낮음     | 네      |
| SC-004 | 중간      | 중간     | 네      |
| SC-005 | 높음      | 높음     | 네      |

---

# 4. PoC 모듈 구현

### 핵심 구현 내용

**1.1 에이전트 워크플로우 (Agent Workflow)**

* **구현 기능:**\
  사용자 자연어 질문(한국어)을 분석하여 **의도 파악 → 스키마 선택 → 값 확인/보정 → JOIN 계획 → SQL 후보 병렬 생성 → 검증 → 실행 미리보기 → 판정 → 결과 요약**의 흐름을 수행하는 에이전트 워크플로우를 구현하였습니다.\
  모델 라우팅과 수정 루프가 포함되어 있으며, 라우팅 방식과 사용 모델은 상태값 및 설정에 따라 달라집니다.

* **동작 원리:**

  * **파이프라인 흐름**

    * START → ①Decomposer → ②SchemaSelector → ③ValueRetriever → ④JoinPlanner → ⑤CandidateGenerator(전략 기반, 최대 3후보)\
      → ⑥SQLPostProcess → ⑦Guardrails ─┬─ pass → ⑧SQLUnitTester ─┬─ pass → ⑨ExecutePreview ─┬─ ok → ⑩Judge ─┬─ accept → ⑪ResultSummarizer\
      └─ fail → ⑫Repair └─ fail → ⑨fallback 가능 └─ err → ⑫Repair └─ reject → ⑫Repair\
      ⑫Repair → retry < max(3)? ─┬─ yes → ⑦Guardrails (재검증 루프)\
      └─ no → ⑬SafeFail

① **Decomposer (의도분석기):** 사용자 질문을 입력으로 받아 LLM이 의도(intent)를 구조화합니다. 질문 유형을 9가지 쿼리 패턴 (simple / group_top_n / group_aggregate / period_comparison / threshold_filter / ratio_calculation / running_calc / set_operation / nested_condition) 중 하나로 분류하고, sub_questions와 extracted_values를 생성합니다. "어제", "최근 3개월" 등 한국어 상대 시간 표현은 RelativeDateTool을 통해 절대 날짜 컨텍스트로 해석되어 상태(state)와 프롬프트에 반영됩니다.

쿼리 패턴이 simple이고 듀얼 모델 설정이 활성화된 경우, 이후 노드에서 fast 모델 중심 라우팅 플래그(use_fast_only)를 설정합니다.

② **SchemaSelector (스키마선택기):** BM25 점수와 벡터 유사도를 결합하여 관련 테이블 후보를 선정합니다. 이후 LLM이 선택된 테이블과 컬럼을 추가 검토할 수 있으며, LLM 호출 실패 시 BM25/벡터 결과만 사용합니다. 동일 질문 반복 호출을 줄이기 위해 결과는 메모리 캐시에 저장됩니다(TTL 300초).

③ **ValueRetriever (값검증기):** Decomposer가 추출한 filters 값을 대상으로, 선택된 테이블의 컬럼명과 키를 비교한 뒤 LIKE 기반 조회로 실제 값을 확인하고 필요 시 표기를 보정합니다.

④ **JoinPlanner (JOIN계획기):** 선택된 테이블들의 외래키(FK) 관계를 양방향 그래프로 구성하고, BFS 기반 탐색으로 **JOIN 경로**를 도출합니다.\
3개 이상 테이블이 선택된 경우 LLM이 추가 JOIN 조건을 제안할 수 있으며, 실패 시 FK 기반 결과만 사용합니다.

⑤ **CandidateGenerator** **(SQL생성기)**: 쿼리 패턴에 맞는 전략 힌트를 로드하여, 스레드 풀을 통해 SQL 후보를 병렬 생성합니다. 각 패턴은 strategy_hints.json에 정의된 전략을 사용하며, 설정상 최대 후보 수는 3개이고 simple 패턴은 기본 2개로 축소됩니다.

⑥ **SQLPostProcess (SQL후처리기):** SQL AST를 기반으로 불필요한 CAST/별칭 정리, 방어적 표현 제거, 일부 JOIN/집합 연산 표현 보정을 수행합니다. 후보 생성 직후에 실행되어 Guardrails 이전의 표현 차이를 줄입니다.

⑦ **Guardrails (안전검증기):** sqlglot기반 AST 검증과 정규식 백업 검증을 사용합니다.\
금지 키워드(DROP, TRUNCATE, ALTER 등)를 차단하고, SELECT/CTE/UNION/EXCEPT/INTERSECT 계열 읽기 전용 쿼리만 허용하며, 선택된 스키마에 없는 테이블 사용을 차단합니다(CTE 별칭 예외 처리).

또한 최외곽 쿼리에 LIMIT이 없으면 자동으로 추가하며(최대 50,000행), CTE 내부 LIMIT과 구분하기 위해 AST 재귀 탐색 + 괄호 깊이(depth) 기반 백업 로직을 함께 사용합니다.

⑧ **SQLUnitTester (정적검증기):** LLM이 SQL의 논리적 타당성을 정적으로 검토합니다.\
구체적인 판정 기준은 프롬프트에 의해 유도되며, 통과 여부와 reasoning을 후보별로 기록합니다. 검증 실패 시 last_error_type은 `SEMANTIC`으로 설정됩니다.

⑨ **ExecutePreview (실행미리보기):** 검증을 통과한 후보 중 confidence가 가장 높은 SQL 1개를 SQLite에서 실행합니다.\
최대 50행 미리보기를 반환하며, 15초 타임아웃이 적용됩니다. 에러 발생 시 SCHEMA / SYNTAX / TIMEOUT / RUNTIME / UNKNOWN으로 분류합니다.

⑩ **Judge (판정기):** LLM이 실행 결과가 질문 의도에 부합하는지 판단합니다. (승인/거부)

⑪ **ResultOutput (결과출력기):** 최종 승인된 결과를 정리하는 노드입니다. 내부에서 ResultSummarizer가 실행 결과를 한국어로 요약하고, AuditLogger가 JSONL 감사 로그를 남기며, ConversationMemory에 성공 결과를 저장합니다. 요약 제약은 프롬프트로 적용되며 200자 이내와 마크다운 금지가 포함됩니다.

⑫ **Repair (수정기):** 에러 타입에 따라 7종의 맞춤 수정 프롬프트(SCHEMA / SYNTAX / SEMANTIC / SAFETY / RUNTIME / TIMEOUT / UNKNOWN)를 선택합니다.\
이전 실행 결과, 수정 이력, 실패 메모리를 참조하며, 2회 이상 실패 시 다른 접근법을 유도하는 문구를 추가합니다. SQL 해시 기반 중복 감지로 동일 SQL 반복 생성을 차단합니다.\
최대 재시도 횟수(기본 3회)를 초과하면 SafeFail로 전환됩니다.

⑬ **SafeFail (안전실패):** 최대 재시도를 초과하면 마지막 에러 정보를 포함한 안내 메시지를 생성합니다. 실패 결과를 감사 로그와 대화 메모리에 기록합니다.

* **LLM 라우팅:**

| 모델             | 역할             | 사용 노드                                                                                  |
| -------------- | -------------- | -------------------------------------------------------------------------------------- |
| 기본 설정의 메인 모델   | primary 라우팅 대상 | CandidateGenerator, Repair, Judge                                                      |
| 기본 설정의 fast 모델 | fast 라우팅 대상    | Decomposer, SchemaSelector, JoinPlanner, SQLUnitTester, ResultSummarizer, ResultOutput |

각 노드는 상태의 라우팅 플래그를 확인하여 모델을 선택합니다. 단, simple 패턴이고 use_fast_only=True인 CandidateGenerator, Repair, Judge도 fast 모델로 라우팅될 수 있습니다.

* **주요 기술:**

  * LangGraph StateGraph — 13개 노드 상태 그래프 + 5개 조건부 엣지 + Repair 재시도 루프

  * Azure OpenAI 기반 듀얼 모델 설정 (기본값: primary=gpt-4.1, fast=gpt-4.1-mini)

  * TypedDict 기반 상태 관리 + 핵심 결과 객체(dataclass) 구조화

  * Python ThreadPoolExecutor 기반 병렬 SQL 생성

  * System Prompt + Constraint Prompt + 패턴별 CTE 예시 기반 프롬프트 구성

**1.2 도구(Tool) 및 함수 연동**

* **구현 기능:**\
  SQL 생성·검증·실행을 분리한 구조를 구현하였습니다.\
  LLM이 직접 DB 세션을 조작하지 않고, 노드와 도구 계층을 통해 SQL 생성·검증·실행이 이루어집니다.

핵심 실행 결과 객체(예: `SQLCandidate`, `ExecReport`, `ValidationResult`)는 dataclass/구조화 타입으로 관리하고, 노드 간 상태 전달은 `TypedDict(GraphState)` 및 dict/list 기반 데이터를 함께 사용합니다.

* **동작 원리:**

  * LLM은 LangGraph 노드 내에서 프롬프트 응답(JSON 형태)을 생성하며, 노드 간 실행 흐름은 상태 기반 조건 분기로 제어됩니다.

  * DB 접근/실행은 전용 도구 계층에서 처리하고, LLM은 직접 DB 세션을 조작하지 않습니다.

  * 검증·실행·판정 단계의 실패는 조건부 엣지로 차단되거나 Repair로 분기되며, 일부 선택 단계는 fallback 전략으로 계속 진행할 수 있습니다.

  * 각 도구의 역할:

| 도구                   | 입출력                     | 역할                               |
| -------------------- | ----------------------- | -------------------------------- |
| **AuditLogger**      | 실행 정보 → JSONL 로그        | 실행 이력 감사 로그 파일 기록                |
| **SimpleCache**      | 키 → 값                   | 스키마/JOIN 결과 TTL 캐싱 (300초)        |
| **RelativeDateTool** | 텍스트 → 날짜 범위 리스트         | 한국어 상대 시간 → 절대 날짜 변환 (44종 패턴)    |
| **SchemaReader**     | DB 경로 → 스키마 정보          | PRAGMA 기반 DB 스키마 메타데이터 읽기        |
| **SQLExecutor**      | SQL+DB 경로 → 실행 보고서      | SQL 실행, 50행 미리보기, 에러 분류, 타임아웃 적용 |
| **SQLGuard**         | SQL 문 → 검증 결과(유효/무효+사유) | AST+정규식 기반 안전성 검증, LIMIT 강제      |

* **주요 기술:**

  * Python dataclass / TypedDict 기반 구조화 타입 정의 (SQLCandidate, ExecReport, ValidationResult, DateRange, TableScore 등)

  * sqlglot AST 파서 기반 SQL 분석 (DML/DDL 감지, CTE 별칭 인식, 최외곽 LIMIT 탐지)

  * ThreadPoolExecutor 기반 병렬 SQL 생성

  * SQLite PRAGMA 기반 스키마 리딩 (table_info, foreign_key_list)

  * sqlite3 progress handler 기반 타임아웃 인터럽트

  * 설정/메모리/캐시/벡터스토어 등의 싱글톤/전역 인스턴스 관리 패턴

**1.3 데이터 및 메모리 (RAG & Context)**

* **구현 기능:**\
  chema RAG 기반 스키마 참조 + 대화 메모리 + 벡터 검색을 결합하여, LLM이 DB 스키마를 암기하기보다 **하이브리드 검색 기반으로 필요한 스키마 정보를 참조**하도록 설계하였습니다.\
  대화 메모리를 통해 유사 질문의 성공 SQL을 재활용하고, 최근 실패 패턴을 회피하도록 유도합니다.

* **동작 원리:**

  * **스키마 메타데이터 관리:** 테이블/컬럼 설명, 샘플 값, 도메인 키워드 매핑, 전략 힌트를 JSON 파일로 관리

  * **하이브리드 테이블 검색:** BM25(70%) + 벡터 유사도(30%) 결합

  * **벡터 검색 장애 대응:** SchemaSelector 단계에서 벡터 검색 실패 시 BM25-only로 계속 진행하도록 설계 (환경 의존성 초기화 이슈는 별도 대응 필요)

  * **스키마 외 사용 차단:** Guardrails AST 검증에서 선택된 테이블 외 사용 차단 (CTE 별칭 예외)

  * **대화 메모리:** 성공 SQL 참조 / 실패 패턴 회피 / 최근 대화 컨텍스트 유지

  * **캐싱:** SchemaSelector, JoinPlanner 결과 TTL 300초 메모리 캐시

* **주요 기술:**

  * Schema RAG 패턴 (BM25 + 벡터 하이브리드, 가중합 0.7/0.3)

  * ChromaDB PersistentClient + 코사인 유사도 벡터 검색

  * Azure OpenAI text-embedding-3-large 임베딩

  * BM25 키워드 검색 (IDF 가중 TF 매칭, k1=1.5, b=0.75)

  * 테이블 단위 Chunking + 메타데이터 보강 (설명, FK, 샘플값)

  * ConversationMemory: 성공 SQL 참조(Jaccard 유사도) + 실패 패턴 참조 + 대화 컨텍스트 유지

  * SimpleCache: TTL 메모리 캐싱 (SHA-256 키)

### 주요 문제 해결 및 기술 리서치

|                       |                                                                                           |                                                                                                                                                                                                                                                     |
| --------------------- | ----------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **이슈 구분**             | **문제 상황 및 원인**                                                                            | **리서치 및 해결 과정 (Reference & Solution)**                                                                                                                                                                                                              |
| **LLM 성능-정확도 트레이드오프** | primary 모델만 사용할 경우 호출 비용/지연이 커지고, fast 모델만 사용할 경우 일부 노드에서 판단 품질 저하 가능성이 있음                | • **리서치:** 멀티 LLM 라우팅, 모델 캐스케이딩 패턴 조사 • **적용:&#x20;**&#xB178;드 역할별 gpt-4.1-mini, gpt-4.1 모델 분리 사용 - SQL 생성·수정·판단(gpt-4.1) / 분석·선택·검증·요약(gpt-4.1-mini) + simple 패턴은 전체 gpt-4.1-mini 자동 전환                                                            |
| **프롬프트 환각**           | 존재하지 않는 컬럼/테이블을 생성할 가능성                                                                   | • **리서치:** Text-to-SQL Hallucination 사례 조사 • **적용:** Schema RAG로 관련 테이블만 LLM에 제공 + "스키마 외 컬럼 사용 금지" Constraint Prompt 추가 + Guardrails AST 검증에서 미확인 테이블 자동 차단                                                                                        |
| **오류 복구 반복**          | SQL 실행 실패 시 동일하거나 유사한 SQL을 반복 생성할 수 있음                                                    | • **리서치:** Self-Refine / Repair Loop 패턴 조사 • **적용:** ①에러 타입별 7종 맞춤 수정 프롬프트 분기 ②SQL 해시 기반 중복 차단 ③2회 이상 실패 시 "완전히 다른 접근법" 유도 ④실패 메모리에서 동일 패턴 회피 힌트 자동 삽입                                                                                              |
| **워크플로우 복잡도**         | 12개 노드 + 5개 조건 분기의 복잡한 흐름에서 코드 가독성 저하                                                     | • **리서치:** LangGraph State Machine 설계 사례 • **적용:** ①TypedDict 기반 40개 필드 명시적 상태 관리 ②5개 조건부 엣지 함수로 분기 로직 분리 ③노드 함수를 역할별 5개 모듈 파일로 분리                                                                                                                  |
| **SQL 안전성**           | 대량 조회 SQL 실행 위험                                                                           | • **리서치:** 운영 DB 장애 사례 분석 • **적용:** ①Guardrails에서 LIMIT 자동 강제(최대 50,000행) — AST 기반 최외곽 LIMIT 재귀 탐색 + 괄호 깊이 추적 정규식 백업 ②DML/DDL 금지(9종 키워드) + SELECT/CTE/UNION/EXCEPT/INTERSECT만 허용 ③실행 타임아웃 15초 적용 ④질문에 명시적 기간 조건이 없는데 SQL이 현재 날짜 기반 필터를 임의로 넣는 경우 차단 |
| **GPT-5 API 호환성**     | GPT-5 모델이 기존 max_tokens 파라미터를 지원하지 않고, temperature 파라미터도 미지원(기본값 1만 허용)하여 API 호출이 실패하는 문제 | • **리서치:** Azure OpenAI 신규 모델 API 문서 조사 • **적용:** 모델명 기반 자동 파라미터 분기 ①GPT-5/4.1/4o/o1/o3/o4 계열은 max_completion_tokens 사용, 그 외 max_tokens 사용 ②GPT-5/o1/o3/o4 계열은 temperature 파라미터 자동 제외                                                               |
| **한국어 시간 표현**         | "어제", "최근 3개월", "지난주" 등 한국어 상대 시간 표현을 날짜 범위로 변환해야 함                                       | • **리서치:** 한국어 NLP 시간 표현 파싱 사례 • **적용:** RelativeDateTool 구현 — 고정 패턴 30종(오늘/어제/이번주/금주/올해/작년 등) + 숫자 패턴 14종("N일 전", "최근 N개월" 등) → 절대 날짜 범위(시작일~종료일)로 변환. 기준 날짜 시뮬레이션 지원                                                                              |
| **CTE LIMIT 오판**      | Guardrails에서 CTE 내부의 LIMIT을 최외곽 LIMIT으로 오판하여, LIMIT 없는 최종 쿼리가 그대로 통과하는 문제                 | • **리서치:** SQL 파서 깊이 분석 기법 • **적용:** ①AST 기반: 재귀 함수가 With → Union → Select 타입별로 최외곽만 LIMIT 검사 ②정규식 백업: 괄호 깊이(depth)를 추적하여 depth=0인 최외곽 영역만 LIMIT 검사                                                                                                 |
| **쿼리 패턴 오분류**         | "Top 5 트랙"(simple)을 "각 장르별 Top 1 트랙"(group_top_n)으로 오분류 → 불필요한 RANK() 사용으로 복잡도 증가         | • **리서치:** Few-shot Prompting 분류 정확도 향상 사례 **• 적용**: Decomposer 프롬프트에 ①"simple로 분류해야 하는 경우" 명시적 반례 추가 ②"각 X별/X별로 그룹 컨텍스트 없으면 group_top_n 아님" 경고 포함                                                                                                  |

### 핵심 동작 검증

**[검증 시나리오:&#x20;**&#xC7A5;애 상황에서 특정 서비스의 최근 에러 발생 현황 조&#xD68C;**]**

* **입력:** 어제 결제 서비스에서 에러가 가장 많이 발생한 API Top 5 보여줘

* **에이전트 동작:**

  * **Decomposer** (보조 모델 gpt-4.1-mini) — 의도 분석 + 날짜 해석

    * 의도/패턴/sub_questions/extracted_values를 생성

    * "어제"는 RelativeDateTool 기준 날짜에 따라 절대 날짜로 변환됨

    * simple + 듀얼 모델 설정이면 use_fast_only=True로 설정될 수 있음

  * **SchemaSelector** (보조 모델) — BM25 70% + 벡터 30% 하이브리드 테이블 선택

    * 질문과 스키마를 바탕으로 상위 테이블을 선택

    * LLM이 selected_tables / selected_columns를 보조 검토

    * 캐시 저장 (TTL 300초)

  * **ValueRetriever** — 추출값 DB 실제값 보정

    * filters에 문자열 값이 있으면 선택된 테이블 컬럼과 매칭하여 LIKE 조회로 실제값을 확인하거나 보정

  * **JoinPlanner** — FK 기반 JOIN 경로 계획

  * **CandidateGenerator** — 전략별 병렬 SQL 생성(최대 3개, simple 기본 2개)

    * simple 패턴이면 conservative / recall / metric 전략 사용

    * 대화 메모리에서 유사 질문 검색 (Jaccard 유사도 ≥ 0.5)

  * **Guardrails** — AST 기반 안전성 검증

    * 금지 키워드 검사

    * SELECT/CTE/UNION/EXCEPT/INTERSECT 계열 여부 확인

    * 미확인 테이블 검사

    * 최외곽 LIMIT 검사 및 필요 시 추가

  * **SQLUnitTester** — LLM 기반 정적 검토

    * 통과 여부와 reasoning 기록

  * **ExecutePreview** — SQLite 실행 + 50행 미리보기

    * 통과한 후보 중 confidence가 가장 높은 SQL 1개 실행

  * **Judge** — 결과 품질 판단

    * 승인/거부 판단

  * **ResultOutput** (보조 모델 기반 요약 + AuditLogger + MemorySave)

    * 한국어 요약 생성 + 감사 로그 기록 + 대화 메모리 저장

* **최종 결과:**

어제 결제 서비스에서 에러가 가장 많이 발생한 API는 /orders로 21건이었고, 그 다음은 /users/{id} 15건, /products 14건, /auth/login와 /payments 각각 11건입니다. 총 5개 엔드포인트에서 에러가 집중되었습니다.

[질문.png](/file/fe2d03d6987344ceae962794f4338af3_6548.png)[성공 쿼리.png](/file/a935ef7f54ed4b96ab208e0358b5c73f_6457.png)[쿼리결과.png](/file/b91cc9b0952f458e9bc9d9ee636621f2_6461.png)
