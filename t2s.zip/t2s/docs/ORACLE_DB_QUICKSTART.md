# Oracle 운영 DB 연결 가이드 (초보자용)

이 문서는 Text-to-SQL Assistant에 **내 회사의 Oracle DB**를 연결하는 방법을 처음부터 끝까지 설명합니다.
Oracle이 처음이어도 그대로 따라하면 됩니다.

---

## 전체 흐름 (5단계)

```
1. Oracle DB 접속 정보 확인     ← DBA에게 받기
2. .env 파일에 정보 입력        ← 복사 + 붙여넣기
3. 연결 테스트                  ← 스크립트 1줄 실행
4. 테이블 메타데이터 추출       ← 스크립트 1줄 실행
5. 테이블/컬럼 설명 보강        ← JSON 파일 편집
```

---

## STEP 1. Oracle DB 접속 정보 확인

DBA(데이터베이스 관리자)에게 아래 6가지를 받으세요.

| 항목 | 예시 | 설명 |
|------|------|------|
| **호스트(Host)** | `192.168.1.100` 또는 `oracle-prod.company.com` | DB 서버 주소 |
| **포트(Port)** | `1521` | Oracle 기본 포트 (보통 1521) |
| **서비스명(Service Name)** | `ORCL` 또는 `HRDB` | DB 인스턴스 이름 |
| **사용자(User)** | `t2sql_reader` | 로그인 계정 |
| **비밀번호(Password)** | `MyP@ssw0rd!` | 로그인 비밀번호 |
| **스키마(Schema)** | `HR` 또는 `ERP_OWNER` | 조회할 테이블이 있는 스키마 |

> **스키마(Schema)란?**
> Oracle에서 테이블을 소유한 계정 이름입니다.
> 예를 들어 `HR.EMPLOYEES` 테이블이 있으면, 스키마는 `HR`이고 테이블은 `EMPLOYEES`입니다.
> 모르겠으면 DBA에게 "어떤 스키마의 테이블을 조회하면 되나요?"라고 물어보세요.

> **서비스명(Service Name)이란?**
> Oracle 인스턴스를 구분하는 이름입니다. DBA에게 "TNS 서비스명이 뭔가요?" 또는 "tnsnames.ora에 있는 SERVICE_NAME이 뭔가요?"라고 물어보세요.
> 보통 `ORCL`, `PRODDB`, `HRDB` 같은 이름입니다.

---

## STEP 2. .env 파일에 정보 입력

프로젝트 루트(`10613/`)에 `.env` 파일을 만들고 아래 내용을 붙여넣으세요.
**꺾쇠(<>) 안의 값만 내 정보로 바꾸면 됩니다.**

```bash
# ═══════════════════════════════════════════
# 내 Oracle DB 설정
# ═══════════════════════════════════════════

# ── 1) DB 연결 정보 (DBA에게 받은 값 입력) ──
T2SQL_DB_DIALECT=oracle
T2SQL_DB_HOST=<호스트 주소>
T2SQL_DB_PORT=<포트 번호>
T2SQL_DB_SERVICE_NAME=<서비스명>
T2SQL_DB_USER=<사용자 계정>
T2SQL_DB_PASSWORD=<비밀번호>
T2SQL_DB_SCHEMA=<스키마 이름>

# ── 2) 안전 설정 (수정하지 마세요) ──────────
T2SQL_DB_READ_ONLY=true
T2SQL_DB_CONNECT_TIMEOUT_SEC=10
T2SQL_DB_QUERY_TIMEOUT_MS=15000
T2SQL_DB_ID=my_oracle

# ── 3) LLM 설정 ────────────────────────────
T2SQL_LLM_PROVIDER=openai_compatible
T2SQL_LLM_BASE_URL=<LLM 서버 주소, 예: http://10.0.1.50:8000/v1>
T2SQL_LLM_API_KEY=EMPTY
T2SQL_LLM_MODEL_PRIMARY=gpt-oss-120b
T2SQL_LLM_MODEL_FAST=gpt-oss-120b

# ── 4) 기타 (수정하지 마세요) ───────────────
ALLOW_EMPTY_RESULT=true
T2SQL_MAX_RETRIES=3
T2SQL_ENFORCE_LIMIT=true
```

### 실제 입력 예시

DBA에게 아래 정보를 받았다고 가정합니다:
- 호스트: `oracle-prod.company.com`
- 포트: `1521`
- 서비스명: `HRDB`
- 계정: `hr_reader`
- 비밀번호: `ReadOnly2024!`
- 스키마: `HR`

그러면 이렇게 입력합니다:

```bash
T2SQL_DB_DIALECT=oracle
T2SQL_DB_HOST=oracle-prod.company.com
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=HRDB
T2SQL_DB_USER=hr_reader
T2SQL_DB_PASSWORD=ReadOnly2024!
T2SQL_DB_SCHEMA=HR
```

### 자주 하는 실수

| 실수 | 올바른 방법 |
|------|-------------|
| 값에 따옴표 넣기: `T2SQL_DB_HOST="192.168.1.100"` | 따옴표 없이: `T2SQL_DB_HOST=192.168.1.100` |
| 값 뒤에 공백: `T2SQL_DB_USER=hr_reader ` | 공백 없이 정확히 입력 |
| 스키마를 소문자로: `T2SQL_DB_SCHEMA=hr` | Oracle 스키마는 대문자: `T2SQL_DB_SCHEMA=HR` |
| 포트를 생략 | 반드시 입력 (보통 `1521`) |
| 비밀번호에 `#` 포함 | `#`은 주석으로 인식될 수 있음 → 따옴표로 감싸기: `T2SQL_DB_PASSWORD='My#Pass'` |

---

## STEP 3. 연결 테스트

터미널(명령 프롬프트)에서 아래 명령 하나만 실행하세요.

```bash
python scripts/check_oracle_connection.py
```

### 성공하면 이렇게 나옵니다:

```
============================================================
Oracle 연결 확인
============================================================
  Host:         oracle-prod.company.com
  Port:         1521
  Service:      HRDB
  User:         hr_reader
  Schema:       HR
  Read-only:    True

[1/5] 연결 테스트...
  ✅ Oracle 연결 성공 — user=HR_READER, schema=HR, 테이블 42개, 메타뷰 접근 가능

[2/5] User: HR_READER, Schema: HR

[3/5] 읽기 가능 테이블 목록...
  테이블 수: 42
    - COUNTRIES
    - DEPARTMENTS
    - EMPLOYEES
    ...

[4/5] 메타데이터 접근 확인...
  ALL_TAB_COLUMNS 접근: ✅

[5/5] 샘플 SELECT...
  ✅ 'COUNTRIES' 조회 성공 (3행)
============================================================
Oracle 연결 확인 완료
============================================================
```

### 실패하면?

아래 표에서 에러 메시지를 찾아 해결하세요.

| 에러 메시지 | 원인 | 해결 방법 |
|-------------|------|-----------|
| `ORA-12541: TNS:no listener` | 서버에 접속할 수 없음 | Host/Port/Service Name을 DBA에게 다시 확인 |
| `ORA-12514: TNS:listener does not currently know of service` | Service Name이 틀림 | `T2SQL_DB_SERVICE_NAME` 값을 DBA에게 확인 |
| `ORA-01017: invalid username/password` | 계정/비밀번호 틀림 | `T2SQL_DB_USER`, `T2SQL_DB_PASSWORD` 다시 확인 |
| `ORA-28000: the account is locked` | 계정이 잠김 | DBA에게 계정 잠금 해제 요청 |
| `DPI-1047: Cannot locate a 64-bit Oracle Client library` | Oracle Client 미설치 | `pip install oracledb`로 thin 모드 사용 (별도 설치 불필요) |
| `Connection timed out` | 네트워크 차단 | 방화벽 확인, VPN 연결 확인 |
| `[ERROR] oracledb 패키지 미설치` | oracledb 미설치 | `pip install oracledb` 실행 |

---

## STEP 4. 테이블 메타데이터 추출

연결에 성공했으면 아래 명령으로 테이블 정보를 자동 추출합니다.

```bash
python scripts/export_oracle_metadata.py
```

### 특정 테이블만 추출하고 싶으면

```bash
# EMPLOYEES, DEPARTMENTS, JOBS 테이블만 추출
python scripts/export_oracle_metadata.py --include EMPLOYEES,DEPARTMENTS,JOBS
```

### 특정 테이블을 제외하고 싶으면

```bash
# SYS_LOG, AUDIT_TRAIL은 빼고 추출
python scripts/export_oracle_metadata.py --exclude SYS_LOG,AUDIT_TRAIL
```

### 결과 파일

실행하면 `src/text2sql/config/schema_metadata_oracle.json` 파일이 생성됩니다.

`.env`에 아래 한 줄을 추가하세요:

```bash
T2SQL_METADATA_PATH=src/text2sql/config/schema_metadata_oracle.json
```

---

## STEP 5. 테이블/컬럼 설명 보강 (선택사항이지만 강력 권장)

STEP 4에서 생성된 JSON 파일을 열면 이런 구조입니다:

```json
{
  "databases": {
    "my_oracle": {
      "tables": {
        "EMPLOYEES": {
          "description": "",           ← 여기에 설명을 넣으세요
          "columns": {
            "EMPLOYEE_ID": {
              "type": "NUMBER(6,0)",
              "description": ""        ← 여기에 설명을 넣으세요
            },
            "FIRST_NAME": {
              "type": "VARCHAR2(20)",
              "description": ""
            }
          }
        }
      }
    }
  }
}
```

### 왜 설명을 넣어야 하나요?

LLM이 사용자의 자연어 질문을 SQL로 변환할 때, 테이블/컬럼 설명을 참고합니다.
설명이 없으면 LLM이 컬럼 이름만 보고 추측해야 해서 정확도가 떨어집니다.

### 설명 넣는 방법

`description` 필드에 한국어로 업무 설명을 넣으세요:

```json
"EMPLOYEES": {
  "description": "직원 정보 (이름, 부서, 직급, 급여, 입사일 등)",
  "columns": {
    "EMPLOYEE_ID": {
      "type": "NUMBER(6,0)",
      "description": "직원 고유 번호 (PK)"
    },
    "FIRST_NAME": {
      "type": "VARCHAR2(20)",
      "description": "이름 (영문)"
    },
    "LAST_NAME": {
      "type": "VARCHAR2(25)",
      "description": "성 (영문)"
    },
    "SALARY": {
      "type": "NUMBER(8,2)",
      "description": "월급여 (달러)"
    },
    "DEPARTMENT_ID": {
      "type": "NUMBER(4,0)",
      "description": "소속 부서 ID (DEPARTMENTS.DEPARTMENT_ID 참조)"
    },
    "HIRE_DATE": {
      "type": "DATE",
      "description": "입사일"
    }
  }
}
```

### 대표 값(샘플 값) 넣는 방법 (선택)

컬럼에 자주 쓰이는 값을 알려주면 LLM이 WHERE 조건을 더 정확하게 만듭니다.

```json
"EMPLOYEES": {
  "description": "직원 정보",
  "columns": { ... },
  "sample_values": {
    "JOB_ID": ["IT_PROG", "SA_REP", "FI_ACCOUNT", "ST_CLERK"],
    "DEPARTMENT_ID": [10, 20, 30, 50, 80, 90]
  }
}
```

### 특정 컬럼을 숨기고 싶으면

민감한 컬럼(주민번호, 비밀번호 등)은 JSON에서 해당 컬럼을 삭제하세요.
삭제된 컬럼은 LLM이 인식하지 못하므로 SQL에 포함되지 않습니다.

```json
"columns": {
  "EMPLOYEE_ID": { ... },
  "FIRST_NAME": { ... },
  "SSN": { ... }              ← 이 줄을 삭제하면 LLM이 SSN 컬럼을 모름
}
```

---

## STEP 6. 도메인 정보 가공 (keyword_map, few_shot, 관계 보너스)

`src/text2sql/config/domain_hints.json` 파일에 **업무 용어 매핑**, **자주 쓰는 SQL 예시**, **테이블 관계 보너스**를 넣으면 LLM의 정확도가 크게 올라갑니다.

### domain_hints.json 구조

```json
{
  "databases": {
    "my_oracle": {
      "keyword_map": { ... },
      "relation_bonus_map": { ... },
      "few_shot_examples": [ ... ]
    }
  }
}
```

> **중요:** `"my_oracle"`은 `.env`의 `T2SQL_DB_ID` 값과 정확히 같아야 합니다.

### 6-1. keyword_map (업무 용어 → 테이블 매핑)

사용자가 한국어로 질문할 때, 어떤 단어가 어떤 테이블과 관련 있는지 알려주는 사전입니다.

**왜 필요한가요?**
사용자가 "직원 급여 현황"이라고 물으면, LLM은 `EMPLOYEES` 테이블을 찾아야 합니다.
keyword_map이 없으면 테이블 이름(`EMPLOYEES`)만 보고 추측해야 합니다.

**작성 방법:**

```json
"keyword_map": {
  "직원": ["EMPLOYEES", "DEPARTMENTS"],
  "급여": ["EMPLOYEES"],
  "부서": ["DEPARTMENTS", "EMPLOYEES"],
  "관리자": ["EMPLOYEES"],
  "채용": ["EMPLOYEES", "JOB_HISTORY"],
  "이직": ["JOB_HISTORY"],
  "직무": ["JOBS", "EMPLOYEES"],
  "국가": ["COUNTRIES", "LOCATIONS"],
  "지역": ["REGIONS", "LOCATIONS", "COUNTRIES"],
  "사무실": ["LOCATIONS", "DEPARTMENTS"]
}
```

**규칙:**
- 키(왼쪽): 사용자가 질문에 쓸 만한 **한국어 단어**
- 값(오른쪽): 그 단어와 관련된 **테이블 이름 배열** (대문자)
- 한 단어에 여러 테이블을 넣어도 됩니다
- 비슷한 표현도 각각 넣으세요 (예: "급여", "월급", "연봉", "임금" 모두 등록)

**팁:** 아래 질문에 답하면서 작성하세요:
- "우리 팀이 이 DB에 자주 하는 질문이 뭐지?"
- "그 질문에 들어가는 한국어 핵심 단어가 뭐지?"
- "그 단어가 어떤 테이블과 관련 있지?"

### 6-2. relation_bonus_map (관련 테이블 보너스)

어떤 테이블이 선택되면, 함께 필요할 가능성이 높은 테이블을 알려줍니다.

**왜 필요한가요?**
"직원별 부서 이름"을 물으면 `EMPLOYEES`와 `DEPARTMENTS`를 함께 선택해야 합니다.
relation_bonus_map은 `EMPLOYEES`가 선택되면 `DEPARTMENTS`에 가산점을 줍니다.

**작성 방법:**

```json
"relation_bonus_map": {
  "EMPLOYEES": ["DEPARTMENTS", "JOBS", "JOB_HISTORY"],
  "DEPARTMENTS": ["EMPLOYEES", "LOCATIONS"],
  "LOCATIONS": ["COUNTRIES", "DEPARTMENTS"],
  "COUNTRIES": ["REGIONS", "LOCATIONS"],
  "JOB_HISTORY": ["EMPLOYEES", "JOBS", "DEPARTMENTS"]
}
```

**규칙:**
- 키: 테이블 이름
- 값: 그 테이블과 자주 JOIN하는 테이블 배열
- FK 관계가 있는 테이블을 넣으면 됩니다
- 양방향으로 넣으세요 (EMPLOYEES→DEPARTMENTS, DEPARTMENTS→EMPLOYEES)

### 6-3. few_shot_examples (자주 쓰는 SQL 예시)

사용자가 자주 하는 질문과 정답 SQL을 넣어두면, LLM이 비슷한 질문에 참고합니다.

**왜 필요한가요?**
"부서별 평균 급여"에 대한 정확한 SQL을 미리 보여주면, 비슷한 질문("부서별 인원수", "부서별 최고 급여")에도 더 정확한 SQL을 생성합니다.

**작성 방법:**

```json
"few_shot_examples": [
  {
    "question": "부서별 평균 급여를 구해라",
    "sql": "SELECT d.DEPARTMENT_NAME, ROUND(AVG(e.SALARY), 2) FROM EMPLOYEES e JOIN DEPARTMENTS d ON e.DEPARTMENT_ID = d.DEPARTMENT_ID GROUP BY d.DEPARTMENT_NAME ORDER BY AVG(e.SALARY) DESC"
  },
  {
    "question": "2024년에 입사한 직원 목록",
    "sql": "SELECT FIRST_NAME, LAST_NAME, HIRE_DATE FROM EMPLOYEES WHERE EXTRACT(YEAR FROM HIRE_DATE) = 2024 ORDER BY HIRE_DATE"
  },
  {
    "question": "급여가 가장 높은 직원 5명",
    "sql": "SELECT FIRST_NAME, LAST_NAME, SALARY FROM EMPLOYEES ORDER BY SALARY DESC FETCH FIRST 5 ROWS ONLY"
  }
]
```

**규칙:**
- `question`: 사용자가 할 만한 질문 (한국어)
- `sql`: **실제 DB에서 실행 가능한 정확한 SQL** (Oracle 문법)
- 5~20개 정도 넣으면 충분합니다
- 다양한 패턴을 포함하세요 (단순 조회, 집계, JOIN, 필터, 정렬)

**팁:** Oracle에서 자주 쓰는 SQL이 있으면 그대로 넣으세요. 새로 만들 필요 없습니다.

### 6-4. 전체 예시 (HR DB)

```json
{
  "databases": {
    "my_oracle": {
      "keyword_map": {
        "직원": ["EMPLOYEES", "DEPARTMENTS"],
        "급여": ["EMPLOYEES"],
        "월급": ["EMPLOYEES"],
        "연봉": ["EMPLOYEES"],
        "부서": ["DEPARTMENTS", "EMPLOYEES"],
        "관리자": ["EMPLOYEES"],
        "매니저": ["EMPLOYEES"],
        "직무": ["JOBS", "EMPLOYEES"],
        "직책": ["JOBS", "EMPLOYEES"],
        "채용": ["EMPLOYEES", "JOB_HISTORY"],
        "입사": ["EMPLOYEES"],
        "퇴사": ["JOB_HISTORY"],
        "이직": ["JOB_HISTORY"],
        "국가": ["COUNTRIES", "LOCATIONS"],
        "지역": ["REGIONS", "LOCATIONS"],
        "사무실": ["LOCATIONS", "DEPARTMENTS"],
        "위치": ["LOCATIONS"],
        "최고": ["EMPLOYEES"],
        "최소": ["EMPLOYEES"],
        "평균": ["EMPLOYEES"],
        "인원": ["EMPLOYEES", "DEPARTMENTS"]
      },
      "relation_bonus_map": {
        "EMPLOYEES": ["DEPARTMENTS", "JOBS", "JOB_HISTORY"],
        "DEPARTMENTS": ["EMPLOYEES", "LOCATIONS"],
        "LOCATIONS": ["COUNTRIES", "DEPARTMENTS"],
        "COUNTRIES": ["REGIONS", "LOCATIONS"],
        "JOBS": ["EMPLOYEES", "JOB_HISTORY"],
        "JOB_HISTORY": ["EMPLOYEES", "JOBS", "DEPARTMENTS"]
      },
      "few_shot_examples": [
        {
          "question": "부서별 평균 급여를 구해라",
          "sql": "SELECT d.DEPARTMENT_NAME, ROUND(AVG(e.SALARY), 2) FROM EMPLOYEES e JOIN DEPARTMENTS d ON e.DEPARTMENT_ID = d.DEPARTMENT_ID GROUP BY d.DEPARTMENT_NAME ORDER BY AVG(e.SALARY) DESC"
        },
        {
          "question": "급여가 가장 높은 직원 5명",
          "sql": "SELECT FIRST_NAME, LAST_NAME, SALARY FROM EMPLOYEES ORDER BY SALARY DESC FETCH FIRST 5 ROWS ONLY"
        },
        {
          "question": "직원이 없는 부서 목록",
          "sql": "SELECT DEPARTMENT_NAME FROM DEPARTMENTS WHERE DEPARTMENT_ID NOT IN (SELECT DISTINCT DEPARTMENT_ID FROM EMPLOYEES WHERE DEPARTMENT_ID IS NOT NULL)"
        }
      ]
    }
  }
}
```

---

## STEP 7. 스키마 정리 — 어떤 테이블을 노출할지 결정

모든 테이블을 LLM에 보여주면 오히려 정확도가 떨어집니다.
**사용자가 질문할 테이블만** 골라서 노출하세요.

### 판단 기준

| 노출해야 하는 테이블 | 숨겨야 하는 테이블 |
|----------------------|-------------------|
| 사용자가 질문하는 업무 데이터 | 시스템 로그 테이블 (SYS_LOG, AUDIT_TRAIL) |
| 마스터 테이블 (고객, 상품, 부서) | 임시 테이블 (TMP_*, TEMP_*) |
| 트랜잭션 테이블 (주문, 결제) | 백업 테이블 (*_BAK, *_OLD) |
| 코드/분류 테이블 (상태코드, 지역코드) | 관리자 전용 테이블 (CONFIG, SETTINGS) |

### 방법 1: 환경변수로 필터링

```bash
# 이 테이블만 사용 (가장 간단)
T2SQL_INCLUDE_TABLES=EMPLOYEES,DEPARTMENTS,JOBS,LOCATIONS,COUNTRIES

# 이 테이블만 제외
T2SQL_EXCLUDE_TABLES=SYS_LOG,AUDIT_TRAIL,TMP_REPORT
```

### 방법 2: 메타데이터 추출 시 필터링

```bash
python scripts/export_oracle_metadata.py --include EMPLOYEES,DEPARTMENTS,JOBS
```

### 방법 3: JSON에서 직접 삭제

`schema_metadata_oracle.json`을 열어서 불필요한 테이블 블록을 삭제합니다.

### 컬럼 단위 숨기기

테이블은 보여주되, 특정 컬럼만 숨기고 싶으면:
JSON에서 해당 컬럼을 삭제하세요.

```json
"EMPLOYEES": {
  "columns": {
    "EMPLOYEE_ID": { ... },
    "FIRST_NAME": { ... },
    "SALARY": { ... }
  }
}
```

---

## 설정 완료 후 실행

```bash
# Web UI 실행
streamlit run app.py

# 또는 CLI로 질문
python scripts/run_cli.py --question "부서별 평균 급여를 구해줘"
```

Web UI 사이드바에서 아래가 표시되면 정상입니다:
```
🔌 환경: oracle + openai_compatible
DB Dialect: oracle
LLM Provider: openai_compatible
```

---

## 자주 묻는 질문 (FAQ)

### Q. Oracle Client를 따로 설치해야 하나요?

**아니요.** `python-oracledb`는 thin 모드를 기본 사용하므로 별도 Oracle Client 설치가 필요 없습니다.
`pip install oracledb`만 하면 됩니다.

### Q. 읽기 전용인데 혹시 데이터가 변경될 수 있나요?

**아니요.** 두 겹의 안전장치가 있습니다:
1. OracleAdapter가 `INSERT/UPDATE/DELETE/DROP` 등을 실행 전에 차단
2. SQLGuard가 SQL 구문 분석(AST)으로 DML/DDL을 한 번 더 차단

`T2SQL_DB_READ_ONLY=true`는 절대 `false`로 바꾸지 마세요.

### Q. DBA가 SELECT 권한만 줬는데 메타데이터 추출이 가능한가요?

가능합니다. `ALL_*` 뷰 접근이 안 되면 자동으로 `USER_*` 뷰를 사용합니다.
다만 이 경우 자기 계정 소유의 테이블만 보입니다.
다른 스키마 테이블을 보려면 DBA에게 `SELECT_CATALOG_ROLE` 권한을 요청하세요.

### Q. 테이블이 수백 개인데 전부 추출해야 하나요?

**아니요.** 사용자가 질문할 테이블만 추출하세요.

```bash
# 필요한 테이블만 지정
python scripts/export_oracle_metadata.py --include EMPLOYEES,DEPARTMENTS,JOBS,LOCATIONS
```

또는 `.env`에서:
```bash
T2SQL_INCLUDE_TABLES=EMPLOYEES,DEPARTMENTS,JOBS,LOCATIONS
```

### Q. 테이블 구조가 변경되면 어떻게 하나요?

메타데이터를 다시 추출하면 됩니다:
```bash
python scripts/export_oracle_metadata.py
```
단, **수동으로 넣은 설명(`description`)은 다시 넣어야 합니다.**
설명을 따로 보관하고 싶으면 별도 파일로 관리하세요.

### Q. 여러 Oracle DB를 동시에 사용할 수 있나요?

현재는 `.env` 파일 하나에 하나의 DB만 설정 가능합니다.
DB를 바꾸려면 `.env` 파일을 수정하고 앱을 재시작하세요.

### Q. LLM 서버 주소는 어디서 확인하나요?

AI/ML 팀에게 "gpt-oss-120b 모델의 OpenAI-compatible API endpoint가 뭔가요?"라고 물어보세요.
보통 `http://서버IP:8000/v1` 형태입니다.

테스트: `curl http://서버IP:8000/v1/models`를 실행해서 모델 목록이 나오면 정상입니다.

---

## 빠른 체크리스트

설정이 끝나면 아래를 순서대로 확인하세요:

- [ ] `.env` 파일에 Oracle 접속 정보 6개 입력 완료 (STEP 2)
- [ ] `python scripts/check_oracle_connection.py` → ✅ 연결 성공 (STEP 3)
- [ ] `python scripts/export_oracle_metadata.py` → JSON 파일 생성됨 (STEP 4)
- [ ] `.env`에 `T2SQL_METADATA_PATH=...` 추가 (STEP 4)
- [ ] JSON 파일에서 테이블/컬럼 `description` 보강 (STEP 5)
- [ ] `domain_hints.json`에 keyword_map 작성 (STEP 6)
- [ ] `domain_hints.json`에 few_shot_examples 3~5개 추가 (STEP 6)
- [ ] 불필요한 테이블은 `T2SQL_INCLUDE_TABLES`로 필터링 (STEP 7)
- [ ] `streamlit run app.py` → 사이드바에 `oracle` 표시됨
- [ ] 질문 입력 → SQL이 Oracle 문법으로 생성됨 (FETCH FIRST, TO_DATE 등)

---

## 부록 A. DBA에게 전달할 권한 SQL

DBA에게 아래 SQL을 전달하면 됩니다:

```sql
-- 읽기 전용 계정 생성
CREATE USER t2sql_reader IDENTIFIED BY "강력한_비밀번호";
GRANT CREATE SESSION TO t2sql_reader;

-- 테이블 읽기 권한
GRANT SELECT ANY TABLE TO t2sql_reader;

-- 메타데이터 조회 권한
GRANT SELECT_CATALOG_ROLE TO t2sql_reader;
-- 또는 개별 뷰:
-- GRANT SELECT ON SYS.ALL_TABLES TO t2sql_reader;
-- GRANT SELECT ON SYS.ALL_TAB_COLUMNS TO t2sql_reader;
-- GRANT SELECT ON SYS.ALL_CONSTRAINTS TO t2sql_reader;
-- GRANT SELECT ON SYS.ALL_CONS_COLUMNS TO t2sql_reader;
-- GRANT SELECT ON SYS.ALL_COL_COMMENTS TO t2sql_reader;
-- GRANT SELECT ON SYS.ALL_TAB_COMMENTS TO t2sql_reader;
```

---

## 부록 B. LLM 서버 연결 방식별 설정

| 서빙 방식 | T2SQL_LLM_BASE_URL | T2SQL_LLM_API_KEY |
|-----------|---------------------|-------------------|
| vLLM | `http://서버IP:8000/v1` | `EMPTY` |
| 사내 API Gateway | `https://ai-gateway.company.com/v1` | 발급받은 키 |
| Ollama (로컬) | `http://localhost:11434/v1` | `ollama` |

---

## 부록 C. Troubleshooting

| 에러 | 원인 | 해결 |
|------|------|------|
| `ORA-12541: TNS:no listener` | 서버 접속 불가 | Host/Port/Service Name 확인 |
| `ORA-12514: listener does not know of service` | Service Name 틀림 | DBA에게 정확한 서비스명 확인 |
| `ORA-01017: invalid username/password` | 계정/비밀번호 틀림 | 대소문자 포함 정확히 입력 |
| `ORA-00933: SQL command not properly ended` | Oracle에서 LIMIT 사용 | 자동 변환되므로 정상. 프롬프트 확인 |
| `Connection timed out` | 네트워크 차단 | 방화벽/VPN 확인 |
| `BM25로 대체` 로그 | Embedding 미설정 | 정상 동작. 벡터 검색 없이 키워드 검색만 사용 |

---

## 부록 D. 로컬 SQLite 개발과 공존

같은 코드에서 `.env`만 바꾸면 SQLite/Oracle 전환됩니다:

```bash
# 로컬 개발
T2SQL_DB_DIALECT=sqlite

# 운영
T2SQL_DB_DIALECT=oracle
```

SQLite 모드에서는 `data/databases/*.db` 파일을 자동 탐색합니다.
