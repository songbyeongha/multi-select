"""
운영 환경 전환 관련 단위 테스트
================================
Oracle 실서버 없이도 실행 가능한 테스트.

실행:
  pytest tests/local/test_prod_config.py -v
"""
import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

ROOT = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(ROOT / "src"))


# ═══ 1. Provider Selection ═══════════════════════════════════
@pytest.mark.unit
class TestProviderSelection:

    def test_default_provider_is_openai_compatible(self):
        """운영 기본값: openai_compatible"""
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_LLM_PROVIDER": "openai_compatible"}, clear=False):
            reset_settings()
            s = get_settings()
            assert s.llm_provider.provider == "openai_compatible"
            reset_settings()

    def test_azure_provider_backward_compat(self):
        """Azure 하위 호환: provider=azure_openai"""
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_LLM_PROVIDER": "azure_openai"}, clear=False):
            reset_settings()
            s = get_settings()
            assert s.llm_provider.provider == "azure_openai"
            reset_settings()

    def test_default_model_is_gpt_oss(self):
        """운영 기본 모델: gpt-oss-120b"""
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {
            "T2SQL_LLM_PROVIDER": "openai_compatible",
            "T2SQL_LLM_MODEL_PRIMARY": "gpt-oss-120b",
        }, clear=False):
            reset_settings()
            s = get_settings()
            assert s.llm_provider.model == "gpt-oss-120b"
            reset_settings()


# ═══ 2. Env Parsing ══════════════════════════════════════════
@pytest.mark.unit
class TestEnvParsing:

    def test_db_dialect_default_oracle(self):
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_DB_DIALECT": "oracle"}, clear=False):
            reset_settings()
            s = get_settings()
            assert s.db.dialect == "oracle"
            reset_settings()

    def test_db_dialect_sqlite_fallback(self):
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_DB_DIALECT": "sqlite"}, clear=False):
            reset_settings()
            s = get_settings()
            assert s.db.dialect == "sqlite"
            reset_settings()

    def test_oracle_connection_params(self):
        from text2sql.config.settings import reset_settings, get_settings, DBCfg
        reset_settings()
        env = {
            "T2SQL_DB_HOST": "dbhost.example.com",
            "T2SQL_DB_PORT": "1522",
            "T2SQL_DB_SERVICE_NAME": "TESTDB",
            "T2SQL_DB_USER": "testuser",
            "T2SQL_DB_PASSWORD": "testpass",
            "T2SQL_DB_SCHEMA": "TEST_SCHEMA",
            "T2SQL_DB_READ_ONLY": "true",
        }
        with patch.dict(os.environ, env, clear=False):
            reset_settings()
            s = get_settings()
            assert s.db.host == "dbhost.example.com"
            assert s.db.port == 1522
            assert s.db.service_name == "TESTDB"
            assert s.db.user == "testuser"
            assert s.db.schema == "TEST_SCHEMA"
            assert s.db.read_only is True
            reset_settings()

    def test_include_exclude_tables(self):
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {
            "T2SQL_INCLUDE_TABLES": "TABLE_A, TABLE_B",
            "T2SQL_EXCLUDE_TABLES": "SYS_LOG",
        }, clear=False):
            reset_settings()
            s = get_settings()
            assert s.db.include_table_list() == ["TABLE_A", "TABLE_B"]
            assert s.db.exclude_table_list() == ["SYS_LOG"]
            reset_settings()

    def test_embed_availability_check(self):
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {
            "T2SQL_EMBED_PROVIDER": "openai_compatible",
            "T2SQL_EMBED_BASE_URL": "http://localhost:8000/v1",
            "T2SQL_EMBED_API_KEY": "test",
        }, clear=False):
            reset_settings()
            s = get_settings()
            assert s.embed.is_available()
            reset_settings()


# ═══ 3. Adapter Factory ═════════════════════════════════════
@pytest.mark.unit
class TestAdapterFactory:

    def test_sqlite_adapter_creation(self):
        from text2sql.tools.db_adapters.sqlite_adapter import SQLiteAdapter
        # chinook DB가 있는 경우
        chinook = ROOT / "data" / "databases" / "chinook.db"
        if chinook.exists():
            adapter = SQLiteAdapter(str(chinook))
            assert adapter.dialect == "sqlite"
            info = adapter.test_connection()
            assert info["ok"]
            adapter.close()

    def test_oracle_adapter_requires_oracledb(self):
        """oracledb 미설치 시 ImportError 확인"""
        try:
            import oracledb
            pytest.skip("oracledb가 설치되어 있어 스킵")
        except ImportError:
            pass
        # oracledb 없으면 import 시 ImportError
        from text2sql.tools.db_adapters.oracle_adapter import _HAS_ORACLEDB
        if not _HAS_ORACLEDB:
            from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
            with pytest.raises(ImportError, match="oracledb"):
                OracleAdapter(host="localhost", user="test", password="test",
                              service_name="ORCL")


# ═══ 4. Oracle Metadata Query Builder ═══════════════════════
@pytest.mark.unit
class TestOracleMetadataQueries:

    def test_oracle_adapter_has_required_methods(self):
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
        required = ["list_tables", "table_info", "execute",
                     "test_connection", "close", "sample_values"]
        for method in required:
            assert hasattr(OracleAdapter, method), f"Missing method: {method}"

    def test_adapter_base_interface(self):
        from text2sql.tools.db_adapters.base import DBAdapter, TableMeta, ColumnInfo, ForeignKey
        # TableMeta legacy dict conversion
        tm = TableMeta(
            table_name="TEST",
            columns=[ColumnInfo(name="ID", type="NUMBER(10,0)", is_pk=True),
                     ColumnInfo(name="NAME", type="VARCHAR2(100)")],
            foreign_keys=[ForeignKey(from_column="PARENT_ID",
                                     to_table="PARENT", to_column="ID")],
            sample_rows=[{"ID": 1, "NAME": "test"}],
        )
        d = tm.to_legacy_dict()
        assert d["table_name"] == "TEST"
        assert len(d["columns"]) == 2
        assert d["columns"][0]["pk"] is True
        assert len(d["foreign_keys"]) == 1


# ═══ 5. Dialect-aware Guardrails ═════════════════════════════
@pytest.mark.unit
class TestDialectGuardrails:

    def test_oracle_limit_enforcement(self):
        from text2sql.tools.guardrails import SQLGuard
        guard = SQLGuard()
        # Oracle: FETCH FIRST N ROWS ONLY 추가
        sql = "SELECT * FROM users"
        result = guard.validate(sql, dialect="oracle")
        if result.valid:
            upper = result.sql.upper()
            assert "FETCH FIRST" in upper or "LIMIT" in upper or "ROWNUM" in upper

    def test_sqlite_limit_enforcement(self):
        from text2sql.tools.guardrails import SQLGuard
        guard = SQLGuard()
        sql = "SELECT * FROM users"
        result = guard.validate(sql, dialect="sqlite")
        if result.valid:
            assert "LIMIT" in result.sql.upper()

    def test_drop_blocked_all_dialects(self):
        from text2sql.tools.guardrails import SQLGuard
        guard = SQLGuard()
        for dialect in ["sqlite", "oracle"]:
            r = guard.validate("DROP TABLE users", dialect=dialect)
            assert not r.valid

    def test_dml_blocked_all_dialects(self):
        from text2sql.tools.guardrails import SQLGuard
        guard = SQLGuard()
        for dialect in ["sqlite", "oracle"]:
            r = guard.validate("DELETE FROM users WHERE id=1", dialect=dialect)
            assert not r.valid


# ═══ 6. SQL PostProcess ═════════════════════════════════════
@pytest.mark.unit
class TestSQLPostProcess:

    def test_process_accepts_dialect_param(self):
        from text2sql.tools.sql_postprocess import SQLPostProcessor
        proc = SQLPostProcessor()
        sql = "SELECT a FROM t"
        # dialect 파라미터 전달 확인
        result = proc.process(sql, dialect="sqlite")
        assert "SELECT" in result.upper()

    def test_process_oracle_dialect(self):
        from text2sql.tools.sql_postprocess import SQLPostProcessor
        proc = SQLPostProcessor()
        sql = "SELECT a FROM t"
        result = proc.process(sql, dialect="oracle")
        assert "SELECT" in result.upper()


# ═══ 7. Metadata Merge ═════════════════════════════════════
@pytest.mark.unit
class TestMetadataMerge:

    def test_schema_metadata_with_custom_path(self, tmp_path):
        """커스텀 metadata 경로 지원 확인"""
        meta_file = tmp_path / "custom_meta.json"
        meta_file.write_text('{"databases": {"test_db": {"tables": {"T1": {"description": "Test"}}}}}')

        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_METADATA_PATH": str(meta_file)}, clear=False):
            reset_settings()
            s = get_settings()
            meta = s.schema_metadata("test_db")
            assert meta["tables"]["T1"]["description"] == "Test"
            reset_settings()

    def test_default_metadata_fallback(self):
        """기본 schema_metadata.json fallback"""
        from text2sql.config.settings import reset_settings, get_settings
        reset_settings()
        with patch.dict(os.environ, {"T2SQL_METADATA_PATH": ""}, clear=False):
            reset_settings()
            s = get_settings()
            meta = s.schema_metadata("chinook")
            assert meta  # chinook은 기본 파일에 있음
            reset_settings()


# ═══ 8. Oracle Integration (optional) ═══════════════════════
@pytest.mark.skipif(
    not os.getenv("T2SQL_DB_HOST") or os.getenv("T2SQL_DB_DIALECT", "") != "oracle",
    reason="Oracle 환경변수 미설정"
)
@pytest.mark.integration
class TestOracleIntegration:
    """Oracle 실서버가 있을 때만 실행되는 통합 테스트."""

    def test_oracle_connection(self):
        from text2sql.tools.db_adapters import get_adapter
        adapter = get_adapter(dialect="oracle")
        info = adapter.test_connection()
        assert info["ok"], info.get("message")

    def test_oracle_list_tables(self):
        from text2sql.tools.db_adapters import get_adapter
        adapter = get_adapter(dialect="oracle")
        tables = adapter.list_tables()
        assert len(tables) > 0

    def test_oracle_table_info(self):
        from text2sql.tools.db_adapters import get_adapter
        adapter = get_adapter(dialect="oracle")
        tables = adapter.list_tables()
        if tables:
            meta = adapter.table_info(tables[0])
            assert len(meta.columns) > 0

    def test_oracle_select(self):
        from text2sql.tools.db_adapters import get_adapter
        adapter = get_adapter(dialect="oracle")
        result = adapter.execute("SELECT 1 FROM DUAL", limit=1)
        assert result["ok"]
