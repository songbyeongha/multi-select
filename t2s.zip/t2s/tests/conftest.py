"""Shared pytest fixtures."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

load_dotenv(ROOT / ".env")

os.environ.setdefault("T2SQL_LLM_PROVIDER", "openai_compatible")
os.environ.setdefault("T2SQL_DB_DIALECT", "sqlite")

DB_DIR = ROOT / "data" / "databases"


@pytest.fixture(scope="session")
def db_chinook() -> str:
    path = str(DB_DIR / "chinook.db")
    assert Path(path).exists(), f"chinook.db not found: {path}"
    return path


@pytest.fixture(scope="session")
def db_monitor() -> str:
    path = str(DB_DIR / "monitor.db")
    assert Path(path).exists(), f"monitor.db not found: {path}"
    return path


@pytest.fixture(scope="session")
def settings():
    from text2sql.config.settings import get_settings

    return get_settings()


@pytest.fixture
def guard():
    from text2sql.tools.guardrails import SQLGuard

    return SQLGuard()


@pytest.fixture
def executor():
    from text2sql.tools.executor import SQLExecutor

    return SQLExecutor()


@pytest.fixture(scope="session")
def chinook_schema(db_chinook: str):
    from text2sql.tools.executor import SchemaReader

    return SchemaReader.full_schema(db_chinook)


@pytest.fixture(scope="session")
def monitor_schema(db_monitor: str):
    from text2sql.tools.executor import SchemaReader

    return SchemaReader.full_schema(db_monitor)


@pytest.fixture
def memory():
    from text2sql.memory.conversation import ConversationMemory

    return ConversationMemory()
