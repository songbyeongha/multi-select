# Text-to-SQL Assistant

LLM 기반 Text-to-SQL 파이프라인입니다. 자연어 질문을 SQL로 변환하며, SQLite(개발)와 Oracle(운영)을 지원합니다.
사용자 피드백 + 자동 피드백으로 사용할수록 자동 개선됩니다.

## 프로젝트 구조

```text
├── app.py                          # Streamlit 웹 UI
├── pyproject.toml                  # pytest 설정
├── requirements.txt                # 런타임 의존성
├── requirements-dev.txt            # 개발/테스트 의존성
├── .env.example                    # 환경변수 템플릿
│
├── src/text2sql/
│   ├── agents/                     # 13-node LangGraph 파이프라인
│   │   ├── decomposer.py          #   질문 분석, 패턴 분류
│   │   ├── schema_nodes.py        #   BM25+LLM 스키마 선택, JOIN 계획
│   │   ├── generation_nodes.py    #   다중 전략 SQL 생성 + 피드백 힌트 주입
│   │   ├── validation_nodes.py    #   Guardrails, UnitTest, 실행 검증, Judge
│   │   ├── repair_output.py       #   SQL 수리, 결과 출력 + 자동 피드백
│   │   ├── nodes.py               #   노드 re-export
│   │   └── _utils.py              #   공유 유틸리티
│   ├── lg/                         # LangGraph 상태 및 그래프
│   │   ├── state.py               #   GraphState, SQLCandidate, ExecReport
│   │   └── graph.py               #   13-node 컴파일 그래프
│   ├── llm/                        # LLM 클라이언트
│   │   ├── client.py              #   Provider 추상화 (openai_compatible / azure_openai)
│   │   └── prompts.py             #   dialect-aware 프롬프트 템플릿
│   ├── feedback/                   # 피드백 기반 자동 개선
│   │   ├── store.py               #   피드백 저장소 (5단계 점수)
│   │   ├── auto_scorer.py         #   파이프라인 결과 기반 자동 피드백
│   │   ├── learner.py             #   자동 학습 엔진 (few_shot/keyword 갱신)
│   │   └── logger.py              #   학습 이벤트 로그
│   ├── rag/                        # 스키마 검색
│   │   ├── schema_rag.py          #   BM25 + Vector 하이브리드 선택
│   │   └── vector_store.py        #   Chroma 벡터 스토어
│   ├── tools/                      # SQL 도구
│   │   ├── executor.py            #   SQL 실행, 스키마 조회 (adapter 기반)
│   │   ├── guardrails.py          #   sqlglot AST 기반 안전성 검증
│   │   ├── sql_postprocess.py     #   AST 기반 SQL 후처리
│   │   ├── db_adapters/           #   DB 접속 추상화 계층
│   │   │   ├── base.py            #     DBAdapter 인터페이스
│   │   │   ├── sqlite_adapter.py  #     SQLite 구현
│   │   │   ├── oracle_adapter.py  #     Oracle 구현 (python-oracledb)
│   │   │   └── factory.py         #     dialect별 adapter 팩토리
│   │   ├── db_registry.py         #   DB 경로 레지스트리
│   │   ├── cli_display.py         #   rich 기반 CLI 콘솔 디스플레이
│   │   ├── date_tools.py          #   날짜 파싱
│   │   ├── audit.py               #   실행 감사 로그
│   │   └── cache.py               #   요청 캐시
│   ├── config/                     # 설정
│   │   ├── settings.py            #   환경변수 기반 설정 관리
│   │   ├── domain_hints.json      #   DB별 키워드 매핑 (자동 갱신됨)
│   │   ├── schema_metadata.json   #   스키마 메타데이터
│   │   ├── strategy_hints.json    #   쿼리 패턴별 전략
│   │   └── scenarios.json         #   테스트 시나리오
│   └── memory/                     # 대화 메모리
│       └── conversation.py        #   세션별 메모리 관리
│
├── tests/                          # 테스트
│   ├── conftest.py                #   공유 fixtures
│   └── local/                     #   유닛 테스트
│       ├── test_local.py          #     파이프라인 핵심 컴포넌트
│       └── test_prod_config.py    #     Oracle/Provider 설정, adapter 테스트
│
├── scripts/                        # 실행 스크립트
│   ├── run_cli.py                 #   CLI 실행 (rich 콘솔 + HITL + 피드백)
│   ├── check_oracle_connection.py #   Oracle 연결 확인
│   └── export_oracle_metadata.py  #   Oracle 메타데이터 추출
│
├── docs/                           # 프로젝트 문서
│   ├── ORACLE_DB_QUICKSTART.md    #   Oracle DB 연결 + 운영 설정 가이드
│   └── PROJECT_DESIGN.md          #   기획/설계/시나리오/PoC 통합 문서
│
└── data/
    ├── databases/                  #   SQLite DB 파일 (chinook, monitor)
    └── feedback/                   #   피드백 + 학습 로그 (실행 시 자동 생성)
```

## Agent 파이프라인

```mermaid
flowchart LR
    A["Question"] --> B["Decomposer"]
    B --> C["Schema Selector"]
    C --> D["Value Retriever"]
    D --> E["Join Planner"]
    E --> F["Candidate Generator"]
    F --> G["SQL PostProcess"]
    G --> H["Guardrails"]
    H --> I["Unit Tester"]
    I --> J["Execute Preview"]
    J --> K["Judge"]
    K --> L["Result Output"]
    L --> FB["Auto Feedback"]
    H -. retry .-> R["Repair"]
    I -. retry .-> R
    J -. retry .-> R
    K -. retry .-> R
    R --> H
    R -. exhausted .-> M["Safe Fail"]
    M --> FB
```

**주요 특징:**
- **Provider 추상화**: openai_compatible(운영 gpt-oss-120b) / azure_openai(개발) 전환 가능
- **Oracle + SQLite 지원**: dialect-aware adapter 기반, 운영 Oracle / 개발 SQLite 공존
- **자동 개선 피드백 루프**: 사용할수록 few_shot / keyword_map이 자동 확장
- **Self-Consistency Voting**: 다중 SQL 후보 실행 후 다수결 선택
- **읽기 전용 보장**: DML/DDL 차단 (Guardrails + Adapter 이중 검증)

## 자동 개선 시스템

```
질문 실행 → 결과 표시
                │
    ┌───────────┼────────────┐
    ▼                        ▼
 자동 피드백              사용자 피드백
 (파이프라인 신호)         (5단계 수동 평가)
    │                        │
    └───────────┬────────────┘
                ▼
        ┌───────────────┐
        │ AutoLearner   │
        └───────┬───────┘
      ┌─────────┼─────────┐
      ▼         ▼         ▼
  few_shot    keyword   error
  자동 등록   자동 확장  패턴 기록
      │         │         │
      ▼         ▼         ▼
  domain_hints.json    feedback_log
  (자동 갱신)          (다음 질문 시 주의사항 주입)
```

| 점수 | 자동 피드백 기준 | 자동 동작 |
|------|-----------------|----------|
| 5점 (매우 좋음) | 성공 + Judge 승인 + repair 0회 | few_shot 등록, keyword 확장 |
| 4점 (좋음) | 성공 + Judge 승인 + repair 1회 | few_shot 등록, keyword 확장 |
| 3점 (보통) | 성공 + repair 2회 이상 | 통계 기록 |
| 2점 (나쁨) | 실행 실패 | 오류 패턴 기록 |
| 1점 (매우 나쁨) | SAFE_FAIL (재시도 소진) | 오류 패턴 기록, 프롬프트 주의사항 주입 |

## 설치

```bash
git clone <repo-url>
cd text-to-sql-assistant-v1.0.0/10613

python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/Mac
source .venv/bin/activate

pip install -r requirements.txt
```

## 환경 설정

```bash
cp .env.example .env
# .env 파일을 열어 DB/LLM 정보 입력
```

전체 설정 항목은 [.env.example](.env.example) 참조.

## 실행

```bash
# 웹 UI
streamlit run app.py

# CLI
python scripts/run_cli.py --question "전체 고객 수를 구하라"
python scripts/run_cli.py --question "국가별 매출 현황" --hitl

# Oracle 연결 확인
python scripts/check_oracle_connection.py

# Oracle 메타데이터 추출
python scripts/export_oracle_metadata.py --db-id prod_erp

# 테스트
pytest tests/local -v
```

## 문서

| 문서 | 내용 |
|------|------|
| [docs/ORACLE_DB_QUICKSTART.md](docs/ORACLE_DB_QUICKSTART.md) | Oracle DB 연결 + 도메인 설정 + 권한/Troubleshooting 가이드 |
| [docs/PROJECT_DESIGN.md](docs/PROJECT_DESIGN.md) | 프로젝트 기획/설계/시나리오/PoC 구현 문서 |
