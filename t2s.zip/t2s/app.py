"""
Text-to-SQL Assistant  ──  Streamlit UI
"""
import sys, time, re
from pathlib import Path
import sqlglot

# 프로젝트 경로
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

import streamlit as st
from text2sql.config.settings import get_settings
from text2sql.tools.executor import SchemaReader
from text2sql.tools.date_tools import get_date_tool, parse_relative_dates
from text2sql.tools.db_registry import list_flat_dbs

# ═══════════════════════════════════════════════════════════════
# 페이지 설정
# ═══════════════════════════════════════════════════════════════
st.set_page_config(page_title="Text-to-SQL Assistant", page_icon="⚡", layout="wide")

# ═══════════════════════════════════════════════════════════════
# 스타일
# ═══════════════════════════════════════════════════════════════
st.markdown("""
<style>
/* 헤더 */
.hero { text-align:center; padding:1.2rem 0 .6rem; }
.hero h1 { font-size:2.2rem; font-weight:800;
  background:linear-gradient(135deg,#4F46E5,#7C3AED,#EC4899);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin:0; }
.hero p { color:#6B7280; font-size:1rem; margin:.3rem 0 0; }

/* 추적 로그 */
.trace-node {
  display:inline-block; padding:.15rem .55rem; border-radius:6px;
  font-size:.78rem; font-weight:600; margin-right:.4rem;
}
.tn-decomposer    { background:#EEF2FF; color:#4338CA; }
.tn-valueretriever { background:#FEF3C7; color:#92400E; }
.tn-schemaselector{ background:#D1FAE5; color:#065F46; }
.tn-joinplanner   { background:#DBEAFE; color:#1E40AF; }
.tn-candidategenerator { background:#FDE68A; color:#78350F; }
.tn-guardrails    { background:#FEE2E2; color:#991B1B; }
.tn-sqlunittester { background:#E0E7FF; color:#3730A3; }
.tn-executepreview{ background:#CCFBF1; color:#065F46; }
.tn-judge         { background:#F3E8FF; color:#6B21A8; }
.tn-repair        { background:#FFF7ED; color:#9A3412; }
.tn-resultsummarizer { background:#ECFDF5; color:#047857; }
.tn-safe_fail     { background:#FEE2E2; color:#991B1B; }
.tn-memorysave    { background:#ECFDF5; color:#047857; }

/* 날짜 지원 표현 */
.date-support { background:#F0FDF4; border:1px solid #86EFAC; border-radius:8px;
  padding:.6rem; font-size:.8rem; color:#166534; }
</style>
""", unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════
# 헤더
# ═══════════════════════════════════════════════════════════════
st.markdown("""
<div class="hero">
  <h1>⚡ Text-to-SQL Assistant</h1>
</div>
""", unsafe_allow_html=True)

# ═══════════════════════════════════════════════════════════════
# 세션 초기화
# ═══════════════════════════════════════════════════════════════
if "history" not in st.session_state:
    st.session_state.history = []
# HITL 세션
if "hitl_phase1_state" not in st.session_state:
    st.session_state.hitl_phase1_state = None
if "hitl_phase1_elapsed" not in st.session_state:
    st.session_state.hitl_phase1_elapsed = 0
if "hitl_sql_approved" not in st.session_state:
    st.session_state.hitl_sql_approved = False
# HITL 수정 요청 루프
if "hitl_repair_cycle" not in st.session_state:
    st.session_state.hitl_repair_cycle = 0
# 대량 HITL 세션
if "batch_phase1_results" not in st.session_state:
    st.session_state.batch_phase1_results = []
if "batch_approvals" not in st.session_state:
    st.session_state.batch_approvals = {}
# 시나리오 통합 테스트
if "scenario_results" not in st.session_state:
    st.session_state.scenario_results = {}

settings = get_settings()
scenarios = settings.scenarios()

DB_MAP = list_flat_dbs()  # 기존 data/databases/*.db 만 UI에 노출

# 날짜 도구 (서버 현재 시간 기준)
date_tool = get_date_tool()
current_ref = date_tool.reference_date

# ═══════════════════════════════════════════════════════════════
# 사이드바
# ═══════════════════════════════════════════════════════════════
with st.sidebar:
    # ── 환경 정보 ──
    _provider = settings.current_provider()
    _dialect = settings.current_dialect()
    _model = settings.current_model()
    st.markdown(f"### 🔌 환경: `{_dialect}` + `{_provider}`")
    st.caption(f"**DB Dialect:** `{_dialect}`")
    st.caption(f"**LLM Provider:** `{_provider}`")

    st.markdown("### 🤖 모델 정보")
    if settings.is_dual_model():
        st.caption(f"**메인 LLM:** `{_model}` _(정확도 우선)_")
        st.caption("사용처: SQL 생성, Judge, Repair")
        _fast_model = settings.llm_fast_cfg.model if _provider == "openai_compatible" else settings.llm_fast_cfg.azure_deployment
        st.caption(f"**보조 LLM:** `{_fast_model}` _(속도 우선)_")
        st.caption("사용처: 분석, 선택, 검증, 요약")
    else:
        st.caption(f"**LLM:** `{_model}`")
        st.caption("모든 Agent가 이 모델을 사용합니다")

    st.divider()
    max_retries = st.slider("최대 Repair 시도", 1, 5, 3)

    st.divider()
    hitl_enabled = st.toggle("🧑‍⚖️ SQL 실행 전 검토 (HITL)", value=False,
                              help="활성화 시 SQL 생성 후 실행 전에 사용자가 검토·수정")

    st.divider()
    st.markdown("### 📊 스키마")
    peek_db = st.selectbox("DB", list(DB_MAP.keys()))
    if peek_db and Path(DB_MAP[peek_db]).exists():
        for tbl in SchemaReader.tables(DB_MAP[peek_db]):
            with st.expander(f"📁 {tbl}", expanded=False):
                info = SchemaReader.table_info(DB_MAP[peek_db], tbl)
                for c in info["columns"]:
                    pk = " 🔑" if c["pk"] else ""
                    st.caption(f"`{c['name']}` {c['type']}{pk}")

    st.divider()
    show_feedback_stats()

# ═══════════════════════════════════════════════════════════════
# 유틸리티 함수
# ═══════════════════════════════════════════════════════════════
def format_sql(sql: str) -> str:
    """SQL을 정렬된 형태로 포맷 (sqlglot 활용)"""
    if not sql or sql == "N/A":
        return sql
    try:
        formatted = sqlglot.transpile(sql, read="sqlite", pretty=True)
        return formatted[0] if formatted else sql
    except Exception:
        return sql


def clean_summary(text: str) -> str:
    """LLM 요약의 잔존 마크다운 제거 (SUMMARIZER_SYS에서 금지하지만 안전망)"""
    if not text:
        return text
    text = re.sub(r'\*{1,2}([^*]+?)\*{1,2}', r'\1', text)
    text = re.sub(r'~~([^~]+)~~', r'\1', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    return text.strip()


# ═══════════════════════════════════════════════════════════════
# 토큰/비용 표시 헬퍼
# ═══════════════════════════════════════════════════════════════
def show_token_usage(token_usage):
    """토큰 사용량 및 비용 메트릭 표시"""
    if not token_usage:
        return
    st.markdown("#### 💰 토큰 사용량 & 비용")
    tc1, tc2, tc3, tc4 = st.columns(4)
    with tc1:
        st.metric("총 토큰", f"{token_usage.get('total_tokens', 0):,}")
    with tc2:
        st.metric("입력 토큰", f"{token_usage.get('total_prompt_tokens', 0):,}")
    with tc3:
        st.metric("출력 토큰", f"{token_usage.get('total_completion_tokens', 0):,}")
    with tc4:
        cost = token_usage.get('total_cost_usd', 0)
        st.metric("예상 비용", f"${cost:.4f}")
    with st.expander("모델별 상세", expanded=False):
        for model_name, md in token_usage.get("by_model", {}).items():
            st.caption(
                f"**{model_name}**: {md['calls']}회 호출 | "
                f"입력 {md['prompt_tokens']:,} | "
                f"출력 {md['completion_tokens']:,} | "
                f"비용 ${md.get('cost_usd', 0):.4f}"
            )


# ═══════════════════════════════════════════════════════════════
# 추적 로그 표시 헬퍼
# ═══════════════════════════════════════════════════════════════
NODE_COLORS = {
    "Decomposer": "tn-decomposer",
    "ValueRetriever": "tn-valueretriever",
    "SchemaSelector": "tn-schemaselector",
    "JoinPlanner": "tn-joinplanner",
    "CandidateGenerator": "tn-candidategenerator",
    "Guardrails": "tn-guardrails",
    "SQLUnitTester": "tn-sqlunittester",
    "ExecutePreview": "tn-executepreview",
    "Judge": "tn-judge",
    "Repair": "tn-repair",
    "ResultSummarizer": "tn-resultsummarizer",
    "MemorySave": "tn-memorysave",
    "SAFE_FAIL": "tn-safe_fail",
}


def show_trace(result):
    """파이프라인 추적 로그 표시"""
    st.markdown("#### 🔍 파이프라인 추적 로그")
    trace = result.get("trace", [])
    if not trace:
        st.caption("추적 로그가 없습니다.")
        return

    for i, entry in enumerate(trace):
        node = entry.get("node", "")
        detail = entry.get("detail", "")
        extra = entry.get("extra", {})
        css_cls = NODE_COLORS.get(node, "tn-decomposer")

        elapsed_ms = extra.get("elapsed_ms") if extra else None
        time_tag = f" ⏱️ {elapsed_ms}ms" if elapsed_ms is not None else ""

        with st.expander(
            f"**{i+1}.** {node}{time_tag} — {detail[:80]}",
            expanded=(i < 3 or "❌" in detail or "✅ 승인" in detail)
        ):
            meta_parts = []
            if elapsed_ms is not None:
                if elapsed_ms >= 1000:
                    meta_parts.append(f"⏱️ {elapsed_ms / 1000:.1f}s")
                else:
                    meta_parts.append(f"⏱️ {elapsed_ms}ms")
            model_name = extra.get("model") if extra else None
            if model_name and model_name != "—":
                meta_parts.append(f"🤖 {model_name}")
            if meta_parts:
                st.caption(" | ".join(meta_parts))

            st.markdown(
                f'<span class="trace-node {css_cls}">{node}</span> '
                f'{detail}',
                unsafe_allow_html=True
            )
            if extra:
                for k, v in extra.items():
                    if k in ("elapsed_ms", "model"):
                        continue
                    elif k == "sql":
                        st.code(format_sql(v), language="sql")
                    elif k == "reasoning":
                        st.markdown(f"**📝 이유:** {v}")
                    elif k == "issues":
                        for iss in (v if isinstance(v, list) else [v]):
                            st.warning(iss)
                    elif k == "sub_questions":
                        for sq in v:
                            st.caption(f"  ▸ {sq}")
                    elif k == "extracted_values":
                        st.json(v)
                    elif k == "detected_dates":
                        st.markdown("**🕐 감지된 날짜:**")
                        for dd in v:
                            st.caption(f"  • {dd['original']} → {dd['description']}")
                    elif k == "confidence":
                        st.progress(min(float(v), 1.0), text=f"신뢰도: {v}")
                    elif k == "query_pattern":
                        st.caption(f"🏷️ 쿼리 패턴: {v}")
                    else:
                        st.caption(f"{k}: {v}")


# ═══════════════════════════════════════════════════════════════
# HITL Phase 헬퍼
# ═══════════════════════════════════════════════════════════════
def run_phase1_generate(state):
    """Phase 1: SQL 생성 + 검증 (실행 전까지)"""
    from text2sql.agents.nodes import (
        node_decomposer, node_schema_selector, node_value_retriever,
        node_join_planner, node_candidate_generator,
        node_guardrails, node_unit_tester, node_repair,
    )

    state = node_decomposer(state)
    state = node_schema_selector(state)
    state = node_value_retriever(state)
    state = node_join_planner(state)
    state = node_candidate_generator(state)
    state = node_guardrails(state)

    # Guardrails 실패 시 repair 루프
    if not state.get("guard_passed"):
        for _ in range(state.get("max_retries", 3)):
            state = node_repair(state)
            state = node_guardrails(state)
            if state.get("guard_passed"):
                break

    if state.get("guard_passed"):
        state = node_unit_tester(state)

        # UT 실패 시 repair 루프
        if not state.get("ut_passed"):
            for _ in range(state.get("max_retries", 3) - state.get("repair_count", 0)):
                state = node_repair(state)
                state = node_guardrails(state)
                if not state.get("guard_passed"):
                    continue
                state = node_unit_tester(state)
                if state.get("ut_passed"):
                    break

    # best candidate SQL 설정
    passed = [c for c in state.get("candidates", []) if c.is_valid and c.ut_passed]
    if not passed:
        passed = [c for c in state.get("candidates", []) if c.is_valid]
    if passed:
        passed.sort(key=lambda c: c.confidence, reverse=True)
        state["preview_sql"] = passed[0].sql
        state["selected_sql"] = passed[0].sql

    return state


def run_phase2_execute(state):
    """Phase 2: SQL 실행 + Judge + 결과 요약"""
    from text2sql.agents.nodes import (
        node_execute_preview, node_judge, node_repair,
        node_guardrails, node_unit_tester,
        node_result_output, node_safe_fail,
    )

    state = node_execute_preview(state)
    report = state.get("exec_report")

    if report and report.ok:
        state = node_judge(state)
        if state.get("judge_accepted"):
            return node_result_output(state)
    else:
        # 실행 실패 → repair 필요
        pass

    # repair 루프 (Judge 거부 또는 실행 실패)
    remaining = state.get("max_retries", 3) - state.get("repair_count", 0)
    for _ in range(remaining):
        state = node_repair(state)
        if state.get("repair_count", 0) >= state.get("max_retries", 3):
            break
        state = node_guardrails(state)
        if not state.get("guard_passed"):
            continue
        state = node_unit_tester(state)
        state = node_execute_preview(state)
        r = state.get("exec_report")
        if r and r.ok:
            state = node_judge(state)
            if state.get("judge_accepted"):
                return node_result_output(state)

    return node_safe_fail(state)


def run_hitl_repair(result_state, user_feedback, max_rounds=2):
    """사용자 피드백 기반 Repair 수동 루프"""
    from text2sql.agents.repair_output import node_repair, node_result_output
    from text2sql.agents.validation_nodes import (
        node_guardrails, node_unit_tester,
        node_execute_preview, node_judge
    )
    from text2sql.lg.state import ErrorType

    state = dict(result_state)
    state["judge_accepted"] = False
    state["hitl_user_feedback"] = user_feedback
    state["judge_rationale"] = (
        f"[사용자 피드백 - 최우선] {user_feedback}\n\n"
        f"[LLM Judge] {state.get('judge_rationale', '')}"
    )
    state["last_error_type"] = ErrorType.SEMANTIC
    state["last_error_msg"] = user_feedback

    for _ in range(max_rounds):
        state = node_repair(state)
        state = node_guardrails(state)
        if not state.get("guard_passed"):
            continue
        state = node_unit_tester(state)
        state = node_execute_preview(state)
        report = state.get("exec_report")
        if report and report.ok:
            state = node_judge(state)
            if state.get("judge_accepted"):
                state = node_result_output(state)
                return state

    return state


def run_hitl_feedback_repair(state, user_feedback):
    """사용자 피드백 기반 SQL 수정 (실행 없이, HITL 검토 루프용)"""
    from text2sql.agents.nodes import node_repair, node_guardrails, node_unit_tester
    from text2sql.lg.state import ErrorType

    state = dict(state)
    state["hitl_user_feedback"] = user_feedback
    state["judge_rationale"] = f"[사용자 피드백] {user_feedback}"
    state["last_error_type"] = ErrorType.SEMANTIC
    state["last_error_msg"] = user_feedback

    # LLM repair → 검증 (실행 없이)
    state = node_repair(state)
    state = node_guardrails(state)
    if state.get("guard_passed"):
        state = node_unit_tester(state)

    # best candidate SQL 설정
    passed = [c for c in state.get("candidates", [])
              if c.is_valid and c.ut_passed]
    if not passed:
        passed = [c for c in state.get("candidates", []) if c.is_valid]
    if not passed:
        passed = state.get("candidates", [])
    if passed:
        passed.sort(key=lambda c: c.confidence, reverse=True)
        state["preview_sql"] = passed[0].sql
        state["selected_sql"] = passed[0].sql

    return state


# ═══════════════════════════════════════════════════════════════
# 결과 표시 헬퍼
# ═══════════════════════════════════════════════════════════════
def show_result(result, elapsed):
    """파이프라인 결과 전체 표시"""
    st.divider()

    # 메트릭
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.metric("상태", "✅ 성공" if result.get("success") else "❌ 실패")
    with m2:
        st.metric("처리 시간", f"{elapsed:.1f}s")
    with m3:
        st.metric("Repair 횟수", result.get("repair_count", 0))
    with m4:
        tables = result.get("selected_tables", [])
        st.metric("선택 테이블", len(tables))

    # 토큰/비용
    show_token_usage(result.get("token_usage"))

    # SQL
    st.markdown("#### 🔧 생성된 SQL")
    st.code(format_sql(result.get("final_sql", "N/A")), language="sql")

    # 결과 요약
    if result.get("success"):
        st.markdown("#### 💡 결과 요약")
        summary = clean_summary(result.get("result_summary", ""))
        st.success(summary)

        if result.get("final_result"):
            st.markdown("#### 📊 실행 결과")
            st.dataframe(result["final_result"], use_container_width=True,
                         hide_index=True)
    else:
        st.error(result.get("error", "알 수 없는 오류"))

    # 추적 로그
    st.divider()
    show_trace(result)

    # 피드백 수집
    show_feedback_ui(result)


def show_feedback_ui(result: dict):
    """결과에 대한 5단계 피드백 수집 + 자동 개선 트리거."""
    from text2sql.feedback import FeedbackRecord, FeedbackScore, get_feedback_store, get_learner

    question = result.get("question", "")
    sql = result.get("final_sql", "") or result.get("selected_sql", "")
    db_id = result.get("database_id", "")
    if not question or not sql:
        return

    feedback_key = f"fb_{hash(question + sql)}"

    if st.session_state.get(feedback_key):
        prev = st.session_state[feedback_key]
        st.info(f"피드백 완료: {prev['emoji']} {prev['label']}")
        return

    # 자동 피드백 점수 미리 표시
    from text2sql.feedback import compute_auto_score, build_auto_comment
    auto_score = compute_auto_score(result)
    auto_fs = FeedbackScore(auto_score)
    auto_comment = build_auto_comment(result, auto_score)

    st.markdown("#### 📝 결과 피드백")
    st.caption(
        f"자동 평가: {auto_fs.emoji} **{auto_fs.label_ko}** ({auto_comment}) "
        f"— 아래 버튼으로 직접 평가하면 자동 평가를 덮어씁니다."
    )

    cols = st.columns(5)
    labels = [
        ("🤩", "매우 좋음", 5),
        ("😊", "좋음", 4),
        ("😐", "보통", 3),
        ("😞", "나쁨", 2),
        ("😡", "매우 나쁨", 1),
    ]

    clicked_score = None
    for col, (emoji, label, score) in zip(cols, labels):
        with col:
            if st.button(f"{emoji}\n{label}", key=f"{feedback_key}_{score}",
                         use_container_width=True):
                clicked_score = score

    comment = st.text_input(
        "한 줄 코멘트 (선택)", key=f"{feedback_key}_comment",
        placeholder="예: 부서 이름이 아니라 부서 ID가 나왔어요",
    )

    if clicked_score is not None:
        fs = FeedbackScore(clicked_score)
        tables_used = result.get("selected_tables", [])
        exec_report = result.get("exec_report")
        row_count = 0
        if exec_report and hasattr(exec_report, "row_count"):
            row_count = exec_report.row_count or 0

        record = FeedbackRecord(
            question=question,
            sql=sql,
            database_id=db_id,
            score=clicked_score,
            user_comment=comment,
            query_pattern=result.get("query_pattern", ""),
            row_count=row_count,
            dialect=result.get("dialect", settings.current_dialect()),
            tables_used=tables_used,
        )
        get_feedback_store().add(record)

        learner = get_learner()
        learn_result = learner.learn(db_id)

        st.session_state[feedback_key] = {"emoji": fs.emoji, "label": fs.label_ko}
        st.success(f"{fs.emoji} 피드백 감사합니다! ({fs.label_ko})")

        if learn_result.get("few_shots_added", 0) > 0:
            st.toast(f"좋은 SQL이 학습 데이터에 자동 등록되었습니다 (+{learn_result['few_shots_added']}개)")
        if learn_result.get("keywords_added", 0) > 0:
            st.toast(f"키워드 매핑이 자동 확장되었습니다 (+{learn_result['keywords_added']}개)")
        if learn_result.get("errors_logged", 0) > 0:
            st.toast(f"오류 패턴이 기록되어 다음 질문에 반영됩니다")

        st.rerun()


def show_feedback_stats():
    """사이드바용 피드백 통계 표시."""
    from text2sql.feedback import get_feedback_store
    store = get_feedback_store()
    stats = store.stats()
    if stats["total"] == 0:
        return
    st.markdown(f"### 📈 피드백 통계")
    st.caption(f"총 {stats['total']}건 | 평균 {stats['avg_score']}점 | 긍정률 {stats['positive_rate']}%")
    for label, cnt in stats["distribution"].items():
        if cnt > 0:
            st.caption(f"  {label}: {cnt}건")


# ═══════════════════════════════════════════════════════════════
# 메인: 탭 구성
# ═══════════════════════════════════════════════════════════════
tab_main, tab_scenario, tab_batch, tab_history, tab_learn = st.tabs([
    "💬 질의 실행", "🧪 시나리오 통합 테스트", "📦 대량 질의", "📜 히스토리", "🧠 학습 로그"
])

with tab_main:
    # ── 질문 입력 ────────────────────────────────────────
    st.markdown("#### ✏️ 질문 입력")

    col_q, col_db = st.columns([3, 1])
    with col_q:
        question = st.text_area(
            "자연어 질문",
            height=80,
            placeholder="예: 올해 가장 많이 팔린 앨범은?",
            label_visibility="collapsed",
        )
    with col_db:
        db_choice = st.selectbox(
            "데이터베이스",
            list(DB_MAP.keys()),
            index=0,  # default: chinook
        )

    # ── 상대적 시간 표현 미리보기 ────────────────────────
    if question.strip():
        detected_dates = parse_relative_dates(question)
        if detected_dates:
            st.markdown(f"""
            <div class="date-support">
            ⏰ <b>시간 표현 해석</b> (기준: {current_ref.isoformat()}):<br/>
            {"<br/>".join([f"• <b>{rd.original_expression}</b> → {rd.description}" for rd in detected_dates])}
            </div>
            """, unsafe_allow_html=True)

    run_btn = st.button("🚀  SQL 생성 및 실행", type="primary", use_container_width=True)

    # ── 실행 ─────────────────────────────────────────────
    if run_btn and question.strip():
        # 이전 HITL 상태 초기화
        st.session_state.hitl_phase1_state = None
        st.session_state.hitl_sql_approved = False

        db_path = DB_MAP[db_choice]

        if not Path(db_path).exists():
            st.error(f"DB 파일 없음: {db_path}")
            st.stop()

        from text2sql.lg.state import new_state
        from text2sql.llm.client import get_token_accumulator

        initial = new_state(
            question=question,
            database_id=db_choice,
            db_path=db_path,
            max_retries=max_retries,
            hitl_enabled=hitl_enabled,
        )

        if hitl_enabled:
            # ── HITL Phase 1: SQL 생성만 ──
            with st.spinner("🔄 Phase 1: SQL 생성 중..."):
                get_token_accumulator().reset()
                t0 = time.time()
                try:
                    phase1_state = run_phase1_generate(initial)
                    phase1_elapsed = time.time() - t0
                except Exception as e:
                    st.error(f"파이프라인 오류: {e}")
                    import traceback
                    st.code(traceback.format_exc())
                    st.stop()

            st.session_state.hitl_phase1_state = phase1_state
            st.session_state.hitl_phase1_elapsed = phase1_elapsed
            st.session_state.hitl_sql_approved = False
            st.session_state["_hitl_question"] = question
            st.session_state["_hitl_db"] = db_choice
            st.session_state["_hitl_sc_id"] = ""
            st.rerun()

        else:
            # ── 기존 플로우: 전체 파이프라인 ──
            from text2sql.lg.graph import get_compiled_graph

            with st.spinner("🔄 파이프라인 실행 중..."):
                get_token_accumulator().reset()
                t0 = time.time()
                try:
                    graph = get_compiled_graph()
                    result = graph.invoke(initial)
                    elapsed = time.time() - t0
                except Exception as e:
                    st.error(f"파이프라인 오류: {e}")
                    import traceback
                    st.code(traceback.format_exc())
                    st.stop()

            show_result(result, elapsed)

            # 히스토리 저장
            st.session_state.history.append({
                "question": question,
                "db": db_choice,
                "scenario": "",
                "sql": result.get("final_sql", ""),
                "success": result.get("success", False),
                "time": elapsed,
                "summary": clean_summary(result.get("result_summary", "")),
            })

    elif run_btn:
        st.warning("질문을 입력하세요.")

    # ── HITL: SQL 실행 전 검토 UI ────────────────────────
    if st.session_state.get("hitl_phase1_state") is not None and not st.session_state.get("hitl_sql_approved"):
        phase1_state = st.session_state.hitl_phase1_state
        phase1_elapsed = st.session_state.get("hitl_phase1_elapsed", 0)
        repair_cycle = st.session_state.get("hitl_repair_cycle", 0)

        st.divider()
        st.markdown("#### 🔍 SQL 실행 전 검토 (HITL)")

        preview_sql = phase1_state.get("preview_sql", "")

        if preview_sql:
            m1, m2, m3, m4 = st.columns(4)
            with m1:
                st.metric("생성 시간", f"{phase1_elapsed:.1f}s")
            with m2:
                cands = phase1_state.get("candidates", [])
                st.metric("후보 수", len(cands))
            with m3:
                st.metric("선택 테이블", len(phase1_state.get("selected_tables", [])))
            with m4:
                st.metric("수정 횟수", repair_cycle)

            # 토큰 사용량
            from text2sql.llm.client import get_token_accumulator
            p1_tokens = get_token_accumulator().summary()
            show_token_usage(p1_tokens)

            # 최종 생성된 SQL (읽기 전용)
            st.markdown("**생성된 SQL:**")
            st.code(format_sql(preview_sql), language="sql")

            # 추적 로그
            show_trace(phase1_state)

            # SQL 수정 영역 (승인/취소 버튼 바로 위)
            st.divider()
            edited_sql = st.text_area(
                "SQL 수정 (필요 시 직접 수정 가능)",
                value=format_sql(preview_sql),
                height=150,
                key="hitl_sql_editor",
            )

            # ── 실행 승인 / 취소 ──
            col_approve, col_cancel = st.columns([3, 1])
            with col_approve:
                if st.button("✅ 실행 승인", type="primary",
                             use_container_width=True, key="hitl_approve"):
                    if edited_sql.strip() != preview_sql:
                        from text2sql.lg.state import SQLCandidate
                        phase1_state["candidates"] = [SQLCandidate(
                            sql=edited_sql.strip(),
                            strategy="user_edited",
                            confidence=1.0,
                            rationale="사용자가 직접 수정",
                            is_valid=True,
                            ut_passed=True,
                        )]
                        phase1_state["preview_sql"] = edited_sql.strip()
                        phase1_state["selected_sql"] = edited_sql.strip()

                    st.session_state.hitl_sql_approved = True
                    st.session_state.hitl_phase1_state = phase1_state
                    st.session_state.hitl_repair_cycle = 0
                    st.rerun()

            with col_cancel:
                if st.button("❌ 취소", use_container_width=True,
                             key="hitl_reject"):
                    st.session_state.hitl_phase1_state = None
                    st.session_state.hitl_sql_approved = False
                    st.session_state.hitl_repair_cycle = 0
                    st.rerun()

            # ── 수정 요청 (피드백 → LLM Repair) ──
            st.divider()
            st.markdown("**🔄 수정 요청**")
            st.caption("SQL이 의도와 다르면 수정 사항을 입력하세요. LLM이 피드백을 반영하여 SQL을 재생성합니다.")
            feedback = st.text_area(
                "수정 요청 사항",
                placeholder="예: GROUP BY 대신 WINDOW 함수를 사용해줘, WHERE 조건에 날짜 필터 추가해줘",
                height=80,
                key="hitl_feedback",
            )
            if st.button("🔄 수정 요청", use_container_width=True,
                         key="hitl_repair_btn",
                         disabled=not feedback.strip()):
                with st.spinner("🔄 피드백 반영하여 SQL 수정 중..."):
                    repaired = run_hitl_feedback_repair(phase1_state, feedback.strip())

                st.session_state.hitl_phase1_state = repaired
                st.session_state.hitl_repair_cycle = repair_cycle + 1
                st.rerun()
        else:
            st.error("유효한 SQL을 생성하지 못했습니다.")
            show_trace(phase1_state)
            # 유효 SQL 없어도 피드백 수정 요청 가능
            st.divider()
            st.markdown("**🔄 수정 요청**")
            feedback_fail = st.text_area(
                "추가 지시사항 입력",
                placeholder="예: 테이블명을 확인해줘, 조건을 단순화해줘",
                height=80,
                key="hitl_feedback_fail",
            )
            col_retry, col_cancel2 = st.columns([3, 1])
            with col_retry:
                if st.button("🔄 수정 요청", use_container_width=True,
                             key="hitl_repair_fail_btn",
                             disabled=not feedback_fail.strip()):
                    with st.spinner("🔄 피드백 반영하여 SQL 수정 중..."):
                        repaired = run_hitl_feedback_repair(phase1_state, feedback_fail.strip())
                    st.session_state.hitl_phase1_state = repaired
                    st.session_state.hitl_repair_cycle = repair_cycle + 1
                    st.rerun()
            with col_cancel2:
                if st.button("❌ 취소", use_container_width=True,
                             key="hitl_cancel_fail"):
                    st.session_state.hitl_phase1_state = None
                    st.session_state.hitl_sql_approved = False
                    st.session_state.hitl_repair_cycle = 0
                    st.rerun()

    # ── HITL: Phase 2 실행 (승인 후) ─────────────────────
    if st.session_state.get("hitl_sql_approved") and st.session_state.get("hitl_phase1_state") is not None:
        phase1_state = st.session_state.hitl_phase1_state
        phase1_elapsed = st.session_state.get("hitl_phase1_elapsed", 0)

        st.divider()
        with st.spinner("🔄 Phase 2: SQL 실행 중..."):
            t0 = time.time()
            try:
                result = run_phase2_execute(phase1_state)
                phase2_elapsed = time.time() - t0
                elapsed = phase1_elapsed + phase2_elapsed
            except Exception as e:
                st.error(f"실행 오류: {e}")
                import traceback
                st.code(traceback.format_exc())
                st.session_state.hitl_phase1_state = None
                st.session_state.hitl_sql_approved = False
                st.stop()

        show_result(result, elapsed)

        # 히스토리 저장
        _q = st.session_state.get("_hitl_question", "")
        _db = st.session_state.get("_hitl_db", "")
        _sc = st.session_state.get("_hitl_sc_id", "")
        st.session_state.history.append({
            "question": _q,
            "db": _db,
            "scenario": _sc,
            "sql": result.get("final_sql", ""),
            "success": result.get("success", False),
            "time": elapsed,
            "summary": clean_summary(result.get("result_summary", "")),
        })

        # HITL 상태 초기화
        st.session_state.hitl_phase1_state = None
        st.session_state.hitl_sql_approved = False


# ═══════════════════════════════════════════════════════════════
# 시나리오 통합 테스트 탭
# ═══════════════════════════════════════════════════════════════
with tab_scenario:
    st.markdown("#### 🧪 시나리오 통합 테스트")
    st.caption("사전 정의된 시나리오를 실행하여 파이프라인을 검증합니다.")

    # ── 전체 실행 버튼 ──
    run_all_btn = st.button(
        "🚀  전체 시나리오 실행",
        type="primary",
        use_container_width=True,
        key="sc_run_all",
    )

    st.divider()

    # ── 시나리오 카드 + 개별 실행 ──
    for sc in scenarios:
        sc_id = sc["id"]
        with st.container():
            col_info, col_action = st.columns([4, 1])
            with col_info:
                st.markdown(
                    f"**{sc['icon']} {sc_id}: {sc['title']}**  "
                    f"&nbsp;`{sc['db']}`"
                )
                st.caption(sc["description"])
                with st.expander("상세 정보", expanded=False):
                    st.markdown(f"**예시 질문:** {sc['example_question']}")
                    st.markdown("**기대 출력:**")
                    for o in sc.get("expected_output", []):
                        st.caption(f"• {o}")
                    st.markdown("**성공 기준:**")
                    for c in sc.get("success_criteria", []):
                        st.caption(f"• {c}")
            with col_action:
                if st.button(
                    "▶ 실행",
                    key=f"sc_run_{sc_id}",
                    use_container_width=True,
                ):
                    sc_db_path = DB_MAP.get(sc["db"], "")
                    if not sc_db_path or not Path(sc_db_path).exists():
                        st.error(f"DB 파일 없음: {sc['db']}")
                    else:
                        from text2sql.lg.state import new_state
                        from text2sql.lg.graph import get_compiled_graph
                        from text2sql.llm.client import get_token_accumulator

                        with st.spinner(f"🔄 {sc_id} 실행 중..."):
                            get_token_accumulator().reset()
                            t0 = time.time()
                            try:
                                graph = get_compiled_graph()
                                initial = new_state(
                                    question=sc["example_question"],
                                    database_id=sc["db"],
                                    db_path=sc_db_path,
                                    scenario_id=sc_id,
                                    max_retries=max_retries,
                                    hitl_enabled=False,
                                )
                                result = graph.invoke(initial)
                                elapsed = time.time() - t0
                                token_usage = result.get("token_usage")
                                st.session_state.scenario_results[sc_id] = {
                                    "scenario": sc,
                                    "result": result,
                                    "elapsed": elapsed,
                                    "success": result.get("success", False),
                                    "sql": result.get("final_sql", ""),
                                    "summary": clean_summary(result.get("result_summary", "")),
                                    "repair_count": result.get("repair_count", 0),
                                    "token_usage": token_usage,
                                    "final_result": result.get("final_result"),
                                    "error": result.get("error", ""),
                                    "trace": result.get("trace", []),
                                }
                            except Exception as e:
                                elapsed = time.time() - t0
                                st.session_state.scenario_results[sc_id] = {
                                    "scenario": sc,
                                    "result": None,
                                    "elapsed": elapsed,
                                    "success": False,
                                    "sql": "",
                                    "summary": "",
                                    "repair_count": 0,
                                    "token_usage": None,
                                    "final_result": None,
                                    "error": str(e),
                                    "trace": [],
                                }
                        st.rerun()

            # 개별 결과 표시 (이미 실행된 경우)
            sr = st.session_state.scenario_results.get(sc_id)
            if sr:
                icon = "✅" if sr["success"] else "❌"
                st.markdown(f"{icon} **결과:** {sr['summary'][:80] or sr['error'][:80]}  |  ⏱️ {sr['elapsed']:.1f}s")

        st.divider()

    # ── 전체 실행 ──
    if run_all_btn:
        from text2sql.lg.state import new_state
        from text2sql.lg.graph import get_compiled_graph
        from text2sql.llm.client import get_token_accumulator

        graph = get_compiled_graph()
        progress = st.progress(0, text="시나리오 실행 준비 중...")

        for idx, sc in enumerate(scenarios):
            sc_id = sc["id"]
            progress.progress(
                idx / len(scenarios),
                text=f"({idx+1}/{len(scenarios)}) {sc_id}: {sc['title'][:30]} 실행 중...",
            )

            sc_db_path = DB_MAP.get(sc["db"], "")
            if not sc_db_path or not Path(sc_db_path).exists():
                st.session_state.scenario_results[sc_id] = {
                    "scenario": sc,
                    "result": None,
                    "elapsed": 0,
                    "success": False,
                    "sql": "",
                    "summary": "",
                    "repair_count": 0,
                    "token_usage": None,
                    "final_result": None,
                    "error": f"DB 파일 없음: {sc['db']}",
                    "trace": [],
                }
                continue

            get_token_accumulator().reset()
            t0 = time.time()
            try:
                initial = new_state(
                    question=sc["example_question"],
                    database_id=sc["db"],
                    db_path=sc_db_path,
                    scenario_id=sc_id,
                    max_retries=max_retries,
                    hitl_enabled=False,
                )
                result = graph.invoke(initial)
                elapsed = time.time() - t0
                token_usage = result.get("token_usage")
                st.session_state.scenario_results[sc_id] = {
                    "scenario": sc,
                    "result": result,
                    "elapsed": elapsed,
                    "success": result.get("success", False),
                    "sql": result.get("final_sql", ""),
                    "summary": clean_summary(result.get("result_summary", "")),
                    "repair_count": result.get("repair_count", 0),
                    "token_usage": token_usage,
                    "final_result": result.get("final_result"),
                    "error": result.get("error", ""),
                    "trace": result.get("trace", []),
                }
            except Exception as e:
                elapsed = time.time() - t0
                st.session_state.scenario_results[sc_id] = {
                    "scenario": sc,
                    "result": None,
                    "elapsed": elapsed,
                    "success": False,
                    "sql": "",
                    "summary": "",
                    "repair_count": 0,
                    "token_usage": None,
                    "final_result": None,
                    "error": str(e),
                    "trace": [],
                }

            # 히스토리에도 저장
            sr = st.session_state.scenario_results[sc_id]
            st.session_state.history.append({
                "question": sc["example_question"],
                "db": sc["db"],
                "scenario": sc_id,
                "sql": sr["sql"],
                "success": sr["success"],
                "time": sr["elapsed"],
                "summary": sr["summary"],
            })

        progress.progress(1.0, text="전체 시나리오 실행 완료!")
        st.rerun()

    # ── 통합 결과 요약 ──
    if st.session_state.scenario_results:
        st.markdown("---")
        st.markdown("#### 📊 테스트 결과 요약")

        all_sr = st.session_state.scenario_results
        total = len(all_sr)
        passed = sum(1 for sr in all_sr.values() if sr["success"])
        failed = total - passed
        total_time = sum(sr["elapsed"] for sr in all_sr.values())
        total_cost = sum(
            sr["token_usage"].get("total_cost_usd", 0)
            for sr in all_sr.values() if sr.get("token_usage")
        )

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.metric("전체", f"{total}건")
        with m2:
            st.metric("성공", f"{passed}건")
        with m3:
            st.metric("실패", f"{failed}건")
        with m4:
            st.metric("총 소요시간", f"{total_time:.1f}s")

        m5, m6 = st.columns(2)
        with m5:
            st.metric("성공률", f"{passed/total*100:.0f}%" if total else "—")
        with m6:
            st.metric("총 비용", f"${total_cost:.4f}")

        # 결과 요약 테이블
        summary_rows = []
        for sc in scenarios:
            sr = all_sr.get(sc["id"])
            if not sr:
                continue
            icon = "✅" if sr["success"] else "❌"
            summary_rows.append({
                "상태": icon,
                "시나리오": f"{sc['icon']} {sc['id']}",
                "제목": sc["title"],
                "DB": sc["db"],
                "소요시간(초)": round(sr["elapsed"], 1),
                "Repair": sr["repair_count"],
                "요약": sr["summary"][:60] or sr["error"][:60],
            })
        if summary_rows:
            st.dataframe(summary_rows, use_container_width=True, hide_index=True)

        # 개별 상세 결과
        st.markdown("#### 📋 개별 상세 결과")
        for sc in scenarios:
            sr = all_sr.get(sc["id"])
            if not sr:
                continue
            icon = "✅" if sr["success"] else "❌"
            with st.expander(
                f"{icon} **{sc['icon']} {sc['id']}: {sc['title']}**  —  "
                f"{'성공' if sr['success'] else '실패'} ({sr['elapsed']:.1f}s)"
            ):
                c1, c2, c3 = st.columns(3)
                with c1:
                    st.metric("상태", f"{icon} {'성공' if sr['success'] else '실패'}")
                with c2:
                    st.metric("소요시간", f"{sr['elapsed']:.1f}s")
                with c3:
                    st.metric("Repair 횟수", sr["repair_count"])

                # 토큰/비용 (expander 중첩 방지를 위해 인라인 표시)
                tu = sr.get("token_usage")
                if tu:
                    tc1, tc2, tc3, tc4 = st.columns(4)
                    with tc1:
                        st.metric("총 토큰", f"{tu.get('total_tokens', 0):,}")
                    with tc2:
                        st.metric("입력 토큰", f"{tu.get('total_prompt_tokens', 0):,}")
                    with tc3:
                        st.metric("출력 토큰", f"{tu.get('total_completion_tokens', 0):,}")
                    with tc4:
                        st.metric("예상 비용", f"${tu.get('total_cost_usd', 0):.4f}")

                if sr["sql"]:
                    st.markdown("**생성된 SQL:**")
                    st.code(format_sql(sr["sql"]), language="sql")

                if sr["success"] and sr["summary"]:
                    st.markdown("**결과 요약:**")
                    st.success(sr["summary"])

                if sr["success"] and sr.get("final_result"):
                    st.markdown("**실행 결과:**")
                    st.dataframe(sr["final_result"], use_container_width=True,
                                 hide_index=True)

                if sr["error"]:
                    st.error(f"오류: {sr['error']}")

        # 초기화 버튼
        if st.button("🗑️ 테스트 결과 초기화", key="sc_clear"):
            st.session_state.scenario_results = {}
            st.rerun()


# ═══════════════════════════════════════════════════════════════
# 대량 질의 탭
# ═══════════════════════════════════════════════════════════════
with tab_batch:
    st.markdown("#### 📦 대량 질의 실행")
    st.caption("여러 질문을 한 줄에 하나씩 입력하세요. 빈 줄은 무시됩니다.")

    col_bq, col_bdb = st.columns([3, 1])
    with col_bq:
        batch_text = st.text_area(
            "대량 질문 입력",
            height=200,
            placeholder="올해 가장 많이 팔린 앨범은?\n장르별 트랙 수를 알려줘\n최근 한 달간 에러율이 가장 높은 서비스는?",
            label_visibility="collapsed",
        )
    with col_bdb:
        batch_db = st.selectbox(
            "데이터베이스", list(DB_MAP.keys()), key="batch_db_select"
        )

    batch_questions = [q.strip() for q in batch_text.splitlines() if q.strip()]
    st.caption(f"총 **{len(batch_questions)}**개 질문 감지")

    batch_run = st.button(
        "🚀  대량 실행 시작", type="primary",
        use_container_width=True, key="batch_run",
    )

    # ── 대량 실행 ──────────────────────────────────────────
    if batch_run and batch_questions:
        batch_db_path = DB_MAP[batch_db]
        if not Path(batch_db_path).exists():
            st.error(f"DB 파일 없음: {batch_db_path}")
            st.stop()

        from text2sql.lg.state import new_state
        from text2sql.llm.client import get_token_accumulator

        if hitl_enabled:
            # ── 대량 HITL: Phase 1만 실행 ──
            phase1_results = []
            progress_bar = st.progress(0, text="SQL 생성 중...")

            for idx, q in enumerate(batch_questions):
                progress_bar.progress(
                    idx / len(batch_questions),
                    text=f"({idx + 1}/{len(batch_questions)}) SQL 생성 중: {q[:50]}...",
                )

                initial = new_state(
                    question=q,
                    database_id=batch_db,
                    db_path=batch_db_path,
                    max_retries=max_retries,
                    hitl_enabled=True,
                )

                get_token_accumulator().reset()
                t0 = time.time()
                try:
                    state = run_phase1_generate(initial)
                    p1_elapsed = time.time() - t0
                    phase1_results.append({
                        "idx": idx,
                        "question": q,
                        "state": state,
                        "sql": state.get("preview_sql", ""),
                        "elapsed": p1_elapsed,
                        "has_sql": bool(state.get("preview_sql", "")),
                    })
                except Exception as e:
                    phase1_results.append({
                        "idx": idx,
                        "question": q,
                        "state": None,
                        "sql": "",
                        "elapsed": time.time() - t0,
                        "has_sql": False,
                        "error": str(e),
                    })

            progress_bar.progress(1.0, text="SQL 생성 완료!")
            st.session_state.batch_phase1_results = phase1_results
            st.session_state.batch_approvals = {
                r["idx"]: r["has_sql"] for r in phase1_results
            }
            st.rerun()

        else:
            # ── 기존 플로우: 전체 실행 ──
            from text2sql.lg.graph import get_compiled_graph

            graph = get_compiled_graph()
            batch_results = []

            progress_bar = st.progress(0, text="대량 질의 준비 중...")

            for idx, q in enumerate(batch_questions):
                progress_bar.progress(
                    (idx) / len(batch_questions),
                    text=f"({idx + 1}/{len(batch_questions)}) 실행 중: {q[:50]}...",
                )

                initial = new_state(
                    question=q,
                    database_id=batch_db,
                    db_path=batch_db_path,
                    max_retries=max_retries,
                    hitl_enabled=False,
                )

                get_token_accumulator().reset()
                t0 = time.time()
                try:
                    result = graph.invoke(initial)
                    elapsed = time.time() - t0
                    token_usage = result.get("token_usage")
                    models_used = ", ".join(token_usage.get("by_model", {}).keys()) if token_usage else ""
                    batch_results.append({
                        "번호": idx + 1,
                        "질문": q,
                        "상태": "성공" if result.get("success") else "실패",
                        "소요시간(초)": round(elapsed, 1),
                        "Repair 횟수": result.get("repair_count", 0),
                        "사용 모델": models_used,
                        "선택 테이블": ", ".join(result.get("selected_tables", [])),
                        "SQL": result.get("final_sql", ""),
                        "요약": clean_summary(result.get("result_summary", "")),
                        "토큰": token_usage.get("total_tokens", 0) if token_usage else 0,
                        "비용($)": round(token_usage.get("total_cost_usd", 0), 4) if token_usage else 0,
                        "오류": result.get("error", "") or "",
                        "_success": result.get("success", False),
                        "_result": result.get("final_result"),
                        "_token_usage": token_usage,
                    })
                except Exception as e:
                    elapsed = time.time() - t0
                    batch_results.append({
                        "번호": idx + 1,
                        "질문": q,
                        "상태": "오류",
                        "소요시간(초)": round(elapsed, 1),
                        "Repair 횟수": 0,
                        "사용 모델": "",
                        "선택 테이블": "",
                        "SQL": "",
                        "요약": "",
                        "토큰": 0,
                        "비용($)": 0,
                        "오류": str(e),
                        "_success": False,
                        "_result": None,
                        "_token_usage": None,
                    })

                # 히스토리에도 저장
                st.session_state.history.append({
                    "question": q,
                    "db": batch_db,
                    "scenario": "",
                    "sql": batch_results[-1]["SQL"],
                    "success": batch_results[-1]["_success"],
                    "time": batch_results[-1]["소요시간(초)"],
                    "summary": batch_results[-1]["요약"],
                })

            progress_bar.progress(1.0, text="완료!")
            st.session_state["batch_results"] = batch_results

    elif batch_run:
        st.warning("질문을 입력하세요.")

    # ── 대량 HITL: SQL 검토 UI ────────────────────────────
    if st.session_state.get("batch_phase1_results"):
        phase1_results = st.session_state.batch_phase1_results
        approvals = st.session_state.batch_approvals

        st.divider()
        st.markdown("#### 🔍 대량 SQL 실행 전 검토")

        col_all, col_none = st.columns(2)
        with col_all:
            if st.button("전체 선택", key="batch_hitl_all"):
                for r in phase1_results:
                    if r["has_sql"]:
                        st.session_state.batch_approvals[r["idx"]] = True
                st.rerun()
        with col_none:
            if st.button("전체 해제", key="batch_hitl_none"):
                for r in phase1_results:
                    st.session_state.batch_approvals[r["idx"]] = False
                st.rerun()

        for r in phase1_results:
            if not r.get("has_sql"):
                st.error(f"[{r['idx']+1}] {r['question'][:60]} — SQL 생성 실패"
                         f"{': ' + r.get('error', '') if r.get('error') else ''}")
                continue

            approved = st.checkbox(
                f"[{r['idx']+1}] {r['question'][:60]}",
                value=approvals.get(r["idx"], True),
                key=f"batch_hitl_{r['idx']}",
            )
            st.session_state.batch_approvals[r["idx"]] = approved

            with st.expander(f"SQL 미리보기·수정 [{r['idx']+1}]", expanded=False):
                st.text_area(
                    "SQL (직접 수정 가능)",
                    value=format_sql(r["sql"]),
                    height=120,
                    key=f"batch_sql_edit_{r['idx']}",
                    label_visibility="collapsed",
                )

        approved_count = sum(1 for v in approvals.values() if v)
        st.caption(f"승인된 질의: {approved_count}/{len(phase1_results)}")

        col_exec, col_cancel = st.columns(2)
        with col_exec:
            if st.button(f"🚀 승인된 {approved_count}개 실행", type="primary",
                         use_container_width=True, key="batch_hitl_execute"):
                from text2sql.llm.client import get_token_accumulator

                batch_results = []
                approved_list = [r for r in phase1_results
                                 if approvals.get(r["idx"], False) and r.get("state")]
                progress_bar = st.progress(0, text="실행 중...")

                for i, r in enumerate(approved_list):
                    progress_bar.progress(
                        i / max(len(approved_list), 1),
                        text=f"({i+1}/{len(approved_list)}) 실행 중: {r['question'][:50]}...",
                    )

                    # 사용자가 SQL을 수정한 경우 반영
                    exec_state = r["state"]
                    edit_key = f"batch_sql_edit_{r['idx']}"
                    edited = st.session_state.get(edit_key, "")
                    if edited and edited.strip() != r["sql"]:
                        from text2sql.lg.state import SQLCandidate
                        exec_state = dict(exec_state)
                        exec_state["candidates"] = [SQLCandidate(
                            sql=edited.strip(),
                            strategy="user_edited",
                            confidence=1.0,
                            rationale="사용자가 직접 수정",
                            is_valid=True,
                            ut_passed=True,
                        )]
                        exec_state["preview_sql"] = edited.strip()
                        exec_state["selected_sql"] = edited.strip()

                    get_token_accumulator().reset()
                    t0 = time.time()
                    try:
                        result = run_phase2_execute(exec_state)
                        elapsed = r["elapsed"] + (time.time() - t0)
                        token_usage = result.get("token_usage")
                        models_used = ", ".join(token_usage.get("by_model", {}).keys()) if token_usage else ""
                        batch_results.append({
                            "번호": r["idx"] + 1,
                            "질문": r["question"],
                            "상태": "성공" if result.get("success") else "실패",
                            "소요시간(초)": round(elapsed, 1),
                            "Repair 횟수": result.get("repair_count", 0),
                            "사용 모델": models_used,
                            "선택 테이블": ", ".join(result.get("selected_tables", [])),
                            "SQL": result.get("final_sql", ""),
                            "요약": clean_summary(result.get("result_summary", "")),
                            "토큰": token_usage.get("total_tokens", 0) if token_usage else 0,
                            "비용($)": round(token_usage.get("total_cost_usd", 0), 4) if token_usage else 0,
                            "오류": result.get("error", "") or "",
                            "_success": result.get("success", False),
                            "_result": result.get("final_result"),
                            "_token_usage": token_usage,
                        })
                    except Exception as e:
                        batch_results.append({
                            "번호": r["idx"] + 1,
                            "질문": r["question"],
                            "상태": "오류",
                            "소요시간(초)": round(time.time() - t0, 1),
                            "Repair 횟수": 0,
                            "사용 모델": "",
                            "선택 테이블": "",
                            "SQL": "",
                            "요약": "",
                            "토큰": 0,
                            "비용($)": 0,
                            "오류": str(e),
                            "_success": False,
                            "_result": None,
                            "_token_usage": None,
                        })

                    st.session_state.history.append({
                        "question": r["question"],
                        "db": batch_db,
                        "scenario": "",
                        "sql": batch_results[-1]["SQL"],
                        "success": batch_results[-1]["_success"],
                        "time": batch_results[-1]["소요시간(초)"],
                        "summary": batch_results[-1]["요약"],
                    })

                progress_bar.progress(1.0, text="완료!")
                st.session_state["batch_results"] = batch_results
                st.session_state.batch_phase1_results = []
                st.rerun()

        with col_cancel:
            if st.button("❌ 전체 취소", use_container_width=True,
                         key="batch_hitl_cancel"):
                st.session_state.batch_phase1_results = []
                st.session_state.batch_approvals = {}
                st.rerun()

    # ── 대량 실행 결과 표시 ─────────────────────────────────
    if "batch_results" in st.session_state and st.session_state["batch_results"]:
        results = st.session_state["batch_results"]
        st.divider()

        # 요약 메트릭
        total = len(results)
        success_count = sum(1 for r in results if r["_success"])
        fail_count = total - success_count
        total_time = sum(r["소요시간(초)"] for r in results)
        avg_time = total_time / total if total else 0
        total_cost = sum(r.get("비용($)", 0) for r in results)
        total_tokens = sum(r.get("토큰", 0) for r in results)

        m1, m2, m3 = st.columns(3)
        with m1:
            st.metric("전체", f"{total}건")
        with m2:
            st.metric("성공", f"{success_count}건")
        with m3:
            st.metric("실패", f"{fail_count}건")

        m4, m5, m6 = st.columns(3)
        with m4:
            st.metric("총 소요시간", f"{total_time:.1f}s")
        with m5:
            st.metric("평균 소요시간", f"{avg_time:.1f}s")
        with m6:
            st.metric("총 비용", f"${total_cost:.4f}")

        m7, m8 = st.columns(2)
        with m7:
            st.metric("총 토큰", f"{total_tokens:,}")
        with m8:
            # 모델별 비용 집계
            model_summary = {}
            for r in results:
                tu = r.get("_token_usage")
                if not tu:
                    continue
                for mname, md in tu.get("by_model", {}).items():
                    if mname not in model_summary:
                        model_summary[mname] = {"calls": 0, "tokens": 0, "cost": 0.0}
                    model_summary[mname]["calls"] += md.get("calls", 0)
                    model_summary[mname]["tokens"] += md.get("total_tokens", 0)
                    model_summary[mname]["cost"] += md.get("cost_usd", 0.0)
            if model_summary:
                parts = [f"{m}: {d['calls']}회 ${d['cost']:.4f}"
                         for m, d in model_summary.items()]
                st.metric("모델별 비용", " | ".join(parts))
            else:
                st.metric("모델별 비용", "—")

        # 요약 테이블
        st.markdown("#### 📊 결과 요약 테이블")
        display_df = [
            {k: v for k, v in r.items() if not k.startswith("_")}
            for r in results
        ]
        st.dataframe(display_df, use_container_width=True, hide_index=True)

        # 모델별 상세 비용 테이블
        if model_summary:
            with st.expander("모델별 상세 비용", expanded=False):
                model_rows = []
                for mname, md in model_summary.items():
                    model_rows.append({
                        "모델": mname,
                        "호출 수": md["calls"],
                        "총 토큰": f"{md['tokens']:,}",
                        "비용($)": f"${md['cost']:.4f}",
                    })
                st.dataframe(model_rows, use_container_width=True, hide_index=True)

        # 개별 상세 결과
        st.markdown("#### 📋 개별 상세 결과")
        for r in results:
            icon = "✅" if r["_success"] else "❌"
            with st.expander(
                f"{icon} **[{r['번호']}]** {r['질문'][:60]}  —  "
                f"{r['상태']} ({r['소요시간(초)']}s)",
            ):
                c1, c2, c3 = st.columns(3)
                with c1:
                    st.metric("상태", f"{icon} {r['상태']}")
                with c2:
                    st.metric("소요시간", f"{r['소요시간(초)']}s")
                with c3:
                    st.metric("Repair 횟수", r["Repair 횟수"])

                if r["선택 테이블"]:
                    st.caption(f"**선택 테이블:** {r['선택 테이블']}")

                if r["SQL"]:
                    st.markdown("**생성된 SQL:**")
                    st.code(format_sql(r["SQL"]), language="sql")

                if r["_success"] and r["요약"]:
                    st.markdown("**결과 요약:**")
                    st.success(r["요약"])

                if r["_success"] and r["_result"]:
                    st.markdown("**실행 결과:**")
                    st.dataframe(r["_result"], use_container_width=True,
                                 hide_index=True)

                if r["오류"]:
                    st.error(f"오류: {r['오류']}")

        # 초기화 버튼
        if st.button("🗑️ 대량 질의 결과 초기화", key="batch_clear"):
            st.session_state["batch_results"] = []
            st.rerun()


# ═══════════════════════════════════════════════════════════════
# 히스토리 탭
# ═══════════════════════════════════════════════════════════════
with tab_history:
    st.markdown("### 📜 실행 히스토리")
    if st.session_state.history:
        for i, h in enumerate(reversed(st.session_state.history)):
            icon = "✅" if h["success"] else "❌"
            with st.expander(f"{icon} [{h.get('scenario','')}] {h['question'][:60]}"):
                st.markdown(f"**DB:** {h['db']}  |  **시간:** {h['time']:.1f}s")
                st.code(format_sql(h["sql"]), language="sql")
                if h.get("summary"):
                    st.info(h["summary"])
        if st.button("🗑️ 히스토리 초기화"):
            st.session_state.history = []
            st.rerun()
    else:
        st.caption("아직 실행 기록이 없습니다.")

# ═══════════════════════════════════════════════════════════════
# 학습 로그 탭
# ═══════════════════════════════════════════════════════════════
with tab_learn:
    st.markdown("#### 🧠 자동 개선 학습 로그")
    st.caption(
        "사용자 피드백이 시스템을 어떻게 개선하는지 실시간으로 확인할 수 있습니다."
    )

    from text2sql.feedback import get_feedback_store, get_feedback_logger

    _fb_store = get_feedback_store()
    _fb_logger = get_feedback_logger()

    # 통계 요약
    _fb_stats = _fb_store.stats()
    if _fb_stats["total"] > 0:
        st.markdown("##### 📊 피드백 통계")
        mc1, mc2, mc3, mc4 = st.columns(4)
        with mc1:
            st.metric("총 피드백", f"{_fb_stats['total']}건")
        with mc2:
            st.metric("평균 점수", f"{_fb_stats['avg_score']}/5")
        with mc3:
            st.metric("긍정률", f"{_fb_stats['positive_rate']}%")
        with mc4:
            st.metric("학습된 few_shot",
                       len([r for r in _fb_store.all() if r.promoted_to_few_shot]))

        st.markdown("##### 점수 분포")
        dist_cols = st.columns(5)
        _score_emojis = {
            "매우 좋음": "🤩", "좋음": "😊", "보통": "😐",
            "나쁨": "😞", "매우 나쁨": "😡"
        }
        for col, (label, cnt) in zip(dist_cols, _fb_stats["distribution"].items()):
            with col:
                emoji = _score_emojis.get(label, "")
                st.metric(f"{emoji} {label}", f"{cnt}건")

        st.divider()

    # 학습 이벤트 로그
    st.markdown("##### 📋 학습 이벤트 로그")
    _learn_events = _fb_logger.read_recent(30)

    if _learn_events:
        _event_icons = {
            "FEEDBACK_RECEIVED": "📝",
            "FEW_SHOT_PROMOTED": "✨",
            "KEYWORD_EXPANDED": "📚",
            "PATTERN_PROMOTED": "🏆",
            "PATTERN_REPLACED": "🔄",
            "ERROR_PATTERN_RECORDED": "🔍",
            "HINT_INJECTED": "💡",
            "LEARN_COMPLETE": "🎓",
        }
        for ev in reversed(_learn_events):
            ts = ev.get("timestamp", "")[:19].replace("T", " ")
            event_type = ev.get("event", "")
            icon = _event_icons.get(event_type, "📌")
            msg = ev.get("message", "")

            with st.expander(f"{icon} [{ts}] {msg}", expanded=False):
                action = ev.get("action", "")
                if action:
                    st.info(f"동작: {action}")
                if ev.get("question"):
                    st.caption(f"질문: {ev['question']}")
                if ev.get("sql"):
                    st.code(ev["sql"][:300], language="sql")
                if ev.get("score"):
                    st.caption(f"점수: {ev.get('score_label', '')} ({ev['score']}/5)")
                if ev.get("comment"):
                    st.caption(f"코멘트: {ev['comment']}")
                if ev.get("keyword"):
                    st.caption(f"키워드: {ev['keyword']} → {ev.get('tables', [])}")
                if ev.get("hint_type"):
                    st.caption(f"힌트 유형: {ev['hint_type']}")
                if ev.get("hint_preview"):
                    st.code(ev["hint_preview"], language="text")
    else:
        st.caption("아직 학습 이벤트가 없습니다. 질문 실행 후 피드백을 남겨보세요!")

    # 텍스트 로그 원문
    with st.expander("📄 텍스트 로그 원문 (최근 30줄)", expanded=False):
        raw_log = _fb_logger.read_text(30)
        st.code(raw_log, language="text")

    # 피드백 전체 목록
    with st.expander(f"📑 피드백 전체 목록 ({_fb_store.count()}건)", expanded=False):
        all_fb = _fb_store.all()
        if all_fb:
            import pandas as pd
            df = pd.DataFrame([
                {
                    "시각": r.timestamp[:19],
                    "점수": f"{r.score_label} ({r.score}/5)",
                    "질문": r.question[:50],
                    "DB": r.database_id,
                    "few_shot": "✅" if r.promoted_to_few_shot else "",
                    "코멘트": r.user_comment[:30] if r.user_comment else "",
                }
                for r in reversed(all_fb)
            ])
            st.dataframe(df, use_container_width=True, hide_index=True)

# ═══════════════════════════════════════════════════════════════
# 푸터
# ═══════════════════════════════════════════════════════════════
st.divider()
st.caption(f"Text-to-SQL Assistant v1.0  |  {settings.current_provider()} / {settings.current_model()}  |  dialect: {settings.current_dialect()}")
