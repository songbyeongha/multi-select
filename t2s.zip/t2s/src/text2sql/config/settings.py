"""
Environment-backed application settings.
=========================================
운영 기본값: Oracle + gpt-oss-120b (openai_compatible)
로컬 dev: SQLite + azure_openai 또는 openai_compatible
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[3] / ".env")

_CFG_DIR = Path(__file__).parent


def _bool_env(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).lower() in ("true", "1", "yes")


def _int_env(name: str, default: int = 0) -> int:
    return int(os.getenv(name, str(default)))


# ═══════════════════════════════════════════════════════════════
# LLM Provider 설정
# ═══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class LLMProviderCfg:
    """LLM provider 통합 설정 — openai_compatible / azure_openai 양쪽 커버."""
    provider: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_PROVIDER", "openai_compatible")
    )
    # openai_compatible
    base_url: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_BASE_URL", "http://localhost:8000/v1")
    )
    api_key: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_API_KEY", "EMPTY")
    )
    model: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_MODEL_PRIMARY", "gpt-oss-120b")
    )
    temperature: float = field(
        default_factory=lambda: float(os.getenv("T2SQL_LLM_TEMPERATURE", "0.0"))
    )
    max_tokens: int = field(
        default_factory=lambda: _int_env("T2SQL_LLM_MAX_TOKENS", 4096)
    )
    timeout_sec: int = field(
        default_factory=lambda: _int_env("T2SQL_LLM_TIMEOUT_SEC", 60)
    )
    # azure_openai 전용
    azure_endpoint: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT", "")
    )
    azure_api_key: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY", "")
    )
    azure_deployment: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_MODEL", "gpt-4.1")
    )
    azure_api_version: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview")
    )

    def effective_model(self) -> str:
        if self.provider == "azure_openai":
            return self.azure_deployment
        return self.model

    def effective_api_key(self) -> str:
        if self.provider == "azure_openai":
            return self.azure_api_key
        return self.api_key


@dataclass(frozen=True)
class LLMFastCfg:
    """보조(Fast) 모델 설정. 미지정 시 Primary와 동일."""
    model: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_MODEL_FAST",
                                          os.getenv("T2SQL_LLM_MODEL_PRIMARY", "gpt-oss-120b"))
    )
    base_url: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_BASE_URL_FAST",
                                          os.getenv("T2SQL_LLM_BASE_URL", "http://localhost:8000/v1"))
    )
    api_key: str = field(
        default_factory=lambda: os.getenv("T2SQL_LLM_API_KEY_FAST",
                                          os.getenv("T2SQL_LLM_API_KEY", "EMPTY"))
    )
    # azure fallback
    azure_endpoint: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT_FAST",
                                          os.getenv("SKCC_AZURE_ENDPOINT", ""))
    )
    azure_api_key: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY_FAST",
                                          os.getenv("SKCC_AZURE_OPENAI_KEY", ""))
    )
    azure_deployment: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_MODEL_FAST",
                                          os.getenv("SKCC_AZURE_MODEL", "gpt-4.1-mini"))
    )
    azure_api_version: str = field(
        default_factory=lambda: os.getenv("SKCC_AZURE_API_VERSION_FAST",
                                          os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview"))
    )
    temperature: float = 0.0
    max_tokens: int = 4096


# ═══════════════════════════════════════════════════════════════
# Embedding 설정
# ═══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class EmbedCfg:
    provider: str = field(
        default_factory=lambda: os.getenv("T2SQL_EMBED_PROVIDER",
                                          os.getenv("T2SQL_LLM_PROVIDER", "openai_compatible"))
    )
    model: str = field(default_factory=lambda: os.getenv("T2SQL_EMBED_MODEL", "text-embedding-3-large"))
    deployment: str = field(
        default_factory=lambda: os.getenv(
            "T2SQL_EMBED_DEPLOYMENT",
            os.getenv("T2SQL_EMBED_MODEL", "text-embedding-3-large"),
        )
    )
    base_url: str = field(
        default_factory=lambda: os.getenv("T2SQL_EMBED_BASE_URL",
                                          os.getenv("T2SQL_LLM_BASE_URL", ""))
    )
    api_key: str = field(
        default_factory=lambda: os.getenv("T2SQL_EMBED_API_KEY",
                                          os.getenv("T2SQL_LLM_API_KEY", ""))
    )
    # azure 전용
    endpoint: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_ENDPOINT", ""))
    azure_api_key: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_OPENAI_KEY", ""))
    api_version: str = field(default_factory=lambda: os.getenv("SKCC_AZURE_API_VERSION", "2024-02-15-preview"))

    def is_available(self) -> bool:
        if self.provider == "azure_openai":
            return bool(self.endpoint and self.azure_api_key)
        if self.provider == "openai_compatible":
            return bool(self.base_url and self.api_key)
        return False


# ═══════════════════════════════════════════════════════════════
# DB 설정
# ═══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class DBCfg:
    dialect: str = field(
        default_factory=lambda: os.getenv("T2SQL_DB_DIALECT", "oracle")
    )
    db_id: str = field(
        default_factory=lambda: os.getenv("T2SQL_DB_ID", "")
    )
    # Oracle 연결
    host: str = field(default_factory=lambda: os.getenv("T2SQL_DB_HOST", "localhost"))
    port: int = field(default_factory=lambda: _int_env("T2SQL_DB_PORT", 1521))
    service_name: str = field(default_factory=lambda: os.getenv("T2SQL_DB_SERVICE_NAME", ""))
    dsn: str = field(default_factory=lambda: os.getenv("T2SQL_DB_DSN", ""))
    user: str = field(default_factory=lambda: os.getenv("T2SQL_DB_USER", ""))
    password: str = field(default_factory=lambda: os.getenv("T2SQL_DB_PASSWORD", ""))
    schema: str = field(default_factory=lambda: os.getenv("T2SQL_DB_SCHEMA", ""))
    read_only: bool = field(default_factory=lambda: _bool_env("T2SQL_DB_READ_ONLY", "true"))
    connect_timeout_sec: int = field(
        default_factory=lambda: _int_env("T2SQL_DB_CONNECT_TIMEOUT_SEC", 10)
    )
    # 메타데이터
    metadata_path: str = field(
        default_factory=lambda: os.getenv("T2SQL_METADATA_PATH", "")
    )
    include_tables: str = field(
        default_factory=lambda: os.getenv("T2SQL_INCLUDE_TABLES", "")
    )
    exclude_tables: str = field(
        default_factory=lambda: os.getenv("T2SQL_EXCLUDE_TABLES", "")
    )

    def include_table_list(self) -> List[str]:
        if not self.include_tables:
            return []
        return [t.strip() for t in self.include_tables.split(",") if t.strip()]

    def exclude_table_list(self) -> List[str]:
        if not self.exclude_tables:
            return []
        return [t.strip() for t in self.exclude_tables.split(",") if t.strip()]


# ═══════════════════════════════════════════════════════════════
# Guardrails / Pipeline
# ═══════════════════════════════════════════════════════════════
@dataclass(frozen=True)
class GuardrailsCfg:
    allowed_statements: tuple[str, ...] = ("SELECT",)
    max_rows: int = 50_000
    timeout_ms: int = field(
        default_factory=lambda: _int_env("T2SQL_DB_QUERY_TIMEOUT_MS", 15000)
    )
    forbidden_kw: tuple[str, ...] = (
        "DROP", "TRUNCATE", "ALTER", "GRANT", "REVOKE",
        "EXECUTE", "EXEC", "ATTACH", "DETACH",
    )
    enforce_limit: bool = field(default_factory=lambda: _bool_env("T2SQL_ENFORCE_LIMIT", "true"))


@dataclass(frozen=True)
class PipelineCfg:
    max_retries: int = field(default_factory=lambda: _int_env("T2SQL_MAX_RETRIES", 3))
    num_candidates: int = 3
    preview_limit: int = 50
    allow_empty_result: bool = field(default_factory=lambda: _bool_env("ALLOW_EMPTY_RESULT", "true"))
    execution_mode: str = field(default_factory=lambda: os.getenv("T2SQL_EXECUTION_MODE", "production"))


# ═══════════════════════════════════════════════════════════════
# Master Settings
# ═══════════════════════════════════════════════════════════════
@dataclass
class Settings:
    llm_provider: LLMProviderCfg = field(default_factory=LLMProviderCfg)
    llm_fast_cfg: LLMFastCfg = field(default_factory=LLMFastCfg)
    db: DBCfg = field(default_factory=DBCfg)
    embed: EmbedCfg = field(default_factory=EmbedCfg)
    guard: GuardrailsCfg = field(default_factory=GuardrailsCfg)
    pipeline: PipelineCfg = field(default_factory=PipelineCfg)
    cfg_dir: Path = _CFG_DIR

    def is_dual_model(self) -> bool:
        provider = self.llm_provider.provider
        if provider == "azure_openai":
            return bool(os.getenv("SKCC_AZURE_MODEL_FAST", ""))
        return (self.llm_provider.model != self.llm_fast_cfg.model)

    def current_dialect(self) -> str:
        return self.db.dialect

    def current_provider(self) -> str:
        return self.llm_provider.provider

    def current_model(self) -> str:
        return self.llm_provider.effective_model()

    def load_json(self, name: str) -> Dict[str, Any]:
        path = self.cfg_dir / name
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}

    def schema_metadata(self, db_id: str) -> Dict[str, Any]:
        # 커스텀 metadata 경로 지원
        if self.db.metadata_path:
            meta_path = Path(self.db.metadata_path)
            if meta_path.exists():
                raw = json.loads(meta_path.read_text(encoding="utf-8"))
                return raw.get("databases", {}).get(db_id, raw)
        return self.load_json("schema_metadata.json").get("databases", {}).get(db_id, {})

    def domain_hints(self, db_id: str) -> Dict[str, Any]:
        return self.load_json("domain_hints.json").get("databases", {}).get(db_id, {})

    def scenarios(self) -> List[Dict[str, Any]]:
        return self.load_json("scenarios.json").get("scenarios", [])


_inst: Optional[Settings] = None


def get_settings() -> Settings:
    global _inst
    if _inst is None:
        _inst = Settings()
    return _inst


def reset_settings() -> None:
    global _inst
    _inst = None
