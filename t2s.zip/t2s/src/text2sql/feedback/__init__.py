"""
Feedback Loop — 사용자 피드백 + 자동 피드백 기반 자동 개선 시스템
=================================================================
수동 피드백: 사용자가 1~5점 직접 평가
자동 피드백: 파이프라인 결과 신호(성공/실패/repair 횟수 등)로 자동 산출
"""
from .store import FeedbackStore, FeedbackRecord, FeedbackScore, get_feedback_store
from .learner import AutoLearner, get_learner
from .logger import FeedbackLogger, get_feedback_logger
from .auto_scorer import compute_auto_score, build_auto_feedback, build_auto_comment

__all__ = [
    "FeedbackStore", "FeedbackRecord", "FeedbackScore", "get_feedback_store",
    "AutoLearner", "get_learner",
    "FeedbackLogger", "get_feedback_logger",
    "compute_auto_score", "build_auto_feedback", "build_auto_comment",
]
