"""
AutoLearner — 피드백 기반 자동 개선 엔진
========================================
좋은 피드백 → few_shot 자동 등록 + keyword_map 확장
나쁜 피드백 → 오류 패턴 기록 + repair 힌트 강화

개선 흐름:
  ┌─────────────────────────────────────────────────┐
  │          사용자 피드백 (1~5점)                     │
  └─────────────┬───────────────────────┬───────────┘
                │                       │
        4~5점 (좋음)              1~2점 (나쁨)
                │                       │
    ┌───────────▼──────────┐  ┌────────▼──────────┐
    │ few_shot 자동 등록     │  │ 오류 패턴 기록      │
    │ keyword_map 자동 확장  │  │ 실패 SQL 저장       │
    │ relation_bonus 보강   │  │ 다음 질문 시 참고    │
    └──────────────────────┘  └───────────────────┘
                │                       │
                ▼                       ▼
         domain_hints.json       feedback_log.json
         자동 업데이트              (negative patterns)
"""
from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

from .store import FeedbackRecord, FeedbackScore, FeedbackStore, get_feedback_store
from .logger import FeedbackLogger, get_feedback_logger

logger = logging.getLogger(__name__)

_CFG_DIR = Path(__file__).resolve().parents[1] / "config"


class AutoLearner:
    """피드백을 분석하여 domain_hints.json을 자동 갱신한다."""

    def __init__(self, store: FeedbackStore | None = None,
                 fb_logger: FeedbackLogger | None = None):
        self._store = store or get_feedback_store()
        self._hints_path = _CFG_DIR / "domain_hints.json"
        self._fb_log = fb_logger or get_feedback_logger()

    def learn(self, db_id: str) -> Dict[str, Any]:
        """
        미처리 피드백을 분석하여 domain_hints.json을 갱신한다.

        Returns:
            {"few_shots_added": int, "keywords_added": int, "errors_logged": int}
        """
        result = {
            "few_shots_added": 0, "keywords_added": 0,
            "patterns_added": 0, "errors_logged": 0,
        }

        # 1) 좋은 피드백 → few_shot 등록
        promotable = self._store.not_yet_promoted(db_id)
        if promotable:
            added = self._promote_few_shots(db_id, promotable)
            result["few_shots_added"] = added

        # 2) 좋은 피드백에서 keyword_map 자동 확장
        positives = self._store.positive(db_id)
        if positives:
            kw_added = self._expand_keyword_map(db_id, positives)
            result["keywords_added"] = kw_added

        # 3) 좋은 피드백에서 common_patterns 자동 보강
        if positives:
            pat_added = self._expand_common_patterns(db_id, positives)
            result["patterns_added"] = pat_added

        # 4) 나쁜 피드백 → 오류 패턴 기록
        negatives = [r for r in self._store.negative(db_id) if not r.error_logged]
        if negatives:
            logged = self._log_error_patterns(db_id, negatives)
            result["errors_logged"] = logged

        if any(v > 0 for v in result.values()):
            logger.info(f"[{db_id}] AutoLearner 결과: {result}")
            self._fb_log.log_learn_summary(db_id, result)

        return result

    def get_negative_hints(self, db_id: str, question: str) -> str:
        """
        질문과 유사한 과거 실패 사례가 있으면 repair 힌트를 반환한다.
        CandidateGenerator 프롬프트에 주입하여 같은 실수를 반복하지 않도록 한다.
        """
        negatives = self._store.negative(db_id)
        if not negatives:
            return ""

        q_tokens = set(re.findall(r"[가-힣a-zA-Z0-9_]+", question.lower()))
        hints = []
        for r in negatives[-20:]:  # 최근 20개만
            r_tokens = set(re.findall(r"[가-힣a-zA-Z0-9_]+", r.question.lower()))
            overlap = len(q_tokens & r_tokens)
            if overlap >= 2:
                comment = r.user_comment or "결과 부정확"
                hints.append(
                    f"- 유사 질문 '{r.question[:40]}' 에서 [{r.score_label}] 평가: "
                    f"{comment} (이전 SQL: {r.sql[:80]}...)"
                )

        if not hints:
            return ""

        result = (
            "\n\n[과거 피드백 기반 주의사항]\n"
            "아래 유사 질문에서 사용자가 부정적 평가를 했습니다. 같은 실수를 반복하지 마세요.\n"
            + "\n".join(hints[:3])
        )
        self._fb_log.log_hint_injected(db_id, question, "negative", result[:150])
        return result

    def get_positive_references(self, db_id: str, question: str) -> str:
        """
        질문과 유사한 과거 성공 사례가 있으면 참고 SQL을 반환한다.
        """
        positives = self._store.positive(db_id)
        if not positives:
            return ""

        q_tokens = set(re.findall(r"[가-힣a-zA-Z0-9_]+", question.lower()))
        refs = []
        for r in positives[-30:]:
            r_tokens = set(re.findall(r"[가-힣a-zA-Z0-9_]+", r.question.lower()))
            overlap = len(q_tokens & r_tokens)
            if overlap >= 2:
                refs.append((overlap, r))

        if not refs:
            return ""

        refs.sort(key=lambda x: x[0], reverse=True)
        lines = []
        for _, r in refs[:2]:
            lines.append(f"-- [사용자 평가: {r.score_label}] Q: {r.question}")
            lines.append(r.sql)
        result = "\n".join(lines)
        self._fb_log.log_hint_injected(db_id, question, "positive", result[:150])
        return result

    # ── 내부 구현 ────────────────────────────────────────

    def _load_hints(self) -> Dict[str, Any]:
        if self._hints_path.exists():
            return json.loads(self._hints_path.read_text(encoding="utf-8"))
        return {"databases": {}}

    def _save_hints(self, data: Dict[str, Any]):
        self._hints_path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _promote_few_shots(self, db_id: str, records: List[FeedbackRecord]) -> int:
        """좋은 피드백의 question+sql을 few_shot_examples에 추가."""
        hints = self._load_hints()
        db_hints = hints.setdefault("databases", {}).setdefault(db_id, {})
        few_shots: List[Dict[str, str]] = db_hints.setdefault("few_shot_examples", [])

        existing_questions = {fs["question"].strip().lower() for fs in few_shots}

        added = 0
        for r in records:
            q_norm = r.question.strip().lower()
            if q_norm in existing_questions:
                self._store.mark_promoted(r)
                continue
            if not r.sql or not r.sql.strip():
                self._store.mark_promoted(r)
                continue

            few_shots.append({
                "question": r.question,
                "sql": r.sql,
            })
            existing_questions.add(q_norm)
            self._store.mark_promoted(r)
            added += 1
            logger.info(f"[{db_id}] few_shot 자동 등록: '{r.question[:40]}' (점수: {r.score_label})")
            self._fb_log.log_few_shot_promoted(db_id, r.question, r.sql)

        # few_shot이 너무 많으면 최근 것 위주로 유지
        max_few_shots = 50
        if len(few_shots) > max_few_shots:
            few_shots[:] = few_shots[-max_few_shots:]

        if added > 0:
            self._save_hints(hints)

        return added

    def _expand_keyword_map(self, db_id: str, records: List[FeedbackRecord]) -> int:
        """좋은 피드백의 질문에서 키워드를 추출하여 keyword_map을 확장."""
        hints = self._load_hints()
        db_hints = hints.setdefault("databases", {}).setdefault(db_id, {})
        keyword_map: Dict[str, List[str]] = db_hints.setdefault("keyword_map", {})

        existing_keywords = set(keyword_map.keys())
        added = 0

        for r in records:
            if not r.tables_used:
                continue
            tokens = set(re.findall(r"[가-힣]{2,}", r.question))
            for token in tokens:
                if token in existing_keywords:
                    current = set(keyword_map[token])
                    new_tables = set(r.tables_used) - current
                    if new_tables:
                        keyword_map[token] = list(current | new_tables)
                        added += 1
                        self._fb_log.log_keyword_expanded(db_id, token, keyword_map[token])
                else:
                    keyword_map[token] = list(r.tables_used)
                    existing_keywords.add(token)
                    added += 1
                    self._fb_log.log_keyword_expanded(db_id, token, keyword_map[token])

        if added > 0:
            self._save_hints(hints)

        return added

    def _expand_common_patterns(self, db_id: str, records: List[FeedbackRecord]) -> int:
        """좋은 피드백의 SQL을 query_pattern별 common_patterns에 등록 또는 교체.

        동작 방식:
        1. query_pattern별로 피드백 이력에서 최고 점수 SQL을 선정
        2. 해당 패턴에 기존 fb_ 패턴이 있으면 점수를 비교
        3. 새 SQL이 더 좋으면 기존 것을 교체
        4. 기존 정적 패턴(fb_ 아닌 것)은 보존하고, fb_ 슬롯에서만 경쟁
        """
        hints = self._load_hints()
        db_hints = hints.setdefault("databases", {}).setdefault(db_id, {})
        patterns: Dict[str, str] = db_hints.setdefault("common_patterns", {})
        pattern_scores: Dict[str, Dict] = db_hints.setdefault("_pattern_scores", {})

        added = 0
        for r in records:
            if not r.query_pattern or r.query_pattern == "simple":
                continue
            if not r.sql or not r.sql.strip():
                continue

            qp = r.query_pattern
            fb_slot = f"fb_best_{qp}"

            # SQL 중복 체크
            normalized_new = " ".join(r.sql.lower().split())
            duplicate = any(
                " ".join(v.lower().split()) == normalized_new
                for v in patterns.values()
            )
            if duplicate:
                # 중복이지만 점수가 더 높으면 기록 갱신
                if fb_slot in pattern_scores:
                    old = pattern_scores[fb_slot]
                    if r.score > old.get("score", 0):
                        pattern_scores[fb_slot] = {
                            "score": r.score, "question": r.question,
                            "use_count": old.get("use_count", 0),
                        }
                continue

            if fb_slot in patterns:
                old_meta = pattern_scores.get(fb_slot, {})
                old_score = old_meta.get("score", 3)

                if r.score > old_score:
                    old_sql_preview = patterns[fb_slot][:60]
                    patterns[fb_slot] = r.sql
                    pattern_scores[fb_slot] = {
                        "score": r.score, "question": r.question,
                        "use_count": 0,
                    }
                    added += 1
                    self._fb_log.log_pattern_replaced(
                        db_id, qp, fb_slot,
                        old_score=old_score, new_score=r.score,
                        question=r.question,
                    )
                # 점수 같으면 유지 (먼저 들어온 것 우선)
            else:
                patterns[fb_slot] = r.sql
                pattern_scores[fb_slot] = {
                    "score": r.score, "question": r.question,
                    "use_count": 0,
                }
                added += 1
                self._fb_log.log_pattern_promoted(
                    db_id, qp, fb_slot, r.question,
                )

        # fb_ 슬롯 수 제한
        max_fb = 20
        fb_keys = [k for k in patterns if k.startswith("fb_")]
        if len(fb_keys) > max_fb:
            scored = sorted(
                fb_keys,
                key=lambda k: pattern_scores.get(k, {}).get("score", 0),
            )
            for k in scored[:len(fb_keys) - max_fb]:
                del patterns[k]
                pattern_scores.pop(k, None)

        if added > 0:
            self._save_hints(hints)

        return added

    def _log_error_patterns(self, db_id: str, records: List[FeedbackRecord]) -> int:
        """나쁜 피드백의 오류 패턴을 기록."""
        logged = 0
        for r in records:
            self._store.mark_error_logged(r)
            logged += 1
            logger.info(
                f"[{db_id}] 오류 패턴 기록: [{r.score_label}] "
                f"'{r.question[:40]}'"
            )
            self._fb_log.log_error_pattern_recorded(
                db_id, r.question, r.score_label, r.user_comment or "",
            )
        return logged


_learner: AutoLearner | None = None


def get_learner() -> AutoLearner:
    global _learner
    if _learner is None:
        _learner = AutoLearner()
    return _learner
