"""
SchemaSelector · JoinPlanner 노드
──────────────────────────────────
2. SchemaSelector: BM25 + LLM 하이브리드 테이블·컬럼 선택 (캐싱 지원)
4. JoinPlanner: FK 기반 + LLM 보조 JOIN 경로 계획 (캐싱 지원)
"""
from __future__ import annotations
import json
import time as _time
from typing import Dict, List, Any, Set
from ..lg.state import GraphState
from ..llm.client import get_llm_fast
from ..llm import prompts as P
from ..rag.schema_rag import SchemaSelector, JoinPlanner
from ..tools.executor import SchemaReader
from ..tools.cache import get_cache
from ..config.settings import get_settings
from ._utils import trace, make_cache_key


# ═══════════════════════════════════════════════════════════════
# 2. SchemaSelector (Schema RAG)
# ═══════════════════════════════════════════════════════════════
def node_schema_selector(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "SchemaSelector", "관련 테이블·컬럼 선택 시작")

    db_path = state["db_path"]
    db_id = state["database_id"]
    question = state["question"]

    cache = get_cache()
    cache_key = make_cache_key("schema_sel", question, db_path)
    cached = cache.get(cache_key)
    if cached:
        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "SchemaSelector",
              f"✅ 캐시 히트 — 선택된 테이블: {cached['selected_tables']}",
              {"cache_hit": True, "elapsed_ms": _elapsed})
        return {**state, **cached}

    settings = get_settings()
    meta = settings.schema_metadata(db_id)
    hints = settings.domain_hints(db_id)

    full_schema = SchemaReader.full_schema(db_path)

    selector = SchemaSelector(
        keyword_map=hints.get("keyword_map", {}),
        relation_bonus=hints.get("relation_bonus_map", {}),
    )
    scores = selector.select(question, full_schema, top_k=5, db_id=db_id)
    selected = [s.table_name for s in scores]

    schema_text = SchemaReader.format_text(full_schema, meta)

    try:
        llm = get_llm_fast()
        prompt = P.SELECTOR_USR.format(
            question=question,
            intent=state.get("intent", ""),
            extracted_values=json.dumps(state.get("extracted_values", {}),
                                        ensure_ascii=False),
            schema_text=schema_text,
            keyword_map=json.dumps(hints.get("keyword_map", {}),
                                   ensure_ascii=False)[:2000],
        )
        llm_res = llm.generate_json(prompt, system=P.SELECTOR_SYS,
                                        node_name="SchemaSelector")
        llm_tables = llm_res.get("selected_tables") or []
        llm_cols = llm_res.get("selected_columns") or {}
        reasoning = llm_res.get("reasoning", "")

        # BM25 결과와 LLM 결과 합집합
        for t in llm_tables:
            if t not in selected:
                selected.append(t)

        selected_cols = llm_cols
    except Exception:
        selected_cols = {}
        reasoning = "LLM 선택 실패 – BM25 결과만 사용"

    # FK 기반 브리지 테이블 자동 보완
    selected = _ensure_join_connectivity(selected, full_schema)

    kw_matches = {s.table_name: s.matched_keywords for s in scores if s.matched_keywords}

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "SchemaSelector",
          f"선택된 테이블: {selected}",
          {"reasoning": reasoning,
           "keyword_matches": kw_matches,
           "bm25_scores": {s.table_name: round(s.score, 2) for s in scores},
           "elapsed_ms": _elapsed,
           "model": llm.model_label})

    result_data = {
        "full_schema": full_schema,
        "selected_tables": selected,
        "selected_columns": selected_cols,
        "schema_text": schema_text,  # full schema → CandidateGenerator/Repair가 모든 테이블 참조 가능
        "selector_rationale": reasoning,
    }
    cache.set(cache_key, result_data, ttl=300)

    return {**state, **result_data}


# ═══════════════════════════════════════════════════════════════
# 4. JoinPlanner
# ═══════════════════════════════════════════════════════════════
def node_join_planner(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "JoinPlanner", "JOIN 경로 계획 시작")

    selected = state["selected_tables"]
    full_schema = state["full_schema"]

    cache = get_cache()
    tables_key = ",".join(sorted(selected))
    cache_key = make_cache_key("join_plan", tables_key, state["db_path"])
    cached = cache.get(cache_key)
    if cached:
        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "JoinPlanner",
              f"✅ 캐시 히트 — JOIN {len(cached['join_plan'])}개",
              {"cache_hit": True, "elapsed_ms": _elapsed})
        return {**state, **cached}

    planner = JoinPlanner(full_schema)
    joins = planner.plan(selected)

    # LLM 보조 – 복잡한 경우 추가 검증
    reasoning = ""
    _jp_model = "—"
    if len(selected) >= 3:
        try:
            llm = get_llm_fast()
            _jp_model = llm.model_label
            prompt = P.JOINPLANNER_USR.format(
                selected_tables=", ".join(selected),
                schema_text=state["schema_text"],
            )
            res = llm.generate_json(prompt, system=P.JOINPLANNER_SYS,
                                       node_name="JoinPlanner")
            llm_joins = res.get("join_conditions", [])
            reasoning = res.get("reasoning", "")
            # LLM이 추가 조인을 제안하면 병합
            for j in llm_joins:
                if j not in joins:
                    joins.append(j)
        except Exception:
            reasoning = "LLM 검증 실패 – FK 기반 결과 사용"

    if not reasoning:
        reasoning = f"FK 기반 자동 계획: {len(joins)}개 JOIN"

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "JoinPlanner",
          f"JOIN {len(joins)}개 계획 완료",
          {"joins": joins, "reasoning": reasoning,
           "elapsed_ms": _elapsed, "model": _jp_model})

    result_data = {
        "join_plan": joins,
        "join_rationale": reasoning,
    }
    cache.set(cache_key, result_data, ttl=300)

    return {**state, **result_data}


# ═══════════════════════════════════════════════════════════════
# FK 기반 브리지 테이블 자동 보완
# ═══════════════════════════════════════════════════════════════
def _ensure_join_connectivity(selected: List[str],
                               full_schema: List[Dict[str, Any]]) -> List[str]:
    """
    선택된 테이블 간 FK 경로가 끊어져 있으면 브리지 테이블을 자동 추가.
    예: Student, Pets 선택 → Has_Pet 자동 추가 (FK 연결 경로).
    """
    if len(selected) < 2:
        return selected

    # FK 그래프 구축: table -> {related_table: bridge_table or None}
    fk_graph: Dict[str, Set[str]] = {}
    all_tables = {t["table_name"] for t in full_schema}
    for tbl in full_schema:
        tname = tbl["table_name"]
        fk_graph.setdefault(tname, set())
        for fk in tbl.get("foreign_keys", []):
            to_table = fk["to_table"]
            fk_graph.setdefault(to_table, set())
            fk_graph[tname].add(to_table)
            fk_graph[to_table].add(tname)

    # BFS로 selected 테이블 간 연결 확인
    selected_set = set(selected)
    connected: Set[str] = set()
    if selected:
        # 첫 번째 테이블부터 BFS — selected 내에서만
        queue = [selected[0]]
        visited = {selected[0]}
        while queue:
            cur = queue.pop(0)
            if cur in selected_set:
                connected.add(cur)
            for neighbor in fk_graph.get(cur, set()):
                if neighbor not in visited and neighbor in selected_set:
                    visited.add(neighbor)
                    queue.append(neighbor)

    # 연결되지 않은 테이블이 있으면 브리지 추가 시도
    disconnected = selected_set - connected
    if not disconnected:
        return selected

    added = []
    for disc in disconnected:
        # disc에서 FK로 1-hop 연결 가능한 테이블 중 connected와 연결된 것 찾기
        for bridge in fk_graph.get(disc, set()):
            if bridge in connected or (bridge in all_tables and
                    fk_graph.get(bridge, set()) & connected):
                if bridge not in selected_set:
                    added.append(bridge)
                    selected_set.add(bridge)
                    connected.add(bridge)
                connected.add(disc)
                break

    if added:
        return selected + added
    return selected
