"""
Repair · ResultSummarizer · SafeFail 노드
──────────────────────────────────────────
11. Repair: 실패한 SQL을 LLM으로 수정 (해시 기반 중복 감지)
12. ResultSummarizer + AuditLogger + MemorySave: 최종 결과 요약 및 기록
13. SafeFail: 최대 재시도 초과 시 안전한 실패 처리
"""
from __future__ import annotations
import json
import re
import time as _time
from ..lg.state import GraphState, SQLCandidate, ErrorType, ExecReport
from ..llm.client import get_llm, get_llm_fast, get_token_accumulator
from ..llm import prompts as P
from ..tools.audit import log_execution
from ..memory.conversation import get_memory
from ._utils import trace, sql_hash, get_llm_for_node


# ═══════════════════════════════════════════════════════════════
# 11. Repair / Refiner
# ═══════════════════════════════════════════════════════════════
def node_repair(state: GraphState) -> GraphState:
    _t0 = _time.time()
    count = state.get("repair_count", 0)
    trace(state, "Repair", f"수정 시도 #{count + 1}")

    et = state.get("last_error_type", ErrorType.UNKNOWN)
    et_key = et.value if et else "UNKNOWN"
    tmpl = P.REPAIR_PROMPTS.get(et_key, P.REPAIR_PROMPTS["UNKNOWN"])

    prev_sql_hashes: set = set()
    t_trace = state.get("trace", [])
    for t in t_trace:
        extra = t.get("extra", {})
        if "new_sql" in extra:
            prev_sql_hashes.add(sql_hash(extra["new_sql"]))
        if "sql" in extra:
            prev_sql_hashes.add(sql_hash(extra["sql"]))
    current_sql = state.get("selected_sql", "")
    if current_sql:
        prev_sql_hashes.add(sql_hash(current_sql))

    exec_report = state.get("exec_report")
    prev_result_info = ""
    if exec_report:
        if exec_report.ok:
            if exec_report.rows_preview:
                preview_str = json.dumps(exec_report.rows_preview[:5],
                                        ensure_ascii=False, default=str)
                prev_result_info = f"""
■ 이전 실행 결과 (문제점):
  - 상태: 실행 성공, 하지만 결과가 질문 의도와 다름
  - 반환된 행 수: {exec_report.row_count}
  - 결과 샘플: {preview_str[:500]}
"""
            else:
                prev_result_info = """
■ 이전 실행 결과 (문제점):
  - 상태: 실행 성공, 하지만 결과가 비어있음 (0행)
  - 원인: WHERE 조건이 너무 엄격하거나, JOIN이 잘못되었을 수 있음
"""
        else:
            prev_result_info = f"""
■ 이전 실행 결과 (문제점):
  - 상태: 실행 실패
  - 에러 타입: {exec_report.error_type}
  - 에러 메시지: {exec_report.error_message}
"""

    repair_history = ""
    prev_repairs = [t for t in t_trace if t.get("node") == "Repair"]
    if prev_repairs:
        repair_history = "\n■ 이전 수정 시도 이력 (같은 실수 반복 금지):\n"
        for i, r in enumerate(prev_repairs[-3:], 1):  # 최근 3개만
            repair_history += f"  {i}. {r.get('detail', '')}\n"
        if count >= 2:
            repair_history += (
                "\n  ⚠️ 이미 여러 번 수정을 시도했습니다. "
                "이전과 완전히 다른 접근법(다른 CTE 구조, 다른 JOIN 순서, "
                "다른 집계 방식)을 사용하세요!\n"
            )

    memory = get_memory()
    failed_sqls = memory.get_failed_patterns(db_id=state["database_id"], n=3)
    memory_hint = ""
    if failed_sqls:
        memory_hint = "\n■ 이전 세션 실패 SQL (이 패턴을 반복하지 마세요):\n"
        for i, fsql in enumerate(failed_sqls, 1):
            memory_hint += f"  {i}. {fsql[:200]}{'...' if len(fsql) > 200 else ''}\n"

    additional_parts = []

    if prev_result_info:
        additional_parts.append(prev_result_info)
    if repair_history:
        additional_parts.append(repair_history)
    if memory_hint:
        additional_parts.append(memory_hint)

    query_pattern = state.get("query_pattern", "simple")
    pattern_hints = {
        "group_top_n": "그룹별 1위 항목 이름이 필요. RANK 또는 다른 방법 모두 가능.",
        "group_aggregate": "그룹별 수치 집계. MAX/MIN/AVG/SUM + GROUP BY 권장.",
        "period_comparison": (
            "기간 비교. LAG() OVER 또는 셀프조인 사용. "
            "복합 질문이면 증가율 계산 후 순위 선택 추가. "
            "특정 연도/기간 필터 없이 모든 기간 결과 반환."
        ),
        "threshold_filter": (
            "기준값 비교. CTE로 기준값 먼저 계산 권장. "
            "'X를 제외한 평균' → 제외는 평균 계산에만, 비교 대상은 전체 데이터."
        ),
        "ratio_calculation": "비율 계산. 전체합계를 먼저 구한 뒤 비율 계산.",
        "set_operation": (
            "집합 연산 문제. EXCEPT/INTERSECT/UNION 사용을 최우선으로 고려하세요.\n"
            "  - '~하지 않는/않은 X' → SELECT ... EXCEPT SELECT ... 형태\n"
            "  - '두 조건 모두 만족하는 X' → SELECT ... INTERSECT SELECT ... 형태\n"
            "  - NOT IN/NOT EXISTS/LEFT JOIN IS NULL로 변환하지 말고 EXCEPT를 먼저 시도하세요.\n"
            "  예: SELECT name FROM stadium EXCEPT SELECT T2.name FROM concert AS T1 JOIN stadium AS T2 ON T1.stadium_id = T2.stadium_id"
        ),
        "nested_condition": (
            "중첩 조건 문제. 단계별로 분해하세요:\n"
            "  1. 기본 데이터 필터\n"
            "  2. 서브쿼리 또는 CTE로 중첩 조건 구현\n"
            "  3. 최종 결과 결합"
        ),
    }

    if query_pattern != "simple":
        hint = pattern_hints.get(query_pattern, "")
        if hint:
            additional_parts.append(f"""
■ 쿼리 패턴 참고: {query_pattern}
  → {hint}
""")

    # failure_category 기반 구체적 수정 힌트
    last_err = state.get("last_error_msg") or ""
    _fc_hints = {
        "set_op_missing": (
            "■ 실패 원인: 집합 연산 누락\n"
            "  현재 SQL에 EXCEPT/INTERSECT가 없습니다.\n"
            "  반드시 EXCEPT 또는 INTERSECT를 사용하여 다시 작성하세요.\n"
            "  예: SELECT col FROM A EXCEPT SELECT col FROM A WHERE cond"
        ),
        "negation_wrong": (
            "■ 실패 원인: 부정/제외 조건 오류\n"
            "  '~하지 않는', '~를 제외한' 조건이 올바르게 구현되지 않았습니다.\n"
            "  EXCEPT 사용: SELECT ... EXCEPT SELECT ...\n"
            "  또는 NOT IN: WHERE col NOT IN (SELECT col FROM ...)"
        ),
        "distinct_missing": (
            "■ 실패 원인: DISTINCT 누락\n"
            "  결과에 중복이 포함되었습니다. SELECT DISTINCT를 추가하세요."
        ),
        "aggregation_scope": (
            "■ 실패 원인: 집계 범위 오류\n"
            "  GROUP BY, HAVING, 집계 함수의 범위를 확인하세요."
        ),
        "join_wrong": (
            "■ 실패 원인: JOIN 오류\n"
            "  JOIN 조건이나 테이블 연결이 잘못되었습니다.\n"
            "  스키마의 FK 관계를 다시 확인하세요."
        ),
        "answer_shape_wrong": (
            "■ 실패 원인: 결과 형태 불일치\n"
            "  질문이 요구하는 결과 형태(행 수, 컬럼, 단위)를 다시 확인하세요."
        ),
    }
    for fc_key, fc_hint in _fc_hints.items():
        if fc_key in last_err:
            additional_parts.append(fc_hint)
            break

    # 질문에서 집합 연산이 필요한 키워드 감지 (query_pattern과 무관하게)
    question_lower = state["question"].lower()
    current_sql_lower = (state.get("selected_sql") or "").lower()
    # 단어 경계(\b)로 매칭하여 "nothing", "another" 등 오탐 방지
    _has_set_keyword = (
        bool(re.search(r'\b(not|never|both|without)\b', question_lower))
        or any(kw in question_lower for kw in ['없는', '않는', '않은', '아닌', '제외', '모두', '동시에', '이면서'])
    )
    _uses_set_op = any(op in current_sql_lower for op in ["except", "intersect"])
    if _has_set_keyword and not _uses_set_op and query_pattern != "set_operation":
        additional_parts.append(
            "\n■ 힌트: 질문에 부정/제외/교집합 키워드가 감지되었습니다.\n"
            "  현재 SQL에 EXCEPT/INTERSECT가 없습니다. 집합 연산 사용을 고려하세요.\n"
            "  - '~하지 않는/없는 X' → SELECT ... EXCEPT SELECT ...\n"
            "  - '두 조건 모두/both' → SELECT ... INTERSECT SELECT ...\n"
        )

    additional_context = "\n".join(additional_parts)

    prompt = tmpl.format(
        sql=state.get("selected_sql") or "",
        error_message=state.get("last_error_msg") or "",
        question=state["question"],
        intent=state.get("intent") or "",
        schema_text=state.get("schema_text") or "",
        judge_feedback=state.get("judge_rationale") or "",
        additional_context=additional_context,
    )

    try:
        llm = get_llm_for_node(state, prefer_primary=True)
        res = llm.generate_json(prompt, node_name="Repair")
        new_sql = res.get("sql", "")
        changes = res.get("changes", [])
        reasoning = res.get("reasoning", "")

        _elapsed = round((_time.time() - _t0) * 1000)
        trace(state, "Repair",
              f"수정 완료: {changes}",
              {"new_sql": new_sql[:300], "reasoning": reasoning,
               "error_type": et_key, "attempt": count + 1,
               "elapsed_ms": _elapsed, "model": llm.model_label})

        if new_sql and new_sql.strip():
            new_hash = sql_hash(new_sql)
            if new_hash in prev_sql_hashes:
                trace(state, "Repair",
                      "⚠️ 수정된 SQL이 이전 시도와 동일(해시 일치) – "
                      "다른 접근 필요")
                return {**state, "repair_count": count + 1}

            new_candidate = SQLCandidate(
                sql=new_sql,
                strategy=f"repair_{count + 1}",
                confidence=max(0.3, 0.7 - count * 0.1),
                rationale=reasoning,
            )
            return {
                **state,
                "candidates": [new_candidate],
                "repair_count": count + 1,
            }
    except Exception as e:
        trace(state, "Repair", f"수정 실패: {e}")

    return {**state, "repair_count": count + 1}


# ═══════════════════════════════════════════════════════════════
# 12. ResultSummarizer + AuditLogger + MemorySave
# ═══════════════════════════════════════════════════════════════
def node_result_output(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "ResultSummarizer", "결과 요약 생성 시작")

    report = state.get("exec_report")
    sql = state.get("selected_sql", "")

    if not report or not report.ok:
        summary = "실행에 실패했습니다."
        trace(state, "ResultSummarizer", summary)
        log_execution(state["question"], sql, state["database_id"],
                      False, summary, state.get("trace"), state.get("error"))
        return {**state, "success": False, "error": summary,
                "final_sql": sql, "result_summary": summary}

    preview = json.dumps(report.rows_preview[:20], ensure_ascii=False, default=str)
    _summary_model = "—"
    try:
        llm = get_llm_fast()
        _summary_model = llm.model_label
        prompt = P.SUMMARIZER_USR.format(
            question=state["question"], sql=sql,
            result=preview[:3000], row_count=report.row_count)
        summary = llm.generate(prompt, system=P.SUMMARIZER_SYS,
                                node_name="ResultSummarizer")
    except Exception:
        summary = f"총 {report.row_count}건의 결과가 조회되었습니다."

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "ResultSummarizer", f"요약: {summary[:100]}...",
          {"elapsed_ms": _elapsed, "model": _summary_model})

    log_execution(state["question"], sql, state["database_id"],
                  True, summary, state.get("trace"))

    memory = get_memory()
    memory.save(
        question=state["question"],
        sql=sql,
        database_id=state["database_id"],
        success=True,
        summary=summary,
        row_count=report.row_count,
        tables_used=state.get("selected_tables", []),
    )
    trace(state, "MemorySave",
          f"대화 메모리 저장 완료 (총 {memory.size()}건)")

    final = {
        **state,
        "success": True,
        "final_sql": sql,
        "final_result": report.rows_preview,
        "result_summary": summary,
        "token_usage": get_token_accumulator().summary(),
    }

    _try_auto_feedback(final)
    return final


# ═══════════════════════════════════════════════════════════════
# 13. SAFE FAIL
# ═══════════════════════════════════════════════════════════════
def node_safe_fail(state: GraphState) -> GraphState:
    _t0 = _time.time()
    _raw_err_type = state.get('last_error_type')
    _err_type = _raw_err_type.value if hasattr(_raw_err_type, 'value') else str(_raw_err_type or '')
    _err_msg = str(state.get('last_error_msg') or '').strip()
    _final_sql = state.get("selected_sql", "") or state.get("preview_sql", "")
    if not _err_msg:
        report = state.get("exec_report")
        if report and report.error_message:
            _err_msg = str(report.error_message).strip()
            if not _err_type:
                _err_type = report.error_type.value if hasattr(report.error_type, "value") else str(report.error_type or "")
        if not _final_sql:
            for candidate in state.get("candidates", []) or []:
                if candidate.sql:
                    _final_sql = candidate.sql
                    break
        if not _err_msg:
            candidate_issues = []
            for candidate in state.get("candidates", []) or []:
                if candidate.validation_errors:
                    candidate_issues.extend(str(issue) for issue in candidate.validation_errors if str(issue).strip())
                elif not candidate.is_valid and candidate.rationale:
                    candidate_issues.append(str(candidate.rationale).strip())
            if candidate_issues:
                _err_msg = "; ".join(candidate_issues[:5])
                if not _err_type:
                    _err_type = ErrorType.SCHEMA.value
        if not _err_msg:
            trace_details = []
            for entry in reversed(state.get("trace", []) or []):
                node = str(entry.get("node") or "").strip()
                detail = str(entry.get("detail") or "").strip()
                if not detail or node == "SAFE_FAIL":
                    continue
                trace_details.append(f"{node}: {detail}")
                if len(trace_details) >= 3:
                    break
            if trace_details:
                _err_msg = " | ".join(reversed(trace_details))
        if not _err_msg:
            _err_msg = "상세 오류를 캡처하지 못했습니다."
    if not _err_type:
        _err_type = ErrorType.UNKNOWN.value
    msg = (f"최대 재시도({state.get('max_retries', 3)})를 초과했습니다.\n"
           f"마지막 오류: [{_err_type}] {_err_msg}\n\n"
           "질문을 더 구체적으로 수정하거나, 필요한 조건을 추가해 주세요.")
    trace(state, "SAFE_FAIL", msg)

    log_execution(state["question"], _final_sql,
                  state["database_id"], False, "SAFE_FAIL",
                  state.get("trace"), msg)

    memory = get_memory()
    memory.save(
        question=state["question"],
        sql=_final_sql,
        database_id=state["database_id"],
        success=False,
        summary="SAFE_FAIL",
        row_count=0,
        tables_used=state.get("selected_tables", []),
    )

    _elapsed = round((_time.time() - _t0) * 1000)
    trace(state, "SAFE_FAIL", f"처리 완료", {"elapsed_ms": _elapsed})

    final = {**state, "success": False, "error": msg,
             "final_sql": _final_sql,
             "token_usage": get_token_accumulator().summary()}

    _try_auto_feedback(final)
    return final


def _try_auto_feedback(state: dict):
    """자동 피드백 수집. T2SQL_AUTO_FEEDBACK=true (기본값) 일 때만 동작."""
    import os
    if os.getenv("T2SQL_AUTO_FEEDBACK", "true").lower() not in ("true", "1", "yes"):
        return
    try:
        from ..feedback.auto_scorer import build_auto_feedback
        from ..feedback.store import get_feedback_store
        from ..feedback.learner import get_learner

        record = build_auto_feedback(state)
        get_feedback_store().add(record)
        get_learner().learn(state.get("database_id", ""))
    except Exception:
        pass
