"""
벡터 스토어  ──  Chroma + Embeddings 기반 스키마 시맨틱 검색
═══════════════════════════════════════════════════════════════
필수 의존성: chromadb, openai

사용 흐름:
  1. get_vector_store(db_id) 호출 시 인덱스 미빌드면 자동 빌드
  2. SchemaSelector.select() 에서 hybrid_search() 호출
  3. BM25 스코어 + 벡터 유사도 가중합으로 최종 테이블 선택
"""
from __future__ import annotations
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

import chromadb
from chromadb.config import Settings as ChromaSettings

from ..config.settings import get_settings
from ..llm.client import build_azure_openai_client, build_openai_compatible_client

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════
# Embedding 함수 — Provider-agnostic
# ═══════════════════════════════════════════════════════════════
class Embedder:
    """Provider-agnostic Embeddings 클라이언트.

    지원 provider:
      - azure_openai: AzureOpenAI 클라이언트
      - openai_compatible: OpenAI(base_url=...) 클라이언트
    """

    def __init__(self):
        cfg = get_settings().embed

        if cfg.provider == "azure_openai":
            if not cfg.endpoint or not cfg.azure_api_key:
                raise RuntimeError(
                    "Embedding 설정 누락 (azure_openai: SKCC_AZURE_ENDPOINT/KEY, "
                    "openai_compatible: T2SQL_EMBED_BASE_URL/API_KEY 확인)")
            self._client = build_azure_openai_client(
                azure_endpoint=cfg.endpoint,
                api_key=cfg.azure_api_key,
                api_version=cfg.api_version,
            )
            self._model = cfg.deployment
        else:
            if not cfg.base_url or not cfg.api_key:
                raise RuntimeError(
                    "OpenAI-compatible Embedding 설정 누락 "
                    "(T2SQL_EMBED_BASE_URL, T2SQL_EMBED_API_KEY 확인)")
            self._client = build_openai_compatible_client(
                base_url=cfg.base_url,
                api_key=cfg.api_key,
            )
            self._model = cfg.model

        self._cache: Dict[str, List[float]] = {}

    def embed(self, texts: List[str]) -> List[List[float]]:
        """텍스트 리스트 → 임베딩 벡터 리스트"""
        resp = self._client.embeddings.create(input=texts, model=self._model)
        results = [d.embedding for d in resp.data]
        for text, vec in zip(texts, results):
            self._cache[text] = vec
        return results

    def embed_one(self, text: str) -> List[float]:
        """단일 텍스트 임베딩 (캐시 활용)"""
        if text in self._cache:
            return self._cache[text]
        result = self.embed([text])[0]
        return result


# ═══════════════════════════════════════════════════════════════
# Chroma 벡터 스토어
# ═══════════════════════════════════════════════════════════════
_STORE_DIR = Path(__file__).resolve().parents[3] / "data" / "vector_store"


class SchemaVectorStore:
    """
    DB 스키마를 벡터화하여 Chroma에 저장·검색하는 클래스.

    컬렉션명: schema_{db_id}
    문서: 테이블별 텍스트 (테이블명 + 컬럼 + FK + 샘플)
    메타데이터: table_name, column_count, has_fk
    """

    def __init__(self, db_id: str, persist_dir: Path | str | None = None):
        self._db_id = db_id
        self._persist_dir = str(persist_dir or _STORE_DIR)
        self._client = chromadb.PersistentClient(
            path=self._persist_dir,
            settings=ChromaSettings(anonymized_telemetry=False),
        )
        self._collection_name = f"schema_{db_id}"
        self._collection = self._client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )
        self._embedder: Optional[Embedder] = None

    @property
    def embedder(self) -> Embedder:
        if self._embedder is None:
            self._embedder = Embedder()
        return self._embedder

    # ── 인덱스 빌드 ───────────────────────────────────────
    def build_index(self, schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None):
        """
        스키마 정보로 벡터 인덱스 빌드 (기존 인덱스 덮어쓰기).

        Args:
            schema: SchemaReader.full_schema() 결과
            meta: schema_metadata 딕셔너리 (설명, 샘플값 등)
        """
        try:
            self._client.delete_collection(self._collection_name)
        except Exception:
            pass
        self._collection = self._client.create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": "cosine"},
        )

        tables_meta = (meta or {}).get("tables", {})
        ids, docs, metadatas = [], [], []

        for tbl in schema:
            tname = tbl["table_name"]
            doc = self._table_to_text(tbl, tables_meta.get(tname, {}))
            ids.append(tname)
            docs.append(doc)
            metadatas.append({
                "table_name": tname,
                "column_count": len(tbl.get("columns", [])),
                "has_fk": len(tbl.get("foreign_keys", [])) > 0,
            })

        embeddings = self.embedder.embed(docs)
        self._collection.add(
            ids=ids,
            documents=docs,
            embeddings=embeddings,
            metadatas=metadatas,
        )
        logger.info(f"[{self._db_id}] 벡터 인덱스 빌드 완료: {len(schema)}개 테이블")

    # ── 검색 ──────────────────────────────────────────────
    def search(self, question: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        질문과 유사한 테이블 검색.

        Returns:
            [{"table_name": str, "score": float, "document": str}, ...]
            score: cosine similarity (0~1, 높을수록 유사)
        """
        if self._collection.count() == 0:
            return []

        query_embedding = self.embedder.embed_one(question)
        results = self._collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_k, self._collection.count()),
            include=["documents", "metadatas", "distances"],
        )

        hits = []
        for i, doc_id in enumerate(results["ids"][0]):
            # Chroma cosine distance → similarity
            distance = results["distances"][0][i]
            similarity = 1.0 - distance  # cosine distance → similarity
            hits.append({
                "table_name": doc_id,
                "score": similarity,
                "document": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
            })
        return hits

    def is_indexed(self) -> bool:
        """인덱스가 빌드되었는지 확인"""
        return self._collection.count() > 0

    # ── 내부 ──────────────────────────────────────────────
    @staticmethod
    def _table_to_text(tbl: Dict[str, Any],
                       tmeta: Dict[str, Any] | None = None) -> str:
        """테이블 정보를 검색용 텍스트로 변환"""
        tmeta = tmeta or {}
        parts = [f"테이블: {tbl['table_name']}"]

        desc = tmeta.get("description", "")
        if desc:
            parts.append(f"설명: {desc}")

        col_meta = tmeta.get("columns", {})
        col_parts = []
        for c in tbl.get("columns", []):
            cname = c["name"] if isinstance(c, dict) else str(c)
            ctype = c.get("type", "") if isinstance(c, dict) else ""
            cdesc = ""
            if isinstance(col_meta, dict):
                cm = col_meta.get(cname, {})
                cdesc = cm.get("description", "") if isinstance(cm, dict) else str(cm) if cm else ""
            col_str = f"{cname} ({ctype})"
            if cdesc:
                col_str += f" - {cdesc}"
            col_parts.append(col_str)
        parts.append("컬럼: " + ", ".join(col_parts))

        fk_parts = []
        for fk in tbl.get("foreign_keys", []):
            fk_parts.append(f"{fk['from']} → {fk['to_table']}.{fk['to_column']}")
        if fk_parts:
            parts.append("관계: " + ", ".join(fk_parts))

        return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════
# 자동 인덱스 빌드
# ═══════════════════════════════════════════════════════════════
def _auto_build_index(store: SchemaVectorStore, db_id: str):
    """인덱스가 없을 때 자동으로 빌드"""
    from ..tools.executor import SchemaReader
    from ..tools.db_registry import resolve_db_path
    from ..config.settings import get_settings

    db_path = resolve_db_path(db_id)
    schema = SchemaReader.full_schema(db_path)
    meta = get_settings().schema_metadata(db_id)
    store.build_index(schema, meta)


# ═══════════════════════════════════════════════════════════════
# 유틸리티
# ═══════════════════════════════════════════════════════════════
_stores: Dict[str, SchemaVectorStore] = {}
_failed_dbs: set = set()


def get_vector_store(db_id: str) -> SchemaVectorStore:
    """벡터 스토어 싱글톤 — 인덱스 미빌드 시 자동 빌드. 실패한 DB는 재시도하지 않음."""
    if db_id in _failed_dbs:
        raise RuntimeError(f"[{db_id}] 벡터 스토어 이전 초기화 실패 — 스킵")

    if db_id not in _stores:
        try:
            store = SchemaVectorStore(db_id)
            if not store.is_indexed():
                logger.debug(f"[{db_id}] 벡터 인덱스 없음 — 자동 빌드 시작")
                _auto_build_index(store, db_id)
            _stores[db_id] = store
        except Exception as e:
            _failed_dbs.add(db_id)
            logger.debug(f"[{db_id}] 벡터 스토어 초기화 실패 (BM25로 대체): {e}")
            raise

    return _stores[db_id]
