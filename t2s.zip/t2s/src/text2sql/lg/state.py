"""
LangGraph State  ──  파이프라인 전체에서 공유되는 상태
"""
from __future__ import annotations
from typing import TypedDict, List, Dict, Any, Optional
from dataclasses import dataclass, field
from enum import Enum


# ── 열거형 ────────────────────────────────────────────────────
class ErrorType(str, Enum):
    SYNTAX   = "SYNTAX"
    SCHEMA   = "SCHEMA"
    SEMANTIC = "SEMANTIC"
    TIMEOUT  = "TIMEOUT"
    RUNTIME  = "RUNTIME"
    SAFETY   = "SAFETY"
    UNKNOWN  = "UNKNOWN"


# ── 데이터 클래스 ─────────────────────────────────────────────
@dataclass
class SQLCandidate:
    sql: str
    strategy: str                          # conservative / recall / metric
    confidence: float = 0.0
    rationale: str = ""
    is_valid: bool = True
    validation_errors: List[str] = field(default_factory=list)
    ut_passed: bool = False
    ut_detail: str = ""


@dataclass
class ExecReport:
    ok: bool
    rows_preview: Optional[List[Dict[str, Any]]] = None
    row_count: int = 0
    error_type: Optional[ErrorType] = None
    error_message: Optional[str] = None
    exec_ms: Optional[float] = None


# ── LangGraph 상태 ────────────────────────────────────────────
class GraphState(TypedDict, total=False):
    # 입력
    question: str
    database_id: str
    db_path: str
    scenario_id: str

    # 추적 로그 (UI 표시용)
    trace: List[Dict[str, Any]]

    # 날짜 컨텍스트 (시뮬레이션 또는 실제)
    current_date: str      # YYYY-MM-DD
    current_year: int      # YYYY
    current_month: int     # MM

    # Decomposer
    sub_questions: List[str]
    intent: str
    query_pattern: str  # group_top_n | group_aggregate | period_comparison | threshold_filter | ratio_calculation | running_calc | simple

    # ValueRetriever
    extracted_values: Dict[str, Any]

    # SchemaSelector
    full_schema: List[Dict[str, Any]]
    selected_tables: List[str]
    selected_columns: Dict[str, List[str]]
    schema_text: str
    selector_rationale: str

    # JoinPlanner
    join_plan: List[str]
    join_rationale: str

    # CandidateGenerator
    candidates: List[SQLCandidate]

    # Guardrails
    guard_passed: bool

    # SQLUnitTester
    ut_passed: bool

    # ExecutePreview
    exec_report: Optional[ExecReport]
    preview_sql: str

    # Judge
    judge_accepted: bool
    judge_rationale: str
    selected_sql: str

    # Repair
    repair_count: int
    max_retries: int
    last_error_type: Optional[ErrorType]
    last_error_msg: Optional[str]

    # LLM 라우팅 / HITL
    use_fast_only: bool
    hitl_enabled: bool

    # 토큰 사용량
    token_usage: Optional[Dict[str, Any]]

    # dialect
    dialect: str               # "sqlite" (기본) 또는 "oracle"

    # 최종
    final_sql: str
    final_result: Optional[List[Dict[str, Any]]]
    result_summary: str
    success: bool
    error: Optional[str]


def new_state(question: str, database_id: str, db_path: str,
              scenario_id: str = "", max_retries: int = 3,
              hitl_enabled: bool = False,
              dialect: str = "sqlite") -> GraphState:
    return GraphState(
        question=question, database_id=database_id, db_path=db_path,
        scenario_id=scenario_id,
        trace=[],
        current_date="", current_year=0, current_month=0,  # Decomposer에서 설정
        sub_questions=[], intent="",
        query_pattern="simple",
        extracted_values={},
        full_schema=[], selected_tables=[], selected_columns={},
        schema_text="", selector_rationale="",
        join_plan=[], join_rationale="",
        candidates=[],
        guard_passed=False, ut_passed=False,
        exec_report=None, preview_sql="",
        judge_accepted=False, judge_rationale="", selected_sql="",
        repair_count=0, max_retries=max_retries,
        last_error_type=None, last_error_msg=None,
        use_fast_only=False, hitl_enabled=hitl_enabled,
        token_usage=None,
        final_sql="", final_result=None, result_summary="",
        success=False, error=None,
        dialect=dialect,
    )
