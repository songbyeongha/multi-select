# Qwen3-VL OCR Service

Qwen3-VL 비전 언어 모델 API를 활용한 이미지 텍스트 추출 FastAPI 서비스.

## 프로젝트 구조

```
qwen3_vl_ocr/
├── app/
│   ├── main.py            # FastAPI 앱
│   ├── config.py          # 환경 설정 (pydantic-settings)
│   ├── schemas.py         # 요청/응답 Pydantic 모델
│   ├── router.py          # OCR API 엔드포인트
│   ├── vlm_client.py      # Qwen3-VL API 호출 (핵심)
│   └── image_utils.py     # 이미지 검증/다운로드
├── streamlit_app.py       # Streamlit 웹 UI
├── test_client.py         # CLI 테스트 클라이언트
├── Dockerfile
├── docker-compose.yml     # FastAPI + Ollama 원클릭 실행
├── .env.example
├── requirements.txt       # FastAPI 서버용
└── requirements-ui.txt    # Streamlit UI용
```

## 빠른 시작

### 방법 1: 로컬 실행 (Ollama)

```bash
# 1) Qwen3-VL 모델 다운로드
ollama pull qwen3-vl

# 2) 프로젝트 세팅
cp .env.example .env
pip install -r requirements.txt

# 3) FastAPI 서버 실행
uvicorn app.main:app --host 0.0.0.0 --port 8080 --reload

# 4) (선택) Streamlit UI 실행
pip install -r requirements-ui.txt
streamlit run streamlit_app.py
```

### 방법 2: Docker Compose (원클릭)

```bash
cp .env.example .env
docker compose up -d

# Ollama 컨테이너에 모델 다운로드
docker compose exec ollama ollama pull qwen3-vl
```

- FastAPI: http://localhost:8080
- Swagger UI: http://localhost:8080/docs
- Ollama: http://localhost:11434

## API 사용법

### 1. 이미지 파일 업로드

```bash
curl -X POST http://localhost:8080/api/v1/ocr/upload \
  -F "file=@./document.png" \
  -F "language=ko"
```

### 2. 이미지 URL 전달

```bash
curl -X POST http://localhost:8080/api/v1/ocr/url \
  -H "Content-Type: application/json" \
  -d '{
    "image_url": "https://example.com/receipt.jpg",
    "language": "ko"
  }'
```

### 3. 커스텀 프롬프트

```bash
curl -X POST http://localhost:8080/api/v1/ocr/upload \
  -F "file=@./receipt.jpg" \
  -F 'prompt=이 영수증에서 상호명, 날짜, 총 금액을 JSON으로 추출해주세요.'
```

### 4. Python 클라이언트

```python
import httpx

# 파일 업로드
with open("document.png", "rb") as f:
    resp = httpx.post(
        "http://localhost:8080/api/v1/ocr/upload",
        files={"file": ("document.png", f, "image/png")},
        data={"language": "ko"},
    )
print(resp.json()["text"])

# URL 전달
resp = httpx.post(
    "http://localhost:8080/api/v1/ocr/url",
    json={"image_url": "https://example.com/image.png", "language": "ko"},
)
print(resp.json()["text"])
```

### 5. 테스트 클라이언트 (CLI)

```bash
python test_client.py --file ./document.png
python test_client.py --url https://example.com/image.jpg
python test_client.py --file ./receipt.jpg --prompt "금액을 JSON으로 추출"
```

## 응답 형식

```json
{
  "success": true,
  "text": "추출된 텍스트 내용...",
  "model": "qwen3-vl",
  "prompt_used": "이 이미지의 모든 텍스트를 정확하게 추출해주세요..."
}
```

## 백엔드별 .env 설정

| 백엔드 | API_BASE_URL | API_MODEL_NAME | GPU |
|--------|-------------|----------------|-----|
| Ollama | `http://localhost:11434/v1` | `qwen3-vl` | 로컬 |
| vLLM | `http://localhost:8000/v1` | `Qwen/Qwen3-VL-8B-Instruct` | 서버 |
| LM Studio | `http://localhost:1234/v1` | `qwen3-vl` | 로컬 |
| DashScope | `https://dashscope-intl.aliyuncs.com/compatible-mode/v1` | `qwen-vl-ocr-2025-11-20` | 클라우드 |
| OpenRouter | `https://openrouter.ai/api/v1` | `qwen/qwen3-vl-235b-a22b` | 클라우드 |

## Streamlit UI

```bash
pip install -r requirements-ui.txt
streamlit run streamlit_app.py
```

좌측 사이드바에서 서버 주소, 언어, 커스텀 프롬프트를 설정하고,
파일 업로드 또는 URL 입력 탭에서 이미지를 제출하면 OCR 결과가 표시됩니다.
