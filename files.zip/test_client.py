"""
Qwen3-VL OCR 테스트 클라이언트
==============================
서버 실행 후 테스트:
  python test_client.py
  python test_client.py --url https://example.com/image.png
  python test_client.py --file ./document.png
  python test_client.py --file ./receipt.jpg --prompt "상호명, 날짜, 금액을 JSON으로 추출"
"""

import argparse
import json
import sys
import time

import httpx

BASE = "http://localhost:8080"


def test_health():
    """헬스체크"""
    print("=" * 50)
    print("[1] 헬스체크")
    print("=" * 50)
    resp = httpx.get(f"{BASE}/health", timeout=5.0)
    data = resp.json()
    print(json.dumps(data, indent=2, ensure_ascii=False))
    print(f"  상태: {'✅ 정상' if data['status'] == 'ok' else '❌ 비정상'}")
    print()
    return data["status"] == "ok"


def test_upload(file_path: str, prompt: str | None = None, language: str = "ko"):
    """파일 업로드 OCR 테스트"""
    print("=" * 50)
    print(f"[2] 파일 업로드 OCR: {file_path}")
    print("=" * 50)

    with open(file_path, "rb") as f:
        files = {"file": (file_path.split("/")[-1], f)}
        data = {"language": language}
        if prompt:
            data["prompt"] = prompt

        start = time.time()
        resp = httpx.post(
            f"{BASE}/api/v1/ocr/upload",
            files=files,
            data=data,
            timeout=120.0,
        )
        elapsed = time.time() - start

    if resp.status_code != 200:
        print(f"  ❌ 에러 {resp.status_code}: {resp.text}")
        return

    result = resp.json()
    print(f"  모델: {result['model']}")
    print(f"  소요시간: {elapsed:.1f}초")
    print(f"  프롬프트: {result['prompt_used'][:60]}...")
    print()
    print("── 추출 결과 ──")
    print(result["text"])
    print()


def test_url(image_url: str, prompt: str | None = None, language: str = "ko"):
    """URL OCR 테스트"""
    print("=" * 50)
    print(f"[3] URL OCR: {image_url}")
    print("=" * 50)

    payload = {"image_url": image_url, "language": language}
    if prompt:
        payload["prompt"] = prompt

    start = time.time()
    resp = httpx.post(
        f"{BASE}/api/v1/ocr/url",
        json=payload,
        timeout=120.0,
    )
    elapsed = time.time() - start

    if resp.status_code != 200:
        print(f"  ❌ 에러 {resp.status_code}: {resp.text}")
        return

    result = resp.json()
    print(f"  모델: {result['model']}")
    print(f"  소요시간: {elapsed:.1f}초")
    print(f"  프롬프트: {result['prompt_used'][:60]}...")
    print()
    print("── 추출 결과 ──")
    print(result["text"])
    print()


def main():
    parser = argparse.ArgumentParser(description="Qwen3-VL OCR 테스트 클라이언트")
    parser.add_argument("--base", default=BASE, help="서버 주소")
    parser.add_argument("--file", help="업로드할 이미지 파일 경로")
    parser.add_argument("--url", help="이미지 URL")
    parser.add_argument("--prompt", help="커스텀 프롬프트")
    parser.add_argument("--language", default="ko", help="언어 (ko/en/ja/zh)")
    args = parser.parse_args()

    global BASE
    BASE = args.base.rstrip("/")

    # 헬스체크
    try:
        if not test_health():
            print("서버가 비정상 상태입니다.")
            sys.exit(1)
    except httpx.ConnectError:
        print(f"❌ 서버 연결 실패: {BASE}")
        print("  → uvicorn app.main:app --port 8080 으로 서버를 먼저 실행해주세요.")
        sys.exit(1)

    # 파일 또는 URL 테스트
    if args.file:
        test_upload(args.file, prompt=args.prompt, language=args.language)
    elif args.url:
        test_url(args.url, prompt=args.prompt, language=args.language)
    else:
        print("ℹ️  --file 또는 --url 인자를 지정해주세요.")
        print()
        print("사용 예시:")
        print(f"  python test_client.py --file ./document.png")
        print(f"  python test_client.py --url https://example.com/image.jpg")
        print(f'  python test_client.py --file ./receipt.jpg --prompt "금액을 JSON으로 추출"')


if __name__ == "__main__":
    main()
