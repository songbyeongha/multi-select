"""이미지 유틸리티: 검증, 다운로드, MIME 타입 추론"""

import io
import mimetypes
from pathlib import Path

import httpx
from PIL import Image
from fastapi import UploadFile

from app.config import settings


def get_mime_type(filename: str) -> str:
    """파일명 → MIME 타입"""
    mime, _ = mimetypes.guess_type(filename)
    return mime or "image/jpeg"


def validate_extension(filename: str) -> bool:
    """허용 확장자 체크"""
    ext = Path(filename).suffix.lstrip(".").lower()
    return ext in settings.ALLOWED_EXTENSIONS


async def read_upload(file: UploadFile) -> tuple[bytes, str]:
    """업로드 파일 → (바이트, MIME) 반환 + 유효성 검증"""
    content = await file.read()

    max_bytes = settings.MAX_IMAGE_SIZE_MB * 1024 * 1024
    if len(content) > max_bytes:
        raise ValueError(f"이미지 크기 초과: {settings.MAX_IMAGE_SIZE_MB}MB 제한")

    # PIL로 유효한 이미지인지 검증
    Image.open(io.BytesIO(content)).verify()

    mime = get_mime_type(file.filename or "image.jpg")
    return content, mime


async def download_image(url: str) -> tuple[bytes, str]:
    """URL에서 이미지 다운로드 → (바이트, MIME) 반환"""
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        resp = await client.get(url)
        resp.raise_for_status()

    content = resp.content

    max_bytes = settings.MAX_IMAGE_SIZE_MB * 1024 * 1024
    if len(content) > max_bytes:
        raise ValueError(f"이미지 크기 초과: {settings.MAX_IMAGE_SIZE_MB}MB 제한")

    Image.open(io.BytesIO(content)).verify()

    content_type = resp.headers.get("content-type", "image/jpeg").split(";")[0]
    return content, content_type
