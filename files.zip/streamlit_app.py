"""
Streamlit OCR UI
================
FastAPI 서버와 연동하는 웹 UI.

실행:
  streamlit run streamlit_app.py
"""

import streamlit as st
import httpx
import time

st.set_page_config(page_title="Qwen3-VL OCR", page_icon="🔍", layout="wide")

# ── 사이드바: 설정 ──────────────────────────────────────
with st.sidebar:
    st.header("⚙️ 설정")
    api_base = st.text_input("FastAPI 서버 주소", value="http://localhost:8080")
    language = st.selectbox("언어", ["ko", "en", "ja", "zh"], index=0)
    custom_prompt = st.text_area(
        "커스텀 프롬프트 (비우면 기본값)",
        placeholder="예: 이 영수증에서 상호명, 날짜, 금액을 JSON으로 추출해주세요.",
        height=100,
    )

    st.divider()
    # 헬스체크
    if st.button("🔌 서버 연결 확인"):
        try:
            resp = httpx.get(f"{api_base.rstrip('/')}/health", timeout=5.0)
            data = resp.json()
            if data["status"] == "ok":
                st.success(f"✅ 연결 성공\n\n모델: `{data['model']}`")
            else:
                st.error("서버 비정상")
        except Exception as e:
            st.error(f"❌ 연결 실패: {e}")

# ── 메인 영역 ──────────────────────────────────────────
st.title("🔍 Qwen3-VL OCR")
st.caption("이미지에서 텍스트를 추출합니다.")

tab_upload, tab_url = st.tabs(["📁 파일 업로드", "🔗 URL 입력"])

# ── 탭 1: 파일 업로드 ──────────────────────────────────
with tab_upload:
    uploaded_file = st.file_uploader(
        "이미지 파일 선택",
        type=["jpg", "jpeg", "png", "webp", "bmp", "tiff"],
        help="최대 20MB",
    )

    if uploaded_file:
        col_img, col_result = st.columns(2)

        with col_img:
            st.image(uploaded_file, caption=uploaded_file.name, use_container_width=True)

        with col_result:
            if st.button("🚀 텍스트 추출", key="btn_upload"):
                with st.spinner("Qwen3-VL 처리 중..."):
                    start = time.time()
                    try:
                        files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
                        data = {"language": language}
                        if custom_prompt.strip():
                            data["prompt"] = custom_prompt.strip()

                        resp = httpx.post(
                            f"{api_base.rstrip('/')}/api/v1/ocr/upload",
                            files=files,
                            data=data,
                            timeout=120.0,
                        )
                        elapsed = time.time() - start

                        if resp.status_code == 200:
                            result = resp.json()
                            st.success(f"완료 ({elapsed:.1f}초) · 모델: {result['model']}")
                            st.text_area(
                                "추출된 텍스트",
                                value=result["text"],
                                height=400,
                            )
                        else:
                            st.error(f"에러 {resp.status_code}: {resp.text}")
                    except httpx.ConnectError:
                        st.error(f"서버 연결 실패: {api_base}")
                    except Exception as e:
                        st.error(f"오류: {e}")

# ── 탭 2: URL 입력 ─────────────────────────────────────
with tab_url:
    image_url = st.text_input(
        "이미지 URL",
        placeholder="https://example.com/document.png",
    )

    if image_url:
        col_img2, col_result2 = st.columns(2)

        with col_img2:
            try:
                st.image(image_url, caption="미리보기", use_container_width=True)
            except Exception:
                st.warning("이미지 미리보기를 불러올 수 없습니다.")

        with col_result2:
            if st.button("🚀 텍스트 추출", key="btn_url"):
                with st.spinner("Qwen3-VL 처리 중..."):
                    start = time.time()
                    try:
                        payload = {"image_url": image_url, "language": language}
                        if custom_prompt.strip():
                            payload["prompt"] = custom_prompt.strip()

                        resp = httpx.post(
                            f"{api_base.rstrip('/')}/api/v1/ocr/url",
                            json=payload,
                            timeout=120.0,
                        )
                        elapsed = time.time() - start

                        if resp.status_code == 200:
                            result = resp.json()
                            st.success(f"완료 ({elapsed:.1f}초) · 모델: {result['model']}")
                            st.text_area(
                                "추출된 텍스트",
                                value=result["text"],
                                height=400,
                            )
                        else:
                            st.error(f"에러 {resp.status_code}: {resp.text}")
                    except httpx.ConnectError:
                        st.error(f"서버 연결 실패: {api_base}")
                    except Exception as e:
                        st.error(f"오류: {e}")
