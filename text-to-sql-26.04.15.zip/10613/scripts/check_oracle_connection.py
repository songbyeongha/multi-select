#!/usr/bin/env python3
"""Validate Oracle connectivity and basic metadata access."""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


def main():
    from text2sql.config.settings import get_settings

    settings = get_settings()
    db_cfg = settings.db

    print("=" * 60)
    print("Oracle Connection Check")
    print("=" * 60)

    if db_cfg.dialect != "oracle":
        print(f"[INFO] Current dialect: {db_cfg.dialect}")
        print("[INFO] Set T2SQL_DB_DIALECT=oracle before running this script.")
        return

    print(f"  Host:         {db_cfg.host}")
    print(f"  Port:         {db_cfg.port}")
    print(f"  Service:      {db_cfg.service_name}")
    print(f"  User:         {db_cfg.user}")
    print(f"  Schema:       {db_cfg.schema or '(user default)'}")
    print(f"  Read-only:    {db_cfg.read_only}")
    print()

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError as exc:
        print(f"[ERROR] Oracle driver is not available: {exc}")
        print("        Install it with `pip install oracledb`.")
        return

    try:
        adapter = OracleAdapter(
            host=db_cfg.host,
            port=db_cfg.port,
            service_name=db_cfg.service_name,
            dsn=db_cfg.dsn,
            user=db_cfg.user,
            password=db_cfg.password,
            schema=db_cfg.schema,
            connect_timeout_sec=db_cfg.connect_timeout_sec,
        )
    except Exception as exc:
        print(f"[ERROR] Failed to create Oracle adapter: {exc}")
        return

    print("[1/5] Testing connection...")
    info = adapter.test_connection()
    if not info["ok"]:
        print(f"  [FAIL] {info['message']}")
        return
    print(f"  [OK] {info['message']}")
    print()

    print(f"[2/5] Effective user/schema: {info.get('user')} / {info.get('schema')}")
    print()

    print("[3/5] Listing readable tables...")
    tables = adapter.list_tables()
    print(f"  Table count: {len(tables)}")
    if tables:
        for table_name in tables[:20]:
            print(f"    - {table_name}")
        if len(tables) > 20:
            print(f"    ... and {len(tables) - 20} more")

        system_like = [
            table_name
            for table_name in tables
            if table_name.upper().startswith(("AQ$_", "MVIEW$_", "LOGSTDBY$", "REDO_DB$"))
            or table_name.upper() in {"HELP", "SQLPLUS_PRODUCT_PROFILE"}
        ]
        if (info.get("schema") or "").upper() in {"SYSTEM", "SYS"} or len(system_like) >= max(5, len(tables) // 3):
            print("  [WARN] The current schema still looks like SYSTEM/SYS or a system-table schema.")
            print("         For production Text-to-SQL, use a business schema or tighten include/exclude filters.")
    print()

    print("[4/5] Checking metadata access...")
    metadata_ok = info.get("metadata_accessible", False)
    print(f"  ALL_* metadata views accessible: {'YES' if metadata_ok else 'NO (USER_* fallback)'}")
    if tables:
        sample_table = tables[0]
        table_meta = adapter.table_info(sample_table)
        print(f"  Sample table: {sample_table}")
        print(f"    Columns: {len(table_meta.columns)}")
        for column in table_meta.columns[:5]:
            pk = " [PK]" if column.is_pk else ""
            comment = f" -- {column.comment}" if column.comment else ""
            print(f"      {column.name}  {column.type}{pk}{comment}")
        if len(table_meta.columns) > 5:
            print(f"      ... and {len(table_meta.columns) - 5} more columns")
        print(f"    Foreign keys: {len(table_meta.foreign_keys)}")
    print()

    print("[5/5] Running sample SELECT...")
    if tables:
        sample_table = tables[0]
        owner = adapter.owner
        sql = f'SELECT * FROM "{owner}"."{sample_table}" WHERE ROWNUM <= 3'
        result = adapter.execute(sql, limit=3)
        if result["ok"]:
            print(f"  [OK] Query succeeded on {sample_table} ({result['row_count']} rows)")
            for row in result["rows"][:3]:
                print(f"    {dict(list(row.items())[:5])}")
        else:
            print(f"  [FAIL] Query failed: {result['error_message']}")
    print()

    adapter.close()
    print("=" * 60)
    print("Next recommended commands")
    print("=" * 60)
    print("  python scripts/run_ops.py first-run --db-id <db_id>")
    print("  python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>")
    print("  python scripts/run_ops.py test --db-id <db_id> --catalog <catalog.json>")
    print("  python scripts/run_ops.py release --db-id <db_id> --catalog <catalog.json>")


if __name__ == "__main__":
    main()
