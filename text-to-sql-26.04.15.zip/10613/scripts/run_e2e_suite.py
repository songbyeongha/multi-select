#!/usr/bin/env python3
"""Run a Text-to-SQL regression suite against the active database."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def parse_args():
    parser = argparse.ArgumentParser(description="Run Text-to-SQL e2e suite")
    parser.add_argument("--catalog", required=True, help="JSON/JSONL catalog with question and expected SQL")
    parser.add_argument("--db-id", default="", help="Database ID")
    parser.add_argument("--max-retries", type=int, default=2, help="Pipeline max retries")
    parser.add_argument("--report", default="logs/e2e_suite_report.json", help="Report output path")
    parser.add_argument("--limit", type=int, default=50000, help="Execution limit for result comparison")
    parser.add_argument("--probe-timeout-sec", type=int, default=5, help="Timeout for the LLM endpoint preflight probe")
    parser.add_argument("--skip-llm-check", action="store_true", help="Skip the fast LLM endpoint reachability check")
    parser.add_argument("--record-feedback", action="store_true", help="Store E2E pass/fail results as feedback records")
    parser.add_argument("--learn", action="store_true", help="Run the learner after recording E2E feedback")
    parser.add_argument("--domain", default="", help="Run only cases from a single domain")
    parser.add_argument("--tag", action="append", default=[], help="Run only cases that include this tag")
    parser.add_argument("--max-items", type=int, default=0, help="Run only the first N filtered cases")
    return parser.parse_args()


def _stable_rows(rows: List[Dict[str, Any]]) -> str:
    return json.dumps(rows, ensure_ascii=False, sort_keys=True, default=str)


def _stable_row_values(rows: List[Dict[str, Any]]) -> str:
    return json.dumps([list(row.values()) for row in rows], ensure_ascii=False, default=str)


def main():
    from text2sql.config.settings import get_settings
    from text2sql.feedback import FeedbackRecord, get_feedback_store, get_learner
    from text2sql.lg.graph import get_compiled_graph
    from text2sql.lg.state import new_state
    from text2sql.tools.executor import SQLExecutor
    from text2sql.tools.harness_catalog import (
        filter_catalog_cases,
        load_catalog_cases,
        summarize_result_dimensions,
        validate_catalog_cases,
    )
    from text2sql.tools.runtime_checks import probe_llm_endpoint

    args = parse_args()
    settings = get_settings()
    if not args.skip_llm_check:
        llm_probe = probe_llm_endpoint(settings, timeout_sec=args.probe_timeout_sec)
        if not llm_probe["ok"]:
            print(f"[ERROR] LLM endpoint is unreachable: {llm_probe['message']}")
            print(f"        provider={llm_probe['provider']} url={llm_probe['url']}")
            sys.exit(1)

    db_id = args.db_id or settings.db.db_id or "oracle_db"
    catalog_path = Path(args.catalog)
    if not catalog_path.is_absolute():
        catalog_path = ROOT / catalog_path

    cases = load_catalog_cases(catalog_path)
    catalog_validation = validate_catalog_cases(cases)
    if catalog_validation["errors"]:
        print("[ERROR] Catalog validation failed.")
        for item in catalog_validation["errors"]:
            print(f"        - {item}")
        sys.exit(1)
    if catalog_validation["warnings"]:
        print(f"[WARN] Catalog validation produced {len(catalog_validation['warnings'])} warnings.")

    cases = filter_catalog_cases(
        cases,
        domain=args.domain,
        tags=args.tag,
        max_items=args.max_items,
    )
    if not cases:
        print("[ERROR] No catalog cases matched the selected filters.")
        sys.exit(1)

    db_path = "__oracle__"
    graph = get_compiled_graph()
    executor = SQLExecutor(preview_limit=args.limit)
    results = []
    passed = 0

    for index, case in enumerate(cases, start=1):
        question = str(case.get("question") or "").strip()
        expected_sql = str(case.get("expected_sql") or case.get("sql") or "").strip()
        if not question or not expected_sql:
            continue

        started = time.time()
        state = new_state(question=question, database_id=db_id, db_path=db_path, max_retries=args.max_retries)
        result = graph.invoke(state)
        generated_sql = result.get("final_sql") or result.get("selected_sql") or ""
        generated_report = executor.execute(db_path, generated_sql, limit=args.limit) if generated_sql else None
        expected_report = executor.execute(db_path, expected_sql, limit=args.limit)

        row_match = bool(
            generated_report
            and generated_report.ok
            and expected_report.ok
            and generated_report.row_count == expected_report.row_count
            and (
                _stable_rows(generated_report.rows_preview) == _stable_rows(expected_report.rows_preview)
                or _stable_row_values(generated_report.rows_preview) == _stable_row_values(expected_report.rows_preview)
            )
        )
        success = bool(result.get("success")) and row_match
        if success:
            passed += 1

        results.append(
            {
                "index": index,
                "case_id": case.get("case_id"),
                "title": case.get("title"),
                "question": question,
                "domain": case.get("domain"),
                "difficulty": case.get("difficulty"),
                "tags": case.get("tags"),
                "elapsed_sec": round(time.time() - started, 2),
                "pipeline_success": bool(result.get("success")),
                "result_match": row_match,
                "success": success,
                "generated_sql": generated_sql,
                "expected_sql": expected_sql,
                "selected_tables": result.get("selected_tables"),
                "summary": result.get("result_summary"),
                "error": result.get("error"),
            }
        )
        print(f"[{'PASS' if success else 'FAIL'}] {question}")
        if args.record_feedback:
            feedback_score = 5 if success else 2
            feedback_sql = generated_sql if generated_sql else expected_sql
            feedback_comment = "[auto][e2e] regression pass" if success else "[auto][e2e] regression fail"
            get_feedback_store().add(
                FeedbackRecord(
                    question=question,
                    sql=feedback_sql,
                    database_id=db_id,
                    score=feedback_score,
                    score_label="[auto] very_good" if success else "[auto] bad",
                    user_comment=feedback_comment,
                    query_pattern=f"e2e_regression:{case.get('domain')}",
                    dialect=settings.db.dialect,
                    tables_used=result.get("selected_tables", []),
                )
            )

    dimension_summary = summarize_result_dimensions(results)
    report = {
        "db_id": db_id,
        "catalog": str(catalog_path),
        "catalog_validation": catalog_validation,
        "filters": {
            "domain": args.domain,
            "tags": args.tag,
            "max_items": args.max_items,
        },
        "total": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "pass_rate": round((passed / len(results)) * 100, 1) if results else 0.0,
        "by_domain": dimension_summary["by_domain"],
        "by_difficulty": dimension_summary["by_difficulty"],
        "by_tag": dimension_summary["by_tag"],
        "results": results,
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] report saved: {report_path}")
    if args.record_feedback and args.learn:
        learn_result = get_learner().learn(db_id)
        print(f"[OK] learner updated from E2E feedback: {learn_result}")
    if passed != len(results):
        sys.exit(2)


if __name__ == "__main__":
    main()
