#!/usr/bin/env python3
"""Oracle release gate for production-readiness checks."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def parse_args():
    parser = argparse.ArgumentParser(description="Oracle release gate")
    parser.add_argument("--db-id", default="", help="Database ID")
    parser.add_argument("--catalog", default="", help="E2E question catalog path")
    parser.add_argument("--e2e-report", default="logs/release_gate_e2e.json", help="E2E report output path")
    parser.add_argument("--report", default="logs/oracle_release_gate.json", help="Release-gate report output path")
    parser.add_argument("--max-retries", type=int, default=2, help="Pipeline max retries for E2E execution")
    parser.add_argument("--run-e2e", action="store_true", help="Run the E2E regression suite as part of the gate")
    parser.add_argument("--run-pytest", action="store_true", help="Run the local pytest suite as part of the gate")
    parser.add_argument("--run-vulture", action="store_true", help="Run vulture dead-code checks as part of the gate")
    parser.add_argument("--allow-system-schema", action="store_true", help="Do not fail on SYSTEM/SYS-like schemas")
    parser.add_argument("--fail-under-overall", type=int, default=90, help="Fail when the overall release score is below this value")
    parser.add_argument("--fail-under-query-accuracy", type=int, default=90, help="Fail when query accuracy is below this value")
    parser.add_argument("--fail-under-pass-rate", type=float, default=100.0, help="Fail when E2E pass rate is below this value")
    parser.add_argument("--max-vulture-issues", type=int, default=0, help="Fail when high-confidence vulture findings exceed this count")
    return parser.parse_args()


def _resolve_path(path_str: str, *, default: Path | None = None) -> Path:
    path = Path(path_str) if path_str else (default or Path())
    if not path.is_absolute():
        path = ROOT / path
    return path


def _resolve_runtime_paths(settings) -> Dict[str, Path]:
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
    )

    metadata_path = (
        Path(settings.db.metadata_path)
        if settings.db.metadata_path
        else default_metadata_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    if not metadata_path.is_absolute():
        metadata_path = ROOT / metadata_path

    manual_metadata_path = (
        Path(settings.db.manual_metadata_path)
        if settings.db.manual_metadata_path
        else sibling_overlay_path(metadata_path)
    )
    if not manual_metadata_path.is_absolute():
        manual_metadata_path = ROOT / manual_metadata_path

    hints_primary_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    domain_hints_path = (
        Path(hints_primary_env)
        if hints_primary_env
        else default_domain_hints_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    if not domain_hints_path.is_absolute():
        domain_hints_path = ROOT / domain_hints_path

    hints_manual_env = os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
    domain_hints_manual_path = (
        Path(hints_manual_env) if hints_manual_env else domain_hints_path.with_name(f"{domain_hints_path.stem}_manual{domain_hints_path.suffix}")
    )
    if not domain_hints_manual_path.is_absolute():
        domain_hints_manual_path = ROOT / domain_hints_manual_path

    return {
        "metadata": metadata_path,
        "manual_metadata": manual_metadata_path,
        "domain_hints": domain_hints_path,
        "manual_domain_hints": domain_hints_manual_path,
    }


def _db_entry(path: Path, db_id: str) -> Dict[str, Any]:
    from text2sql.config.metadata_utils import get_db_scoped_entry, load_json_file

    return get_db_scoped_entry(load_json_file(path), db_id)


def _looks_like_system_schema(schema: str, tables: Iterable[str]) -> bool:
    schema_name = (schema or "").upper()
    table_list = [str(table).upper() for table in tables]
    if schema_name in {"SYSTEM", "SYS"}:
        return True
    system_like = [
        table
        for table in table_list
        if table.startswith(("AQ$_", "MVIEW$_", "LOGSTDBY$", "REDO_DB$"))
        or table in {"HELP", "SQLPLUS_PRODUCT_PROFILE"}
    ]
    return bool(table_list) and len(system_like) >= max(5, len(table_list) // 3)


def _run_command(command: list[str]) -> Dict[str, Any]:
    result = subprocess.run(
        command,
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    return {
        "command": command,
        "returncode": result.returncode,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }


def _load_report(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def main():
    from text2sql.config.settings import get_settings
    from text2sql.feedback.evaluator import AgentEvaluator
    from text2sql.tools.harness_catalog import load_catalog_cases, validate_catalog_cases
    from text2sql.tools.release_gate import build_release_report, vector_index_status
    from text2sql.tools.runtime_checks import probe_embedding_endpoint, probe_llm_endpoint

    args = parse_args()
    settings = get_settings()
    tests_root = ROOT / "tests"
    local_tests_root = tests_root / "local"
    if settings.db.dialect != "oracle":
        print("[ERROR] T2SQL_DB_DIALECT must be set to oracle.")
        sys.exit(1)

    db_id = args.db_id or settings.db.db_id or "oracle_db"
    paths = _resolve_runtime_paths(settings)
    metadata_entry = settings.schema_metadata(db_id)
    hints_entry = settings.domain_hints(db_id)
    raw_metadata_entry = _db_entry(paths["metadata"], db_id)
    raw_manual_metadata_entry = _db_entry(paths["manual_metadata"], db_id)
    raw_domain_hints_entry = _db_entry(paths["domain_hints"], db_id)
    raw_manual_domain_hints_entry = _db_entry(paths["manual_domain_hints"], db_id)

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError as exc:
        print(f"[ERROR] Failed to import OracleAdapter: {exc}")
        sys.exit(1)

    adapter = OracleAdapter(
        host=settings.db.host,
        port=settings.db.port,
        service_name=settings.db.service_name,
        dsn=settings.db.dsn,
        user=settings.db.user,
        password=settings.db.password,
        schema=settings.db.schema,
        connect_timeout_sec=settings.db.connect_timeout_sec,
        query_timeout_ms=settings.guard.timeout_ms,
        read_only=settings.db.read_only,
    )

    connection = adapter.test_connection()
    tables = adapter.list_tables() if connection.get("ok") else []
    system_schema = _looks_like_system_schema(connection.get("schema") or settings.db.schema, tables)
    adapter.close()
    llm_probe = probe_llm_endpoint(settings)
    embedding_probe = probe_embedding_endpoint(settings)
    catalog_validation: Dict[str, Any] | None = None
    if args.catalog:
        catalog_path = _resolve_path(args.catalog)
        catalog_validation = validate_catalog_cases(load_catalog_cases(catalog_path))

    e2e_path = _resolve_path(args.e2e_report)
    e2e_execution: Dict[str, Any] | None = None
    if args.run_e2e:
        if not args.catalog:
            print("[ERROR] --catalog is required when --run-e2e is enabled.")
            sys.exit(1)
        if not llm_probe["ok"]:
            print(f"[ERROR] LLM endpoint is unreachable: {llm_probe['message']}")
            print(f"        provider={llm_probe['provider']} url={llm_probe['url']}")
            sys.exit(1)
        if catalog_validation and catalog_validation["errors"]:
            print("[ERROR] Catalog validation failed.")
            for item in catalog_validation["errors"]:
                print(f"        - {item}")
            sys.exit(1)
        catalog_path = _resolve_path(args.catalog)
        e2e_execution = _run_command(
            [
                sys.executable,
                str(ROOT / "scripts" / "run_e2e_suite.py"),
                "--catalog",
                str(catalog_path),
                "--db-id",
                db_id,
                "--max-retries",
                str(args.max_retries),
                "--report",
                str(e2e_path),
            ]
        )

    pytest_execution: Dict[str, Any] | None = None
    if args.run_pytest:
        if local_tests_root.exists():
            pytest_execution = _run_command([sys.executable, "-m", "pytest", "tests/local", "-q"])
        elif tests_root.exists():
            pytest_execution = _run_command([sys.executable, "-m", "pytest", "tests", "-q"])
        else:
            pytest_execution = {
                "command": [],
                "returncode": 0,
                "stdout": "",
                "stderr": "",
                "skipped": True,
                "reason": "tests directory is not packaged in this runtime bundle",
            }

    vulture_execution: Dict[str, Any] | None = None
    if args.run_vulture:
        vulture_targets = ["src", "scripts", "app.py"]
        if tests_root.exists():
            vulture_targets.append("tests")
        vulture_execution = _run_command(
            [sys.executable, "-m", "vulture", *vulture_targets, "--min-confidence", "80"]
        )

    e2e_report = _load_report(e2e_path) if e2e_path.exists() else {}
    evaluator_report = AgentEvaluator().evaluate(db_id, cycle_index=10)
    vector_status = vector_index_status(db_id, metadata_entry)
    vector_ready = bool(vector_status.get("fresh")) or not embedding_probe.get("ok")
    if vector_status.get("fresh"):
        vector_mode = "fresh-index"
    elif not embedding_probe.get("ok"):
        vector_mode = "bm25-only"
    else:
        vector_mode = "stale-index"

    docs = {
        "readme": (ROOT / "README.md").exists(),
        "docs_index": (ROOT / "docs" / "README.md").exists(),
        "system_vision": (ROOT / "docs" / "architecture" / "SYSTEM_VISION.md").exists(),
        "quickstart": (ROOT / "docs" / "operations" / "ORACLE_DB_QUICKSTART.md").exists(),
        "playbook": (ROOT / "docs" / "operations" / "ORACLE_PRODUCTION_PLAYBOOK.md").exists(),
        "endpoint_audit": (ROOT / "docs" / "operations" / "ENDPOINT_AUDIT.md").exists(),
        "harness_engineering": (ROOT / "docs" / "harness" / "HARNESS_ENGINEERING.md").exists(),
        "metadata_enrichment": (ROOT / "docs" / "metadata" / "SQL_METADATA_ENRICHMENT.md").exists(),
        "release_checklist": (ROOT / "docs" / "operations" / "RELEASE_CHECKLIST.md").exists(),
    }
    automation = {
        "metadata_export": (ROOT / "scripts" / "export_oracle_metadata.py").exists(),
        "sql_enrichment": (ROOT / "scripts" / "enrich_metadata_from_sql.py").exists(),
        "oracle_ops": (ROOT / "scripts" / "oracle_ops.py").exists(),
        "e2e_runner": (ROOT / "scripts" / "run_e2e_suite.py").exists(),
        "catalog_validator": (ROOT / "scripts" / "validate_query_catalog.py").exists(),
        "release_gate": (ROOT / "scripts" / "oracle_release_gate.py").exists(),
    }

    vulture_issues = 0
    if vulture_execution:
        lines = [
            line.strip()
            for line in (vulture_execution.get("stdout") or "").splitlines()
            if line.strip()
        ]
        vulture_issues = len(lines)

    code_hygiene = {
        "pytest_ok": (
            None
            if pytest_execution is None or pytest_execution.get("skipped")
            else pytest_execution["returncode"] == 0
        ),
        "pytest_skipped": bool(pytest_execution.get("skipped")) if pytest_execution else False,
        "pytest_reason": pytest_execution.get("reason", "") if pytest_execution else "",
        "pytest_summary": (
            (pytest_execution.get("stdout") or "").splitlines()[-1]
            if pytest_execution and (pytest_execution.get("stdout") or "").splitlines()
            else ""
        ),
        "vulture_issues": vulture_issues,
        "vulture_output": (vulture_execution.get("stdout") or "").splitlines() if vulture_execution else [],
    }

    checks = {
        "connection_ok": bool(connection.get("ok")),
        "llm_reachable": bool(llm_probe.get("ok")),
        "read_only": bool(settings.db.read_only),
        "schema_is_business": args.allow_system_schema or not system_schema,
        "metadata_present": bool(raw_metadata_entry),
        "manual_metadata_present": bool(raw_manual_metadata_entry),
        "domain_hints_present": bool(raw_domain_hints_entry),
        "manual_domain_hints_present": bool(raw_manual_domain_hints_entry),
        "vector_fresh": vector_ready,
        "include_exclude_supported": True,
        "catalog_valid": catalog_validation["valid"] if catalog_validation is not None else True,
    }

    release = build_release_report(
        db_id=db_id,
        evaluator_report=evaluator_report,
        checks=checks,
        docs=docs,
        automation=automation,
        e2e_report=e2e_report or None,
        code_hygiene=code_hygiene,
    )

    overall_score = int(release["overall_score"])
    query_accuracy = int(release["dimensions"]["query_accuracy"])
    e2e_pass_rate = float((e2e_report or {}).get("pass_rate", 0.0) or 0.0)
    passed = True
    if release["blocking_issues"]:
        passed = False
    if overall_score < args.fail_under_overall:
        passed = False
    if query_accuracy < args.fail_under_query_accuracy:
        passed = False
    if (args.run_e2e or e2e_report) and e2e_pass_rate < args.fail_under_pass_rate:
        passed = False
    if vulture_issues > args.max_vulture_issues:
        passed = False

    report = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "db_id": db_id,
        "passed": passed,
        "config": {
            "host": settings.db.host,
            "service_name": settings.db.service_name,
            "schema": settings.db.schema,
            "read_only": settings.db.read_only,
        },
        "paths": {name: str(path) for name, path in paths.items()},
        "connection": connection,
        "llm_probe": llm_probe,
        "embedding_probe": embedding_probe,
        "catalog_validation": catalog_validation,
        "tables_preview": tables[:20],
        "vector_status": vector_status,
        "vector_mode": vector_mode,
        "docs": docs,
        "automation": automation,
        "checks": checks,
        "evaluator": evaluator_report,
        "e2e_report": e2e_report,
        "code_hygiene": code_hygiene,
        "executions": {
            "e2e": e2e_execution,
            "pytest": pytest_execution,
            "vulture": vulture_execution,
        },
        "release": release,
        "thresholds": {
            "overall": args.fail_under_overall,
            "query_accuracy": args.fail_under_query_accuracy,
            "pass_rate": args.fail_under_pass_rate,
            "max_vulture_issues": args.max_vulture_issues,
        },
    }

    report_path = _resolve_path(args.report)
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[{'PASS' if passed else 'FAIL'}] Oracle release gate")
    print(f"  db_id={db_id}")
    print(f"  overall_score={overall_score}")
    print(f"  query_accuracy={query_accuracy}")
    print(f"  e2e_pass_rate={e2e_pass_rate:.1f}")
    print(f"  vector_mode={vector_mode}")
    print(f"  report={report_path}")
    if release["blocking_issues"]:
        print("  blockers:")
        for blocker in release["blocking_issues"]:
            print(f"    - {blocker}")
    if release["recommendations"]:
        print("  recommendations:")
        for item in release["recommendations"][:10]:
            print(f"    - {item}")

    if not passed:
        sys.exit(2)


if __name__ == "__main__":
    main()
