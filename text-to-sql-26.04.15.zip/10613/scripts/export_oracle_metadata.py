#!/usr/bin/env python3
"""Export Oracle metadata and seed editable overlay files."""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


def parse_args():
    parser = argparse.ArgumentParser(description="Export Oracle metadata")
    parser.add_argument("--output", "-o", default="", help="Primary metadata output path")
    parser.add_argument("--manual-output", default="", help="Manual metadata overlay path")
    parser.add_argument("--domain-hints-output", default="", help="Oracle domain hints seed path")
    parser.add_argument("--domain-hints-manual-output", default="", help="Oracle manual domain hints overlay path")
    parser.add_argument("--include", default="", help="Comma-separated include tables")
    parser.add_argument("--exclude", default="", help="Comma-separated exclude tables")
    parser.add_argument("--samples", type=int, default=3, help="Sample value count per column")
    parser.add_argument("--db-id", default="", help="Database ID")
    return parser.parse_args()


def main():
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
    )
    from text2sql.config.settings import get_settings
    from text2sql.tools.oracle_metadata import (
        ensure_seed_file,
        export_oracle_metadata_payload,
        scaffold_domain_hints,
        scaffold_manual_domain_hints,
        scaffold_manual_metadata,
        write_json,
    )

    args = parse_args()
    settings = get_settings()
    db_cfg = settings.db

    if db_cfg.dialect != "oracle":
        print("[ERROR] T2SQL_DB_DIALECT must be set to oracle.")
        sys.exit(1)

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError as exc:
        print(f"[ERROR] Failed to import OracleAdapter: {exc}")
        print("        Install the driver with `pip install oracledb`.")
        sys.exit(1)

    adapter = OracleAdapter(
        host=db_cfg.host,
        port=db_cfg.port,
        service_name=db_cfg.service_name,
        dsn=db_cfg.dsn,
        user=db_cfg.user,
        password=db_cfg.password,
        schema=db_cfg.schema,
        connect_timeout_sec=db_cfg.connect_timeout_sec,
    )

    info = adapter.test_connection()
    if not info["ok"]:
        print(f"[ERROR] Oracle connection failed: {info['message']}")
        sys.exit(1)
    print(f"[OK] Oracle connection succeeded: {info['message']}")

    db_id = args.db_id or db_cfg.db_id or "oracle_db"
    include = [t.strip() for t in args.include.split(",") if t.strip()]
    exclude = [t.strip() for t in args.exclude.split(",") if t.strip()]
    include.extend(db_cfg.include_table_list())
    exclude.extend(db_cfg.exclude_table_list())

    payload = export_oracle_metadata_payload(
        adapter,
        db_id=db_id,
        db_description=f"Oracle DB: {db_cfg.schema or db_cfg.user}@{db_cfg.host}",
        include_tables=include,
        exclude_tables=exclude,
        sample_limit=args.samples,
    )

    output_path = (
        Path(args.output)
        if args.output
        else (
            Path(db_cfg.metadata_path)
            if db_cfg.metadata_path
            else default_metadata_path(ROOT / "src" / "text2sql" / "config", db_cfg.dialect)
        )
    )
    if not output_path.is_absolute():
        output_path = ROOT / output_path
    output_path = write_json(output_path, payload)
    manual_path = (
        Path(args.manual_output)
        if args.manual_output
        else (
            Path(db_cfg.manual_metadata_path)
            if db_cfg.manual_metadata_path
            else sibling_overlay_path(output_path)
        )
    )
    if not manual_path.is_absolute():
        manual_path = ROOT / manual_path
    domain_hints_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    domain_hints_path = (
        Path(args.domain_hints_output)
        if args.domain_hints_output
        else (
            Path(domain_hints_env)
            if domain_hints_env
            else default_domain_hints_path(ROOT / "src" / "text2sql" / "config", db_cfg.dialect)
        )
    )
    if not domain_hints_path.is_absolute():
        domain_hints_path = ROOT / domain_hints_path
    domain_hints_manual_env = os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
    domain_hints_manual_path = (
        Path(args.domain_hints_manual_output)
        if args.domain_hints_manual_output
        else (Path(domain_hints_manual_env) if domain_hints_manual_env else sibling_overlay_path(domain_hints_path))
    )
    if not domain_hints_manual_path.is_absolute():
        domain_hints_manual_path = ROOT / domain_hints_manual_path

    ensure_seed_file(manual_path, scaffold_manual_metadata(payload, db_id))
    ensure_seed_file(domain_hints_path, scaffold_domain_hints(payload, db_id))
    ensure_seed_file(domain_hints_manual_path, scaffold_manual_domain_hints(payload, db_id))

    db_meta = payload["databases"][db_id]
    print(f"[OK] Metadata saved: {output_path}")
    print(f"     tables={len(db_meta.get('tables', {}))}, relationships={len(db_meta.get('relationships', []))}")
    print(f"[OK] Manual metadata scaffold: {manual_path}")
    print(f"[OK] Domain hints seed: {domain_hints_path}")
    print(f"[OK] Manual domain hints scaffold: {domain_hints_manual_path}")

    adapter.close()


if __name__ == "__main__":
    main()
