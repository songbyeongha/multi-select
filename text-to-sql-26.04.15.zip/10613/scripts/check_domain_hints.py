#!/usr/bin/env python3
"""도메인 힌트 진단 도구.

현재 keyword_map / few_shot_examples / common_patterns 상태를 출력하고,
--question 옵션 시 실제 파이프라인과 동일한 로직으로 매칭 결과를 시뮬레이션한다.

사용법:
  python scripts/check_domain_hints.py --db-id oracle_prod
  python scripts/check_domain_hints.py --db-id oracle_prod -q "이번 달 공장별 생산량은?"
  python scripts/check_domain_hints.py --db-id oracle_prod --show-all
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def _fmt_status(path: Path) -> str:
    if path.exists():
        return f"✓  ({path.stat().st_size:,} bytes)"
    return "✗  (없음)"


def _header(title: str) -> None:
    print(f"\n[{title}]")


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="check_domain_hints.py",
        description="도메인 힌트 상태 확인 + 질문 매칭 시뮬레이션",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "예시:\n"
            "  python scripts/check_domain_hints.py --db-id oracle_prod\n"
            "  python scripts/check_domain_hints.py --db-id oracle_prod -q \"이번 달 생산량은?\"\n"
            "  python scripts/check_domain_hints.py --db-id oracle_prod --show-all\n"
        ),
    )
    parser.add_argument("--db-id", required=True, help="데이터베이스 ID")
    parser.add_argument("--question", "-q", default="", help="시뮬레이션할 질문")
    parser.add_argument(
        "--show-all",
        action="store_true",
        help="keyword_map / relation_bonus_map / few_shots / patterns 전체 목록 출력",
    )
    args = parser.parse_args()

    from text2sql.agents._utils import PATTERN_TO_KEYS, get_reference_sql
    from text2sql.agents.generation_nodes import _pick_seed_few_shot, _select_few_shots
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        sibling_overlay_path,
    )
    from text2sql.config.settings import get_settings
    from text2sql.rag.schema_rag import SchemaSelector

    settings = get_settings()
    db_id = args.db_id

    # ── 파일 경로 확인 ────────────────────────────────────────────
    hints_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    primary_path = (
        Path(hints_env)
        if hints_env
        else default_domain_hints_path(
            ROOT / "src" / "text2sql" / "config", settings.db.dialect
        )
    )
    if not primary_path.is_absolute():
        primary_path = ROOT / primary_path
    manual_path = sibling_overlay_path(primary_path)

    print("\n" + "═" * 64)
    print(f"  도메인 힌트 진단 — {db_id}")
    print("═" * 64)

    _header("파일 상태")
    print(f"  Primary : {primary_path.name:<46} {_fmt_status(primary_path)}")
    print(f"  Manual  : {manual_path.name:<46} {_fmt_status(manual_path)}")

    # ── 병합 hints 로드 ───────────────────────────────────────────
    hints = settings.domain_hints(db_id)
    if not hints:
        print(
            f"\n[경고] domain_hints 로드 결과가 비어 있습니다.\n"
            f"       'run_ops.py prepare --db-id {db_id}' 를 먼저 실행하세요."
        )
        return 1

    kw_map: dict = hints.get("keyword_map", {})
    rel_bonus: dict = hints.get("relation_bonus_map", {})
    few_shots: list = hints.get("few_shot_examples", [])
    patterns: dict = hints.get("common_patterns", {})

    # ── 현재 상태 요약 ────────────────────────────────────────────
    _header("현재 상태")
    print(f"  keyword_map        : {len(kw_map):>5,}개 키워드 매핑")
    print(f"  relation_bonus_map : {len(rel_bonus):>5,}개 테이블 관계")
    print(f"  few_shot_examples  : {len(few_shots):>5,}개 예제")
    print(f"  common_patterns    : {len(patterns):>5,}개 패턴")

    # ── 권장사항 ──────────────────────────────────────────────────
    warns = []
    if not kw_map:
        warns.append("keyword_map 비어 있음 → 'prepare' 재실행 또는 _manual.json 편집")
    if not few_shots:
        warns.append("few_shot_examples 없음 → 'prepare --catalog <파일>' 또는 _manual.json 편집")
    elif len(few_shots) < 5:
        warns.append(f"few_shot_examples {len(few_shots)}개 (5개 이상 권장)")
    if not patterns:
        warns.append("common_patterns 없음 → 'maintain' 실행 또는 _manual.json 에 fb_ 키로 추가")
    if warns:
        _header("권장사항")
        for w in warns:
            print(f"  ⚠  {w}")

    # ── --show-all ────────────────────────────────────────────────
    if args.show_all:
        _header(f"keyword_map 전체 ({len(kw_map)}개)")
        for tok, tables in sorted(kw_map.items()):
            print(f"  '{tok}' → {', '.join(tables)}")

        if rel_bonus:
            _header(f"relation_bonus_map 전체 ({len(rel_bonus)}개)")
            for tbl, related in sorted(rel_bonus.items()):
                print(f"  {tbl} → {', '.join(related)}")

        if few_shots:
            _header(f"few_shot_examples 전체 ({len(few_shots)}개)")
            for i, fs in enumerate(few_shots, 1):
                q = fs.get("question", "")
                sql_first = fs.get("sql", "").split("\n")[0][:80]
                print(f"  [{i:2d}] Q  : {q}")
                print(f"       SQL: {sql_first}...")

        if patterns:
            _header(f"common_patterns 전체 ({len(patterns)}개)")
            for key, sql in sorted(patterns.items()):
                sql_preview = sql[:80].replace("\n", " ") + ("..." if len(sql) > 80 else "")
                print(f"  [{key}]")
                print(f"       {sql_preview}")

    # ── 질문 시뮬레이션 ───────────────────────────────────────────
    if not args.question:
        if not args.show_all:
            print(
                "\n[팁] '--question \"질문\"' 옵션으로 keyword 매칭 시뮬레이션을 실행하세요."
            )
        return 0

    print("\n" + "─" * 64)
    print(f'  질문 시뮬레이션: "{args.question}"')
    print("─" * 64)

    # SchemaSelector의 실제 토크나이저 사용
    selector = SchemaSelector(keyword_map=kw_map, relation_bonus=rel_bonus)
    qtoks = set(selector._tok(args.question))

    # ── 1. keyword_map 매칭 ───────────────────────────────────────
    _header("1. keyword_map 매칭")
    kw_hits: dict[str, list[str]] = {}
    for tok in qtoks:
        if tok in kw_map:
            for tbl in kw_map[tok]:
                kw_hits.setdefault(tbl, []).append(tok)

    if kw_hits:
        for tbl, toks in sorted(kw_hits.items()):
            bonus = len(toks) * 2.0
            print(f"  '{', '.join(sorted(toks))}' → {tbl}  (BM25 보너스 +{bonus:.1f}점)")
    else:
        print("  매칭된 키워드 없음")
        print(f"  질문 토큰: {sorted(qtoks)}")
        if kw_map:
            sample = list(kw_map.keys())[:12]
            print(f"  keyword_map 등록 토큰 샘플: {sample}")

    # ── 2. relation_bonus 효과 ────────────────────────────────────
    _header("2. relation_bonus_map 효과")
    if kw_hits and rel_bonus:
        rel_hits: dict[str, list[str]] = {}
        for matched_tbl in kw_hits:
            # 대소문자 무관 비교
            for key in [matched_tbl, matched_tbl.upper(), matched_tbl.lower()]:
                for rel_tbl in rel_bonus.get(key, []):
                    if rel_tbl not in kw_hits:  # 이미 직접 매칭된 테이블 제외
                        rel_hits.setdefault(rel_tbl, []).append(matched_tbl)
        if rel_hits:
            for rel_tbl, from_tbls in sorted(rel_hits.items()):
                print(f"  {rel_tbl}  (+0.5점, {', '.join(from_tbls)} 매칭으로 인해 부스트)")
        else:
            print("  연관 테이블 없음 (매칭 테이블의 relation 없음)")
    else:
        print("  적용 없음 (keyword 매칭 없거나 relation_bonus_map 미등록)")

    # ── 3. few_shot_examples ──────────────────────────────────────
    _header("3. few_shot_examples 매칭")
    if few_shots:
        seed, exact = _pick_seed_few_shot(args.question, few_shots)
        if exact:
            print("  ★ EXACT MATCH — LLM 생성 스킵, 즉시 반환")
            print(f"    Q  : {seed['question']}")
            print(f"    SQL: {seed.get('sql', '')[:100].replace(chr(10), ' ')}...")
        elif seed:
            print("  ≈ FUZZY MATCH — seed 후보 주입 + LLM 생성 병행")
            print(f"    Q  : {seed['question']}")
            print(f"    SQL: {seed.get('sql', '')[:100].replace(chr(10), ' ')}...")
        else:
            print("  매칭 없음 (토큰 겹침 4개 미만 — LLM만으로 생성)")

        top5 = _select_few_shots(args.question, few_shots, limit=5)
        if top5:
            print(f"\n  LLM 프롬프트에 전달될 상위 {len(top5)}개 예제:")
            for i, fs in enumerate(top5, 1):
                q = fs.get("question", "")
                sql_first = fs.get("sql", "").split("\n")[0][:70]
                print(f"    [{i}] Q  : {q}")
                print(f"         SQL: {sql_first}...")
    else:
        print("  등록된 예제 없음 → 'prepare --catalog <파일>' 또는 _manual.json 편집")

    # ── 4. common_patterns ────────────────────────────────────────
    _header("4. common_patterns (query_pattern별 가용 패턴)")
    if patterns:
        found_any = False
        for qp in PATTERN_TO_KEYS:
            ref = get_reference_sql(db_id, qp)
            if ref != "없음":
                found_any = True
                print(f"  [{qp}]")
                for line in ref.split("\n")[:4]:
                    print(f"    {line}")
        if not found_any:
            fb_keys = [k for k in patterns if k.startswith("fb_")]
            if fb_keys:
                print(f"  fb_ 패턴 {len(fb_keys)}개 등록됨:")
                for k in sorted(fb_keys)[:10]:
                    sql_preview = patterns[k][:60].replace("\n", " ")
                    print(f"    [{k}] {sql_preview}")
            else:
                print("  fb_ 패턴 없음 → 'maintain' 실행 또는 _manual.json 에 fb_<pattern>_<이름> 키로 추가")
    else:
        print("  common_patterns 없음")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
