#!/usr/bin/env python3
"""Enrich metadata and domain hints from an existing SQL corpus."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def parse_args():
    parser = argparse.ArgumentParser(description="Enrich metadata from SQL corpus")
    parser.add_argument("--db-id", default="", help="Database ID")
    parser.add_argument("--catalog", action="append", default=[], help="JSON/JSONL/SQL catalog file with question+sql entries")
    parser.add_argument("--sql-glob", action="append", default=[], help="Glob pattern for .sql files relative to project root")
    parser.add_argument("--metadata-output", default="", help="Manual metadata overlay output path")
    parser.add_argument("--domain-hints-output", default="", help="Manual domain hints overlay output path")
    parser.add_argument("--dialect", default="", help="sqlglot dialect")
    parser.add_argument("--min-relation-support", type=int, default=1, help="Minimum SQL evidence count for inferred relationships")
    parser.add_argument("--max-few-shots", type=int, default=40, help="Maximum number of few-shot examples to keep")
    parser.add_argument("--skip-fill-descriptions", action="store_true", help="Do not auto-fill missing descriptions")
    parser.add_argument("--report", default="logs/sql_metadata_enrichment_report.json", help="Report output path")
    return parser.parse_args()


def main():
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
    )
    from text2sql.config.settings import get_settings
    from text2sql.tools.sql_metadata_enricher import (
        enrich_metadata_from_queries,
        get_overlay_entry,
        load_query_artifacts,
        update_overlay_file,
    )

    args = parse_args()
    settings = get_settings()
    db_id = args.db_id or settings.db.db_id or "oracle_db"
    dialect = args.dialect or settings.db.dialect

    metadata_primary = (
        Path(settings.db.metadata_path)
        if settings.db.metadata_path
        else default_metadata_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    metadata_output = Path(args.metadata_output) if args.metadata_output else (
        Path(settings.db.manual_metadata_path) if settings.db.manual_metadata_path else sibling_overlay_path(metadata_primary)
    )
    if not metadata_output.is_absolute():
        metadata_output = ROOT / metadata_output

    hints_primary_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    hints_primary = (
        Path(hints_primary_env)
        if hints_primary_env
        else default_domain_hints_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    hints_output = Path(args.domain_hints_output) if args.domain_hints_output else (
        Path(os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip())
        if os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
        else sibling_overlay_path(hints_primary)
    )
    if not hints_output.is_absolute():
        hints_output = ROOT / hints_output

    artifacts = load_query_artifacts(catalog_paths=args.catalog, sql_globs=args.sql_glob, root_dir=ROOT)
    if not artifacts:
        print("[ERROR] No SQL corpus entries found. Provide --catalog or --sql-glob.")
        sys.exit(1)

    base_metadata = settings.schema_metadata(db_id)
    if not base_metadata.get("tables"):
        print(f"[ERROR] Metadata for db_id={db_id} is empty. Export metadata first.")
        sys.exit(1)

    metadata_overlay = get_overlay_entry(metadata_output, db_id)
    metadata_overlay.setdefault("name", base_metadata.get("name", db_id))
    metadata_overlay.setdefault("description", base_metadata.get("description", ""))
    metadata_overlay.setdefault("dialect", base_metadata.get("dialect", dialect))
    hints_overlay = get_overlay_entry(hints_output, db_id)

    enriched_metadata, enriched_hints, report = enrich_metadata_from_queries(
        db_id=db_id,
        artifacts=artifacts,
        base_metadata=base_metadata,
        metadata_overlay=metadata_overlay,
        domain_hints_overlay=hints_overlay,
        dialect=dialect,
        min_relation_support=max(1, args.min_relation_support),
        max_few_shots=max(1, args.max_few_shots),
        fill_missing_descriptions=not args.skip_fill_descriptions,
    )

    update_overlay_file(metadata_output, db_id=db_id, db_entry=enriched_metadata)
    update_overlay_file(hints_output, db_id=db_id, db_entry=enriched_hints)

    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_payload = {
        "db_id": db_id,
        "metadata_output": str(metadata_output),
        "domain_hints_output": str(hints_output),
        "catalogs": list(args.catalog),
        "sql_globs": list(args.sql_glob),
        "report": report.to_dict(),
    }
    report_path.write_text(json.dumps(report_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[OK] metadata overlay updated: {metadata_output}")
    print(f"[OK] domain hints overlay updated: {hints_output}")
    print(f"[OK] report saved: {report_path}")
    print(
        f"     relationships_added={report.relationships_added}, "
        f"keyword_tokens_added={report.keyword_tokens_added}, "
        f"aliases_added={report.aliases_added}, "
        f"descriptions_filled={report.descriptions_filled}"
    )


if __name__ == "__main__":
    main()
