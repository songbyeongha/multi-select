#!/usr/bin/env python3
"""Oracle production bootstrap and maintenance runner."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from dotenv import load_dotenv

load_dotenv(ROOT / ".env")


def parse_args():
    parser = argparse.ArgumentParser(description="Oracle bootstrap / maintenance")
    parser.add_argument("--cycles", type=int, default=1, help="Number of maintenance cycles")
    parser.add_argument("--samples", type=int, default=3, help="Sample value count per column")
    parser.add_argument("--db-id", default="", help="Database ID")
    parser.add_argument("--report", default="logs/oracle_ops_report.json", help="Report output path")
    parser.add_argument("--sql-catalog", action="append", default=[], help="Query catalog used to enrich metadata/domain hints")
    parser.add_argument("--sql-glob", action="append", default=[], help="Glob for SQL files used to enrich metadata/domain hints")
    parser.add_argument("--no-enrich", action="store_true", help="Skip SQL corpus enrichment")
    parser.add_argument("--no-metadata", action="store_true", help="Skip metadata export")
    parser.add_argument("--no-vector", action="store_true", help="Skip vector rebuild")
    parser.add_argument("--no-learn", action="store_true", help="Skip feedback learner")
    parser.add_argument("--no-eval", action="store_true", help="Skip evaluator")
    parser.add_argument("--fail-under-score", type=int, default=75, help="Fail when final score is below this threshold")
    return parser.parse_args()


def main():
    from text2sql.config.metadata_utils import (
        default_domain_hints_path,
        default_metadata_path,
        sibling_overlay_path,
    )
    from text2sql.config.settings import get_settings
    from text2sql.feedback.evaluator import AgentEvaluator
    from text2sql.feedback.learner import get_learner
    from text2sql.rag.vector_store import rebuild_vector_store
    from text2sql.tools.oracle_metadata import (
        ensure_seed_file,
        export_oracle_metadata_payload,
        scaffold_domain_hints,
        scaffold_manual_domain_hints,
        scaffold_manual_metadata,
        write_json,
    )
    from text2sql.tools.sql_metadata_enricher import (
        enrich_metadata_from_queries,
        get_overlay_entry,
        load_query_artifacts,
        update_overlay_file,
    )

    args = parse_args()
    settings = get_settings()
    db_cfg = settings.db

    if db_cfg.dialect != "oracle":
        print("[ERROR] T2SQL_DB_DIALECT must be set to oracle.")
        sys.exit(1)

    try:
        from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter
    except ImportError as exc:
        print(f"[ERROR] Failed to import OracleAdapter: {exc}")
        print("        Install the driver with `pip install oracledb`.")
        sys.exit(1)

    db_id = args.db_id or db_cfg.db_id or "oracle_db"
    metadata_path = (
        Path(db_cfg.metadata_path)
        if db_cfg.metadata_path
        else default_metadata_path(ROOT / "src" / "text2sql" / "config", db_cfg.dialect)
    )
    if not metadata_path.is_absolute():
        metadata_path = ROOT / metadata_path
    manual_metadata_path = (
        Path(db_cfg.manual_metadata_path)
        if db_cfg.manual_metadata_path
        else sibling_overlay_path(metadata_path)
    )
    if not manual_metadata_path.is_absolute():
        manual_metadata_path = ROOT / manual_metadata_path

    hints_primary_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    domain_hints_path = (
        Path(hints_primary_env)
        if hints_primary_env
        else default_domain_hints_path(ROOT / "src" / "text2sql" / "config", db_cfg.dialect)
    )
    if not domain_hints_path.is_absolute():
        domain_hints_path = ROOT / domain_hints_path
    hints_manual_env = os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
    domain_hints_manual_path = Path(hints_manual_env) if hints_manual_env else sibling_overlay_path(domain_hints_path)
    if not domain_hints_manual_path.is_absolute():
        domain_hints_manual_path = ROOT / domain_hints_manual_path

    adapter = OracleAdapter(
        host=db_cfg.host,
        port=db_cfg.port,
        service_name=db_cfg.service_name,
        dsn=db_cfg.dsn,
        user=db_cfg.user,
        password=db_cfg.password,
        schema=db_cfg.schema,
        connect_timeout_sec=db_cfg.connect_timeout_sec,
        query_timeout_ms=settings.guard.timeout_ms,
        read_only=db_cfg.read_only,
    )

    info = adapter.test_connection()
    if not info["ok"]:
        print(f"[ERROR] Oracle connection failed: {info['message']}")
        sys.exit(1)

    print(f"[OK] Oracle connection succeeded: {info['message']}")
    cycle_reports = []
    include_tables = db_cfg.include_table_list()
    exclude_tables = db_cfg.exclude_table_list()

    for cycle in range(1, max(1, args.cycles) + 1):
        print(f"\n=== Oracle Ops Cycle {cycle}/{args.cycles} ===")
        cycle_report = {"cycle": cycle}

        if not args.no_metadata:
            payload = export_oracle_metadata_payload(
                adapter,
                db_id=db_id,
                db_description=f"Oracle DB: {db_cfg.schema or db_cfg.user}@{db_cfg.host}",
                include_tables=include_tables,
                exclude_tables=exclude_tables,
                sample_limit=args.samples,
            )
            write_json(metadata_path, payload)
            ensure_seed_file(manual_metadata_path, scaffold_manual_metadata(payload, db_id))
            ensure_seed_file(domain_hints_path, scaffold_domain_hints(payload, db_id))
            ensure_seed_file(domain_hints_manual_path, scaffold_manual_domain_hints(payload, db_id))
            db_meta = payload["databases"][db_id]
            cycle_report["metadata"] = {
                "path": str(metadata_path),
                "table_count": len(db_meta.get("tables", {})),
                "relationship_count": len(db_meta.get("relationships", [])),
            }
            print(
                "[OK] metadata sync completed: "
                f"tables={cycle_report['metadata']['table_count']}, "
                f"relationships={cycle_report['metadata']['relationship_count']}"
            )

        if not args.no_enrich and (args.sql_catalog or args.sql_glob):
            base_metadata = settings.schema_metadata(db_id)
            metadata_overlay = get_overlay_entry(manual_metadata_path, db_id)
            domain_hints_overlay = get_overlay_entry(domain_hints_manual_path, db_id)
            artifacts = load_query_artifacts(
                catalog_paths=args.sql_catalog,
                sql_globs=args.sql_glob,
                root_dir=ROOT,
            )
            enriched_metadata, enriched_hints, enrich_report = enrich_metadata_from_queries(
                db_id=db_id,
                artifacts=artifacts,
                base_metadata=base_metadata,
                metadata_overlay=metadata_overlay,
                domain_hints_overlay=domain_hints_overlay,
                dialect=settings.db.dialect,
            )
            update_overlay_file(manual_metadata_path, db_id=db_id, db_entry=enriched_metadata)
            update_overlay_file(domain_hints_manual_path, db_id=db_id, db_entry=enriched_hints)
            cycle_report["enrichment"] = enrich_report.to_dict()
            print(
                "[OK] SQL corpus enrichment completed: "
                f"relationships={enrich_report.relationships_added}, "
                f"keywords={enrich_report.keyword_tokens_added}"
            )

        if not args.no_vector:
            try:
                rebuild_vector_store(db_id)
                cycle_report["vector"] = {"rebuilt": True}
                print("[OK] vector index rebuild completed")
            except Exception as exc:
                cycle_report["vector"] = {
                    "rebuilt": False,
                    "fallback": "bm25",
                    "error": str(exc),
                }
                print(f"[WARN] vector rebuild skipped, BM25-only fallback remains active: {exc}")

        if not args.no_learn:
            learn_result = get_learner().learn(db_id)
            cycle_report["learn"] = learn_result
            print(f"[OK] learner completed: {learn_result}")

        if not args.no_eval:
            evaluation = AgentEvaluator().evaluate(db_id, cycle_index=cycle)
            cycle_report["evaluation"] = evaluation
            print(f"[OK] evaluator score={evaluation['score']} attention={evaluation['needs_attention']}")
            if cycle >= 10 and evaluation["needs_attention"]:
                print("[WARN] cycle 10+ health score is still below target.")
                for rec in evaluation["recommendations"]:
                    print(f"  - {rec}")

        cycle_reports.append(cycle_report)

    adapter.close()

    report = {
        "db_id": db_id,
        "cycles": cycle_reports,
        "final_score": cycle_reports[-1].get("evaluation", {}).get("score") if cycle_reports else None,
    }
    report_path = ROOT / args.report
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[OK] report saved: {report_path}")

    final_score = report.get("final_score")
    if final_score is not None and final_score < args.fail_under_score:
        sys.exit(2)


if __name__ == "__main__":
    main()
