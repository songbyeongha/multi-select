#!/usr/bin/env python3
"""Seed a large synthetic manufacturing schema into Oracle."""
from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
load_dotenv(ROOT / ".env")


def _configure_stdio() -> None:
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        reconfigure = getattr(stream, "reconfigure", None)
        if callable(reconfigure):
            try:
                reconfigure(encoding="utf-8")
            except Exception:
                pass


_configure_stdio()


@dataclass(frozen=True)
class ScaleConfig:
    plants: int
    products: int
    customers: int
    employees: int
    sales_orders: int
    production_orders: int
    inventory_transactions: int
    maintenance_orders: int


SCALE_PRESETS = {
    "small": ScaleConfig(6, 120, 180, 320, 3000, 6000, 20000, 1500),
    "medium": ScaleConfig(10, 240, 500, 750, 9000, 18000, 70000, 3500),
    "large": ScaleConfig(12, 420, 900, 1400, 18000, 36000, 160000, 7000),
}


DROP_ORDER = [
    "maintenance_work_orders",
    "shipments",
    "inventory_transactions",
    "inventory_balances",
    "quality_results",
    "machine_events",
    "production_orders",
    "sales_order_lines",
    "sales_orders",
    "shift_calendar",
    "employees",
    "customers",
    "products",
    "work_centers",
    "warehouses",
    "plants",
]


DDL = [
    "CREATE TABLE plants (plant_id NUMBER PRIMARY KEY, plant_code VARCHAR2(20) UNIQUE NOT NULL, plant_name VARCHAR2(100) NOT NULL, region_name VARCHAR2(40) NOT NULL, opened_date DATE NOT NULL)",
    "CREATE TABLE warehouses (warehouse_id NUMBER PRIMARY KEY, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), warehouse_code VARCHAR2(20) UNIQUE NOT NULL, warehouse_type VARCHAR2(20) NOT NULL)",
    "CREATE TABLE work_centers (center_id NUMBER PRIMARY KEY, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), center_code VARCHAR2(30) UNIQUE NOT NULL, process_type VARCHAR2(20) NOT NULL, status VARCHAR2(20) NOT NULL, hourly_capacity NUMBER(10,2) NOT NULL)",
    "CREATE TABLE products (product_id NUMBER PRIMARY KEY, sku VARCHAR2(30) UNIQUE NOT NULL, product_name VARCHAR2(120) NOT NULL, product_family VARCHAR2(40) NOT NULL, unit_price NUMBER(12,2) NOT NULL, target_cycle_sec NUMBER(10,2) NOT NULL, launch_date DATE NOT NULL)",
    "CREATE TABLE customers (customer_id NUMBER PRIMARY KEY, customer_code VARCHAR2(20) UNIQUE NOT NULL, customer_name VARCHAR2(120) NOT NULL, industry_name VARCHAR2(40) NOT NULL, region_name VARCHAR2(40) NOT NULL, service_level VARCHAR2(10) NOT NULL)",
    "CREATE TABLE employees (employee_id NUMBER PRIMARY KEY, employee_no VARCHAR2(20) UNIQUE NOT NULL, employee_name VARCHAR2(80) NOT NULL, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), center_id NUMBER REFERENCES work_centers(center_id), role_name VARCHAR2(30) NOT NULL, hire_date DATE NOT NULL)",
    "CREATE TABLE shift_calendar (shift_id NUMBER PRIMARY KEY, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), shift_date DATE NOT NULL, shift_code VARCHAR2(10) NOT NULL, planned_minutes NUMBER NOT NULL, actual_minutes NUMBER NOT NULL, UNIQUE (plant_id, shift_date, shift_code))",
    "CREATE TABLE sales_orders (sales_order_id NUMBER PRIMARY KEY, order_no VARCHAR2(30) UNIQUE NOT NULL, customer_id NUMBER NOT NULL REFERENCES customers(customer_id), plant_id NUMBER NOT NULL REFERENCES plants(plant_id), order_status VARCHAR2(20) NOT NULL, priority_code VARCHAR2(10) NOT NULL, order_date DATE NOT NULL, promised_date DATE NOT NULL)",
    "CREATE TABLE sales_order_lines (sales_order_line_id NUMBER PRIMARY KEY, sales_order_id NUMBER NOT NULL REFERENCES sales_orders(sales_order_id), line_no NUMBER NOT NULL, product_id NUMBER NOT NULL REFERENCES products(product_id), ordered_qty NUMBER(12,2) NOT NULL, unit_price NUMBER(12,2) NOT NULL, line_status VARCHAR2(20) NOT NULL, UNIQUE (sales_order_id, line_no))",
    "CREATE TABLE production_orders (production_order_id NUMBER PRIMARY KEY, production_order_no VARCHAR2(30) UNIQUE NOT NULL, sales_order_line_id NUMBER REFERENCES sales_order_lines(sales_order_line_id), plant_id NUMBER NOT NULL REFERENCES plants(plant_id), center_id NUMBER NOT NULL REFERENCES work_centers(center_id), product_id NUMBER NOT NULL REFERENCES products(product_id), shift_id NUMBER REFERENCES shift_calendar(shift_id), planned_qty NUMBER(12,2) NOT NULL, completed_qty NUMBER(12,2) NOT NULL, scrap_qty NUMBER(12,2) NOT NULL, order_status VARCHAR2(20) NOT NULL, priority_code VARCHAR2(10) NOT NULL, plan_start_ts TIMESTAMP NOT NULL, actual_end_ts TIMESTAMP, due_date DATE NOT NULL)",
    "CREATE TABLE machine_events (event_id NUMBER PRIMARY KEY, production_order_id NUMBER REFERENCES production_orders(production_order_id), center_id NUMBER NOT NULL REFERENCES work_centers(center_id), shift_id NUMBER REFERENCES shift_calendar(shift_id), event_type VARCHAR2(20) NOT NULL, reason_code VARCHAR2(40), duration_minutes NUMBER(10,2) NOT NULL, event_start_ts TIMESTAMP NOT NULL, event_end_ts TIMESTAMP NOT NULL)",
    "CREATE TABLE quality_results (inspection_id NUMBER PRIMARY KEY, production_order_id NUMBER NOT NULL REFERENCES production_orders(production_order_id), product_id NUMBER NOT NULL REFERENCES products(product_id), shift_id NUMBER REFERENCES shift_calendar(shift_id), defect_type VARCHAR2(40) NOT NULL, inspected_qty NUMBER(12,2) NOT NULL, defect_qty NUMBER(12,2) NOT NULL, disposition_code VARCHAR2(20) NOT NULL, inspection_ts TIMESTAMP NOT NULL)",
    "CREATE TABLE inventory_balances (inventory_id NUMBER PRIMARY KEY, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), warehouse_id NUMBER NOT NULL REFERENCES warehouses(warehouse_id), product_id NUMBER NOT NULL REFERENCES products(product_id), on_hand_qty NUMBER(12,2) NOT NULL, safety_stock_qty NUMBER(12,2) NOT NULL, in_transit_qty NUMBER(12,2) NOT NULL, reserved_qty NUMBER(12,2) NOT NULL, last_count_date DATE NOT NULL, UNIQUE (warehouse_id, product_id))",
    "CREATE TABLE inventory_transactions (transaction_id NUMBER PRIMARY KEY, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), warehouse_id NUMBER NOT NULL REFERENCES warehouses(warehouse_id), product_id NUMBER NOT NULL REFERENCES products(product_id), production_order_id NUMBER REFERENCES production_orders(production_order_id), sales_order_line_id NUMBER REFERENCES sales_order_lines(sales_order_line_id), transaction_type VARCHAR2(20) NOT NULL, quantity NUMBER(12,2) NOT NULL, balance_after NUMBER(12,2) NOT NULL, transaction_ts TIMESTAMP NOT NULL)",
    "CREATE TABLE shipments (shipment_id NUMBER PRIMARY KEY, shipment_no VARCHAR2(30) UNIQUE NOT NULL, sales_order_id NUMBER NOT NULL REFERENCES sales_orders(sales_order_id), customer_id NUMBER NOT NULL REFERENCES customers(customer_id), plant_id NUMBER NOT NULL REFERENCES plants(plant_id), warehouse_id NUMBER NOT NULL REFERENCES warehouses(warehouse_id), shipped_date DATE NOT NULL, delivery_date DATE, shipment_status VARCHAR2(20) NOT NULL, shipped_qty NUMBER(12,2) NOT NULL)",
    "CREATE TABLE maintenance_work_orders (maintenance_id NUMBER PRIMARY KEY, maintenance_no VARCHAR2(30) UNIQUE NOT NULL, plant_id NUMBER NOT NULL REFERENCES plants(plant_id), center_id NUMBER NOT NULL REFERENCES work_centers(center_id), maintenance_type VARCHAR2(20) NOT NULL, priority_code VARCHAR2(10) NOT NULL, work_status VARCHAR2(20) NOT NULL, requested_ts TIMESTAMP NOT NULL, completed_ts TIMESTAMP, downtime_minutes NUMBER(10,2) NOT NULL)",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Setup large Oracle manufacturing schema")
    parser.add_argument("--admin-user", default="", help="Privileged Oracle account")
    parser.add_argument("--admin-password", default="", help="Privileged Oracle password")
    parser.add_argument("--service-name", default="", help="Oracle service name")
    parser.add_argument("--host", default="", help="Oracle host")
    parser.add_argument("--port", type=int, default=0, help="Oracle port")
    parser.add_argument("--schema-user", default="MFGOPS", help="Schema user")
    parser.add_argument("--schema-password", default="MfgOps123!", help="Schema password")
    parser.add_argument("--drop-existing", action="store_true", help="Drop and recreate schema user")
    parser.add_argument("--schema-only", action="store_true", help="Rebuild objects inside existing schema")
    parser.add_argument("--scale", choices=sorted(SCALE_PRESETS.keys()), default="large", help="Seed volume preset")
    return parser.parse_args()


def _admin_bootstrap(*, oracledb, admin_user: str, admin_password: str, host: str, port: int, service_name: str, schema_user: str, schema_password: str, drop_existing: bool) -> bool:
    admin_conn = oracledb.connect(user=admin_user, password=admin_password, dsn=oracledb.makedsn(host, port, service_name=service_name))
    admin_cur = admin_conn.cursor()
    try:
        if drop_existing:
            try:
                admin_cur.execute(f"DROP USER {schema_user} CASCADE")
                admin_conn.commit()
            except Exception:
                pass
        admin_cur.execute("SELECT COUNT(*) FROM ALL_USERS WHERE USERNAME = :u", {"u": schema_user})
        exists = admin_cur.fetchone()[0] > 0
        if not exists:
            admin_cur.execute(f"CREATE USER {schema_user} IDENTIFIED BY \"{schema_password}\"")
            admin_cur.execute(f"GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE SEQUENCE TO {schema_user}")
            admin_cur.execute(f"ALTER USER {schema_user} QUOTA UNLIMITED ON USERS")
            admin_conn.commit()
        return True
    finally:
        admin_cur.close()
        admin_conn.close()


def _drop_existing_objects(cur) -> None:
    for table_name in DROP_ORDER:
        try:
            cur.execute(f"DROP TABLE {table_name} CASCADE CONSTRAINTS PURGE")
        except Exception:
            pass


def _seed_sql(cfg: ScaleConfig) -> list[str]:
    return [
        f"INSERT INTO plants SELECT LEVEL, 'PLT' || LPAD(LEVEL, 3, '0'), 'Plant ' || LPAD(LEVEL, 3, '0'), CASE MOD(LEVEL, 6) WHEN 0 THEN 'Korea' WHEN 1 THEN 'Vietnam' WHEN 2 THEN 'China' WHEN 3 THEN 'USA' WHEN 4 THEN 'India' ELSE 'Poland' END, DATE '2016-01-01' + MOD(LEVEL * 37, 2500) FROM dual CONNECT BY LEVEL <= {cfg.plants}",
        "INSERT INTO warehouses SELECT (p.plant_id - 1) * 3 + w.seq, p.plant_id, 'WH' || LPAD(p.plant_id, 2, '0') || LPAD(w.seq, 2, '0'), CASE w.seq WHEN 1 THEN 'FG' WHEN 2 THEN 'RM' ELSE 'WIP' END FROM plants p CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 3) w",
        "INSERT INTO work_centers SELECT (p.plant_id - 1) * 8 + wc.seq, p.plant_id, 'WC' || LPAD(p.plant_id, 2, '0') || LPAD(wc.seq, 2, '0'), CASE MOD(wc.seq, 8) WHEN 1 THEN 'CUT' WHEN 2 THEN 'ASM' WHEN 3 THEN 'PAINT' WHEN 4 THEN 'TEST' WHEN 5 THEN 'PACK' WHEN 6 THEN 'WELD' WHEN 7 THEN 'MOLD' ELSE 'CAL' END, CASE MOD(wc.seq, 7) WHEN 0 THEN 'DOWN' ELSE 'RUN' END, 60 + wc.seq * 8 FROM plants p CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 8) wc",
        f"INSERT INTO products SELECT LEVEL, 'SKU' || LPAD(LEVEL, 5, '0'), 'Product ' || LPAD(LEVEL, 5, '0'), CASE MOD(LEVEL, 7) WHEN 0 THEN 'Motor' WHEN 1 THEN 'Drive' WHEN 2 THEN 'Controller' WHEN 3 THEN 'Sensor' WHEN 4 THEN 'HMI' WHEN 5 THEN 'Battery' ELSE 'Accessory' END, ROUND(40 + MOD(LEVEL * 17, 900) / 3, 2), 18 + MOD(LEVEL, 14) * 7, DATE '2021-01-01' + MOD(LEVEL, 1200) FROM dual CONNECT BY LEVEL <= {cfg.products}",
        f"INSERT INTO customers SELECT LEVEL, 'CUST' || LPAD(LEVEL, 5, '0'), 'Customer ' || LPAD(LEVEL, 5, '0'), CASE MOD(LEVEL, 6) WHEN 0 THEN 'Automotive' WHEN 1 THEN 'Battery' WHEN 2 THEN 'Robotics' WHEN 3 THEN 'Electronics' WHEN 4 THEN 'Industrial' ELSE 'Medical' END, CASE MOD(LEVEL, 7) WHEN 0 THEN 'Korea' WHEN 1 THEN 'Japan' WHEN 2 THEN 'China' WHEN 3 THEN 'USA' WHEN 4 THEN 'Germany' WHEN 5 THEN 'India' ELSE 'Vietnam' END, CASE MOD(LEVEL, 5) WHEN 0 THEN 'A' WHEN 1 THEN 'A' WHEN 2 THEN 'B' WHEN 3 THEN 'B' ELSE 'C' END FROM dual CONNECT BY LEVEL <= {cfg.customers}",
        f"INSERT INTO employees SELECT LEVEL, 'EMP' || LPAD(LEVEL, 6, '0'), 'Employee ' || LPAD(LEVEL, 6, '0'), MOD(LEVEL - 1, {cfg.plants}) + 1, CASE WHEN MOD(LEVEL, 5) = 0 THEN NULL ELSE MOD(LEVEL - 1, {cfg.plants} * 8) + 1 END, CASE MOD(LEVEL, 6) WHEN 0 THEN 'Operator' WHEN 1 THEN 'Planner' WHEN 2 THEN 'Inspector' WHEN 3 THEN 'Technician' WHEN 4 THEN 'Supervisor' ELSE 'Sales' END, DATE '2017-01-01' + MOD(LEVEL * 11, 2200) FROM dual CONNECT BY LEVEL <= {cfg.employees}",
        f"INSERT INTO shift_calendar SELECT (p.plant_id - 1) * {365 * 3} + (d.day_no - 1) * 3 + s.seq, p.plant_id, DATE '2025-01-01' + d.day_no - 1, CASE s.seq WHEN 1 THEN 'D1' WHEN 2 THEN 'E1' ELSE 'N1' END, 480, 420 + MOD((d.day_no * s.seq + p.plant_id), 61) FROM plants p CROSS JOIN (SELECT LEVEL day_no FROM dual CONNECT BY LEVEL <= 365) d CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 3) s",
        f"INSERT INTO sales_orders SELECT LEVEL, 'SO' || LPAD(LEVEL, 7, '0'), MOD(LEVEL - 1, {cfg.customers}) + 1, MOD(LEVEL - 1, {cfg.plants}) + 1, CASE MOD(LEVEL, 6) WHEN 0 THEN 'CLOSED' WHEN 1 THEN 'OPEN' WHEN 2 THEN 'OPEN' WHEN 3 THEN 'ALLOCATED' WHEN 4 THEN 'RELEASED' ELSE 'OPEN' END, CASE MOD(LEVEL, 4) WHEN 0 THEN 'LOW' WHEN 1 THEN 'MED' WHEN 2 THEN 'HIGH' ELSE 'HIGH' END, DATE '2025-01-01' + MOD(LEVEL, 365), DATE '2025-01-01' + MOD(LEVEL, 365) + 7 + MOD(LEVEL, 21) FROM dual CONNECT BY LEVEL <= {cfg.sales_orders}",
        f"INSERT INTO sales_order_lines SELECT (so.sales_order_id - 1) * 3 + l.seq, so.sales_order_id, l.seq, MOD((so.sales_order_id * 7 + l.seq), {cfg.products}) + 1, 20 + MOD(so.sales_order_id * l.seq, 400), ROUND(40 + MOD((so.sales_order_id * 11 + l.seq * 19), 900) / 3, 2), CASE MOD(so.sales_order_id, 6) WHEN 0 THEN 'CLOSED' ELSE 'OPEN' END FROM sales_orders so CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 3) l",
        f"INSERT INTO production_orders SELECT LEVEL, 'MO' || LPAD(LEVEL, 8, '0'), MOD(LEVEL - 1, {cfg.sales_orders * 3}) + 1, MOD(LEVEL - 1, {cfg.plants}) + 1, MOD(LEVEL - 1, {cfg.plants} * 8) + 1, MOD(LEVEL * 5, {cfg.products}) + 1, MOD(LEVEL * 3, {cfg.plants * 365 * 3}) + 1, 50 + MOD(LEVEL, 420), ROUND((50 + MOD(LEVEL, 420)) * (0.78 + MOD(LEVEL, 15) * 0.01), 2), ROUND(MOD(LEVEL, 17) * 0.8, 2), CASE MOD(LEVEL, 6) WHEN 0 THEN 'PLANNED' WHEN 1 THEN 'RELEASED' WHEN 2 THEN 'IN_PROGRESS' WHEN 3 THEN 'IN_PROGRESS' WHEN 4 THEN 'COMPLETED' ELSE 'DELAYED' END, CASE MOD(LEVEL, 4) WHEN 0 THEN 'LOW' WHEN 1 THEN 'MED' WHEN 2 THEN 'HIGH' ELSE 'HIGH' END, TO_TIMESTAMP('2025-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(LEVEL * 13, 'MINUTE'), TO_TIMESTAMP('2025-01-01 10:00:00', 'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(LEVEL * 17, 'MINUTE'), DATE '2025-01-10' + MOD(LEVEL, 40) FROM dual CONNECT BY LEVEL <= {cfg.production_orders}",
        f"INSERT INTO machine_events SELECT (po.production_order_id - 1) * 4 + e.seq, po.production_order_id, po.center_id, po.shift_id, CASE MOD(e.seq, 4) WHEN 0 THEN 'SETUP' WHEN 1 THEN 'RUN' WHEN 2 THEN 'RUN' ELSE 'DOWNTIME' END, CASE MOD(po.production_order_id + e.seq, 5) WHEN 0 THEN 'MATERIAL_WAIT' WHEN 1 THEN 'NORMAL' WHEN 2 THEN 'CHANGEOVER' WHEN 3 THEN 'QUALITY_HOLD' ELSE 'MAINT' END, 10 + MOD(po.production_order_id * e.seq, 120), po.plan_start_ts + NUMTODSINTERVAL((e.seq - 1) * 60, 'MINUTE'), po.plan_start_ts + NUMTODSINTERVAL((e.seq - 1) * 60 + 10 + MOD(po.production_order_id * e.seq, 120), 'MINUTE') FROM production_orders po CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 4) e",
        f"INSERT INTO quality_results SELECT (po.production_order_id - 1) * 2 + q.seq, po.production_order_id, po.product_id, po.shift_id, CASE MOD(po.production_order_id + q.seq, 6) WHEN 0 THEN 'COSMETIC' WHEN 1 THEN 'ALIGNMENT' WHEN 2 THEN 'SOLDER' WHEN 3 THEN 'FUNCTION' WHEN 4 THEN 'LABEL' ELSE 'LEAKAGE' END, 30 + MOD(po.production_order_id * q.seq, 220), ROUND(MOD(po.production_order_id + q.seq, 11) * 0.7, 2), CASE MOD(po.production_order_id + q.seq, 4) WHEN 0 THEN 'REWORK' WHEN 1 THEN 'REWORK' WHEN 2 THEN 'USE_AS_IS' ELSE 'SCRAP' END, po.plan_start_ts + NUMTODSINTERVAL(q.seq * 45, 'MINUTE') FROM production_orders po CROSS JOIN (SELECT LEVEL seq FROM dual CONNECT BY LEVEL <= 2) q",
        f"INSERT INTO inventory_balances SELECT (w.warehouse_id - 1) * {cfg.products} + p.product_id, w.plant_id, w.warehouse_id, p.product_id, 80 + MOD(w.warehouse_id * p.product_id, 900), 40 + MOD(w.warehouse_id * p.product_id, 240), MOD(w.warehouse_id * p.product_id, 140), MOD(w.warehouse_id * p.product_id, 110), DATE '2025-03-31' FROM warehouses w CROSS JOIN products p",
        f"INSERT INTO inventory_transactions SELECT LEVEL, MOD(LEVEL - 1, {cfg.plants}) + 1, MOD(LEVEL - 1, {cfg.plants * 3}) + 1, MOD(LEVEL * 7, {cfg.products}) + 1, CASE WHEN MOD(LEVEL, 5) = 0 THEN NULL ELSE MOD(LEVEL, {cfg.production_orders}) + 1 END, CASE WHEN MOD(LEVEL, 4) = 0 THEN MOD(LEVEL, {cfg.sales_orders * 3}) + 1 ELSE NULL END, CASE MOD(LEVEL, 5) WHEN 0 THEN 'RECEIPT' WHEN 1 THEN 'ISSUE' WHEN 2 THEN 'MOVE' WHEN 3 THEN 'ADJUST' ELSE 'SHIP' END, CASE WHEN MOD(LEVEL, 5) IN (1, 4) THEN -(5 + MOD(LEVEL, 90)) ELSE 5 + MOD(LEVEL, 90) END, 100 + MOD(LEVEL * 11, 1000), TO_TIMESTAMP('2025-01-01 00:00:00', 'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(LEVEL * 5, 'MINUTE') FROM dual CONNECT BY LEVEL <= {cfg.inventory_transactions}",
        f"INSERT INTO shipments SELECT LEVEL, 'SHP' || LPAD(LEVEL, 8, '0'), LEVEL, MOD(LEVEL - 1, {cfg.customers}) + 1, MOD(LEVEL - 1, {cfg.plants}) + 1, MOD(LEVEL - 1, {cfg.plants * 3}) + 1, DATE '2025-01-06' + MOD(LEVEL, 365), DATE '2025-01-08' + MOD(LEVEL, 365), CASE MOD(LEVEL, 4) WHEN 0 THEN 'IN_TRANSIT' WHEN 1 THEN 'DELIVERED' WHEN 2 THEN 'DELIVERED' ELSE 'CLOSED' END, 20 + MOD(LEVEL, 520) FROM dual CONNECT BY LEVEL <= {cfg.sales_orders - cfg.sales_orders // 5}",
        f"INSERT INTO maintenance_work_orders SELECT LEVEL, 'MWO' || LPAD(LEVEL, 8, '0'), MOD(LEVEL - 1, {cfg.plants}) + 1, MOD(LEVEL - 1, {cfg.plants * 8}) + 1, CASE MOD(LEVEL, 4) WHEN 0 THEN 'PM' WHEN 1 THEN 'CM' WHEN 2 THEN 'PREDICTIVE' ELSE 'CALIBRATION' END, CASE MOD(LEVEL, 4) WHEN 0 THEN 'LOW' WHEN 1 THEN 'MED' WHEN 2 THEN 'HIGH' ELSE 'HIGH' END, CASE MOD(LEVEL, 5) WHEN 0 THEN 'OPEN' WHEN 1 THEN 'OPEN' WHEN 2 THEN 'DONE' WHEN 3 THEN 'DONE' ELSE 'IN_PROGRESS' END, TO_TIMESTAMP('2025-01-01 06:00:00', 'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(LEVEL * 23, 'MINUTE'), TO_TIMESTAMP('2025-01-01 07:00:00', 'YYYY-MM-DD HH24:MI:SS') + NUMTODSINTERVAL(LEVEL * 23 + 45 + MOD(LEVEL, 720), 'MINUTE'), MOD(LEVEL, 240) FROM dual CONNECT BY LEVEL <= {cfg.maintenance_orders}",
    ]


def main() -> None:
    import oracledb
    from text2sql.config.settings import get_settings

    args = parse_args()
    cfg = SCALE_PRESETS[args.scale]
    settings = get_settings()
    db_cfg = settings.db

    admin_user = args.admin_user or db_cfg.user
    admin_password = args.admin_password or db_cfg.password
    host = args.host or db_cfg.host
    port = args.port or db_cfg.port
    service_name = args.service_name or db_cfg.service_name
    schema_user = args.schema_user.upper()
    schema_password = args.schema_password
    used_admin_bootstrap = False

    if not args.schema_only:
        try:
            used_admin_bootstrap = _admin_bootstrap(
                oracledb=oracledb,
                admin_user=admin_user,
                admin_password=admin_password,
                host=host,
                port=port,
                service_name=service_name,
                schema_user=schema_user,
                schema_password=schema_password,
                drop_existing=args.drop_existing,
            )
        except Exception as exc:
            if admin_user.upper() != schema_user:
                print("[ERROR] Failed to prepare schema with admin credentials.")
                print(f"        reason={exc}")
                sys.exit(1)
            print("[WARN] Admin bootstrap unavailable. Falling back to schema-only rebuild.")
            print(f"       reason={exc}")

    schema_conn = oracledb.connect(
        user=schema_user,
        password=schema_password,
        dsn=oracledb.makedsn(host, port, service_name=service_name),
    )
    cur = schema_conn.cursor()
    _drop_existing_objects(cur)
    for sql in DDL:
        cur.execute(sql)
    for sql in _seed_sql(cfg):
        cur.execute(sql)
        schema_conn.commit()

    cur.execute("SELECT COUNT(*) FROM production_orders")
    production_orders = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM machine_events")
    machine_events = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM inventory_transactions")
    inventory_transactions = cur.fetchone()[0]

    cur.close()
    schema_conn.close()

    print(f"[OK] Manufacturing seed completed: schema={schema_user}")
    print(f"     bootstrap_mode={'admin' if used_admin_bootstrap else 'schema-only'}")
    print(f"     scale={args.scale}")
    print(f"     production_orders={production_orders}")
    print(f"     machine_events={machine_events}")
    print(f"     inventory_transactions={inventory_transactions}")
    print("     Recommended runtime values:")
    print(f"       T2SQL_DB_USER={schema_user}")
    print(f"       T2SQL_DB_PASSWORD={schema_password}")
    print(f"       T2SQL_DB_SCHEMA={schema_user}")
    print("       T2SQL_DB_ID=oracle_prod_local")


if __name__ == "__main__":
    main()
