# Text-to-SQL Assistant

Oracle 운영 DB를 처음 연결해 Text-to-SQL을 실행하는 상황을 기준으로 정리한 패키지입니다. 이 폴더는 압축 파일로 전달해 바로 테스트할 수 있게 최소 구성만 남겨 두었습니다.

## 환경 설정

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

## 공개 진입점

- `app.py`
- `scripts/run_cli.py`
- `scripts/run_ops.py`

## 가장 먼저 할 일

1. [docs/START_HERE.md](docs/START_HERE.md)를 읽습니다.
2. `.env`를 운영 DB 정보로 수정합니다.
3. 아래 명령으로 첫 연결을 시작합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

## 첫 운영 DB 연결 권장 순서

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "안전재고보다 현재고가 낮은 품목과 공장을 보여줘"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

**쿼리 카탈로그** (`{ question, expected_sql }` 쌍 JSON)가 있으면 메타데이터 강화 + E2E 회귀 테스트까지 한 번에 실행됩니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id> --catalog data/catalog.json --run-e2e
```

카탈로그 형식과 예시는 [`data/catalog.example.json`](data/catalog.example.json)을 참고하세요.

## 배포 패키지에 남긴 것

- 실행 코드: `app.py`, `scripts/`, `src/`
- 운영 문서: `docs/`
- 환경 설정: `.env`
- 설치 정보: `requirements.txt`
- 선택 자산: `data/catalog.json` (업무 쿼리 카탈로그) 또는 운영 SQL 모음

## 문서 시작점

- [docs/START_HERE.md](docs/START_HERE.md)
- [docs/operations/FIRST_PRODUCTION_ATTACH.md](docs/operations/FIRST_PRODUCTION_ATTACH.md)
- [docs/operations/OPERATOR_ONE_PAGE.md](docs/operations/OPERATOR_ONE_PAGE.md)
- [docs/operations/ENDPOINT_USAGE_GUIDE.md](docs/operations/ENDPOINT_USAGE_GUIDE.md)

## generated 설정 폴더
- `src/text2sql/config/generated/`는 최초 배포 시 비어 있어도 됩니다.
- first-run 또는 prepare 실행 시 metadata/domain hints/manual overlay 파일이 여기에 생성됩니다.
- 운영 DB를 바꾸거나 초기화할 때는 이 폴더만 백업·삭제·이동하면 됩니다.
- 설명은 [`src/text2sql/config/generated/README.md`](src/text2sql/config/generated/README.md)에 정리했습니다.
