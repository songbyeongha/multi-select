"""
AutoScorer — 파이프라인 실행 결과에서 자동으로 피드백 점수를 산출
================================================================
사용자가 직접 피드백하지 않아도, 파이프라인 결과 신호를 분석하여
자동 피드백을 생성한다. 사용자 피드백이 들어오면 자동 피드백은 덮어씌워진다.

점수 산출 기준:
  ┌───────────────────────────────────────────────────────┐
  │ 신호                            │ 자동 점수          │
  ├───────────────────────────────────────────────────────┤
  │ 성공 + Judge 승인 + repair 0회  │ 5 (매우 좋음)      │
  │ 성공 + Judge 승인 + repair 1회  │ 4 (좋음)           │
  │ 성공 + Judge 승인 + repair 2+회 │ 3 (보통)           │
  │ 성공 + Judge 거부 후 재시도 성공 │ 3 (보통)           │
  │ 실행 실패 (오류 발생)            │ 2 (나쁨)           │
  │ SAFE_FAIL (재시도 소진)          │ 1 (매우 나쁨)      │
  └───────────────────────────────────────────────────────┘
"""
from __future__ import annotations

from typing import Any, Dict

from .store import FeedbackRecord, FeedbackScore


def compute_auto_score(state: Dict[str, Any]) -> int:
    """파이프라인 최종 state에서 자동 피드백 점수를 산출한다."""
    success = state.get("success", False)
    repair_count = state.get("repair_count", 0)
    judge_accepted = state.get("judge_accepted", False)
    error = state.get("error", "")

    if not success:
        if "최대 재시도" in str(error) or "SAFE_FAIL" in str(error):
            return FeedbackScore.VERY_BAD
        return FeedbackScore.BAD

    if judge_accepted and repair_count == 0:
        return FeedbackScore.VERY_GOOD
    if judge_accepted and repair_count == 1:
        return FeedbackScore.GOOD
    return FeedbackScore.NORMAL


def build_auto_comment(state: Dict[str, Any], score: int) -> str:
    """자동 점수에 대한 근거 코멘트를 생성한다."""
    repair_count = state.get("repair_count", 0)
    judge_accepted = state.get("judge_accepted", False)
    error = state.get("error", "")
    exec_report = state.get("exec_report")
    row_count = 0
    exec_ms = 0.0
    if exec_report:
        if hasattr(exec_report, "row_count"):
            row_count = exec_report.row_count or 0
        if hasattr(exec_report, "exec_ms"):
            exec_ms = exec_report.exec_ms or 0.0

    parts = []

    if score == FeedbackScore.VERY_GOOD:
        parts.append("1회 실행으로 Judge 승인")
    elif score == FeedbackScore.GOOD:
        parts.append(f"repair {repair_count}회 후 성공")
    elif score == FeedbackScore.NORMAL:
        parts.append(f"repair {repair_count}회 후 성공 (개선 여지 있음)")
    elif score == FeedbackScore.BAD:
        parts.append("실행 실패")
        if error:
            parts.append(str(error)[:80])
    elif score == FeedbackScore.VERY_BAD:
        parts.append("SAFE_FAIL (재시도 소진)")
        if error:
            parts.append(str(error)[:80])

    if row_count > 0:
        parts.append(f"{row_count}행 반환")
    if exec_ms > 0:
        parts.append(f"{exec_ms:.0f}ms")

    return " | ".join(parts)


def build_auto_feedback(state: Dict[str, Any]) -> FeedbackRecord:
    """파이프라인 결과 state에서 자동 FeedbackRecord를 생성한다."""
    score = compute_auto_score(state)
    comment = build_auto_comment(state, score)

    exec_report = state.get("exec_report")
    row_count = 0
    exec_ms = 0.0
    if exec_report:
        if hasattr(exec_report, "row_count"):
            row_count = exec_report.row_count or 0
        if hasattr(exec_report, "exec_ms"):
            exec_ms = exec_report.exec_ms or 0.0

    return FeedbackRecord(
        question=state.get("question", ""),
        sql=state.get("final_sql", "") or state.get("selected_sql", ""),
        database_id=state.get("database_id", ""),
        score=score,
        score_label=f"[자동] {FeedbackScore(score).label_ko}",
        user_comment=f"[자동 피드백] {comment}",
        query_pattern=state.get("query_pattern", ""),
        row_count=row_count,
        exec_ms=exec_ms,
        dialect=state.get("dialect", "oracle"),
        tables_used=state.get("selected_tables", []),
        is_auto=True,
    )
