"""Evaluate agent health from metadata, readiness, and feedback history."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..config.settings import Settings, get_settings
from .store import FeedbackStore, get_feedback_store


@dataclass
class AgentEvaluator:
    settings: Settings | None = None
    store: FeedbackStore | None = None

    def __post_init__(self) -> None:
        if self.settings is None:
            self.settings = get_settings()
        if self.store is None:
            self.store = get_feedback_store()

    def evaluate(self, db_id: str, *, cycle_index: int = 1) -> Dict[str, Any]:
        metadata = self.settings.schema_metadata(db_id)
        hints = self.settings.domain_hints(db_id)
        feedback = self.store.by_db(db_id)

        metadata_metrics = self._metadata_metrics(metadata)
        feedback_metrics = self._feedback_metrics(feedback)
        readiness = self._readiness_metrics(hints)
        score = self._score(metadata_metrics, feedback_metrics, readiness)
        recommendations = self._recommend(metadata_metrics, feedback_metrics, readiness)

        return {
            "db_id": db_id,
            "cycle_index": cycle_index,
            "score": score,
            "needs_attention": cycle_index >= 10 and score < 80,
            "metadata": metadata_metrics,
            "feedback": feedback_metrics,
            "readiness": readiness,
            "recommendations": recommendations,
        }

    @staticmethod
    def _metadata_metrics(metadata: Dict[str, Any]) -> Dict[str, Any]:
        tables = metadata.get("tables", {}) or {}
        relationships = metadata.get("relationships", []) or []

        table_count = len(tables)
        described_tables = 0
        total_columns = 0
        described_columns = 0
        sampled_columns = 0
        alias_tables = 0

        for _, table_meta in tables.items():
            if table_meta.get("description"):
                described_tables += 1
            aliases = table_meta.get("aliases") or table_meta.get("table_aliases") or []
            if aliases:
                alias_tables += 1
            sample_values = table_meta.get("sample_values", {}) or {}
            sampled_names: set[str] = set()
            for column_name, column_meta in (table_meta.get("columns") or {}).items():
                total_columns += 1
                if not isinstance(column_meta, dict):
                    continue
                if column_meta.get("description"):
                    described_columns += 1
                if column_meta.get("sample_values"):
                    sampled_names.add(column_name)
            for column_name, values in sample_values.items():
                if values:
                    sampled_names.add(column_name)
            sampled_columns += len(sampled_names)

        def _pct(part: int, whole: int) -> float:
            return round((min(part, whole) / whole) * 100, 1) if whole else 0.0

        return {
            "table_count": table_count,
            "relationship_count": len(relationships),
            "table_description_coverage": _pct(described_tables, table_count),
            "column_description_coverage": _pct(described_columns, total_columns),
            "sample_coverage": _pct(sampled_columns, total_columns),
            "alias_coverage": _pct(alias_tables, table_count),
        }

    @staticmethod
    def _feedback_metrics(records: List[Any]) -> Dict[str, Any]:
        if not records:
            return {
                "count": 0,
                "avg_score": 0.0,
                "recent_avg_score": 0.0,
                "positive_rate": 0.0,
                "auto_feedback_rate": 0.0,
                "bad_rate": 0.0,
            }

        scores = [int(r.score) for r in records]
        recent = scores[-20:]
        auto_count = len([r for r in records if AgentEvaluator._is_auto_feedback(r)])
        positive = len([s for s in scores if s >= 4])
        bad = len([s for s in scores if s <= 2])

        return {
            "count": len(records),
            "avg_score": round(sum(scores) / len(scores), 2),
            "recent_avg_score": round(sum(recent) / len(recent), 2),
            "positive_rate": round((positive / len(records)) * 100, 1),
            "auto_feedback_rate": round((auto_count / len(records)) * 100, 1),
            "bad_rate": round((bad / len(records)) * 100, 1),
        }

    @staticmethod
    def _readiness_metrics(hints: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "keyword_count": len(hints.get("keyword_map", {}) or {}),
            "relation_bonus_count": len(hints.get("relation_bonus_map", {}) or {}),
            "few_shot_count": len(hints.get("few_shot_examples", []) or []),
            "common_pattern_count": len(hints.get("common_patterns", {}) or {}),
        }

    @staticmethod
    def _score(metadata: Dict[str, Any], feedback: Dict[str, Any], readiness: Dict[str, Any]) -> int:
        score = 0.0
        score += min(metadata.get("table_description_coverage", 0.0), 100.0) * 0.20
        score += min(metadata.get("column_description_coverage", 0.0), 100.0) * 0.20
        score += min(metadata.get("sample_coverage", 0.0), 100.0) * 0.10
        score += min(metadata.get("alias_coverage", 0.0), 100.0) * 0.05
        score += min((feedback.get("recent_avg_score", 0.0) / 5.0) * 100.0, 100.0) * 0.25
        score += min(feedback.get("positive_rate", 0.0), 100.0) * 0.10
        score += min(readiness.get("few_shot_count", 0) * 5.0, 100.0) * 0.05
        score += min(readiness.get("keyword_count", 0) * 2.0, 100.0) * 0.05
        return round(score)

    @staticmethod
    def _recommend(metadata: Dict[str, Any], feedback: Dict[str, Any], readiness: Dict[str, Any]) -> List[str]:
        recommendations: List[str] = []

        if metadata.get("table_description_coverage", 0.0) < 80:
            recommendations.append("Raise table description coverage above 80%.")
        if metadata.get("column_description_coverage", 0.0) < 70:
            recommendations.append("Raise column description coverage so schema selection and repair stay grounded.")
        if metadata.get("sample_coverage", 0.0) < 40:
            recommendations.append("Collect more sample values for filter columns.")
        if metadata.get("relationship_count", 0) == 0:
            recommendations.append("Add FK or inferred relationship metadata so join planning is reliable.")
        if feedback.get("count", 0) < 10:
            recommendations.append("Collect more validated feedback examples from realistic business scenarios.")
        if feedback.get("recent_avg_score", 0.0) < 3.8 and feedback.get("count", 0) > 0:
            recommendations.append("Promote failed cases into few-shot and negative guidance to reduce repeat errors.")
        if readiness.get("few_shot_count", 0) < 5:
            recommendations.append("Accumulate at least five validated success few-shot examples.")
        if readiness.get("keyword_count", 0) < 10:
            recommendations.append("Expand keyword_map with business synonyms to improve recall.")

        return recommendations

    @staticmethod
    def _is_auto_feedback(record: Any) -> bool:
        label = str(getattr(record, "score_label", "") or "").strip().lower()
        comment = str(getattr(record, "user_comment", "") or "").strip().lower()
        return (
            label.startswith("[auto]")
            or comment.startswith("[auto")
            or "먮룞" in label
            or "먮룞" in comment
        )
