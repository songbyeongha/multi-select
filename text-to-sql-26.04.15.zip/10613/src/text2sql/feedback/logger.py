"""
FeedbackLogger — 자동 개선 과정을 사람이 읽을 수 있는 로그로 기록
================================================================
두 가지 출력:
  1. data/feedback/learn_log.jsonl  — 구조화된 이벤트 로그 (파싱 가능)
  2. data/feedback/learn_log.txt    — 사람이 읽는 텍스트 로그
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

_LOG_DIR = Path(__file__).resolve().parents[3] / "data" / "feedback"


class FeedbackLogger:
    """자동 개선 이벤트를 구조화된 JSONL + 읽기 쉬운 텍스트로 동시 기록."""

    def __init__(self, log_dir: Path | str | None = None):
        self._dir = Path(log_dir) if log_dir else _LOG_DIR
        self._dir.mkdir(parents=True, exist_ok=True)
        self._jsonl = self._dir / "learn_log.jsonl"
        self._txt = self._dir / "learn_log.txt"

    def log_feedback_received(self, question: str, sql: str, db_id: str,
                              score: int, score_label: str, comment: str = ""):
        self._write(
            event="FEEDBACK_RECEIVED",
            message=f"[{score_label}] ({score}/5) Q: {question[:60]}",
            data={
                "question": question,
                "sql": sql[:200],
                "db_id": db_id,
                "score": score,
                "score_label": score_label,
                "comment": comment,
            },
        )

    def log_few_shot_promoted(self, db_id: str, question: str, sql: str):
        self._write(
            event="FEW_SHOT_PROMOTED",
            message=f"few_shot 자동 등록: Q: {question[:60]}",
            data={
                "db_id": db_id,
                "question": question,
                "sql": sql[:300],
                "action": "configured domain hints > few_shot_examples 에 추가됨",
            },
        )

    def log_keyword_expanded(self, db_id: str, keyword: str, tables: list):
        self._write(
            event="KEYWORD_EXPANDED",
            message=f"keyword_map 확장: '{keyword}' -> {tables}",
            data={
                "db_id": db_id,
                "keyword": keyword,
                "tables": tables,
                "action": "configured domain hints > keyword_map 에 추가/확장됨",
            },
        )

    def log_pattern_promoted(self, db_id: str, query_pattern: str,
                             pattern_key: str, question: str):
        self._write(
            event="PATTERN_PROMOTED",
            message=f"common_pattern 자동 등록: [{query_pattern}] {pattern_key}",
            data={
                "db_id": db_id,
                "query_pattern": query_pattern,
                "pattern_key": pattern_key,
                "question": question,
                "action": "configured domain hints > common_patterns 에 참고 SQL 추가됨",
            },
        )

    def log_pattern_replaced(self, db_id: str, query_pattern: str,
                             pattern_key: str, old_score: int, new_score: int,
                             question: str):
        self._write(
            event="PATTERN_REPLACED",
            message=(
                f"common_pattern 교체: [{query_pattern}] "
                f"{old_score}점 -> {new_score}점"
            ),
            data={
                "db_id": db_id,
                "query_pattern": query_pattern,
                "pattern_key": pattern_key,
                "old_score": old_score,
                "new_score": new_score,
                "question": question,
                "action": (
                    f"더 좋은 SQL이 발견되어 기존 패턴을 교체함 "
                    f"({old_score}/5 -> {new_score}/5)"
                ),
            },
        )

    def log_error_pattern_recorded(self, db_id: str, question: str,
                                   score_label: str, comment: str):
        self._write(
            event="ERROR_PATTERN_RECORDED",
            message=f"오류 패턴 기록: [{score_label}] Q: {question[:60]} -- {comment[:40]}",
            data={
                "db_id": db_id,
                "question": question,
                "score_label": score_label,
                "comment": comment,
                "action": "다음 유사 질문 시 프롬프트에 주의사항 자동 주입",
            },
        )

    def log_hint_injected(self, db_id: str, question: str, hint_type: str, hint_preview: str):
        self._write(
            event="HINT_INJECTED",
            message=f"프롬프트에 {hint_type} 힌트 주입: Q: {question[:60]}",
            data={
                "db_id": db_id,
                "question": question,
                "hint_type": hint_type,
                "hint_preview": hint_preview[:200],
                "action": "CandidateGenerator 프롬프트에 피드백 기반 힌트가 추가됨",
            },
        )

    def log_learn_summary(self, db_id: str, result: Dict[str, int]):
        parts = []
        if result.get("few_shots_added", 0) > 0:
            parts.append(f"few_shot +{result['few_shots_added']}")
        if result.get("keywords_added", 0) > 0:
            parts.append(f"keyword +{result['keywords_added']}")
        if result.get("errors_logged", 0) > 0:
            parts.append(f"error_pattern +{result['errors_logged']}")
        if not parts:
            return
        self._write(
            event="LEARN_COMPLETE",
            message=f"자동 학습 완료: {', '.join(parts)}",
            data={"db_id": db_id, **result},
        )

    def read_recent(self, n: int = 20) -> List[Dict[str, Any]]:
        """최근 n개 이벤트를 읽어 반환한다."""
        if not self._jsonl.exists():
            return []
        lines = self._jsonl.read_text(encoding="utf-8").strip().split("\n")
        events = []
        for line in lines[-n:]:
            if line.strip():
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
        return events

    def read_text(self, n: int = 30) -> str:
        """최근 n줄 텍스트 로그를 읽어 반환한다."""
        if not self._txt.exists():
            return "(아직 기록 없음)"
        lines = self._txt.read_text(encoding="utf-8").strip().split("\n")
        return "\n".join(lines[-n:])

    def _write(self, event: str, message: str, data: Dict[str, Any]):
        ts = datetime.now()
        ts_str = ts.strftime("%Y-%m-%d %H:%M:%S")

        jsonl_entry = {
            "timestamp": ts.isoformat(),
            "event": event,
            "message": message,
            **data,
        }
        with open(self._jsonl, "a", encoding="utf-8") as f:
            f.write(json.dumps(jsonl_entry, ensure_ascii=False) + "\n")

        txt_line = f"[{ts_str}] {event:.<30s} {message}"
        with open(self._txt, "a", encoding="utf-8") as f:
            f.write(txt_line + "\n")


_inst: Optional[FeedbackLogger] = None


def get_feedback_logger() -> FeedbackLogger:
    global _inst
    if _inst is None:
        _inst = FeedbackLogger()
    return _inst
