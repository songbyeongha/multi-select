"""Global Streamlit page shell and styling."""
from __future__ import annotations

import streamlit as st


def render_app_shell() -> None:
    """Configure the page and render the shared app header."""
    st.set_page_config(
        page_title="Text-to-SQL Assistant",
        page_icon="⚡",
        layout="wide",
    )
    st.markdown(
        """
<style>
.hero { text-align:center; padding:1.2rem 0 .6rem; }
.hero h1 {
  font-size:2.2rem; font-weight:800;
  background:linear-gradient(135deg,#4F46E5,#7C3AED,#EC4899);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; margin:0;
}
.hero p { color:#6B7280; font-size:1rem; margin:.3rem 0 0; }
.trace-node {
  display:inline-block; padding:.15rem .55rem; border-radius:6px;
  font-size:.78rem; font-weight:600; margin-right:.4rem;
}
.tn-decomposer { background:#EEF2FF; color:#4338CA; }
.tn-valueretriever { background:#FEF3C7; color:#92400E; }
.tn-schemaselector { background:#D1FAE5; color:#065F46; }
.tn-joinplanner { background:#DBEAFE; color:#1E40AF; }
.tn-candidategenerator { background:#FDE68A; color:#78350F; }
.tn-guardrails { background:#FEE2E2; color:#991B1B; }
.tn-sqlunittester { background:#E0E7FF; color:#3730A3; }
.tn-executepreview { background:#CCFBF1; color:#065F46; }
.tn-judge { background:#F3E8FF; color:#6B21A8; }
.tn-repair { background:#FFF7ED; color:#9A3412; }
.tn-resultsummarizer { background:#ECFDF5; color:#047857; }
.tn-safe_fail { background:#FEE2E2; color:#991B1B; }
.tn-memorysave { background:#ECFDF5; color:#047857; }
.date-support {
  background:#F0FDF4; border:1px solid #86EFAC; border-radius:8px;
  padding:.6rem; font-size:.8rem; color:#166534;
}
</style>
        """,
        unsafe_allow_html=True,
    )
    st.markdown(
        """
<div class="hero">
  <h1>⚡ Text-to-SQL Assistant</h1>
</div>
        """,
        unsafe_allow_html=True,
    )


def render_footer(settings) -> None:
    """Render the shared footer."""
    st.divider()
    st.caption(
        "Text-to-SQL Assistant v1.0"
        f"  |  {settings.current_provider()} / {settings.current_model()}"
        f"  |  dialect: {settings.current_dialect()}"
    )

