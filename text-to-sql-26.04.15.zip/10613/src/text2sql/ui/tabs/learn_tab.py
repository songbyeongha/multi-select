"""Learning log and feedback analytics tab."""
from __future__ import annotations

import pandas as pd
import streamlit as st


def render_learn_tab() -> None:
    """Render the automatic learning and feedback log view."""
    from text2sql.feedback import get_feedback_logger, get_feedback_store

    st.markdown("#### 🧠 자동 개선 학습 로그")
    st.caption("사용자 피드백이 시스템을 어떻게 개선하는지 실시간으로 확인할 수 있습니다.")

    feedback_store = get_feedback_store()
    feedback_logger = get_feedback_logger()
    feedback_stats = feedback_store.stats()

    if feedback_stats["total"] > 0:
        st.markdown("##### 📊 피드백 통계")
        metric1, metric2, metric3, metric4 = st.columns(4)
        with metric1:
            st.metric("총 피드백", f"{feedback_stats['total']}건")
        with metric2:
            st.metric("평균 점수", f"{feedback_stats['avg_score']}/5")
        with metric3:
            st.metric("긍정률", f"{feedback_stats['positive_rate']}%")
        with metric4:
            st.metric("학습된 few_shot", len([record for record in feedback_store.all() if record.promoted_to_few_shot]))

        st.markdown("##### 점수 분포")
        score_icons = {
            "매우 좋음": "🤩",
            "좋음": "😊",
            "보통": "😐",
            "나쁨": "😞",
            "매우 나쁨": "😡",
        }
        for column, (label, count) in zip(st.columns(5), feedback_stats["distribution"].items()):
            with column:
                st.metric(f"{score_icons.get(label, '')} {label}", f"{count}건")

        st.divider()

    st.markdown("##### 📋 학습 이벤트 로그")
    learn_events = feedback_logger.read_recent(30)
    if learn_events:
        event_icons = {
            "FEEDBACK_RECEIVED": "📝",
            "FEW_SHOT_PROMOTED": "✨",
            "KEYWORD_EXPANDED": "📚",
            "PATTERN_PROMOTED": "🏆",
            "PATTERN_REPLACED": "🔄",
            "ERROR_PATTERN_RECORDED": "🔍",
            "HINT_INJECTED": "💡",
            "LEARN_COMPLETE": "🎓",
        }
        for event in reversed(learn_events):
            timestamp = event.get("timestamp", "")[:19].replace("T", " ")
            event_type = event.get("event", "")
            icon = event_icons.get(event_type, "📌")
            message = event.get("message", "")
            with st.expander(f"{icon} [{timestamp}] {message}", expanded=False):
                action = event.get("action", "")
                if action:
                    st.info(f"동작: {action}")
                if event.get("question"):
                    st.caption(f"질문: {event['question']}")
                if event.get("sql"):
                    st.code(event["sql"][:300], language="sql")
                if event.get("score"):
                    st.caption(f"점수: {event.get('score_label', '')} ({event['score']}/5)")
                if event.get("comment"):
                    st.caption(f"코멘트: {event['comment']}")
                if event.get("keyword"):
                    st.caption(f"키워드: {event['keyword']} → {event.get('tables', [])}")
                if event.get("hint_type"):
                    st.caption(f"힌트 유형: {event['hint_type']}")
                if event.get("hint_preview"):
                    st.code(event["hint_preview"], language="text")
    else:
        st.caption("아직 학습 이벤트가 없습니다. 질문 실행 후 피드백을 남겨보세요!")

    with st.expander("📄 텍스트 로그 원문 (최근 30줄)", expanded=False):
        st.code(feedback_logger.read_text(30), language="text")

    with st.expander(f"📑 피드백 전체 목록 ({feedback_store.count()}건)", expanded=False):
        all_feedback = feedback_store.all()
        if all_feedback:
            frame = pd.DataFrame(
                [
                    {
                        "시각": record.timestamp[:19],
                        "점수": f"{record.score_label} ({record.score}/5)",
                        "질문": record.question[:50],
                        "DB": record.database_id,
                        "few_shot": "✅" if record.promoted_to_few_shot else "",
                        "코멘트": record.user_comment[:30] if record.user_comment else "",
                    }
                    for record in reversed(all_feedback)
                ]
            )
            st.dataframe(frame, use_container_width=True, hide_index=True)
