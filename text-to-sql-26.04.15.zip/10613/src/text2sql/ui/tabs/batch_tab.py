"""Batch query execution tab."""
from __future__ import annotations

import time
from typing import Any

import streamlit as st

from ..context import AppContext, append_history_entry, get_db_path
from ..pipeline import run_phase1_generate, run_phase2_execute
from ..renderers import clean_summary, format_sql


def _build_batch_result(index: int, question: str, *, result=None, elapsed: float = 0.0, error: str = "") -> dict[str, Any]:
    token_usage = result.get("token_usage") if result else None
    models_used = ", ".join(token_usage.get("by_model", {}).keys()) if token_usage else ""
    return {
        "번호": index + 1,
        "질문": question,
        "상태": "오류" if error and result is None else ("성공" if result and result.get("success") else "실패"),
        "소요시간(초)": round(elapsed, 1),
        "Repair 횟수": result.get("repair_count", 0) if result else 0,
        "사용 모델": models_used,
        "선택 테이블": ", ".join(result.get("selected_tables", [])) if result else "",
        "SQL": result.get("final_sql", "") if result else "",
        "요약": clean_summary(result.get("result_summary", "")) if result else "",
        "토큰": token_usage.get("total_tokens", 0) if token_usage else 0,
        "비용($)": round(token_usage.get("total_cost_usd", 0), 4) if token_usage else 0,
        "오류": error or (result.get("error", "") if result else ""),
        "_success": result.get("success", False) if result else False,
        "_result": result.get("final_result") if result else None,
        "_token_usage": token_usage,
    }


def _summarize_model_cost(results: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    model_summary: dict[str, dict[str, Any]] = {}
    for item in results:
        token_usage = item.get("_token_usage")
        if not token_usage:
            continue
        for model_name, detail in token_usage.get("by_model", {}).items():
            summary = model_summary.setdefault(model_name, {"calls": 0, "tokens": 0, "cost": 0.0})
            summary["calls"] += detail.get("calls", 0)
            summary["tokens"] += detail.get("total_tokens", 0)
            summary["cost"] += detail.get("cost_usd", 0.0)
    return model_summary


def render_batch_tab(context: AppContext, *, max_retries: int, hitl_enabled: bool) -> None:
    """Render the bulk question execution workflow."""
    settings = context.settings

    st.markdown("#### 📦 대량 질의 실행")
    st.caption("여러 질문을 한 줄에 하나씩 입력하세요. 빈 줄은 무시됩니다.")

    col_bq, col_bdb = st.columns([3, 1])
    with col_bq:
        batch_text = st.text_area(
            "대량 질문 입력",
            height=200,
            placeholder="올해 가장 많이 팔린 앨범은?\n장르별 트랙 수를 알려줘\n최근 한 달간 에러율이 가장 높은 서비스는?",
            label_visibility="collapsed",
        )
    with col_bdb:
        oracle_id = settings.db.db_id or "oracle"
        st.selectbox("데이터베이스", [oracle_id], disabled=True, key="batch_db_select")
        batch_db = oracle_id

    batch_questions = [question.strip() for question in batch_text.splitlines() if question.strip()]
    st.caption(f"총 **{len(batch_questions)}**개 질문 감지")

    batch_run = st.button(
        "🚀  대량 실행 시작",
        type="primary",
        use_container_width=True,
        key="batch_run",
    )

    if batch_run and batch_questions:
        batch_db_path = get_db_path(context, batch_db)

        from text2sql.lg.graph import get_compiled_graph
        from text2sql.lg.state import new_state
        from text2sql.llm.client import get_token_accumulator

        if hitl_enabled:
            phase1_results = []
            progress_bar = st.progress(0, text="SQL 생성 중...")
            for index, question in enumerate(batch_questions):
                progress_bar.progress(
                    index / len(batch_questions),
                    text=f"({index + 1}/{len(batch_questions)}) SQL 생성 중: {question[:50]}...",
                )
                initial = new_state(
                    question=question,
                    database_id=batch_db,
                    db_path=batch_db_path,
                    max_retries=max_retries,
                    hitl_enabled=True,
                )
                get_token_accumulator().reset()
                started_at = time.time()
                try:
                    state = run_phase1_generate(initial)
                    phase1_results.append(
                        {
                            "idx": index,
                            "question": question,
                            "state": state,
                            "sql": state.get("preview_sql", ""),
                            "elapsed": time.time() - started_at,
                            "has_sql": bool(state.get("preview_sql", "")),
                        }
                    )
                except Exception as exc:
                    phase1_results.append(
                        {
                            "idx": index,
                            "question": question,
                            "state": None,
                            "sql": "",
                            "elapsed": time.time() - started_at,
                            "has_sql": False,
                            "error": str(exc),
                        }
                    )

            progress_bar.progress(1.0, text="SQL 생성 완료!")
            st.session_state.batch_phase1_results = phase1_results
            st.session_state.batch_approvals = {item["idx"]: item["has_sql"] for item in phase1_results}
            st.rerun()
        else:
            graph = get_compiled_graph()
            batch_results = []
            progress_bar = st.progress(0, text="대량 질의 준비 중...")
            for index, question in enumerate(batch_questions):
                progress_bar.progress(
                    index / len(batch_questions),
                    text=f"({index + 1}/{len(batch_questions)}) 실행 중: {question[:50]}...",
                )
                initial = new_state(
                    question=question,
                    database_id=batch_db,
                    db_path=batch_db_path,
                    max_retries=max_retries,
                    hitl_enabled=False,
                )
                get_token_accumulator().reset()
                started_at = time.time()
                try:
                    result = graph.invoke(initial)
                    elapsed = time.time() - started_at
                    batch_results.append(_build_batch_result(index, question, result=result, elapsed=elapsed))
                except Exception as exc:
                    batch_results.append(_build_batch_result(index, question, elapsed=time.time() - started_at, error=str(exc)))

                last = batch_results[-1]
                append_history_entry(
                    question=question,
                    db=batch_db,
                    sql=last["SQL"],
                    success=last["_success"],
                    elapsed=last["소요시간(초)"],
                    summary=last["요약"],
                )

            progress_bar.progress(1.0, text="완료!")
            st.session_state.batch_results = batch_results
    elif batch_run:
        st.warning("질문을 입력하세요.")

    if st.session_state.get("batch_phase1_results"):
        phase1_results = st.session_state.batch_phase1_results
        approvals = st.session_state.batch_approvals

        st.divider()
        st.markdown("#### 🔍 대량 SQL 실행 전 검토")

        col_all, col_none = st.columns(2)
        with col_all:
            if st.button("전체 선택", key="batch_hitl_all"):
                for item in phase1_results:
                    if item["has_sql"]:
                        st.session_state.batch_approvals[item["idx"]] = True
                st.rerun()
        with col_none:
            if st.button("전체 해제", key="batch_hitl_none"):
                for item in phase1_results:
                    st.session_state.batch_approvals[item["idx"]] = False
                st.rerun()

        for item in phase1_results:
            if not item.get("has_sql"):
                st.error(
                    f"[{item['idx'] + 1}] {item['question'][:60]} — SQL 생성 실패"
                    f"{': ' + item.get('error', '') if item.get('error') else ''}"
                )
                continue

            approved = st.checkbox(
                f"[{item['idx'] + 1}] {item['question'][:60]}",
                value=approvals.get(item["idx"], True),
                key=f"batch_hitl_{item['idx']}",
            )
            st.session_state.batch_approvals[item["idx"]] = approved

            with st.expander(f"SQL 미리보기·수정 [{item['idx'] + 1}]", expanded=False):
                st.text_area(
                    "SQL (직접 수정 가능)",
                    value=format_sql(item["sql"]),
                    height=120,
                    key=f"batch_sql_edit_{item['idx']}",
                    label_visibility="collapsed",
                )

        approved_count = sum(1 for value in approvals.values() if value)
        st.caption(f"승인된 질의: {approved_count}/{len(phase1_results)}")

        col_exec, col_cancel = st.columns(2)
        with col_exec:
            if st.button(
                f"🚀 승인된 {approved_count}개 실행",
                type="primary",
                use_container_width=True,
                key="batch_hitl_execute",
            ):
                from text2sql.lg.state import SQLCandidate
                from text2sql.llm.client import get_token_accumulator

                batch_results = []
                approved_list = [item for item in phase1_results if approvals.get(item["idx"], False) and item.get("state")]
                progress_bar = st.progress(0, text="실행 중...")

                for index, item in enumerate(approved_list):
                    progress_bar.progress(
                        index / max(len(approved_list), 1),
                        text=f"({index + 1}/{len(approved_list)}) 실행 중: {item['question'][:50]}...",
                    )
                    exec_state = item["state"]
                    edit_key = f"batch_sql_edit_{item['idx']}"
                    edited = st.session_state.get(edit_key, "")
                    if edited and edited.strip() != item["sql"]:
                        exec_state = dict(exec_state)
                        exec_state["candidates"] = [
                            SQLCandidate(
                                sql=edited.strip(),
                                strategy="user_edited",
                                confidence=1.0,
                                rationale="사용자가 직접 수정",
                                is_valid=True,
                                ut_passed=True,
                            )
                        ]
                        exec_state["preview_sql"] = edited.strip()
                        exec_state["selected_sql"] = edited.strip()

                    get_token_accumulator().reset()
                    started_at = time.time()
                    try:
                        result = run_phase2_execute(exec_state)
                        elapsed = item["elapsed"] + (time.time() - started_at)
                        batch_results.append(_build_batch_result(item["idx"], item["question"], result=result, elapsed=elapsed))
                    except Exception as exc:
                        batch_results.append(
                            _build_batch_result(
                                item["idx"],
                                item["question"],
                                elapsed=time.time() - started_at,
                                error=str(exc),
                            )
                        )

                    last = batch_results[-1]
                    append_history_entry(
                        question=item["question"],
                        db=batch_db,
                        sql=last["SQL"],
                        success=last["_success"],
                        elapsed=last["소요시간(초)"],
                        summary=last["요약"],
                    )

                progress_bar.progress(1.0, text="완료!")
                st.session_state.batch_results = batch_results
                st.session_state.batch_phase1_results = []
                st.rerun()

        with col_cancel:
            if st.button("❌ 전체 취소", use_container_width=True, key="batch_hitl_cancel"):
                st.session_state.batch_phase1_results = []
                st.session_state.batch_approvals = {}
                st.rerun()

    if not st.session_state.get("batch_results"):
        return

    results = st.session_state.batch_results
    st.divider()

    total = len(results)
    success_count = sum(1 for item in results if item["_success"])
    fail_count = total - success_count
    total_time = sum(item["소요시간(초)"] for item in results)
    avg_time = total_time / total if total else 0.0
    total_cost = sum(item.get("비용($)", 0) for item in results)
    total_tokens = sum(item.get("토큰", 0) for item in results)
    model_summary = _summarize_model_cost(results)

    metric1, metric2, metric3 = st.columns(3)
    with metric1:
        st.metric("전체", f"{total}건")
    with metric2:
        st.metric("성공", f"{success_count}건")
    with metric3:
        st.metric("실패", f"{fail_count}건")

    metric4, metric5, metric6 = st.columns(3)
    with metric4:
        st.metric("총 소요시간", f"{total_time:.1f}s")
    with metric5:
        st.metric("평균 소요시간", f"{avg_time:.1f}s")
    with metric6:
        st.metric("총 비용", f"${total_cost:.4f}")

    metric7, metric8 = st.columns(2)
    with metric7:
        st.metric("총 토큰", f"{total_tokens:,}")
    with metric8:
        if model_summary:
            parts = [f"{name}: {detail['calls']}회 ${detail['cost']:.4f}" for name, detail in model_summary.items()]
            st.metric("모델별 비용", " | ".join(parts))
        else:
            st.metric("모델별 비용", "—")

    st.markdown("#### 📊 결과 요약 테이블")
    st.dataframe([{key: value for key, value in item.items() if not key.startswith("_")} for item in results], use_container_width=True, hide_index=True)

    if model_summary:
        with st.expander("모델별 상세 비용", expanded=False):
            rows = [
                {
                    "모델": model_name,
                    "호출 수": detail["calls"],
                    "총 토큰": f"{detail['tokens']:,}",
                    "비용($)": f"${detail['cost']:.4f}",
                }
                for model_name, detail in model_summary.items()
            ]
            st.dataframe(rows, use_container_width=True, hide_index=True)

    st.markdown("#### 📋 개별 상세 결과")
    for item in results:
        icon = "✅" if item["_success"] else "❌"
        with st.expander(f"{icon} **[{item['번호']}]** {item['질문'][:60]}  —  {item['상태']} ({item['소요시간(초)']}s)"):
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("상태", f"{icon} {item['상태']}")
            with col2:
                st.metric("소요시간", f"{item['소요시간(초)']}s")
            with col3:
                st.metric("Repair 횟수", item["Repair 횟수"])

            if item["선택 테이블"]:
                st.caption(f"**선택 테이블:** {item['선택 테이블']}")

            if item["SQL"]:
                st.markdown("**생성된 SQL:**")
                st.code(format_sql(item["SQL"]), language="sql")

            if item["_success"] and item["요약"]:
                st.markdown("**결과 요약:**")
                st.success(item["요약"])

            if item["_success"] and item["_result"]:
                st.markdown("**실행 결과:**")
                st.dataframe(item["_result"], use_container_width=True, hide_index=True)

            if item["오류"]:
                st.error(f"오류: {item['오류']}")

    if st.button("🗑️ 대량 질의 결과 초기화", key="batch_clear"):
        st.session_state.batch_results = []
        st.rerun()
