"""Execution history tab."""
from __future__ import annotations

import streamlit as st

from ..renderers import format_sql


def render_history_tab() -> None:
    """Render session-level execution history."""
    st.markdown("### 📜 실행 히스토리")
    if st.session_state.history:
        for item in reversed(st.session_state.history):
            icon = "✅" if item["success"] else "❌"
            with st.expander(f"{icon} {item['question'][:60]}"):
                st.markdown(f"**DB:** {item['db']}  |  **시간:** {item['time']:.1f}s")
                st.code(format_sql(item["sql"]), language="sql")
                if item.get("summary"):
                    st.info(item["summary"])
        if st.button("🗑️ 히스토리 초기화"):
            st.session_state.history = []
            st.rerun()
    else:
        st.caption("아직 실행 기록이 없습니다.")
