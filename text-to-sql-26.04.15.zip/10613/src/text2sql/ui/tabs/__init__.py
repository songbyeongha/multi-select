"""Tab renderers for the Streamlit app."""

from .batch_tab import render_batch_tab
from .history_tab import render_history_tab
from .learn_tab import render_learn_tab
from .main_tab import render_main_tab
from .operations_tab import render_operations_tab

__all__ = [
    "render_batch_tab",
    "render_history_tab",
    "render_learn_tab",
    "render_main_tab",
    "render_operations_tab",
]
