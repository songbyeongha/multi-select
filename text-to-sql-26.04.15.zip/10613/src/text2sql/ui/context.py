"""Shared Streamlit app context and session-state helpers."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import streamlit as st

from text2sql.config.settings import Settings, get_settings
from text2sql.tools.date_tools import get_date_tool

ORACLE_PATH = "__oracle__"
SESSION_DEFAULTS = {
    "history": [],
    "hitl_phase1_state": None,
    "hitl_phase1_elapsed": 0.0,
    "hitl_phase1_token_usage": None,
    "hitl_sql_approved": False,
    "hitl_repair_cycle": 0,
    "batch_phase1_results": [],
    "batch_approvals": {},
    "batch_results": [],
    "_hitl_question": "",
    "_hitl_db": "",
}


@dataclass(frozen=True)
class AppContext:
    settings: Settings
    db_map: dict[str, str]
    oracle_path: str
    current_ref: Any


def init_session_state() -> None:
    """Initialize Streamlit session state keys used across tabs."""
    for key, value in SESSION_DEFAULTS.items():
        if key not in st.session_state:
            if isinstance(value, list):
                st.session_state[key] = list(value)
            elif isinstance(value, dict):
                st.session_state[key] = dict(value)
            else:
                st.session_state[key] = value


def build_app_context() -> AppContext:
    """Build immutable app-level context from settings and registry state."""
    settings = get_settings()
    date_tool = get_date_tool()
    return AppContext(
        settings=settings,
        db_map={},
        oracle_path=ORACLE_PATH,
        current_ref=date_tool.reference_date,
    )


def get_db_path(context: AppContext, db_id: str) -> str:
    """Return Oracle sentinel path."""
    return context.oracle_path


def append_history_entry(
    *,
    question: str,
    db: str,
    sql: str,
    success: bool,
    elapsed: float,
    summary: str,
) -> None:
    """Persist a lightweight execution record in session history."""
    st.session_state.history.append(
        {
            "question": question,
            "db": db,
            "sql": sql,
            "success": success,
            "time": elapsed,
            "summary": summary,
        }
    )
