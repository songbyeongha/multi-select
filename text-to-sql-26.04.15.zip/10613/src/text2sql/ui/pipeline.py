"""Reusable pipeline execution helpers for the Streamlit app."""
from __future__ import annotations


def run_phase1_generate(state):
    """Phase 1: SQL generation and validation before execution."""
    from text2sql.agents.nodes import (
        node_candidate_generator,
        node_decomposer,
        node_guardrails,
        node_join_planner,
        node_repair,
        node_schema_selector,
        node_unit_tester,
        node_value_retriever,
    )

    state = node_decomposer(state)
    state = node_schema_selector(state)
    state = node_value_retriever(state)
    state = node_join_planner(state)
    state = node_candidate_generator(state)
    state = node_guardrails(state)

    if not state.get("guard_passed"):
        for _ in range(state.get("max_retries", 3)):
            state = node_repair(state)
            state = node_guardrails(state)
            if state.get("guard_passed"):
                break

    if state.get("guard_passed"):
        state = node_unit_tester(state)
        if not state.get("ut_passed"):
            for _ in range(state.get("max_retries", 3) - state.get("repair_count", 0)):
                state = node_repair(state)
                state = node_guardrails(state)
                if not state.get("guard_passed"):
                    continue
                state = node_unit_tester(state)
                if state.get("ut_passed"):
                    break

    passed = [c for c in state.get("candidates", []) if c.is_valid and c.ut_passed]
    if not passed:
        passed = [c for c in state.get("candidates", []) if c.is_valid]
    if passed:
        passed.sort(key=lambda candidate: candidate.confidence, reverse=True)
        state["preview_sql"] = passed[0].sql
        state["selected_sql"] = passed[0].sql

    return state


def run_phase2_execute(state):
    """Phase 2: execute, judge, summarize, and repair when needed."""
    from text2sql.agents.nodes import (
        node_execute_preview,
        node_guardrails,
        node_judge,
        node_repair,
        node_result_output,
        node_safe_fail,
        node_unit_tester,
    )

    state = node_execute_preview(state)
    report = state.get("exec_report")

    if report and report.ok:
        state = node_judge(state)
        if state.get("judge_accepted"):
            return node_result_output(state)

    remaining = state.get("max_retries", 3) - state.get("repair_count", 0)
    for _ in range(remaining):
        state = node_repair(state)
        if state.get("repair_count", 0) >= state.get("max_retries", 3):
            break
        state = node_guardrails(state)
        if not state.get("guard_passed"):
            continue
        state = node_unit_tester(state)
        state = node_execute_preview(state)
        report = state.get("exec_report")
        if report and report.ok:
            state = node_judge(state)
            if state.get("judge_accepted"):
                return node_result_output(state)

    return node_safe_fail(state)


def run_hitl_feedback_repair(state, user_feedback):
    """Apply user feedback and repair SQL without executing it."""
    from text2sql.agents.nodes import node_guardrails, node_repair, node_unit_tester
    from text2sql.lg.state import ErrorType

    state = dict(state)
    state["hitl_user_feedback"] = user_feedback
    state["judge_rationale"] = f"[사용자 피드백] {user_feedback}"
    state["last_error_type"] = ErrorType.SEMANTIC
    state["last_error_msg"] = user_feedback

    state = node_repair(state)
    state = node_guardrails(state)
    if state.get("guard_passed"):
        state = node_unit_tester(state)

    passed = [candidate for candidate in state.get("candidates", []) if candidate.is_valid and candidate.ut_passed]
    if not passed:
        passed = [candidate for candidate in state.get("candidates", []) if candidate.is_valid]
    if not passed:
        passed = state.get("candidates", [])
    if passed:
        passed.sort(key=lambda candidate: candidate.confidence, reverse=True)
        state["preview_sql"] = passed[0].sql
        state["selected_sql"] = passed[0].sql

    return state

