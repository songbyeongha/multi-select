"""
AuditLogger  ──  실행 이력 + 감사 로그
"""
from __future__ import annotations
import json, time, uuid
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, List


_LOG_DIR = Path(__file__).resolve().parents[3] / "logs"
_LOG_DIR.mkdir(exist_ok=True)


def log_execution(question: str, sql: str, db_id: str,
                  success: bool, result_summary: str,
                  trace: List[Dict[str, Any]] | None = None,
                  error: str | None = None):
    entry = {
        "id": str(uuid.uuid4())[:8],
        "ts": datetime.now().isoformat(),
        "question": question,
        "database": db_id,
        "sql": sql,
        "success": success,
        "summary": result_summary,
        "error": error,
        "trace_steps": len(trace) if trace else 0,
    }
    path = _LOG_DIR / f"audit_{datetime.now():%Y%m%d}.jsonl"
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    return entry["id"]
