"""Helpers for Oracle release-readiness scoring."""
from __future__ import annotations

from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List

from ..config.metadata_utils import load_json_file, payload_fingerprint

_ROOT = Path(__file__).resolve().parents[3]
_DEFAULT_MANIFEST_PATH = _ROOT / "data" / "vector_store" / "manifest.json"


def vector_index_status(
    db_id: str,
    metadata: Dict[str, Any],
    *,
    manifest_path: Path | str | None = None,
) -> Dict[str, Any]:
    path = Path(manifest_path) if manifest_path else _DEFAULT_MANIFEST_PATH
    manifest = load_json_file(path)
    entry = manifest.get(db_id, {}) if isinstance(manifest, dict) else {}
    expected = payload_fingerprint(metadata if metadata.get("tables") else {})
    indexed = isinstance(entry, dict) and bool(entry)
    fresh = indexed and entry.get("fingerprint") == expected
    return {
        "path": str(path),
        "exists": path.exists(),
        "indexed": indexed,
        "fresh": fresh,
        "table_count": int(entry.get("table_count", 0) or 0) if indexed else 0,
    }


def build_release_report(
    *,
    db_id: str,
    evaluator_report: Dict[str, Any],
    checks: Dict[str, Any],
    docs: Dict[str, bool] | None = None,
    automation: Dict[str, bool] | None = None,
    e2e_report: Dict[str, Any] | None = None,
    code_hygiene: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    docs = docs or {}
    automation = automation or {}
    code_hygiene = code_hygiene or {}
    dimensions = build_dimension_scores(
        evaluator_report=evaluator_report,
        checks=checks,
        docs=docs,
        automation=automation,
        e2e_report=e2e_report,
        code_hygiene=code_hygiene,
    )
    blockers = blocking_issues(checks, e2e_report=e2e_report, code_hygiene=code_hygiene)
    recommendations = build_recommendations(
        evaluator_report=evaluator_report,
        checks=checks,
        docs=docs,
        automation=automation,
        e2e_report=e2e_report,
        code_hygiene=code_hygiene,
        dimensions=dimensions,
    )
    return {
        "db_id": db_id,
        "dimensions": dimensions,
        "overall_score": round(mean(dimensions.values())) if dimensions else 0,
        "blocking_issues": blockers,
        "recommendations": recommendations,
    }


def build_dimension_scores(
    *,
    evaluator_report: Dict[str, Any],
    checks: Dict[str, Any],
    docs: Dict[str, bool],
    automation: Dict[str, bool],
    e2e_report: Dict[str, Any] | None,
    code_hygiene: Dict[str, Any],
) -> Dict[str, int]:
    metadata = evaluator_report.get("metadata", {})
    feedback = evaluator_report.get("feedback", {})
    readiness = evaluator_report.get("readiness", {})

    e2e_pass_rate = float((e2e_report or {}).get("pass_rate", 0.0) or 0.0)
    metadata_coverage = _avg(
        metadata.get("table_description_coverage", 0.0),
        metadata.get("column_description_coverage", 0.0),
        metadata.get("sample_coverage", 0.0),
    )
    docs_score = _avg(*(_bool_score(flag) for flag in docs.values())) if docs else 0.0
    automation_score = _avg(*(_bool_score(flag) for flag in automation.values())) if automation else 0.0
    few_shot_score = _count_score(readiness.get("few_shot_count", 0), per_unit=10)
    keyword_score = _count_score(readiness.get("keyword_count", 0), per_unit=25)
    relation_score = _count_score(metadata.get("relationship_count", 0), per_unit=10)
    feedback_score = (
        min((float(feedback.get("recent_avg_score", 0.0) or 0.0) / 5.0) * 100.0, 100.0)
        if int(feedback.get("count", 0) or 0) > 0
        else 50.0
    )
    feedback_capture = _count_score(feedback.get("count", 0), per_unit=10, floor=50.0)
    pytest_score = _bool_score(code_hygiene.get("pytest_ok", False))
    readme_score = _bool_score(docs.get("readme", False))
    dead_code_score = max(0.0, 100.0 - (float(code_hygiene.get("vulture_issues", 0) or 0.0) * 20.0))
    vector_score = _bool_score(checks.get("vector_fresh", False))

    operational_convenience = _weighted(
        (checks.get("connection_ok", False), 0.20),
        (checks.get("llm_reachable", False), 0.15),
        (checks.get("read_only", False), 0.15),
        (checks.get("metadata_present", False), 0.18),
        (checks.get("manual_metadata_present", False), 0.12),
        (checks.get("vector_fresh", False), 0.10),
        (checks.get("schema_is_business", False), 0.10),
    )
    maintainability = _weighted(
        (docs_score, 0.25),
        (pytest_score, 0.20),
        (checks.get("catalog_valid", True), 0.10),
        (checks.get("manual_metadata_present", False), 0.20),
        (checks.get("manual_domain_hints_present", False), 0.15),
        (dead_code_score, 0.10),
    )
    user_appeal = _weighted(
        (e2e_pass_rate, 0.45),
        (metadata_coverage, 0.20),
        (few_shot_score, 0.15),
        (keyword_score, 0.10),
        (vector_score, 0.10),
    )
    autonomous_improvement = _weighted(
        (automation_score, 0.30),
        (few_shot_score, 0.25),
        (keyword_score, 0.20),
        (relation_score, 0.15),
        (feedback_capture, 0.10),
    )
    operator_manageability = _weighted(
        (automation.get("release_gate", False), 0.25),
        (docs.get("playbook", False), 0.20),
        (checks.get("connection_ok", False), 0.15),
        (checks.get("llm_reachable", False), 0.10),
        (checks.get("schema_is_business", False), 0.15),
        (checks.get("include_exclude_supported", False), 0.15),
    )
    automation_dimension = _weighted(
        (automation.get("metadata_export", False), 0.12),
        (automation.get("sql_enrichment", False), 0.12),
        (automation.get("oracle_ops", False), 0.12),
        (automation.get("e2e_runner", False), 0.12),
        (automation.get("catalog_validator", False), 0.10),
        (automation.get("release_gate", False), 0.12),
        (checks.get("vector_fresh", False), 0.10),
        (pytest_score, 0.10),
        (checks.get("catalog_valid", True), 0.10),
    )
    query_accuracy = _weighted(
        (e2e_pass_rate, 0.50),
        (metadata_coverage, 0.15),
        (relation_score, 0.15),
        (few_shot_score, 0.10),
        (feedback_score, 0.05),
        (checks.get("catalog_valid", True), 0.05),
    )
    code_quality = _weighted(
        (pytest_score, 0.30),
        (dead_code_score, 0.25),
        (docs_score, 0.20),
        (readme_score, 0.15),
        (automation.get("release_gate", False), 0.10),
    )

    return {
        "operational_convenience": operational_convenience,
        "maintainability": maintainability,
        "user_appeal": user_appeal,
        "autonomous_improvement": autonomous_improvement,
        "operator_manageability": operator_manageability,
        "automation": automation_dimension,
        "query_accuracy": query_accuracy,
        "code_quality": code_quality,
    }


def blocking_issues(
    checks: Dict[str, Any],
    *,
    e2e_report: Dict[str, Any] | None,
    code_hygiene: Dict[str, Any],
) -> List[str]:
    blockers: List[str] = []
    if not checks.get("connection_ok"):
        blockers.append("Oracle connection check failed.")
    if not checks.get("llm_reachable"):
        blockers.append("The configured LLM endpoint is unreachable.")
    if not checks.get("read_only"):
        blockers.append("Read-only mode is disabled.")
    if not checks.get("catalog_valid", True):
        blockers.append("The regression catalog is invalid.")
    if not checks.get("schema_is_business"):
        blockers.append("The configured schema still looks like SYSTEM/SYS or a system-table schema.")
    if not checks.get("metadata_present"):
        blockers.append("Primary metadata is missing for the target db_id.")
    if not checks.get("manual_metadata_present"):
        blockers.append("Manual metadata overlay is missing for the target db_id.")
    if not checks.get("domain_hints_present"):
        blockers.append("Primary domain hints are missing for the target db_id.")
    if not checks.get("manual_domain_hints_present"):
        blockers.append("Manual domain hints overlay is missing for the target db_id.")
    if not checks.get("vector_fresh"):
        blockers.append("Vector index is missing or stale against the latest metadata.")
    if e2e_report is not None and float(e2e_report.get("pass_rate", 0.0) or 0.0) < 100.0:
        blockers.append("E2E regression pass rate is below 100%.")
    if code_hygiene.get("pytest_ok") is False:
        blockers.append("Local pytest suite is failing.")
    if int(code_hygiene.get("vulture_issues", 0) or 0) > 0:
        blockers.append("High-confidence dead code issues remain.")
    return blockers


def build_recommendations(
    *,
    evaluator_report: Dict[str, Any],
    checks: Dict[str, Any],
    docs: Dict[str, bool],
    automation: Dict[str, bool],
    e2e_report: Dict[str, Any] | None,
    code_hygiene: Dict[str, Any],
    dimensions: Dict[str, int],
) -> List[str]:
    metadata = evaluator_report.get("metadata", {})
    feedback = evaluator_report.get("feedback", {})
    readiness = evaluator_report.get("readiness", {})
    recommendations: List[str] = []

    if metadata.get("table_description_coverage", 0.0) < 90.0:
        recommendations.append("Raise table description coverage to at least 90% in the manual metadata overlay.")
    if metadata.get("column_description_coverage", 0.0) < 90.0:
        recommendations.append("Raise column description coverage to at least 90% in the manual metadata overlay.")
    if metadata.get("sample_coverage", 0.0) < 60.0:
        recommendations.append("Capture more sample values for filter-heavy columns to improve predicate accuracy.")
    if metadata.get("relationship_count", 0) < 3:
        recommendations.append("Run SQL metadata enrichment or add manual relationships so join planning is grounded.")
    if readiness.get("few_shot_count", 0) < 5:
        recommendations.append("Seed at least five validated few-shot examples for the business-critical question patterns.")
    if readiness.get("keyword_count", 0) < 20:
        recommendations.append("Expand keyword_map with business synonyms from operator and analyst queries.")
    if int(feedback.get("count", 0) or 0) < 10:
        recommendations.append("Collect more production-like feedback so the learner has enough signal to evolve safely.")
    if e2e_report is None:
        recommendations.append("Attach a regression catalog and require E2E execution before every release.")
    if code_hygiene.get("pytest_ok") is None:
        recommendations.append("Run local pytest as part of the release gate instead of relying on manual checks.")
    if int(code_hygiene.get("vulture_issues", 0) or 0) > 0:
        recommendations.append("Remove or justify high-confidence dead code findings from vulture.")
    if not docs.get("playbook", False):
        recommendations.append("Add an operator playbook so onboarding and incident handling are repeatable.")
    if not checks.get("catalog_valid", True):
        recommendations.append("Validate and normalize the regression catalog before using it in release checks.")
    if not checks.get("schema_is_business", False):
        recommendations.append("Switch to a business schema or tighten include/exclude table filters before release.")
    if not checks.get("vector_fresh", False):
        recommendations.append("Rebuild the vector index after every metadata or overlay change.")
    if not checks.get("llm_reachable", False):
        recommendations.append("Start the configured LLM endpoint or point .env to a reachable inference service.")
    if not automation.get("release_gate", False):
        recommendations.append("Keep a single release-gate command available to operators for deployment sign-off.")

    for name, score in sorted(dimensions.items(), key=lambda item: item[1]):
        if score < 85:
            recommendations.append(
                f"Improve {name.replace('_', ' ')}. Current score is {score}, target is 85 or higher."
            )
    return _unique(recommendations)


def _weighted(*items: tuple[Any, float]) -> int:
    total = 0.0
    for value, weight in items:
        total += _numeric_score(value) * weight
    return round(min(total, 100.0))


def _numeric_score(value: Any) -> float:
    if isinstance(value, bool):
        return 100.0 if value else 0.0
    try:
        return max(0.0, min(float(value), 100.0))
    except (TypeError, ValueError):
        return 0.0


def _bool_score(value: bool) -> float:
    return 100.0 if value else 0.0


def _count_score(value: Any, *, per_unit: float, floor: float = 0.0) -> float:
    try:
        count = float(value or 0.0)
    except (TypeError, ValueError):
        count = 0.0
    return max(floor, min(count * per_unit, 100.0))


def _avg(*values: float) -> float:
    numeric = [float(v) for v in values if v is not None]
    return mean(numeric) if numeric else 0.0


def _unique(values: Iterable[str]) -> List[str]:
    output: List[str] = []
    seen: set[str] = set()
    for value in values:
        item = str(value).strip()
        if not item:
            continue
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        output.append(item)
    return output
