"""
날짜 도구  ──  상대적 시간 표현 → 절대 날짜 변환 Tool
"""
from __future__ import annotations
import re
from datetime import datetime, date, timedelta
from typing import Optional, Dict, List, Tuple, Any
from dataclasses import dataclass


@dataclass
class DateRange:
    """날짜 범위 결과"""
    start_date: date
    end_date: date
    original_expression: str
    description: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "original": self.original_expression,
            "description": self.description,
        }


class RelativeDateTool:
    """
    상대적 시간 표현을 절대 날짜로 변환하는 Tool
    
    지원 표현:
    - 오늘, 어제, 내일, 모레, 그저께
    - 이번 주, 지난주, 다음 주, 금주
    - 이번 달, 지난달, 다음 달
    - 올해, 작년, 내년
    - N일 전, N일 후, N주 전, N주 후, N개월 전, N개월 후
    - 최근 N일, 최근 N주, 최근 N개월
    """
    
    # 상대적 시간 표현 패턴
    PATTERNS = {
        # 단일 날짜
        "오늘": lambda ref: (ref, ref, "오늘"),
        "어제": lambda ref: (ref - timedelta(days=1), ref - timedelta(days=1), "어제"),
        "내일": lambda ref: (ref + timedelta(days=1), ref + timedelta(days=1), "내일"),
        "모레": lambda ref: (ref + timedelta(days=2), ref + timedelta(days=2), "모레"),
        "그저께": lambda ref: (ref - timedelta(days=2), ref - timedelta(days=2), "그저께"),
        "그제": lambda ref: (ref - timedelta(days=2), ref - timedelta(days=2), "그제"),
        
        # 주 단위
        "이번 ?주": lambda ref: RelativeDateTool._this_week(ref),
        "이번주": lambda ref: RelativeDateTool._this_week(ref),
        "금주": lambda ref: RelativeDateTool._this_week(ref),
        "지난 ?주": lambda ref: RelativeDateTool._last_week(ref),
        "지난주": lambda ref: RelativeDateTool._last_week(ref),
        "저번 ?주": lambda ref: RelativeDateTool._last_week(ref),
        "저번주": lambda ref: RelativeDateTool._last_week(ref),
        "다음 ?주": lambda ref: RelativeDateTool._next_week(ref),
        "다음주": lambda ref: RelativeDateTool._next_week(ref),
        
        # 월 단위
        "이번 ?달": lambda ref: RelativeDateTool._this_month(ref),
        "이번달": lambda ref: RelativeDateTool._this_month(ref),
        "금월": lambda ref: RelativeDateTool._this_month(ref),
        "지난 ?달": lambda ref: RelativeDateTool._last_month(ref),
        "지난달": lambda ref: RelativeDateTool._last_month(ref),
        "저번 ?달": lambda ref: RelativeDateTool._last_month(ref),
        "저번달": lambda ref: RelativeDateTool._last_month(ref),
        "다음 ?달": lambda ref: RelativeDateTool._next_month(ref),
        "다음달": lambda ref: RelativeDateTool._next_month(ref),
        
        # 연 단위
        "올해": lambda ref: RelativeDateTool._this_year(ref),
        "금년": lambda ref: RelativeDateTool._this_year(ref),
        "작년": lambda ref: RelativeDateTool._last_year(ref),
        "지난 ?해": lambda ref: RelativeDateTool._last_year(ref),
        "내년": lambda ref: RelativeDateTool._next_year(ref),
        "다음 ?해": lambda ref: RelativeDateTool._next_year(ref),
    }
    
    # 숫자 + 단위 패턴 (예: "3일 전", "2주 후", "최근 7일")
    NUMERIC_PATTERNS = [
        (r"(\d+)\s*일\s*전", "days_ago"),
        (r"(\d+)\s*일\s*후", "days_later"),
        (r"(\d+)\s*주\s*전", "weeks_ago"),
        (r"(\d+)\s*주\s*후", "weeks_later"),
        (r"(\d+)\s*개월\s*전", "months_ago"),
        (r"(\d+)\s*달\s*전", "months_ago"),
        (r"(\d+)\s*개월\s*후", "months_later"),
        (r"(\d+)\s*달\s*후", "months_later"),
        (r"최근\s*(\d+)\s*일", "recent_days"),
        (r"지난\s*(\d+)\s*일", "recent_days"),
        (r"최근\s*(\d+)\s*주", "recent_weeks"),
        (r"지난\s*(\d+)\s*주", "recent_weeks"),
        (r"최근\s*(\d+)\s*개월", "recent_months"),
        (r"지난\s*(\d+)\s*개월", "recent_months"),
    ]
    
    def __init__(self, reference_date: Optional[date] = None):
        """
        Args:
            reference_date: 기준 날짜. None이면 서버 현재 시간 사용
        """
        self._reference_date = reference_date
    
    @property
    def reference_date(self) -> date:
        """기준 날짜 (설정되지 않으면 현재 서버 시간)"""
        return self._reference_date or date.today()

    def parse(self, text: str) -> List[DateRange]:
        """
        텍스트에서 상대적 시간 표현을 찾아 절대 날짜로 변환
        
        Args:
            text: 분석할 텍스트
            
        Returns:
            List[DateRange]: 발견된 모든 날짜 범위
        """
        results: List[DateRange] = []
        ref = self.reference_date
        
        # 1. 고정 패턴 매칭
        for pattern, func in self.PATTERNS.items():
            regex = pattern.replace(" ?", r"\s*")
            if re.search(regex, text, re.IGNORECASE):
                start, end, desc = func(ref)
                results.append(DateRange(
                    start_date=start,
                    end_date=end,
                    original_expression=pattern.replace(" ?", ""),
                    description=desc,
                ))
        
        # 2. 숫자 패턴 매칭
        for pattern, ptype in self.NUMERIC_PATTERNS:
            match = re.search(pattern, text)
            if match:
                n = int(match.group(1))
                dr = self._handle_numeric_pattern(n, ptype, ref, match.group(0))
                if dr:
                    results.append(dr)
        
        seen = set()
        unique_results = []
        for r in results:
            key = (r.start_date, r.end_date)
            if key not in seen:
                seen.add(key)
                unique_results.append(r)
        
        return unique_results
    
    # ── 헬퍼 메서드 ───────────────────────────────────────
    @staticmethod
    def _this_week(ref: date) -> Tuple[date, date, str]:
        start = ref - timedelta(days=ref.weekday())  # 월요일
        end = start + timedelta(days=6)  # 일요일
        return start, end, f"이번 주 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _last_week(ref: date) -> Tuple[date, date, str]:
        start = ref - timedelta(days=ref.weekday() + 7)
        end = start + timedelta(days=6)
        return start, end, f"지난 주 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _next_week(ref: date) -> Tuple[date, date, str]:
        start = ref + timedelta(days=(7 - ref.weekday()))
        end = start + timedelta(days=6)
        return start, end, f"다음 주 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _this_month(ref: date) -> Tuple[date, date, str]:
        start = ref.replace(day=1)
        # 다음 달 1일 - 1일 = 이번 달 마지막 날
        if ref.month == 12:
            end = ref.replace(month=12, day=31)
        else:
            end = ref.replace(month=ref.month + 1, day=1) - timedelta(days=1)
        return start, end, f"이번 달 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _last_month(ref: date) -> Tuple[date, date, str]:
        first_this_month = ref.replace(day=1)
        end = first_this_month - timedelta(days=1)
        start = end.replace(day=1)
        return start, end, f"지난 달 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _next_month(ref: date) -> Tuple[date, date, str]:
        if ref.month == 12:
            start = date(ref.year + 1, 1, 1)
        else:
            start = date(ref.year, ref.month + 1, 1)
        if start.month == 12:
            end = date(start.year, 12, 31)
        else:
            end = date(start.year, start.month + 1, 1) - timedelta(days=1)
        return start, end, f"다음 달 ({start.isoformat()} ~ {end.isoformat()})"
    
    @staticmethod
    def _this_year(ref: date) -> Tuple[date, date, str]:
        start = date(ref.year, 1, 1)
        end = date(ref.year, 12, 31)
        return start, end, f"올해 ({ref.year}년)"
    
    @staticmethod
    def _last_year(ref: date) -> Tuple[date, date, str]:
        start = date(ref.year - 1, 1, 1)
        end = date(ref.year - 1, 12, 31)
        return start, end, f"작년 ({ref.year - 1}년)"
    
    @staticmethod
    def _next_year(ref: date) -> Tuple[date, date, str]:
        start = date(ref.year + 1, 1, 1)
        end = date(ref.year + 1, 12, 31)
        return start, end, f"내년 ({ref.year + 1}년)"
    
    def _handle_numeric_pattern(self, n: int, ptype: str, ref: date, 
                                 original: str) -> Optional[DateRange]:
        """숫자 패턴 처리"""
        if ptype == "days_ago":
            d = ref - timedelta(days=n)
            return DateRange(d, d, original, f"{n}일 전 ({d.isoformat()})")
        
        elif ptype == "days_later":
            d = ref + timedelta(days=n)
            return DateRange(d, d, original, f"{n}일 후 ({d.isoformat()})")
        
        elif ptype == "weeks_ago":
            d = ref - timedelta(weeks=n)
            return DateRange(d, d, original, f"{n}주 전 ({d.isoformat()})")
        
        elif ptype == "weeks_later":
            d = ref + timedelta(weeks=n)
            return DateRange(d, d, original, f"{n}주 후 ({d.isoformat()})")
        
        elif ptype == "months_ago":
            # 간단한 월 계산 (일수는 유지하되 월 감소)
            year = ref.year
            month = ref.month - n
            while month <= 0:
                month += 12
                year -= 1
            day = min(ref.day, 28)  # 안전하게 28일로
            d = date(year, month, day)
            return DateRange(d, d, original, f"{n}개월 전 ({d.isoformat()})")
        
        elif ptype == "months_later":
            year = ref.year
            month = ref.month + n
            while month > 12:
                month -= 12
                year += 1
            day = min(ref.day, 28)
            d = date(year, month, day)
            return DateRange(d, d, original, f"{n}개월 후 ({d.isoformat()})")
        
        elif ptype == "recent_days":
            end = ref
            start = ref - timedelta(days=n - 1)
            return DateRange(start, end, original, 
                           f"최근 {n}일 ({start.isoformat()} ~ {end.isoformat()})")
        
        elif ptype == "recent_weeks":
            end = ref
            start = ref - timedelta(weeks=n)
            return DateRange(start, end, original,
                           f"최근 {n}주 ({start.isoformat()} ~ {end.isoformat()})")
        
        elif ptype == "recent_months":
            end = ref
            year = ref.year
            month = ref.month - n
            while month <= 0:
                month += 12
                year -= 1
            start = date(year, month, ref.day if ref.day <= 28 else 28)
            return DateRange(start, end, original,
                           f"최근 {n}개월 ({start.isoformat()} ~ {end.isoformat()})")
        
        return None


# ═══════════════════════════════════════════════════════════════
# 스레드 안전 인스턴스 및 글로벌 함수
# ═══════════════════════════════════════════════════════════════
import threading

_thread_local = threading.local()


def get_date_tool() -> RelativeDateTool:
    """날짜 도구 가져오기 (스레드별 독립 인스턴스)"""
    if not hasattr(_thread_local, "date_tool"):
        _thread_local.date_tool = RelativeDateTool()
    return _thread_local.date_tool


def parse_relative_dates(text: str, reference_date: Optional[date] = None) -> List[DateRange]:
    """
    텍스트에서 상대적 시간 표현을 파싱
    
    Args:
        text: 분석할 텍스트
        reference_date: 기준 날짜 (None이면 현재 서버 시간)
    
    Returns:
        List[DateRange]: 발견된 날짜 범위 목록
    """

    if reference_date:
        tool = RelativeDateTool(reference_date=reference_date)
    else:
        tool = get_date_tool()
    return tool.parse(text)
