"""Runtime dependency checks for operator-facing scripts."""
from __future__ import annotations

import urllib.error
import urllib.request
from typing import Any, Dict

from ..llm.client import build_azure_openai_client, build_openai_compatible_client


def probe_llm_endpoint(settings, *, timeout_sec: int = 5) -> Dict[str, Any]:
    provider = settings.llm_provider.provider
    if provider == "azure_openai":
        configured = bool(settings.llm_provider.azure_endpoint and settings.llm_provider.azure_api_key)
        return {
            "provider": provider,
            "url": settings.llm_provider.azure_endpoint,
            "ok": configured,
            "message": "Azure endpoint configured." if configured else "Azure endpoint or API key is missing.",
        }

    base_url = str(settings.llm_provider.base_url or "").rstrip("/")
    if not base_url:
        return {
            "provider": provider,
            "url": "",
            "ok": False,
            "message": "LLM base URL is empty.",
        }

    url = f"{base_url}/models" if not base_url.endswith("/models") else base_url
    headers = {}
    api_key = settings.llm_provider.effective_api_key()
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    request = urllib.request.Request(url, headers=headers)

    try:
        with urllib.request.urlopen(request, timeout=timeout_sec) as response:
            ok = 200 <= getattr(response, "status", 0) < 300
            return {
                "provider": provider,
                "url": url,
                "ok": ok,
                "message": f"HTTP {getattr(response, 'status', 'unknown')}",
            }
    except urllib.error.HTTPError as exc:
        return {
            "provider": provider,
            "url": url,
            "ok": False,
            "message": f"HTTP {exc.code}: {exc.reason}",
        }
    except Exception as exc:
        return {
            "provider": provider,
            "url": url,
            "ok": False,
            "message": str(exc),
        }


def probe_embedding_endpoint(settings, *, timeout_sec: int = 10) -> Dict[str, Any]:
    cfg = settings.embed
    provider = cfg.provider

    if provider == "azure_openai":
        if not (cfg.endpoint and cfg.azure_api_key):
            return {
                "provider": provider,
                "model": cfg.deployment,
                "ok": False,
                "message": "Azure embedding endpoint or key is missing.",
            }
        try:
            client = build_azure_openai_client(
                azure_endpoint=cfg.endpoint,
                api_key=cfg.azure_api_key,
                api_version=cfg.api_version,
                timeout_sec=timeout_sec,
            )
            client.embeddings.create(input=["ping"], model=cfg.deployment)
            return {
                "provider": provider,
                "model": cfg.deployment,
                "ok": True,
                "message": "Embedding endpoint is reachable.",
            }
        except Exception as exc:
            return {
                "provider": provider,
                "model": cfg.deployment,
                "ok": False,
                "message": str(exc),
            }

    if not (cfg.base_url and cfg.api_key):
        return {
            "provider": provider,
            "model": cfg.model,
            "ok": False,
            "message": "Embedding base URL or API key is missing.",
        }

    try:
        client = build_openai_compatible_client(
            base_url=cfg.base_url,
            api_key=cfg.api_key,
            timeout_sec=timeout_sec,
        )
        client.embeddings.create(input=["ping"], model=cfg.model)
        return {
            "provider": provider,
            "model": cfg.model,
            "ok": True,
            "message": "Embedding endpoint is reachable.",
        }
    except Exception as exc:
        return {
            "provider": provider,
            "model": cfg.model,
            "ok": False,
            "message": str(exc),
        }
