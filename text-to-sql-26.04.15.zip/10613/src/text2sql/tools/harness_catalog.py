"""Harness catalog utilities for evaluation engineering."""
from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence


def load_catalog_cases(path: Path | str) -> List[Dict[str, Any]]:
    catalog_path = Path(path)
    payload = json.loads(catalog_path.read_text(encoding="utf-8"))
    items = payload.get("queries") if isinstance(payload, dict) else payload
    if not isinstance(items, list):
        raise ValueError("Catalog must be a list or contain a 'queries' list.")

    cases: List[Dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue
        case = dict(item)
        raw_domain = item.get("domain")
        raw_difficulty = item.get("difficulty")
        raw_tags = item.get("tags")
        case["case_id"] = str(item.get("case_id") or item.get("id") or f"case_{index:03d}").strip()
        case["question"] = str(item.get("question") or "").strip()
        case["expected_sql"] = str(item.get("expected_sql") or item.get("sql") or "").strip()
        case["domain"] = str(item.get("domain") or "general").strip().lower()
        case["difficulty"] = str(item.get("difficulty") or "normal").strip().lower()
        tags = raw_tags or []
        if isinstance(tags, str):
            tags = [part.strip() for part in tags.split(",") if part.strip()]
        case["tags"] = [str(tag).strip().lower() for tag in tags if str(tag).strip()]
        case["title"] = str(item.get("title") or "").strip()
        case["description"] = str(item.get("description") or "").strip()
        case["_source_index"] = index
        case["_provided_domain"] = raw_domain is not None and str(raw_domain).strip() != ""
        case["_provided_difficulty"] = raw_difficulty is not None and str(raw_difficulty).strip() != ""
        case["_provided_tags"] = raw_tags is not None and bool(case["tags"])
        cases.append(case)
    return cases


def validate_catalog_cases(cases: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    errors: List[str] = []
    warnings: List[str] = []
    seen_case_ids: set[str] = set()
    seen_questions: set[str] = set()
    domain_counter: Counter[str] = Counter()
    tag_counter: Counter[str] = Counter()
    difficulty_counter: Counter[str] = Counter()

    for case in cases:
        ref = f"{case.get('case_id')}@{case.get('_source_index')}"
        case_id = str(case.get("case_id") or "").strip()
        question = str(case.get("question") or "").strip()
        expected_sql = str(case.get("expected_sql") or "").strip()
        domain = str(case.get("domain") or "").strip().lower()
        difficulty = str(case.get("difficulty") or "").strip().lower()
        tags = case.get("tags") or []

        if not case_id:
            errors.append(f"{ref}: missing case_id")
        elif case_id in seen_case_ids:
            errors.append(f"{ref}: duplicate case_id '{case_id}'")
        else:
            seen_case_ids.add(case_id)

        if not question:
            errors.append(f"{ref}: missing question")
        elif question.lower() in seen_questions:
            warnings.append(f"{ref}: duplicate question text")
        else:
            seen_questions.add(question.lower())

        if not expected_sql:
            errors.append(f"{ref}: missing expected_sql")
        elif "select" not in expected_sql.lower():
            warnings.append(f"{ref}: expected_sql does not look like a SELECT statement")

        if not case.get("_provided_domain", False):
            warnings.append(f"{ref}: missing domain")
        if domain:
            domain_counter[domain] += 1

        if not case.get("_provided_difficulty", False):
            warnings.append(f"{ref}: missing difficulty")
        if difficulty:
            difficulty_counter[difficulty] += 1

        if not case.get("_provided_tags", False):
            warnings.append(f"{ref}: missing tags")
        if tags:
            tag_counter.update(tags)

        if len(question) < 5:
            warnings.append(f"{ref}: question is suspiciously short")
        if len(expected_sql) < 15:
            warnings.append(f"{ref}: SQL is suspiciously short")

    return {
        "total": len(cases),
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "domain_counts": dict(domain_counter),
        "tag_counts": dict(tag_counter),
        "difficulty_counts": dict(difficulty_counter),
        "coverage": {
            "domains": len(domain_counter),
            "tags": len(tag_counter),
            "difficulties": len(difficulty_counter),
        },
    }


def filter_catalog_cases(
    cases: Sequence[Dict[str, Any]],
    *,
    domain: str = "",
    tags: Iterable[str] = (),
    max_items: int = 0,
) -> List[Dict[str, Any]]:
    selected = list(cases)
    domain = str(domain or "").strip().lower()
    tag_set = {str(tag).strip().lower() for tag in tags if str(tag).strip()}

    if domain:
        selected = [case for case in selected if str(case.get("domain") or "").strip().lower() == domain]
    if tag_set:
        selected = [case for case in selected if tag_set.intersection(case.get("tags") or [])]
    if max_items and max_items > 0:
        selected = selected[:max_items]
    return selected


def summarize_result_dimensions(results: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    by_domain = _summarize_group(results, key="domain")
    by_difficulty = _summarize_group(results, key="difficulty")
    by_tag = _summarize_tags(results)
    return {
        "by_domain": by_domain,
        "by_difficulty": by_difficulty,
        "by_tag": by_tag,
    }


def _summarize_group(results: Sequence[Dict[str, Any]], *, key: str) -> Dict[str, Any]:
    groups: dict[str, list[Dict[str, Any]]] = defaultdict(list)
    for result in results:
        rendered = str(result.get(key) or "unknown").strip().lower()
        groups[rendered].append(result)

    summary: Dict[str, Any] = {}
    for name, items in groups.items():
        passed = len([item for item in items if item.get("success")])
        summary[name] = {
            "total": len(items),
            "passed": passed,
            "failed": len(items) - passed,
            "pass_rate": round((passed / len(items)) * 100, 1) if items else 0.0,
        }
    return summary


def _summarize_tags(results: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    groups: dict[str, list[Dict[str, Any]]] = defaultdict(list)
    for result in results:
        for tag in result.get("tags") or []:
            groups[str(tag).strip().lower()].append(result)

    summary: Dict[str, Any] = {}
    for name, items in groups.items():
        passed = len([item for item in items if item.get("success")])
        summary[name] = {
            "total": len(items),
            "passed": passed,
            "failed": len(items) - passed,
            "pass_rate": round((passed / len(items)) * 100, 1) if items else 0.0,
        }
    return summary
