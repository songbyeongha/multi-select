"""
DB Registry  --  Oracle 모드에서는 adapter를 직접 사용합니다.
"""
from __future__ import annotations


class DBNotFoundError(FileNotFoundError):
    """db_id에 해당하는 DB를 찾을 수 없을 때"""
