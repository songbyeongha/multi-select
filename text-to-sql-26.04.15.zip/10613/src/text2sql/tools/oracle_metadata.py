"""Oracle metadata export and bootstrap helpers."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List

from ..config.metadata_utils import deep_merge, load_json_file

_SYSTEM_TABLE_PREFIXES = (
    "AQ$_",
    "MVIEW$_",
    "LOGSTDBY$",
    "REDO_DB$",
    "ROLLING$",
    "REPCAT$",
    "DEF$_",
)
_SYSTEM_TABLE_NAMES = {
    "HELP",
    "SQLPLUS_PRODUCT_PROFILE",
}


def _normalize_name(name: str) -> str:
    return str(name or "").strip()


def _table_aliases(table_name: str) -> List[str]:
    raw = _normalize_name(table_name)
    short = raw.split(".")[-1]
    aliases = [raw, short, short.lower()]
    aliases.extend(part.lower() for part in re.split(r"[._]+", short) if part)
    unique: List[str] = []
    seen: set[str] = set()
    for alias in aliases:
        key = alias.lower()
        if alias and key not in seen:
            unique.append(alias)
            seen.add(key)
    return unique


def export_oracle_metadata_payload(
    adapter,
    *,
    db_id: str,
    db_description: str,
    include_tables: Iterable[str] | None = None,
    exclude_tables: Iterable[str] | None = None,
    sample_limit: int = 3,
    exclude_system_tables: bool = True,
) -> Dict[str, Any]:
    include = {str(t).upper() for t in (include_tables or []) if str(t).strip()}
    exclude = {str(t).upper() for t in (exclude_tables or []) if str(t).strip()}

    all_tables = adapter.list_tables()
    if exclude_system_tables and not include:
        all_tables = [
            t for t in all_tables
            if t.upper() not in _SYSTEM_TABLE_NAMES
            and not any(t.upper().startswith(prefix) for prefix in _SYSTEM_TABLE_PREFIXES)
        ]
    if include:
        all_tables = [t for t in all_tables if t.upper() in include]
    if exclude:
        all_tables = [t for t in all_tables if t.upper() not in exclude]

    tables_meta: Dict[str, Any] = {}

    for tname in all_tables:
        tmeta = adapter.table_info(tname)
        columns: Dict[str, Any] = {}
        sample_values: Dict[str, List[str]] = {}

        for col in tmeta.columns:
            col_entry: Dict[str, Any] = {
                "type": col.type,
                "description": col.comment or "",
            }
            if col.is_pk:
                col_entry["is_pk"] = True

            values: List[str] = []
            for row in tmeta.sample_rows[:sample_limit]:
                value = row.get(col.name)
                if value is None:
                    continue
                rendered = str(value)
                if len(rendered) > 80:
                    rendered = rendered[:77] + "..."
                values.append(rendered)
            if values:
                unique_vals = list(dict.fromkeys(values))
                col_entry["sample_values"] = unique_vals
                sample_values[col.name] = unique_vals

            columns[col.name] = col_entry

        for fk in tmeta.foreign_keys:
            if fk.from_column in columns:
                columns[fk.from_column]["is_fk"] = True
                columns[fk.from_column]["references"] = f"{fk.to_table}.{fk.to_column}"

        sample_text_parts = []
        for cname, values in sample_values.items():
            sample_text_parts.append(f"{cname}={', '.join(values[:3])}")

        tables_meta[tname] = {
            "description": tmeta.comment or "",
            "short_name": tname.split(".")[-1],
            "schema_name": getattr(adapter, "owner", ""),
            "database_name": db_id,
            "aliases": _table_aliases(tname),
            "columns": columns,
            "sample_values": sample_values,
            "sample_text": "; ".join(sample_text_parts[:8]),
        }

    relationships = []
    for table_name, table_meta in tables_meta.items():
        for column_name, column_meta in (table_meta.get("columns") or {}).items():
            if column_meta.get("is_fk") and column_meta.get("references"):
                relationships.append({
                    "from": f"{table_name}.{column_name}",
                    "to": column_meta["references"],
                    "type": "many-to-one",
                })

    return {
        "databases": {
            db_id: {
                "name": db_id,
                "description": db_description,
                "dialect": "oracle",
                "tables": tables_meta,
                "relationships": relationships,
            }
        }
    }


def write_json(path: Path | str, payload: Dict[str, Any]) -> Path:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return output_path


def scaffold_manual_metadata(payload: Dict[str, Any], db_id: str) -> Dict[str, Any]:
    db_meta = payload.get("databases", {}).get(db_id, {})
    manual_tables: Dict[str, Any] = {}
    for table_name, table_meta in (db_meta.get("tables") or {}).items():
        manual_tables[table_name] = {
            "description": table_meta.get("description", ""),
            "aliases": table_meta.get("aliases", []),
            "columns": {
                column_name: {"description": column_meta.get("description", "")}
                for column_name, column_meta in (table_meta.get("columns") or {}).items()
            },
        }
    return {
        "databases": {
            db_id: {
                "name": db_meta.get("name", db_id),
                "description": db_meta.get("description", ""),
                "dialect": "oracle",
                "tables": manual_tables,
            }
        }
    }


def _keyword_candidates(table_name: str, table_meta: Dict[str, Any]) -> List[str]:
    seeds: List[str] = []
    seeds.extend(_table_aliases(table_name))
    seeds.extend(re.findall(r"[A-Za-z0-9가-힣_]{2,}", table_meta.get("description", "")))
    return [seed.lower() for seed in seeds if seed]


def scaffold_domain_hints(payload: Dict[str, Any], db_id: str) -> Dict[str, Any]:
    db_meta = payload.get("databases", {}).get(db_id, {})
    keyword_map: Dict[str, List[str]] = {}
    relation_bonus_map: Dict[str, List[str]] = {}

    for table_name, table_meta in (db_meta.get("tables") or {}).items():
        for token in _keyword_candidates(table_name, table_meta):
            keyword_map.setdefault(token, [])
            if table_name not in keyword_map[token]:
                keyword_map[token].append(table_name)

    for rel in db_meta.get("relationships") or []:
        from_ref = str(rel.get("from") or "")
        to_ref = str(rel.get("to") or "")
        if "." not in from_ref or "." not in to_ref:
            continue
        from_table = from_ref.rsplit(".", 1)[0]
        to_table = to_ref.rsplit(".", 1)[0]
        relation_bonus_map.setdefault(from_table, [])
        relation_bonus_map.setdefault(to_table, [])
        if to_table not in relation_bonus_map[from_table]:
            relation_bonus_map[from_table].append(to_table)
        if from_table not in relation_bonus_map[to_table]:
            relation_bonus_map[to_table].append(from_table)

    return {
        "databases": {
            db_id: {
                "keyword_map": keyword_map,
                "relation_bonus_map": relation_bonus_map,
                "few_shot_examples": [],
                "common_patterns": {},
            }
        }
    }


def scaffold_manual_domain_hints(payload: Dict[str, Any], db_id: str) -> Dict[str, Any]:
    db_meta = payload.get("databases", {}).get(db_id, {})
    return {
        "databases": {
            db_id: {
                "name": db_meta.get("name", db_id),
                "_usage_guide": {
                    "keyword_map": (
                        "{ '업무용어': ['TABLE_NAME', ...] } — "
                        "자연어 키워드를 테이블로 매핑. "
                        "예: {\"생산량\": [\"PROD_RESULT\"], \"재고\": [\"INVENTORY\"]}"
                    ),
                    "relation_bonus_map": (
                        "{ 'TABLE_A': ['TABLE_B', ...] } — "
                        "함께 조인하는 테이블 목록. "
                        "예: {\"PROD_ORDER\": [\"PROD_RESULT\", \"ITEM_MASTER\"]}"
                    ),
                    "few_shot_examples": (
                        "[ {\"question\": \"자연어 질문\", \"sql\": \"실제 Oracle SQL\"} ] — "
                        "SQL 생성 시 LLM이 참조하는 질문-SQL 쌍. "
                        "자동 추가: run_ops.py prepare --catalog <파일> "
                        "또는 run_ops.py maintain --catalog <파일>"
                    ),
                    "common_patterns": (
                        "{ 'fb_<query_pattern>_<이름>': 'SQL 조각' } — "
                        "query_pattern별 참고 SQL. fb_ 접두사 필수. "
                        "예: {\"fb_group_aggregate_monthly\": \"TRUNC(날짜컬럼, 'MM')\"}"
                    ),
                },
                "keyword_map": {},
                "relation_bonus_map": {},
                "few_shot_examples": [],
                "common_patterns": {},
            }
        }
    }


def ensure_seed_file(path: Path | str, seed_payload: Dict[str, Any], *, prefer_existing: bool = True) -> Path:
    output_path = Path(path)
    existing = load_json_file(output_path)
    merged = deep_merge(seed_payload, existing) if prefer_existing else deep_merge(existing, seed_payload)
    return write_json(output_path, merged)
