"""CLI 콘솔 디스플레이 — rich 기반 파이프라인 실행 시각화."""
from __future__ import annotations

import os
import sys
import time
from typing import Any, Dict, List, Optional

# Windows cp949 인코딩 문제 방지
if sys.platform == "win32":
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console(force_terminal=True)

# 노드별 이모지/아이콘 매핑
NODE_ICONS = {
    "Decomposer": "[cyan]1[/cyan]",
    "SchemaSelector": "[cyan]2[/cyan]",
    "ValueRetriever": "[cyan]3[/cyan]",
    "JoinPlanner": "[cyan]4[/cyan]",
    "CandidateGenerator": "[green]5[/green]",
    "SQLPostProcess": "[green]6[/green]",
    "Guardrails": "[yellow]7[/yellow]",
    "SQLUnitTester": "[yellow]8[/yellow]",
    "ExecutePreview": "[yellow]9[/yellow]",
    "Judge": "[blue]10[/blue]",
    "Repair": "[red]R[/red]",
    "ResultSummarizer": "[green]OK[/green]",
    "SAFE_FAIL": "[red]FAIL[/red]",
    "MemorySave": "[dim]M[/dim]",
}

PIPELINE_STEPS = [
    "Decomposer", "SchemaSelector", "ValueRetriever", "JoinPlanner",
    "CandidateGenerator", "SQLPostProcess", "Guardrails", "SQLUnitTester",
    "ExecutePreview", "Judge", "ResultSummarizer",
]


class PipelineDisplay:
    """파이프라인 실행 상태를 rich 콘솔로 표시."""

    def __init__(self):
        self._start_time = time.time()
        self._logs: List[Dict[str, Any]] = []
        self._current_node = ""
        self._status = "running"
        self._token_usage: Dict[str, Any] = {}
        self._question = ""
        self._db_id = ""
        self._result_sql = ""
        self._result_summary = ""
        self._success: Optional[bool] = None

    def set_question(self, question: str, db_id: str):
        self._question = question
        self._db_id = db_id

    def add_trace(self, node: str, detail: str, extra: Dict[str, Any] | None = None):
        self._current_node = node
        elapsed = time.time() - self._start_time
        self._logs.append({
            "node": node,
            "detail": detail,
            "elapsed": elapsed,
            "extra": extra or {},
        })

    def set_result(self, success: bool, sql: str = "", summary: str = "",
                   token_usage: Dict[str, Any] | None = None):
        self._success = success
        self._result_sql = sql
        self._result_summary = summary
        self._token_usage = token_usage or {}
        self._status = "success" if success else "failed"

    def _build_progress_bar(self) -> str:
        """현재 노드까지의 진행 상태를 시각적으로 표시."""
        if self._current_node in ("SAFE_FAIL",):
            return "[red]FAILED[/red]"
        if self._current_node in ("ResultSummarizer", "MemorySave"):
            return "[green]COMPLETE[/green]"

        parts = []
        found = False
        for step in PIPELINE_STEPS:
            icon = NODE_ICONS.get(step, "?")
            if step == self._current_node:
                parts.append(f"[bold white on blue] {icon} {step} [/bold white on blue]")
                found = True
            elif not found:
                parts.append(f"[green]{icon}[/green]")
            else:
                parts.append(f"[dim]{icon}[/dim]")

        if self._current_node == "Repair":
            parts.append(f" [red]-> Repair[/red]")

        return " > ".join(parts)

    def print_step(self, node: str, detail: str, extra: Dict[str, Any] | None = None):
        """노드 진행 시 한 줄 출력."""
        self.add_trace(node, detail, extra)
        elapsed = time.time() - self._start_time

        icon = NODE_ICONS.get(node, "[dim]?[/dim]")
        time_str = f"[dim]{elapsed:6.1f}s[/dim]"

        # 상세 정보 축약
        short_detail = detail[:80] + "..." if len(detail) > 80 else detail

        if node == "Repair":
            console.print(f"  {time_str} [{icon}] [red]{node}[/red]: {short_detail}")
        elif node in ("ResultSummarizer", "MemorySave"):
            console.print(f"  {time_str} [{icon}] [green]{node}[/green]: {short_detail}")
        elif node == "SAFE_FAIL":
            console.print(f"  {time_str} [{icon}] [bold red]{node}[/bold red]: {short_detail}")
        else:
            console.print(f"  {time_str} [{icon}] [bold]{node}[/bold]: {short_detail}")

        # extra 정보 표시 (SQL 미리보기, 에러 등)
        if extra:
            if "sql" in extra:
                sql_preview = str(extra["sql"])[:100]
                console.print(f"           [dim]SQL: {sql_preview}[/dim]")
            if "issues" in extra and extra["issues"]:
                for issue in extra["issues"][:2]:
                    console.print(f"           [yellow]! {str(issue)[:80]}[/yellow]")
            if "elapsed_ms" in extra:
                console.print(f"           [dim]({extra['elapsed_ms']}ms)[/dim]")

    def print_header(self):
        """실행 시작 헤더 출력."""
        q_display = self._question[:70] + "..." if len(self._question) > 70 else self._question
        console.print()
        console.print(Panel(
            f"[bold]{q_display}[/bold]\n[dim]Database: {self._db_id}[/dim]",
            title="[bold blue]Text-to-SQL Pipeline[/bold blue]",
            border_style="blue",
        ))

    def print_result(self):
        """최종 결과 출력."""
        elapsed = time.time() - self._start_time

        console.print()

        if self._success:
            # 성공 결과
            result_table = Table(show_header=False, box=None, padding=(0, 2))
            result_table.add_column(style="bold")
            result_table.add_column()
            result_table.add_row("Status", "[bold green]SUCCESS[/bold green]")
            result_table.add_row("Time", f"{elapsed:.1f}s")

            if self._token_usage:
                tokens = self._token_usage.get("total_tokens", 0)
                cost = self._token_usage.get("total_cost_usd", 0)
                result_table.add_row("Tokens", f"{tokens:,}")
                if cost:
                    result_table.add_row("Cost", f"${cost:.4f}")

            result_table.add_row("SQL", "")
            console.print(Panel(result_table, title="[bold green]Result[/bold green]", border_style="green"))

            # SQL 출력
            if self._result_sql:
                sql_display = self._result_sql[:500]
                console.print(Panel(sql_display, title="Generated SQL", border_style="green"))

            if self._result_summary:
                console.print(f"  [dim]{self._result_summary}[/dim]")
        else:
            # 실패 결과
            result_table = Table(show_header=False, box=None, padding=(0, 2))
            result_table.add_column(style="bold")
            result_table.add_column()
            result_table.add_row("Status", "[bold red]FAILED[/bold red]")
            result_table.add_row("Time", f"{elapsed:.1f}s")

            if self._token_usage:
                tokens = self._token_usage.get("total_tokens", 0)
                cost = self._token_usage.get("total_cost_usd", 0)
                result_table.add_row("Tokens", f"{tokens:,}")
                if cost:
                    result_table.add_row("Cost", f"${cost:.4f}")

            # 마지막 에러
            error_logs = [l for l in self._logs if l["node"] in ("SAFE_FAIL", "Repair")]
            if error_logs:
                last_err = error_logs[-1]["detail"][:100]
                result_table.add_row("Error", f"[red]{last_err}[/red]")

            console.print(Panel(result_table, title="[bold red]Result[/bold red]", border_style="red"))

        console.print()


class BatchDisplay:
    """배치 실행 전체 진행 상태를 rich 콘솔로 표시."""

    def __init__(self, total: int, title: str = "Batch Execution"):
        self._total = total
        self._title = title
        self._completed = 0
        self._success = 0
        self._failed = 0
        self._start_time = time.time()
        self._results: List[Dict[str, Any]] = []
        self._total_tokens = 0
        self._total_cost = 0.0

    def update(self, instance_id: str, success: bool, elapsed_ms: float = 0,
               token_usage: Dict[str, Any] | None = None):
        self._completed += 1
        if success:
            self._success += 1
        else:
            self._failed += 1

        usage = token_usage or {}
        self._total_tokens += usage.get("total_tokens", 0)
        self._total_cost += usage.get("total_cost_usd", 0)

        self._results.append({
            "id": instance_id,
            "success": success,
            "elapsed_ms": elapsed_ms,
        })

    def print_progress(self):
        """현재 배치 진행 상태 출력."""
        elapsed = time.time() - self._start_time
        pct = self._completed * 100 // max(1, self._total)
        remaining = self._total - self._completed

        # 속도 계산
        rate = self._completed / max(0.1, elapsed)
        eta = remaining / max(0.001, rate)

        bar_len = 30
        filled = int(bar_len * self._completed / max(1, self._total))
        bar = "[green]" + "#" * filled + "[/green]" + "[dim]-[/dim]" * (bar_len - filled)

        console.print(
            f"  {bar} {self._completed}/{self._total} ({pct}%) "
            f"[green]{self._success}[/green]✓ [red]{self._failed}[/red]✗ "
            f"[dim]{elapsed:.0f}s elapsed, ~{eta:.0f}s remaining[/dim]"
        )

    def print_summary(self):
        """배치 완료 후 최종 요약 테이블."""
        elapsed = time.time() - self._start_time

        console.print()
        table = Table(title=f"[bold]{self._title} — Final Results[/bold]", show_lines=True)
        table.add_column("Metric", style="bold")
        table.add_column("Value", justify="right")

        table.add_row("Total Examples", str(self._total))
        table.add_row("Success", f"[green]{self._success}[/green]")
        table.add_row("Failed", f"[red]{self._failed}[/red]")
        table.add_row("Accuracy", f"[bold]{self._success * 100 / max(1, self._total):.1f}%[/bold]")
        table.add_row("Total Time", f"{elapsed:.1f}s ({elapsed/60:.1f}min)")
        table.add_row("Avg Time/Example", f"{elapsed/max(1,self._completed):.1f}s")
        table.add_row("Total Tokens", f"{self._total_tokens:,}")
        if self._total_cost > 0:
            table.add_row("Total Cost", f"${self._total_cost:.2f}")

        console.print(table)

        # 실패 케이스 목록
        failed = [r for r in self._results if not r["success"]]
        if failed and len(failed) <= 20:
            console.print()
            fail_table = Table(title="[red]Failed Cases[/red]", show_lines=False)
            fail_table.add_column("Instance ID")
            fail_table.add_column("Time", justify="right")
            for r in failed[:20]:
                fail_table.add_row(r["id"], f"{r['elapsed_ms']/1000:.1f}s")
            console.print(fail_table)

        console.print()


def print_pipeline_banner():
    """파이프라인 시작 배너."""
    console.print()
    console.print("[bold blue]===========================================[/bold blue]")
    console.print("[bold blue]  Text-to-SQL Pipeline                    [/bold blue]")
    console.print("[bold blue]===========================================[/bold blue]")
    console.print()


def print_score_comparison(scores: List[Dict[str, Any]]):
    """점수 비교 테이블 출력."""
    table = Table(title="[bold]Score Comparison[/bold]", show_lines=True)
    table.add_column("Run", style="bold")
    table.add_column("Score", justify="right")
    table.add_column("Accuracy", justify="right")
    table.add_column("Change", justify="right")

    prev_score = 0
    for s in scores:
        score = s.get("correct", 0)
        total = s.get("total", 547)
        pct = score * 100 / max(1, total)
        change = score - prev_score
        change_str = f"[green]+{change}[/green]" if change > 0 else f"[red]{change}[/red]" if change < 0 else "-"

        table.add_row(
            s.get("name", "?"),
            f"{score}/{total}",
            f"{pct:.1f}%",
            change_str,
        )
        prev_score = score

    console.print(table)
