"""Infer metadata and domain hints from an existing SQL corpus."""
from __future__ import annotations

import copy
import itertools
import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

import sqlglot
from sqlglot import exp as E

from ..config.metadata_utils import get_db_scoped_entry, load_json_file

_TOKEN_RE = re.compile(r"[A-Za-z0-9_가-힣]+")
_HEADER_RE = re.compile(r"^\s*--\s*([A-Za-z_]+)\s*:\s*(.+?)\s*$")
_STOPWORDS = {
    "show",
    "list",
    "find",
    "give",
    "with",
    "where",
    "that",
    "than",
    "below",
    "above",
    "from",
    "into",
    "using",
    "query",
    "queries",
    "table",
    "tables",
    "column",
    "columns",
    "data",
    "the",
    "and",
    "for",
    "per",
    "top",
    "bottom",
    "most",
    "least",
    "showing",
    "please",
    "what",
    "which",
    "who",
    "when",
    "how",
    "all",
    "each",
    "every",
    "보고",
    "보여줘",
    "보여",
    "조회",
    "데이터",
    "목록",
    "합계",
    "건수",
    "정보",
    "기준",
    "상태",
    "관련",
    "내역",
    "현황",
    "그리고",
    "에서",
    "으로",
    "대한",
    "하는",
    "있는",
    "없는",
    "가장",
    "상위",
    "하위",
    "최근",
    "현재",
    "대상",
}
_GENERIC_ALIAS_TOKENS = {
    "공장",
    "제품",
    "품목",
    "고객",
    "주문",
    "생산",
    "라인",
    "설비",
    "재고",
    "품질",
    "table",
    "tables",
    "data",
}
_KOREAN_SUFFIXES = (
    "으로",
    "에서",
    "에게",
    "까지",
    "부터",
    "보다",
    "마다",
    "처럼",
    "하고",
    "이고",
    "이며",
    "이라",
    "라는",
    "하는",
    "있는",
    "없는",
    "으로는",
    "으로만",
    "은",
    "는",
    "이",
    "가",
    "을",
    "를",
    "과",
    "와",
    "의",
    "도",
    "만",
)
_COLUMN_TERM_MAP = {
    "ID": "identifier",
    "QTY": "quantity",
    "TS": "timestamp",
    "DT": "date",
    "NO": "number",
    "CNT": "count",
    "AMT": "amount",
    "SKU": "sku",
}


@dataclass(frozen=True)
class QueryArtifact:
    sql: str
    question: str = ""
    title: str = ""
    description: str = ""
    tags: Tuple[str, ...] = ()
    source: str = ""


@dataclass
class EnrichmentReport:
    artifacts_total: int = 0
    parsed_queries: int = 0
    parse_errors: List[str] = field(default_factory=list)
    relationships_added: int = 0
    keyword_tokens_added: int = 0
    few_shots_added: int = 0
    aliases_added: int = 0
    descriptions_filled: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "artifacts_total": self.artifacts_total,
            "parsed_queries": self.parsed_queries,
            "parse_errors": list(self.parse_errors),
            "relationships_added": self.relationships_added,
            "keyword_tokens_added": self.keyword_tokens_added,
            "few_shots_added": self.few_shots_added,
            "aliases_added": self.aliases_added,
            "descriptions_filled": self.descriptions_filled,
        }


def load_query_artifacts(
    *,
    catalog_paths: Sequence[Path | str] = (),
    sql_globs: Sequence[str] = (),
    root_dir: Path | str | None = None,
) -> List[QueryArtifact]:
    base_dir = Path(root_dir) if root_dir else Path.cwd()
    artifacts: List[QueryArtifact] = []
    seen: set[Tuple[str, str]] = set()

    for raw_path in catalog_paths:
        path = Path(raw_path)
        if not path.is_absolute():
            path = base_dir / path
        for artifact in _load_catalog_path(path):
            key = (artifact.source, artifact.sql.strip())
            if key not in seen and artifact.sql.strip():
                artifacts.append(artifact)
                seen.add(key)

    for pattern in sql_globs:
        for path in sorted(base_dir.glob(pattern)):
            if not path.is_file():
                continue
            artifact = _load_sql_file(path)
            key = (artifact.source, artifact.sql.strip())
            if key not in seen and artifact.sql.strip():
                artifacts.append(artifact)
                seen.add(key)

    return artifacts


def enrich_metadata_from_queries(
    *,
    db_id: str,
    artifacts: Sequence[QueryArtifact],
    base_metadata: Dict[str, Any],
    metadata_overlay: Dict[str, Any] | None = None,
    domain_hints_overlay: Dict[str, Any] | None = None,
    dialect: str = "oracle",
    min_relation_support: int = 1,
    max_few_shots: int = 40,
    fill_missing_descriptions: bool = True,
) -> tuple[Dict[str, Any], Dict[str, Any], EnrichmentReport]:
    metadata_overlay = copy.deepcopy(metadata_overlay or {})
    domain_hints_overlay = copy.deepcopy(domain_hints_overlay or {})
    report = EnrichmentReport(artifacts_total=len(artifacts))

    tables_meta = metadata_overlay.setdefault("tables", {})
    hints_keyword_map: Dict[str, List[str]] = domain_hints_overlay.setdefault("keyword_map", {})
    relation_bonus_map: Dict[str, List[str]] = domain_hints_overlay.setdefault("relation_bonus_map", {})
    few_shots: List[Dict[str, str]] = domain_hints_overlay.setdefault("few_shot_examples", [])
    domain_hints_overlay.setdefault("common_patterns", {})

    pk_map = _pk_columns(base_metadata)
    known_tables = {str(name).upper() for name in (base_metadata.get("tables") or {}).keys()}
    existing_questions = {(item.get("question") or "").strip().lower() for item in few_shots if item.get("question")}
    existing_relationships = {
        (str(rel.get("from", "")).upper(), str(rel.get("to", "")).upper())
        for rel in metadata_overlay.get("relationships", [])
        if rel.get("from") and rel.get("to")
    }

    relationship_votes: Counter[tuple[str, str, str, str]] = Counter()
    relationship_sources: dict[tuple[str, str, str, str], list[str]] = defaultdict(list)
    token_to_tables: dict[str, set[str]] = defaultdict(set)
    token_support: Counter[str] = Counter()
    table_to_terms: dict[str, Counter[str]] = defaultdict(Counter)
    related_pairs: dict[str, set[str]] = defaultdict(set)

    for artifact in artifacts:
        try:
            parsed = sqlglot.parse_one(artifact.sql, read=dialect)
        except Exception as exc:
            report.parse_errors.append(f"{artifact.source}: {exc}")
            continue

        report.parsed_queries += 1
        tables, alias_map = _extract_tables(parsed)
        if not tables:
            continue

        for left_table, right_table in itertools.combinations(sorted(tables), 2):
            related_pairs[left_table].add(right_table)
            related_pairs[right_table].add(left_table)

        tokens = _artifact_tokens(artifact)
        for token in tokens:
            token_to_tables[token].update(tables)
            token_support[token] += 1
        for table_name in tables:
            for token in tokens:
                table_to_terms[table_name][token] += 1

        question_norm = artifact.question.strip().lower()
        if question_norm and artifact.sql.strip() and question_norm not in existing_questions:
            few_shots.append({"question": artifact.question.strip(), "sql": artifact.sql.strip()})
            existing_questions.add(question_norm)
            report.few_shots_added += 1
            if len(few_shots) > max_few_shots:
                del few_shots[:-max_few_shots]

        for rel in _extract_relationships(parsed, alias_map, pk_map):
            if rel[0] not in known_tables or rel[2] not in known_tables:
                continue
            relationship_votes[rel] += 1
            relationship_sources[rel].append(artifact.source)

    for token, tables in sorted(token_to_tables.items()):
        table_list = sorted(tables)
        before = list(hints_keyword_map.get(token, []))
        after = _union_unique(before, table_list)
        hints_keyword_map[token] = after
        if after != before:
            report.keyword_tokens_added += 1

    for table_name, related in related_pairs.items():
        existing = relation_bonus_map.get(table_name, [])
        relation_bonus_map[table_name] = _union_unique(existing, sorted(related))

    relationships = metadata_overlay.setdefault("relationships", [])
    for rel_key, count in relationship_votes.most_common():
        if count < min_relation_support:
            continue
        from_ref = f"{rel_key[0]}.{rel_key[1]}"
        to_ref = f"{rel_key[2]}.{rel_key[3]}"
        relationship_id = (from_ref.upper(), to_ref.upper())
        if relationship_id in existing_relationships:
            continue
        relationships.append(
            {
                "from": from_ref,
                "to": to_ref,
                "type": "inferred-from-sql",
                "evidence_count": count,
                "evidence_sources": sorted(set(relationship_sources[rel_key]))[:5],
            }
        )
        existing_relationships.add(relationship_id)
        report.relationships_added += 1

    base_tables = base_metadata.get("tables") or {}
    for table_name, base_table in base_tables.items():
        table_entry = tables_meta.setdefault(table_name, {})
        aliases = table_entry.setdefault("aliases", [])
        for token, _ in table_to_terms.get(table_name, Counter()).most_common(20):
            if (
                token in _GENERIC_ALIAS_TOKENS
                or token_support[token] < 1
                or len(token_to_tables[token]) != 1
            ):
                continue
            updated = _union_unique(aliases, [token])
            if updated != aliases:
                aliases[:] = updated
                report.aliases_added += 1
            if len(aliases) >= 12:
                break

        if fill_missing_descriptions and not _has_value(table_entry.get("description")):
            if not _has_value(base_table.get("description")):
                table_entry["description"] = f"{_humanize_identifier(table_name)} table"
                report.descriptions_filled += 1

        columns_entry = table_entry.setdefault("columns", {})
        for column_name, base_column in (base_table.get("columns") or {}).items():
            column_entry = columns_entry.setdefault(column_name, {})
            if (
                fill_missing_descriptions
                and not _has_value(column_entry.get("description"))
                and not _has_value(base_column.get("description"))
            ):
                column_entry["description"] = _describe_column(column_name)
                report.descriptions_filled += 1

    return metadata_overlay, domain_hints_overlay, report


def update_overlay_file(path: Path | str, *, db_id: str, db_entry: Dict[str, Any]) -> Path:
    output_path = Path(path)
    raw = load_json_file(output_path)
    databases = raw.setdefault("databases", {})
    databases[db_id] = db_entry
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
    return output_path


def get_overlay_entry(path: Path | str, db_id: str) -> Dict[str, Any]:
    return copy.deepcopy(get_db_scoped_entry(load_json_file(path), db_id))


def _load_catalog_path(path: Path) -> List[QueryArtifact]:
    if path.suffix.lower() == ".sql":
        return [_load_sql_file(path)]

    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".jsonl":
        items = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        payload = json.loads(text)
        if isinstance(payload, dict):
            items = payload.get("queries") or payload.get("items") or []
        elif isinstance(payload, list):
            items = payload
        else:
            items = []

    artifacts: List[QueryArtifact] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        artifacts.append(
            QueryArtifact(
                sql=str(item.get("sql") or item.get("expected_sql") or "").strip(),
                question=str(item.get("question") or item.get("prompt") or "").strip(),
                title=str(item.get("title") or "").strip(),
                description=str(item.get("description") or "").strip(),
                tags=tuple(str(tag).strip() for tag in item.get("tags", []) if str(tag).strip()),
                source=f"{path.name}#{idx + 1}",
            )
        )
    return artifacts


def _load_sql_file(path: Path) -> QueryArtifact:
    headers: Dict[str, str] = {}
    sql_lines: List[str] = []
    in_header = True
    for line in path.read_text(encoding="utf-8").splitlines():
        if in_header and line.strip().startswith("--"):
            match = _HEADER_RE.match(line)
            if match:
                headers[match.group(1).strip().lower()] = match.group(2).strip()
            continue
        if in_header and not line.strip():
            continue
        in_header = False
        sql_lines.append(line)

    tags = tuple(
        token.strip()
        for token in headers.get("tags", "").split(",")
        if token.strip()
    )
    return QueryArtifact(
        sql="\n".join(sql_lines).strip(),
        question=headers.get("question", ""),
        title=headers.get("title", ""),
        description=headers.get("description", ""),
        tags=tags,
        source=path.name,
    )


def _extract_tables(parsed: E.Expression) -> tuple[set[str], dict[str, str]]:
    tables: set[str] = set()
    alias_map: dict[str, str] = {}
    for table in parsed.find_all(E.Table):
        table_name = _qualify_table(table)
        if not table_name:
            continue
        tables.add(table_name)
        alias_map[table.alias_or_name.upper()] = table_name
        alias_map[table.name.upper()] = table_name
    return tables, alias_map


def _extract_relationships(
    parsed: E.Expression,
    alias_map: Dict[str, str],
    pk_map: Dict[str, set[str]],
) -> List[tuple[str, str, str, str]]:
    relationships: List[tuple[str, str, str, str]] = []
    for eq in parsed.find_all(E.EQ):
        left = eq.left
        right = eq.right
        if not isinstance(left, E.Column) or not isinstance(right, E.Column):
            continue
        left_ref = _resolve_column(left, alias_map)
        right_ref = _resolve_column(right, alias_map)
        if not left_ref or not right_ref or left_ref[0] == right_ref[0]:
            continue
        relationships.append(_orient_relationship(left_ref, right_ref, pk_map))
    return relationships


def _resolve_column(column: E.Column, alias_map: Dict[str, str]) -> tuple[str, str] | None:
    table = alias_map.get((column.table or "").upper())
    if not table and len({name for name in alias_map.values()}) == 1:
        table = next(iter(alias_map.values()))
    if not table:
        return None
    return table, column.name.upper()


def _orient_relationship(
    left: tuple[str, str],
    right: tuple[str, str],
    pk_map: Dict[str, set[str]],
) -> tuple[str, str, str, str]:
    left_table, left_column = left
    right_table, right_column = right
    left_pk = left_column in pk_map.get(left_table, set())
    right_pk = right_column in pk_map.get(right_table, set())

    if left_pk and not right_pk:
        return right_table, right_column, left_table, left_column
    if right_pk and not left_pk:
        return left_table, left_column, right_table, right_column
    if left_column.endswith("_ID") and not right_column.endswith("_ID"):
        return left_table, left_column, right_table, right_column
    if right_column.endswith("_ID") and not left_column.endswith("_ID"):
        return right_table, right_column, left_table, left_column
    return left_table, left_column, right_table, right_column


def _artifact_tokens(artifact: QueryArtifact) -> List[str]:
    parts = [artifact.question, artifact.title, artifact.description, " ".join(artifact.tags)]
    seen: set[str] = set()
    tokens: List[str] = []
    for part in parts:
        for token in _tokenize_terms(part):
            if token not in seen:
                tokens.append(token)
                seen.add(token)
    return tokens


def _tokenize_terms(text: str) -> List[str]:
    terms: List[str] = []
    for raw in _TOKEN_RE.findall((text or "").replace("/", " ").replace("-", " ")):
        raw = raw.strip().lower()
        if not raw:
            continue
        candidates = {raw}
        if "_" in raw:
            candidates.update(piece for piece in raw.split("_") if piece)
        candidates.update(_strip_korean_suffixes(raw))
        if raw.endswith("s") and len(raw) > 3:
            candidates.add(raw[:-1])
        for candidate in candidates:
            candidate = candidate.strip().lower()
            if len(candidate) < 2 or candidate in _STOPWORDS:
                continue
            if candidate not in terms:
                terms.append(candidate)
    return terms


def _strip_korean_suffixes(token: str) -> set[str]:
    values = {token}
    for suffix in _KOREAN_SUFFIXES:
        if token.endswith(suffix) and len(token) - len(suffix) >= 2:
            values.add(token[: -len(suffix)])
    return values


def _pk_columns(base_metadata: Dict[str, Any]) -> Dict[str, set[str]]:
    pk_map: Dict[str, set[str]] = {}
    for table_name, table_meta in (base_metadata.get("tables") or {}).items():
        pk_map[str(table_name).upper()] = {
            str(column_name).upper()
            for column_name, column_meta in (table_meta.get("columns") or {}).items()
            if isinstance(column_meta, dict) and column_meta.get("is_pk")
        }
    return pk_map


def _qualify_table(table: E.Table) -> str:
    parts = [part for part in (table.catalog, table.db, table.name) if part]
    return ".".join(str(part).upper() for part in parts if str(part).strip())


def _union_unique(existing: Iterable[str], new_values: Iterable[str]) -> List[str]:
    merged: List[str] = []
    seen: set[str] = set()
    for value in list(existing) + list(new_values):
        rendered = str(value).strip()
        if not rendered:
            continue
        key = rendered.lower()
        if key in seen:
            continue
        seen.add(key)
        merged.append(rendered)
    return merged


def _has_value(value: Any) -> bool:
    return bool(str(value or "").strip())


def _humanize_identifier(name: str) -> str:
    parts = [part for part in re.split(r"[._]+", str(name).upper()) if part]
    humanized: List[str] = []
    for part in parts:
        expanded = _COLUMN_TERM_MAP.get(part, part.lower())
        humanized.append(expanded if expanded.isupper() else expanded.replace("_", " "))
    return " ".join(humanized).strip().capitalize()


def _describe_column(column_name: str) -> str:
    base = str(column_name).upper()
    parts = [_COLUMN_TERM_MAP.get(part, part.lower()) for part in base.split("_") if part]
    if not parts:
        return ""
    description = " ".join(parts)
    return description[:1].upper() + description[1:]
