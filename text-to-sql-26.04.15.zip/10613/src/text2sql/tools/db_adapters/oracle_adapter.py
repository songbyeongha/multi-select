"""
Oracle Adapter — 운영 환경용 (python-oracledb)
==============================================
ALL_TABLES / ALL_TAB_COLUMNS / ALL_CONSTRAINTS 등 Oracle 메타뷰 기반.
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any, Dict, List, Optional

from .base import DBAdapter, ColumnInfo, ForeignKey, TableMeta

logger = logging.getLogger(__name__)

try:
    import oracledb
    _HAS_ORACLEDB = True
except ImportError:
    _HAS_ORACLEDB = False



class OracleAdapter(DBAdapter):
    """Oracle DB adapter (python-oracledb thin/thick mode)."""

    def __init__(
        self,
        *,
        host: str = "localhost",
        port: int = 1521,
        service_name: str = "",
        dsn: str = "",
        user: str = "",
        password: str = "",
        schema: str = "",
        connect_timeout_sec: int = 10,
        query_timeout_ms: int = 15000,
        fetch_size: int = 1000,
        read_only: bool = True,
    ):
        if not _HAS_ORACLEDB:
            raise ImportError(
                "python-oracledb 패키지가 필요합니다: pip install oracledb"
            )

        self._user = user
        self._password = password
        self._schema = schema.upper() if schema else (user.upper() if user else "")
        self._connect_timeout = connect_timeout_sec
        self._query_timeout_ms = query_timeout_ms
        self._fetch_size = fetch_size
        self._read_only = read_only

        # DSN 구성
        if dsn:
            self._dsn = dsn
        else:
            self._dsn = oracledb.makedsn(host, port, service_name=service_name)

        self._conn: Optional[oracledb.Connection] = None

    @property
    def dialect(self) -> str:
        return "oracle"

    @property
    def owner(self) -> str:
        return self._schema

    # ── 내부 연결 관리 ──────────────────────────────────
    def _get_conn(self) -> oracledb.Connection:
        if self._conn is None or not self._is_alive():
            self._conn = oracledb.connect(
                user=self._user,
                password=self._password,
                dsn=self._dsn,
                tcp_connect_timeout=self._connect_timeout,
            )
            if self._read_only:
                self._conn.autocommit = False
        return self._conn

    def _is_alive(self) -> bool:
        try:
            self._conn.ping()
            return True
        except Exception:
            return False

    # ── 연결 테스트 ──────────────────────────────────────
    def test_connection(self) -> Dict[str, Any]:
        try:
            conn = self._get_conn()
            cur = conn.cursor()
            cur.execute("SELECT USER, SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL")
            row = cur.fetchone()
            user, schema = row[0], row[1]

            # 읽기 가능한 테이블 수
            cur.execute(
                "SELECT COUNT(*) FROM ALL_TABLES WHERE OWNER = :owner",
                {"owner": self._schema or user},
            )
            table_count = cur.fetchone()[0]

            # 메타뷰 접근 확인
            meta_ok = True
            try:
                cur.execute("SELECT 1 FROM ALL_TAB_COLUMNS WHERE ROWNUM = 1")
                cur.fetchone()
            except Exception:
                meta_ok = False

            cur.close()
            return {
                "ok": True,
                "user": user,
                "schema": schema,
                "table_count": table_count,
                "metadata_accessible": meta_ok,
                "message": (
                    f"Oracle 연결 성공 - user={user}, schema={schema}, "
                    f"테이블 {table_count}개, 메타뷰 {'접근 가능' if meta_ok else '접근 불가'}"
                ),
            }
        except Exception as e:
            return {"ok": False, "message": f"Oracle 연결 실패: {e}"}

    # ── 스키마 조회 ──────────────────────────────────────
    def list_tables(self) -> List[str]:
        conn = self._get_conn()
        cur = conn.cursor()
        owner = self._schema
        sql = """
            SELECT table_name FROM ALL_TABLES WHERE OWNER = :owner
            UNION
            SELECT view_name FROM ALL_VIEWS WHERE OWNER = :owner
            ORDER BY 1
        """
        try:
            cur.execute(sql, {"owner": owner})
            return [r[0] for r in cur.fetchall()]
        except oracledb.DatabaseError:
            # ALL_* 권한 부족 시 USER_* fallback
            cur.execute(
                "SELECT table_name FROM USER_TABLES "
                "UNION SELECT view_name FROM USER_VIEWS ORDER BY 1"
            )
            return [r[0] for r in cur.fetchall()]
        finally:
            cur.close()

    def table_info(self, table: str) -> TableMeta:
        conn = self._get_conn()
        owner = self._schema
        table_upper = table.upper()

        # 컬럼 정보 + 코멘트
        columns = self._fetch_columns(conn, owner, table_upper)

        # PK 컬럼
        pk_cols = self._fetch_pk_columns(conn, owner, table_upper)
        for c in columns:
            if c.name in pk_cols:
                c.is_pk = True

        # FK 정보
        fks = self._fetch_fks(conn, owner, table_upper)

        # 코멘트
        col_comments = self._fetch_column_comments(conn, owner, table_upper)
        for c in columns:
            if c.name in col_comments:
                c.comment = col_comments[c.name]

        table_comment = self._fetch_table_comment(conn, owner, table_upper)

        # 샘플 행
        samples = self._fetch_samples(conn, owner, table_upper, limit=3)

        return TableMeta(
            table_name=table,
            columns=columns,
            foreign_keys=fks,
            sample_rows=samples,
            comment=table_comment,
        )

    # ── 쿼리 실행 ────────────────────────────────────────
    _DML_DDL_RE = re.compile(
        r"^\s*(?:/\*.*?\*/\s*)*(?:--[^\n]*\n\s*)*"
        r"(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|EXECUTE|EXEC)\b",
        re.I | re.S,
    )

    def execute(self, sql: str, *, limit: int = 50,
                timeout_ms: int | None = None) -> Dict[str, Any]:
        timeout = timeout_ms or self._query_timeout_ms
        conn = self._get_conn()
        t0 = time.time()

        # 읽기 전용 보장: 주석을 건너뛰고 DML/DDL 감지
        m = self._DML_DDL_RE.match(sql)
        if m:
            return {
                "ok": False, "rows": [], "row_count": 0,
                "exec_ms": 0.0, "error_type": "SAFETY",
                "error_message": f"읽기 전용 모드: {m.group(1).upper()} 실행 차단",
            }

        cur = None
        try:
            cur = conn.cursor()
            cur.arraysize = self._fetch_size

            # Oracle call timeout (밀리초)
            cur.callTimeout = timeout

            cur.execute(sql.strip().rstrip(";"))
            if cur.description is None:
                return {
                    "ok": False, "rows": [], "row_count": 0,
                    "exec_ms": (time.time() - t0) * 1000,
                    "error_type": "SAFETY",
                    "error_message": "SELECT 문이 아닙니다.",
                }

            col_names = [d[0] for d in cur.description]
            fetched = cur.fetchmany(limit)
            rows = [dict(zip(col_names, row)) for row in fetched]

            remaining = 0
            if len(rows) == limit:
                while True:
                    batch = cur.fetchmany(1000)
                    if not batch:
                        break
                    remaining += len(batch)

            total_rows = len(rows) + remaining
            ms = (time.time() - t0) * 1000
            return {
                "ok": True, "rows": rows, "row_count": total_rows,
                "exec_ms": ms, "error_type": None, "error_message": None,
            }
        except Exception as e:
            msg = str(e).lower()
            if "ora-00942" in msg or "ora-00904" in msg:
                etype = "SCHEMA"
            elif "ora-00933" in msg or "ora-00907" in msg:
                etype = "SYNTAX"
            elif "ora-01013" in msg or "timeout" in msg:
                etype = "TIMEOUT"
            else:
                etype = "RUNTIME"
            return {
                "ok": False, "rows": [], "row_count": 0,
                "exec_ms": (time.time() - t0) * 1000,
                "error_type": etype, "error_message": str(e),
            }
        finally:
            if cur:
                cur.close()

    @staticmethod
    def _safe_ident(name: str) -> str:
        """식별자 정규화: 큰따옴표 제거 후 f-string에서 재인용하여 사용."""
        return name.replace('"', '')

    def _sample_values_sql(self, table: str, column: str, limit: int) -> str:
        owner = self._safe_ident(self._schema)
        table = self._safe_ident(table)
        column = self._safe_ident(column)
        return (
            f'SELECT DISTINCT "{column}" FROM "{owner}"."{table}" '
            f'WHERE "{column}" IS NOT NULL AND ROWNUM <= {limit}'
        )

    # ── 내부 메타 조회 헬퍼 ──────────────────────────────
    def _fetch_columns(self, conn, owner: str, table: str) -> List[ColumnInfo]:
        cur = conn.cursor()
        sql = """
            SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_LENGTH, DATA_PRECISION, DATA_SCALE
            FROM ALL_TAB_COLUMNS
            WHERE OWNER = :owner AND TABLE_NAME = :tbl
            ORDER BY COLUMN_ID
        """
        try:
            cur.execute(sql, {"owner": owner, "tbl": table})
            rows = cur.fetchall()
        except oracledb.DatabaseError:
            cur.execute(
                "SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_LENGTH, "
                "DATA_PRECISION, DATA_SCALE "
                "FROM USER_TAB_COLUMNS WHERE TABLE_NAME = :tbl "
                "ORDER BY COLUMN_ID",
                {"tbl": table},
            )
            rows = cur.fetchall()
        finally:
            cur.close()

        columns = []
        for r in rows:
            name, dtype, nullable, length, precision, scale = r
            type_str = dtype
            if dtype in ("NUMBER",) and precision is not None:
                type_str = f"NUMBER({precision},{scale or 0})"
            elif dtype in ("VARCHAR2", "CHAR", "NVARCHAR2", "NCHAR"):
                type_str = f"{dtype}({length})"
            columns.append(ColumnInfo(
                name=name, type=type_str,
                nullable=(nullable == "Y"),
            ))
        return columns

    def _fetch_pk_columns(self, conn, owner: str, table: str) -> set:
        cur = conn.cursor()
        sql = """
            SELECT cc.COLUMN_NAME
            FROM ALL_CONSTRAINTS c
            JOIN ALL_CONS_COLUMNS cc ON c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME
                AND c.OWNER = cc.OWNER
            WHERE c.OWNER = :owner AND c.TABLE_NAME = :tbl
              AND c.CONSTRAINT_TYPE = 'P'
        """
        try:
            cur.execute(sql, {"owner": owner, "tbl": table})
            result = {r[0] for r in cur.fetchall()}
        except oracledb.DatabaseError:
            cur.execute(
                "SELECT cc.COLUMN_NAME "
                "FROM USER_CONSTRAINTS c "
                "JOIN USER_CONS_COLUMNS cc ON c.CONSTRAINT_NAME = cc.CONSTRAINT_NAME "
                "WHERE c.TABLE_NAME = :tbl AND c.CONSTRAINT_TYPE = 'P'",
                {"tbl": table},
            )
            result = {r[0] for r in cur.fetchall()}
        finally:
            cur.close()
        return result

    def _fetch_fks(self, conn, owner: str, table: str) -> List[ForeignKey]:
        cur = conn.cursor()
        sql = """
            SELECT a.COLUMN_NAME, c_pk.TABLE_NAME, b.COLUMN_NAME
            FROM ALL_CONS_COLUMNS a
            JOIN ALL_CONSTRAINTS c ON a.CONSTRAINT_NAME = c.CONSTRAINT_NAME
                AND a.OWNER = c.OWNER
            JOIN ALL_CONSTRAINTS c_pk ON c.R_CONSTRAINT_NAME = c_pk.CONSTRAINT_NAME
                AND c.R_OWNER = c_pk.OWNER
            JOIN ALL_CONS_COLUMNS b ON c_pk.CONSTRAINT_NAME = b.CONSTRAINT_NAME
                AND c_pk.OWNER = b.OWNER AND a.POSITION = b.POSITION
            WHERE c.OWNER = :owner AND c.TABLE_NAME = :tbl
              AND c.CONSTRAINT_TYPE = 'R'
            ORDER BY a.POSITION
        """
        try:
            cur.execute(sql, {"owner": owner, "tbl": table})
            rows = cur.fetchall()
        except oracledb.DatabaseError:
            cur.execute(
                "SELECT a.COLUMN_NAME, c_pk.TABLE_NAME, b.COLUMN_NAME "
                "FROM USER_CONS_COLUMNS a "
                "JOIN USER_CONSTRAINTS c ON a.CONSTRAINT_NAME = c.CONSTRAINT_NAME "
                "JOIN USER_CONSTRAINTS c_pk ON c.R_CONSTRAINT_NAME = c_pk.CONSTRAINT_NAME "
                "JOIN USER_CONS_COLUMNS b ON c_pk.CONSTRAINT_NAME = b.CONSTRAINT_NAME "
                "  AND a.POSITION = b.POSITION "
                "WHERE c.TABLE_NAME = :tbl AND c.CONSTRAINT_TYPE = 'R' "
                "ORDER BY a.POSITION",
                {"tbl": table},
            )
            rows = cur.fetchall()
        finally:
            cur.close()

        return [ForeignKey(from_column=r[0], to_table=r[1], to_column=r[2])
                for r in rows]

    def _fetch_column_comments(self, conn, owner: str, table: str) -> Dict[str, str]:
        cur = conn.cursor()
        try:
            cur.execute(
                "SELECT COLUMN_NAME, COMMENTS FROM ALL_COL_COMMENTS "
                "WHERE OWNER = :owner AND TABLE_NAME = :tbl AND COMMENTS IS NOT NULL",
                {"owner": owner, "tbl": table},
            )
            rows = cur.fetchall()
        except oracledb.DatabaseError:
            cur.execute(
                "SELECT COLUMN_NAME, COMMENTS FROM USER_COL_COMMENTS "
                "WHERE TABLE_NAME = :tbl AND COMMENTS IS NOT NULL",
                {"tbl": table},
            )
            rows = cur.fetchall()
        finally:
            cur.close()
        return {r[0]: r[1] for r in rows}

    def _fetch_table_comment(self, conn, owner: str, table: str) -> str:
        cur = conn.cursor()
        try:
            cur.execute(
                "SELECT COMMENTS FROM ALL_TAB_COMMENTS "
                "WHERE OWNER = :owner AND TABLE_NAME = :tbl",
                {"owner": owner, "tbl": table},
            )
            row = cur.fetchone()
        except oracledb.DatabaseError:
            cur.execute(
                "SELECT COMMENTS FROM USER_TAB_COMMENTS WHERE TABLE_NAME = :tbl",
                {"tbl": table},
            )
            row = cur.fetchone()
        finally:
            cur.close()
        return (row[0] or "") if row else ""

    def _fetch_samples(self, conn, owner: str, table: str,
                       limit: int = 3) -> List[Dict[str, Any]]:
        cur = conn.cursor()
        safe_owner = self._safe_ident(owner)
        safe_table = self._safe_ident(table)
        try:
            cur.execute(
                f'SELECT * FROM "{safe_owner}"."{safe_table}" WHERE ROWNUM <= :lim',
                {"lim": limit},
            )
            if cur.description:
                names = [d[0] for d in cur.description]
                return [dict(zip(names, row)) for row in cur.fetchall()]
        except Exception as e:
            logger.debug(f"샘플 조회 실패 ({owner}.{table}): {e}")
        finally:
            cur.close()
        return []

    def close(self) -> None:
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None
