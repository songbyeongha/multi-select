"""
DB Adapter Layer — dialect별 DB 접속·스키마 조회·쿼리 실행 추상화
================================================================
지원 dialect:
  - sqlite  : 로컬 개발
  - oracle  : 운영 환경 (python-oracledb)
"""
from .base import DBAdapter
from .factory import get_adapter

__all__ = ["DBAdapter", "get_adapter"]
