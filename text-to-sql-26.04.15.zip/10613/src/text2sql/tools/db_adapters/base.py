"""
DBAdapter 추상 베이스 클래스
===========================
dialect마다 하나씩 구현한다.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ColumnInfo:
    name: str
    type: str
    nullable: bool = True
    is_pk: bool = False
    comment: str = ""


@dataclass
class ForeignKey:
    from_column: str
    to_table: str
    to_column: str


@dataclass
class TableMeta:
    table_name: str
    columns: List[ColumnInfo] = field(default_factory=list)
    foreign_keys: List[ForeignKey] = field(default_factory=list)
    sample_rows: List[Dict[str, Any]] = field(default_factory=list)
    comment: str = ""

    def to_legacy_dict(self) -> Dict[str, Any]:
        """기존 SchemaReader 출력 형식과 호환되는 dict 반환."""
        return {
            "table_name": self.table_name,
            "columns": [
                {"name": c.name, "type": c.type,
                 "notnull": not c.nullable, "pk": c.is_pk}
                for c in self.columns
            ],
            "foreign_keys": [
                {"from": fk.from_column, "to_table": fk.to_table,
                 "to_column": fk.to_column}
                for fk in self.foreign_keys
            ],
            "sample_rows": self.sample_rows,
        }


class DBAdapter(ABC):
    """dialect-agnostic DB 접속 인터페이스."""

    @property
    @abstractmethod
    def dialect(self) -> str:
        """sqlglot dialect name (sqlite, oracle …)."""

    # ── 연결 ──────────────────────────────────────────────
    @abstractmethod
    def test_connection(self) -> Dict[str, Any]:
        """연결 테스트 결과 반환. keys: ok, user, schema, message."""

    # ── 스키마 조회 ──────────────────────────────────────
    @abstractmethod
    def list_tables(self) -> List[str]:
        """테이블/뷰 이름 목록."""

    @abstractmethod
    def table_info(self, table: str) -> TableMeta:
        """단일 테이블 메타데이터."""

    def full_schema(self) -> List[Dict[str, Any]]:
        """전체 스키마를 legacy dict 리스트로 반환."""
        return [self.table_info(t).to_legacy_dict() for t in self.list_tables()]

    # ── 쿼리 실행 ────────────────────────────────────────
    @abstractmethod
    def execute(self, sql: str, *, limit: int = 50,
                timeout_ms: int = 15000) -> Dict[str, Any]:
        """
        SELECT 쿼리 실행.
        Returns: {"ok": bool, "rows": list[dict], "row_count": int,
                  "exec_ms": float, "error_type": str|None,
                  "error_message": str|None}
        """

    # ── 샘플 값 조회 ────────────────────────────────────
    def sample_values(self, table: str, column: str,
                      limit: int = 5) -> List[Any]:
        """특정 컬럼의 대표 값 조회."""
        sql = self._sample_values_sql(table, column, limit)
        result = self.execute(sql, limit=limit)
        if result["ok"] and result["rows"]:
            return [list(r.values())[0] for r in result["rows"]]
        return []

    def _sample_values_sql(self, table: str, column: str, limit: int) -> str:
        """dialect별 샘플 조회 SQL. 하위 클래스가 오버라이드 가능."""
        return f"SELECT DISTINCT {column} FROM {table} WHERE {column} IS NOT NULL"

    # ── 유틸리티 ────────────────────────────────────────
    @abstractmethod
    def close(self) -> None:
        """연결 자원 정리."""

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
