"""
Adapter Factory — Oracle DBAdapter 반환
========================================
"""
from __future__ import annotations

import logging
from typing import Optional

from .base import DBAdapter

logger = logging.getLogger(__name__)

# 싱글톤 캐시
_adapters: dict[str, DBAdapter] = {}


def get_adapter(
    db_id: str = "",
    *,
    dialect: str | None = None,
    force_new: bool = False,
) -> DBAdapter:
    """
    Oracle DBAdapter를 생성·반환한다.

    Args:
        db_id: DB 식별자 (캐시 키)
        dialect: 무시됨 (Oracle 전용)
        force_new: True이면 캐시 무시
    """
    from ...config.settings import get_settings

    settings = get_settings()
    cache_key = f"oracle:{db_id or 'default'}"
    if not force_new and cache_key in _adapters:
        return _adapters[cache_key]

    from .oracle_adapter import OracleAdapter
    db_cfg = settings.db
    adapter: DBAdapter = OracleAdapter(
        host=db_cfg.host,
        port=db_cfg.port,
        service_name=db_cfg.service_name,
        dsn=db_cfg.dsn,
        user=db_cfg.user,
        password=db_cfg.password,
        schema=db_cfg.schema,
        connect_timeout_sec=db_cfg.connect_timeout_sec,
        query_timeout_ms=settings.guard.timeout_ms,
        read_only=db_cfg.read_only,
    )

    _adapters[cache_key] = adapter
    logger.info(f"Oracle adapter 생성: id={db_id or 'default'}")
    return adapter


def reset_adapters() -> None:
    """모든 캐시된 adapter를 정리한다."""
    for adapter in _adapters.values():
        try:
            adapter.close()
        except Exception:
            pass
    _adapters.clear()
