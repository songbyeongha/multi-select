"""Candidate generation node."""
from __future__ import annotations
import json
import os
import re
import time as _time
from typing import Dict, List, Tuple
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

from ..lg.state import GraphState, SQLCandidate, ErrorType
from ..llm.client import get_llm
from ..llm import prompts as P
from ..memory.conversation import get_memory
from ._utils import trace, get_reference_sql

_HINTS_PATH = Path(__file__).resolve().parents[1] / "config" / "strategy_hints.json"

def _load_strategies() -> Dict[str, List[Tuple[str, str]]]:
    with open(_HINTS_PATH, "r", encoding="utf-8") as f:
        raw = json.load(f)
    return {k: [tuple(pair) for pair in v] for k, v in raw.items()}

_STRATEGIES = _load_strategies()


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[0-9a-z가-힣_]+", (text or "").lower()) if len(token) > 1}


def _select_few_shots(question: str, few_shots: List[Dict[str, str]], limit: int = 5) -> List[Dict[str, str]]:
    question_tokens = _tokenize(question)
    if not few_shots:
        return []
    if not question_tokens:
        return few_shots[:limit]

    def _score(item: Dict[str, str]) -> tuple[int, int, int]:
        tokens = _tokenize(item.get("question", ""))
        overlap = len(question_tokens & tokens)
        contains_exact_phrase = int(item.get("question", "") in question)
        contains_group_keyword = int(any(token in item.get("question", "") for token in ("별", "상위", "하위", "전년", "월별", "5분")))
        return (contains_exact_phrase, overlap, contains_group_keyword)

    ranked = sorted(few_shots, key=_score, reverse=True)
    return ranked[:limit]


def _pick_seed_few_shot(question: str, few_shots: List[Dict[str, str]]) -> tuple[Dict[str, str] | None, bool]:
    normalized = (question or "").strip().lower()
    if not normalized:
        return None, False

    for item in few_shots:
        if (item.get("question") or "").strip().lower() == normalized and item.get("sql"):
            return item, True

    question_tokens = _tokenize(question)
    if not question_tokens:
        return None, False

    best_item: Dict[str, str] | None = None
    best_overlap = 0
    for item in few_shots:
        item_tokens = _tokenize(item.get("question", ""))
        overlap = len(question_tokens & item_tokens)
        if overlap > best_overlap and overlap >= 4 and item.get("sql"):
            best_item = item
            best_overlap = overlap
    return best_item, False


# ═══════════════════════════════════════════════════════════════
# 5. CandidateGenerator ×N  (전략 분기)
# ═══════════════════════════════════════════════════════════════
def node_candidate_generator(state: GraphState) -> GraphState:
    _t0 = _time.time()
    trace(state, "CandidateGenerator", "SQL 후보 생성 시작")

    candidates: List[SQLCandidate] = []

    query_pattern = state.get("query_pattern", "simple")
    strategies = list(_STRATEGIES.get(query_pattern, _STRATEGIES["simple"]))

    if query_pattern != "set_operation":
        q_lower = state["question"].lower()
        _negation = (
            bool(re.search(r'\b(not|never|does not|did not|do not|have not|without)\b', q_lower))
            or any(kw in q_lower for kw in ['없는', '않는', '않은', '아닌', '제외', '빼고'])
        )
        _intersection = (
            bool(re.search(r'\b(both|and also)\b', q_lower))
            or any(kw in q_lower for kw in ['모두', '동시에', '이면서'])
        )
        if _negation:
            strategies.append(("except_bonus",
                "반드시 EXCEPT를 사용하세요. SELECT ... EXCEPT SELECT ... 형태로 작성. "
                "NOT IN/NOT EXISTS 사용 금지."))
        elif _intersection:
            strategies.append(("intersect_bonus",
                "반드시 INTERSECT를 사용하세요. SELECT ... INTERSECT SELECT ... 형태로 작성."))

    from ..config.settings import get_settings
    max_candidates = get_settings().pipeline.num_candidates
    benchmark_extra_candidates = os.getenv("T2SQL_BENCHMARK_EXTRA_CANDIDATES", "").strip().lower() in ("1", "true", "yes", "on")
    if query_pattern == "simple" and max_candidates > 2 and not benchmark_extra_candidates:
        max_candidates = 2
    strategies = strategies[:max_candidates]

    reference_sql = get_reference_sql(state["database_id"], query_pattern)

    from ..config.settings import get_settings as _gs
    _domain = _gs().domain_hints(state["database_id"])
    _few_shots = _domain.get("few_shot_examples", [])
    few_shot_text = ""
    if _few_shots:
        parts = []
        for fs in _select_few_shots(state["question"], _few_shots, limit=5):
            parts.append(f"-- Q: {fs['question']}\n{fs['sql']}")
        few_shot_text = "\n\n".join(parts)
        seed, exact_seed_match = _pick_seed_few_shot(state["question"], _few_shots)
        if seed:
            candidates.append(
                SQLCandidate(
                    sql=seed["sql"],
                    strategy="few_shot_seed",
                    confidence=0.98,
                    rationale=f"Seeded from learned example: {seed['question']}",
                )
            )
            trace(
                state,
                "CandidateGenerator",
                "few-shot seed candidate injected",
                {"question": seed["question"][:120]},
            )
            if exact_seed_match:
                _elapsed = round((_time.time() - _t0) * 1000)
                trace(
                    state,
                    "CandidateGenerator",
                    "exact few-shot match selected; skipping LLM generation",
                    {"elapsed_ms": _elapsed},
                )
                return {**state, "candidates": candidates}

    memory = get_memory()
    similar = memory.find_similar(
        state["question"], db_id=state["database_id"], threshold=0.5
    )
    if similar:
        memory_ref = (
            f"\n-- 이전 유사 질문의 성공 SQL 참고:\n"
            f"-- Q: {similar.question}\n"
            f"{similar.sql}"
        )
        reference_sql = (f"{reference_sql}\n\n{memory_ref}"
                         if reference_sql != "없음" else memory_ref)
        trace(state, "CandidateGenerator",
              f"메모리 유사 질문 발견: '{similar.question[:50]}...'")

    _use_fast = state.get("use_fast_only", False)

    # dialect 가이드 결정
    from ..config.settings import get_settings as _gs2
    _current_dialect = state.get("dialect") or _gs2().db.dialect
    _dialect_guide = P.get_dialect_guide(_current_dialect)

    # 피드백 기반 힌트 주입
    _feedback_hints = ""
    try:
        from ..feedback.learner import get_learner
        _fb_learner = get_learner()
        _neg_hint = _fb_learner.get_negative_hints(state["database_id"], state["question"])
        _pos_ref = _fb_learner.get_positive_references(state["database_id"], state["question"])
        if _pos_ref:
            reference_sql = (f"{reference_sql}\n\n{_pos_ref}"
                             if reference_sql != "없음" else _pos_ref)
            trace(state, "CandidateGenerator", "피드백 기반 성공 SQL 참고 주입")
        if _neg_hint:
            _feedback_hints = _neg_hint
            trace(state, "CandidateGenerator", "피드백 기반 오류 패턴 주의사항 주입")
    except Exception:
        pass

    def _generate_one(strategy_name: str, hint: str) -> SQLCandidate | None:
        prompt = P.COMPOSER_USR.format(
            current_date=state.get("current_date", "2024-01-01"),
            current_year=state.get("current_year", 2024),
            current_month=state.get("current_month", 1),
            dialect_guide=_dialect_guide,
            question=state["question"],
            intent=state.get("intent", ""),
            strategy=f"{strategy_name}: {hint}",
            query_pattern=query_pattern,
            reference_sql=reference_sql,
            few_shot_sql=few_shot_text,
            sub_questions=json.dumps(state.get("sub_questions", []),
                                     ensure_ascii=False),
            schema_text=state["schema_text"],
            join_plan="\n".join(state.get("join_plan", [])),
            extracted_values=json.dumps(state.get("extracted_values", {}),
                                        ensure_ascii=False),
        )
        if _feedback_hints:
            prompt += _feedback_hints
        try:
            from ..llm.client import get_llm_fast as _get_fast
            _llm = _get_fast() if _use_fast else get_llm()
            res = _llm.generate_json(prompt, system=P.COMPOSER_SYS,
                                       node_name="CandidateGenerator")
            sql = res.get("sql", "")
            if sql:
                return SQLCandidate(
                    sql=sql,
                    strategy=strategy_name,
                    confidence=res.get("confidence", 0.8),
                    rationale=res.get("reasoning", ""),
                )
        except Exception:
            pass
        return None

    with ThreadPoolExecutor(max_workers=len(strategies)) as executor:
        futures = {
            executor.submit(_generate_one, name, hint): name
            for name, hint in strategies
        }
        for future in as_completed(futures):
            strategy_name = futures[future]
            try:
                candidate = future.result()
                if candidate:
                    candidates.append(candidate)
                    trace(state, "CandidateGenerator",
                          f"[{strategy_name}] SQL 생성 완료 (패턴: {query_pattern})",
                          {"sql": candidate.sql[:300],
                           "confidence": candidate.confidence})
            except Exception as e:
                trace(state, "CandidateGenerator",
                      f"[{strategy_name}] 생성 실패: {e}")

    _elapsed = round((_time.time() - _t0) * 1000)
    from ..llm.client import get_llm_fast as _gf
    _gen_model = (_gf() if _use_fast else get_llm()).model_label
    trace(state, "CandidateGenerator",
          f"후보 {len(candidates)}개 생성 완료",
          {"elapsed_ms": _elapsed, "model": _gen_model})

    return {**state, "candidates": candidates}


# ═══════════════════════════════════════════════════════════════
# 6. SQLPostProcess — AST 기반 결정론적 후처리
# ═══════════════════════════════════════════════════════════════
def node_sql_postprocess(state: GraphState) -> GraphState:
    """
    CandidateGenerator가 생성한 SQL 후보에 결정론적 AST 변환을 적용.
    CAST 제거, alias 제거, LEFT→INNER JOIN, 방어적 패턴 제거.
    """
    candidates = state.get("candidates", [])
    changed = 0

    from ..tools.sql_postprocess import SQLPostProcessor
    from ..config.settings import get_settings as _gs3
    _pp_dialect = state.get("dialect") or _gs3().db.dialect
    processor = SQLPostProcessor()
    for candidate in candidates:
        original = candidate.sql
        candidate.sql = processor.process(candidate.sql, dialect=_pp_dialect)
        if candidate.sql != original:
            changed += 1

    if changed:
        trace(state, "SQLPostProcess",
              f"후보 {changed}/{len(candidates)}개 SQL 후처리 적용")
    else:
        trace(state, "SQLPostProcess", "변환 대상 없음")

    return {**state, "candidates": candidates}
