from .state import GraphState, new_state, ErrorType, ExecReport, SQLCandidate

def get_compiled_graph():
    from .graph import get_compiled_graph as _get
    return _get()
