"""
LLM 클라이언트 — Provider 추상화 (openai_compatible / azure_openai)
═══════════════════════════════════════════════════════════════════
운영 기본: openai_compatible + gpt-oss-120b
개발 호환: azure_openai

사용법:
    from ..llm.client import get_llm, get_llm_fast

    llm = get_llm()            # 메인 (CandidateGenerator, Repair, Judge)
    llm_fast = get_llm_fast()  # 보조 (Decomposer, Schema, UT, Summarizer)
"""
from __future__ import annotations
import json, os, re, logging, threading
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass
import httpx
from openai import OpenAI, AzureOpenAI
from ..config.settings import get_settings, LLMProviderCfg, LLMFastCfg

logger = logging.getLogger(__name__)


def use_environment_proxy() -> bool:
    value = os.getenv("T2SQL_USE_ENV_PROXY", "").strip().lower()
    return value in ("1", "true", "yes", "on")


def build_azure_openai_client(*, api_key: str, api_version: str, azure_endpoint: str) -> AzureOpenAI:
    http_client = httpx.Client(
        trust_env=use_environment_proxy(),
        timeout=httpx.Timeout(60.0, connect=15.0),
    )
    return AzureOpenAI(
        api_key=api_key,
        api_version=api_version,
        azure_endpoint=azure_endpoint,
        http_client=http_client,
    )


def build_openai_compatible_client(*, base_url: str, api_key: str,
                                    timeout_sec: int = 60) -> OpenAI:
    http_client = httpx.Client(
        trust_env=use_environment_proxy(),
        timeout=httpx.Timeout(float(timeout_sec), connect=15.0),
    )
    return OpenAI(
        base_url=base_url,
        api_key=api_key,
        http_client=http_client,
    )


class OllamaNativeClient:
    """Ollama /api/chat 직접 호출 클라이언트.

    Ollama의 /v1 OpenAI-compatible 엔드포인트가 일부 모델(Qwen3 등)에서
    빈 응답을 반환하는 문제가 있어 native API를 사용한다.
    """

    def __init__(self, base_url: str = "http://localhost:11434",
                 timeout_sec: int = 120):
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout_sec

    class _Completions:
        def __init__(self, client: "OllamaNativeClient"):
            self._client = client

        def create(self, *, model: str, messages: list, **kwargs):
            import urllib.request
            url = f"{self._client._base_url}/api/chat"
            body = {
                "model": model,
                "messages": messages,
                "stream": False,
                "options": {},
            }
            if "temperature" in kwargs:
                body["options"]["temperature"] = kwargs["temperature"]
            req = urllib.request.Request(
                url,
                data=json.dumps(body).encode("utf-8"),
                headers={"Content-Type": "application/json"},
            )
            with urllib.request.urlopen(req, timeout=self._client._timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))

            content = data.get("message", {}).get("content", "")
            prompt_tokens = data.get("prompt_eval_count", 0)
            completion_tokens = data.get("eval_count", 0)

            class _Usage:
                pass
            usage = _Usage()
            usage.prompt_tokens = prompt_tokens
            usage.completion_tokens = completion_tokens
            usage.total_tokens = prompt_tokens + completion_tokens

            class _Message:
                pass
            msg = _Message()
            msg.content = content

            class _Choice:
                pass
            choice = _Choice()
            choice.message = msg

            class _Response:
                pass
            response = _Response()
            response.choices = [choice]
            response.usage = usage
            return response

    class _Chat:
        def __init__(self, client: "OllamaNativeClient"):
            self.completions = OllamaNativeClient._Completions(client)

    @property
    def chat(self):
        return OllamaNativeClient._Chat(self)


# ═══════════════════════════════════════════════════════════════
# 토큰 사용량 추적
# ═══════════════════════════════════════════════════════════════
@dataclass
class TokenRecord:
    node: str
    model: str
    label: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class TokenAccumulator:

    def __init__(self):
        self._lock = threading.Lock()
        self._records: List[TokenRecord] = []

    def record(self, rec: TokenRecord):
        with self._lock:
            self._records.append(rec)

    def reset(self):
        with self._lock:
            self._records.clear()

    def summary(self) -> Dict[str, Any]:
        with self._lock:
            total_prompt = sum(r.prompt_tokens for r in self._records)
            total_completion = sum(r.completion_tokens for r in self._records)
            by_model: Dict[str, Dict[str, Any]] = {}
            for r in self._records:
                key = r.model
                if key not in by_model:
                    by_model[key] = {"prompt_tokens": 0, "completion_tokens": 0,
                                     "total_tokens": 0, "calls": 0}
                by_model[key]["prompt_tokens"] += r.prompt_tokens
                by_model[key]["completion_tokens"] += r.completion_tokens
                by_model[key]["total_tokens"] += r.total_tokens
                by_model[key]["calls"] += 1
            total_cost = sum(
                _calculate_cost(r.model, r.prompt_tokens, r.completion_tokens)
                for r in self._records
            )
            for mk, mv in by_model.items():
                mv["cost_usd"] = _calculate_cost(
                    mk, mv["prompt_tokens"], mv["completion_tokens"])
            return {
                "total_prompt_tokens": total_prompt,
                "total_completion_tokens": total_completion,
                "total_tokens": total_prompt + total_completion,
                "total_calls": len(self._records),
                "total_cost_usd": total_cost,
                "by_model": by_model,
            }


_MODEL_PRICING = {
    "gpt-5":        (10.00, 30.00),
    "gpt-4.1":      (2.00,  8.00),
    "gpt-4.1-mini": (0.40,  1.60),
    "gpt-4.1-nano": (0.10,  0.40),
    "gpt-4o":       (2.50,  10.00),
    "gpt-4o-mini":  (0.15,  0.60),
    "o1":           (15.00, 60.00),
    "o3":           (10.00, 40.00),
    "o4-mini":      (1.10,  4.40),
    "gpt-oss-120b": (0.00,  0.00),
}


def _calculate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    model_lower = model.lower()
    pricing = None
    for key in sorted(_MODEL_PRICING, key=len, reverse=True):
        if key in model_lower:
            pricing = _MODEL_PRICING[key]
            break
    if pricing is None:
        pricing = (2.50, 10.00)
    return (prompt_tokens / 1_000_000) * pricing[0] + \
           (completion_tokens / 1_000_000) * pricing[1]


_token_local = threading.local()


def get_token_accumulator() -> TokenAccumulator:
    accumulator = getattr(_token_local, "accumulator", None)
    if accumulator is None:
        accumulator = TokenAccumulator()
        _token_local.accumulator = accumulator
    return accumulator


class LLMClient:
    """Provider-agnostic Chat Completions wrapper."""

    def __init__(
        self,
        cfg: Optional[Union[LLMProviderCfg, LLMFastCfg]] = None,
        *,
        label: str = "primary",
    ):
        settings = get_settings()
        provider = settings.llm_provider.provider

        if isinstance(cfg, LLMProviderCfg):
            self._init_from_provider_cfg(cfg, provider, label)
        elif isinstance(cfg, LLMFastCfg):
            self._init_from_fast_cfg(cfg, provider, label)
        elif cfg is None:
            self._init_from_provider_cfg(settings.llm_provider, provider, label)
        else:
            self._init_from_provider_cfg(settings.llm_provider, provider, label)

    def _init_from_provider_cfg(self, cfg: LLMProviderCfg, provider: str, label: str):
        self._label = label
        self._temp = cfg.temperature
        self._max_tok = cfg.max_tokens

        if provider == "azure_openai":
            self._client = build_azure_openai_client(
                api_key=cfg.azure_api_key,
                api_version=cfg.azure_api_version,
                azure_endpoint=cfg.azure_endpoint,
            )
            self._deploy = cfg.azure_deployment
        else:
            self._deploy = cfg.model
            if self._is_ollama(cfg.base_url):
                self._client = OllamaNativeClient(
                    base_url=cfg.base_url.replace("/v1", ""),
                    timeout_sec=cfg.timeout_sec,
                )
            else:
                self._client = build_openai_compatible_client(
                    base_url=cfg.base_url,
                    api_key=cfg.api_key,
                    timeout_sec=cfg.timeout_sec,
                )

        self._setup_model_flags()

    def _init_from_fast_cfg(self, cfg: LLMFastCfg, provider: str, label: str):
        self._label = label
        self._temp = cfg.temperature
        self._max_tok = cfg.max_tokens

        if provider == "azure_openai":
            self._client = build_azure_openai_client(
                api_key=cfg.azure_api_key,
                api_version=cfg.azure_api_version,
                azure_endpoint=cfg.azure_endpoint,
            )
            self._deploy = cfg.azure_deployment
        else:
            self._deploy = cfg.model
            if self._is_ollama(cfg.base_url):
                self._client = OllamaNativeClient(
                    base_url=cfg.base_url.replace("/v1", ""),
                )
            else:
                self._client = build_openai_compatible_client(
                    base_url=cfg.base_url,
                    api_key=cfg.api_key,
                )

        self._setup_model_flags()

    @staticmethod
    def _is_ollama(base_url: str) -> bool:
        return "11434" in base_url or "ollama" in base_url.lower()

    def _setup_model_flags(self):
        deploy_lower = self._deploy.lower()
        self._use_completion_tokens = any(
            k in deploy_lower for k in ("gpt-5", "gpt-4.1", "gpt-4o", "o1", "o3", "o4")
        )
        self._supports_temperature = not any(
            k in deploy_lower for k in ("gpt-5", "o1", "o3", "o4")
        )
        if "gpt-oss" in deploy_lower:
            self._use_completion_tokens = False
            self._supports_temperature = True

    @property
    def model_label(self) -> str:
        return f"{self._label}({self._deploy})"

    def generate(self, prompt: str, *, system: str = "",
                 temperature: float | None = None,
                 max_tokens: int | None = None,
                 node_name: str = "") -> str:
        msgs = []
        if system:
            msgs.append({"role": "system", "content": system})
        # Qwen3 thinking 모드 비활성화
        if "qwen" in self._deploy.lower():
            prompt = prompt + " /no_think"
        msgs.append({"role": "user", "content": prompt})

        tok_value = max_tokens or self._max_tok

        params: Dict[str, Any] = {
            "model": self._deploy,
            "messages": msgs,
        }

        if self._supports_temperature:
            params["temperature"] = (
                temperature if temperature is not None else self._temp
            )

        if self._use_completion_tokens:
            params["max_completion_tokens"] = tok_value
        else:
            params["max_tokens"] = tok_value

        resp = self._client.chat.completions.create(**params)

        if resp.usage:
            get_token_accumulator().record(TokenRecord(
                node=node_name,
                model=self._deploy,
                label=self._label,
                prompt_tokens=resp.usage.prompt_tokens or 0,
                completion_tokens=resp.usage.completion_tokens or 0,
                total_tokens=resp.usage.total_tokens or 0,
            ))

        raw = resp.choices[0].message.content or ""
        return self._strip_thinking(raw).strip()

    @staticmethod
    def _strip_thinking(text: str) -> str:
        """Qwen3 등 thinking 모델의 <think>...</think> 태그를 제거한다."""
        return re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()

    def generate_json(self, prompt: str, *, system: str = "",
                      node_name: str = "") -> Dict[str, Any]:
        sys_msg = (system + "\n\n" if system else "") + (
            "반드시 유효한 JSON만 출력하세요. "
            "코드블록(```)이나 추가 설명 없이 순수 JSON만 출력하세요."
        )
        raw = self.generate(prompt, system=sys_msg, node_name=node_name)
        return self._parse_json(raw)

    @staticmethod
    def _parse_json(text: str) -> Dict[str, Any]:
        text = text.strip()
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        result = json.loads(text)
        if not isinstance(result, dict):
            raise ValueError(f"Expected JSON object, got {type(result).__name__}")
        return result


# ═══════════════════════════════════════════════════════════════
# 싱글톤
# ═══════════════════════════════════════════════════════════════
_llm_local = threading.local()


def get_llm() -> LLMClient:
    """메인 모델 — CandidateGenerator, Repair, Judge"""
    if not hasattr(_llm_local, "client"):
        _llm_local.client = LLMClient(get_settings().llm_provider, label="메인")
    return _llm_local.client


def get_llm_fast() -> LLMClient:
    """보조 모델 — Decomposer, SchemaSelector, JoinPlanner, UnitTester, ResultSummarizer"""
    if not hasattr(_llm_local, "client_fast"):
        _llm_local.client_fast = LLMClient(get_settings().llm_fast_cfg, label="보조")
    return _llm_local.client_fast


def reset_llm_clients() -> None:
    for attr in ("client", "client_fast"):
        if hasattr(_llm_local, attr):
            delattr(_llm_local, attr)
