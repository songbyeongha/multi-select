"""
대화 메모리  ──  이전 질문/SQL/결과를 기억하여 컨텍스트 제공
═══════════════════════════════════════════════════════════════
용도:
  1. 동일/유사 질문 재시도 시 이전 성공 SQL 참조
  2. 이전 실패 패턴 회피 (Repair 시 활용)
  3. 대화 흐름 유지 (후속 질문에 이전 컨텍스트 전달)
"""
from __future__ import annotations
import time
from typing import Optional, List
from dataclasses import dataclass, field


@dataclass
class MemoryEntry:
    """단일 대화 기억 항목"""
    question: str
    sql: str
    database_id: str
    success: bool
    summary: str
    row_count: int = 0
    tables_used: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)

    def to_context(self) -> str:
        """LLM 프롬프트용 컨텍스트 문자열로 변환"""
        status = "✅ 성공" if self.success else "❌ 실패"
        return (
            f"[{status}] Q: {self.question}\n"
            f"  DB: {self.database_id} | 테이블: {', '.join(self.tables_used)}\n"
            f"  SQL: {self.sql[:200]}{'...' if len(self.sql) > 200 else ''}\n"
            f"  결과: {self.summary[:100]}"
        )


class ConversationMemory:
    """
    세션 내 대화 메모리.
    최근 N건의 질문-응답 이력을 유지하며,
    유사 질문 검색 및 이전 컨텍스트 제공 기능을 담당합니다.
    """

    def __init__(self, max_entries: int = 20):
        self._entries: List[MemoryEntry] = []
        self._max = max_entries

    def save(self, question: str, sql: str, database_id: str,
             success: bool, summary: str, row_count: int = 0,
             tables_used: List[str] | None = None):
        """대화 결과를 메모리에 저장"""
        entry = MemoryEntry(
            question=question,
            sql=sql,
            database_id=database_id,
            success=success,
            summary=summary,
            row_count=row_count,
            tables_used=tables_used or [],
        )
        self._entries.append(entry)
        if len(self._entries) > self._max:
            self._entries = self._entries[-self._max:]

    def get_recent(self, n: int = 5, db_id: str | None = None,
                   success_only: bool = False) -> List[MemoryEntry]:
        """최근 N건의 메모리 항목 반환 (필터 가능)"""
        filtered = self._entries
        if db_id:
            filtered = [e for e in filtered if e.database_id == db_id]
        if success_only:
            filtered = [e for e in filtered if e.success]
        return filtered[-n:]

    def find_similar(self, question: str, db_id: str | None = None,
                     threshold: float = 0.5) -> Optional[MemoryEntry]:
        """
        유사한 이전 질문을 간단한 단어 겹침(Jaccard)으로 검색.
        정확한 시맨틱 매칭은 아니지만, 동일/거의 동일 질문에 대해
        이전 성공 SQL을 빠르게 참조할 수 있습니다.
        """
        q_tokens = set(question.lower().split())
        best_score = 0.0
        best_entry: Optional[MemoryEntry] = None

        candidates = self._entries
        if db_id:
            candidates = [e for e in candidates if e.database_id == db_id]

        for entry in reversed(candidates):  # 최근 항목 우선
            if not entry.success:
                continue
            e_tokens = set(entry.question.lower().split())
            if not q_tokens or not e_tokens:
                continue
            jaccard = len(q_tokens & e_tokens) / len(q_tokens | e_tokens)
            if jaccard > best_score:
                best_score = jaccard
                best_entry = entry

        return best_entry if best_score >= threshold else None

    def get_failed_patterns(self, db_id: str | None = None,
                            n: int = 3) -> List[str]:
        """최근 실패한 SQL 패턴 반환 (Repair 시 회피 목적)"""
        failed = [e for e in self._entries
                  if not e.success and (db_id is None or e.database_id == db_id)]
        return [e.sql for e in failed[-n:]]

    def get_context_string(self, db_id: str | None = None,
                           n: int = 3) -> str:
        """LLM 프롬프트에 삽입할 이전 대화 컨텍스트 문자열"""
        recent = self.get_recent(n=n, db_id=db_id)
        if not recent:
            return ""
        parts = ["[이전 대화 이력]"]
        for i, entry in enumerate(recent, 1):
            parts.append(f"{i}. {entry.to_context()}")
        return "\n".join(parts)

    def clear(self):
        """메모리 전체 초기화"""
        self._entries.clear()

    def size(self) -> int:
        """저장된 항목 수"""
        return len(self._entries)


# ═══════════════════════════════════════════════════════════════
# 싱글톤
# ═══════════════════════════════════════════════════════════════
_instance: Optional[ConversationMemory] = None


def get_memory() -> ConversationMemory:
    """대화 메모리 싱글톤"""
    global _instance
    if _instance is None:
        _instance = ConversationMemory()
    return _instance
