"""Helpers for loading, merging, and fingerprinting metadata payloads."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable


def load_json_file(path: Path | str) -> Dict[str, Any]:
    file_path = Path(path)
    if not file_path.exists():
        return {}
    return json.loads(file_path.read_text(encoding="utf-8"))


def get_db_scoped_entry(raw: Dict[str, Any], db_id: str) -> Dict[str, Any]:
    if not isinstance(raw, dict) or not raw:
        return {}
    databases = raw.get("databases")
    if isinstance(databases, dict):
        entry = databases.get(db_id, {})
        return entry if isinstance(entry, dict) else {}
    return raw


def deep_merge(base: Any, override: Any) -> Any:
    if isinstance(base, dict) and isinstance(override, dict):
        merged = dict(base)
        for key, value in override.items():
            if key in merged:
                merged[key] = deep_merge(merged[key], value)
            else:
                merged[key] = value
        return merged
    return override


def merge_db_entries(paths: Iterable[Path | str], db_id: str) -> Dict[str, Any]:
    merged: Dict[str, Any] = {}
    for path in paths:
        raw = load_json_file(path)
        scoped = get_db_scoped_entry(raw, db_id)
        if scoped:
            merged = deep_merge(merged, scoped)
    return merged


def sibling_overlay_path(path: Path | str, suffix: str = "_manual") -> Path:
    file_path = Path(path)
    return file_path.with_name(f"{file_path.stem}{suffix}{file_path.suffix}")


def generated_config_dir(config_dir: Path | str) -> Path:
    return Path(config_dir) / "generated"


def default_metadata_path(config_dir: Path | str, dialect: str = "oracle") -> Path:
    file_name = "schema_metadata_oracle.json" if dialect == "oracle" else "schema_metadata.json"
    return generated_config_dir(config_dir) / file_name


def default_domain_hints_path(config_dir: Path | str, dialect: str = "oracle") -> Path:
    file_name = "domain_hints_oracle.json" if dialect == "oracle" else "domain_hints.json"
    return generated_config_dir(config_dir) / file_name


def payload_fingerprint(payload: Any) -> str:
    canonical = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()
