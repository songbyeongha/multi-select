"""Text2SQL PoC  –  MAC-SQL 아키텍처 기반"""
__version__ = "1.0.0"
