# 작업 기록: 도메인 힌트 자동 갱신 효과 검증 및 가시화

---

### [요청]

도메인 힌트가 제대로 동작하는지 모르겠음.
로그로 나오는 것도 아니고 눈으로 확인하고 싶음.

제약 조건: 없음.

---

### [분석]

**현재 상태 파악**

| 항목 | 파일 | 가시화 수준 |
|------|------|------------|
| keyword_map 매칭 여부 | schema_rag.py `_kw_bonus()` | trace()로만 기록, 로그 없음 |
| few_shot exact match | generation_nodes.py | trace() "skipping LLM generation" 있음 |
| few_shot fuzzy match | generation_nodes.py | trace() "few-shot seed candidate injected" |
| common_patterns 적중 | _utils.py `get_reference_sql()` | **로그 전혀 없음** |
| 자동 갱신 (learner) | feedback/learner.py | logger.info + FeedbackLogger 있음 |

**문제 요약**

1. common_patterns 적중 시 로그 없음 → 파이프라인에서 사용됐는지 알 수 없음
2. keyword_map 매칭 디버그 로그 없음 → DEBUG 레벨 로그가 없어 확인 불가
3. 도메인 힌트 상태를 한눈에 확인하는 진단 명령어가 없음

**데이터 흐름 확인**

```
domain_hints_oracle.json (자동)  +  domain_hints_oracle_manual.json (수동/자동갱신)
                └─ merge_db_entries() → settings.domain_hints(db_id)
                        ├─ schema_nodes.py → SchemaSelector(keyword_map, relation_bonus)
                        ├─ generation_nodes.py → few_shot_examples 선택
                        └─ _utils.py → get_reference_sql() → common_patterns 조회
```

---

### [수정 내용]

**수정 파일 1: `scripts/check_domain_hints.py` (신규)**

진단 스크립트. Oracle 접속 없이 실행 가능.

- `--db-id <id>`: 파일 상태 + 필드 개수 요약 출력
- `--question "질문"`: 실제 파이프라인과 동일한 로직으로 시뮬레이션
  1. keyword_map 매칭 (SchemaSelector._tok() 동일 토크나이저 사용)
  2. relation_bonus_map 효과 (어떤 테이블이 부스트 받는지)
  3. few_shot_examples 매칭 (exact/fuzzy 구분, 상위 5개 목록)
  4. common_patterns 가용 패턴 (query_pattern별)
- `--show-all`: keyword_map / relation_bonus / few_shots / patterns 전체 출력

**수정 파일 2: `src/text2sql/tools/ops_gateway.py`**

`build_check_hints_command()` 함수 추가.

**수정 파일 3: `scripts/run_ops.py`**

`check-hints` 서브커맨드 추가.

```powershell
# 상태 확인
python scripts/run_ops.py check-hints --db-id oracle_prod

# 질문 시뮬레이션
python scripts/run_ops.py check-hints --db-id oracle_prod -q "이번 달 생산량은?"

# 전체 목록
python scripts/run_ops.py check-hints --db-id oracle_prod --show-all
```

**수정 파일 4: `src/text2sql/agents/_utils.py`**

- `import logging` + `logger = logging.getLogger(__name__)` 추가
- `get_reference_sql()`: common_patterns 적중 시 `logger.debug()` 추가
  ```
  [oracle_prod] common_patterns 적중: pattern=group_aggregate, keys=['fb_group_aggregate_monthly']
  ```

**수정 파일 5: `src/text2sql/rag/schema_rag.py`**

- `select()`: keyword_map 매칭 결과 `logger.debug()` 추가
  ```
  keyword_map 매칭: PROD_RESULT←[생산량,생산], FACTORY_MASTER←[공장]
  ```
  - `logger.isEnabledFor(logging.DEBUG)` 조건부로 성능 영향 최소화

---

### [사용 방법]

**상태 확인 (진단)**
```powershell
python scripts/run_ops.py check-hints --db-id oracle_prod
```

출력 예시:
```
════════════════════════════════════════════════════════════════
  도메인 힌트 진단 — oracle_prod
════════════════════════════════════════════════════════════════

[파일 상태]
  Primary : domain_hints_oracle.json       ✓  (12,345 bytes)
  Manual  : domain_hints_oracle_manual.json ✓  (2,890 bytes)

[현재 상태]
  keyword_map        :   847개 키워드 매핑
  relation_bonus_map :    23개 테이블 관계
  few_shot_examples  :     5개 예제
  common_patterns    :     3개 패턴
```

**질문 시뮬레이션**
```powershell
python scripts/run_ops.py check-hints --db-id oracle_prod -q "이번 달 공장별 생산량은?"
```

출력 예시:
```
[1. keyword_map 매칭]
  '생산량, 생산' → PROD_RESULT  (BM25 보너스 +4.0점)
  '공장' → FACTORY_MASTER  (BM25 보너스 +2.0점)

[2. relation_bonus_map 효과]
  PROD_ORDER  (+0.5점, PROD_RESULT 매칭으로 인해 부스트)

[3. few_shot_examples 매칭]
  ≈ FUZZY MATCH — seed 후보 주입 + LLM 생성 병행
    Q  : 이번 달 공장별 생산량 합계
    SQL: SELECT FACTORY_CD, SUM(PROD_QTY)...

[4. common_patterns]
  [fb_group_aggregate_monthly]
    -- 피드백 참고(fb_group_aggregate_monthly):
    TRUNC(TO_DATE(날짜컬럼, 'YYYYMMDD'), 'MM')
```

**로그 활성화 (DEBUG)**

`.env`에 추가:
```env
T2SQL_LOG_LEVEL=DEBUG
```

또는 실행 시:
```powershell
python scripts/run_cli.py -q "질문" 2>&1 | findstr "keyword_map\|common_patterns"
```
