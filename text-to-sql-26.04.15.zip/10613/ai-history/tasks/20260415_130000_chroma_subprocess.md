# 작업 기록: ChromaDB 별도 프로세스 격리

---

### [요청]

Chroma DB 쿼리는 별도 프로세스로 실행.
Chroma DB 호출 시 메모리 충돌이 발생하여 오류가 남.
오류가 발생하지 않도록 별도 프로세스로 실행 필요.

제약 조건: Chroma DB로 벡터값이 정상적으로 CRUD 가능해야 함.

---

### [분석]

**메모리 충돌 원인**

ChromaDB의 PersistentClient 는 내부적으로 SQLite를 사용한다.
Streamlit 멀티스레드 환경(또는 여러 Python 인스턴스)에서 SQLite에 동시 접근하면
파일 잠금 또는 메모리 충돌이 발생할 수 있다.

기존 `_chroma_client_lock` 으로는 같은 프로세스 내 스레드 경쟁만 막을 수 있고,
ChromaDB 자체의 내부 상태(SQLite 연결, 메모리 캐시)가 fork/spawn 시 복제되어
충돌이 생기는 경우를 막지 못한다.

**해결 방향**

ChromaDB 연산 전체를 별도 subprocess에서 격리한다.

```
main process                        child process
────────────────                    ──────────────────────────
SchemaVectorStore                   _chroma_worker_loop()
  └─ _ChromaWorker ──[Queue]──►  PersistentClient
       (proxy)       ◄──[Queue]──    (실제 Chroma I/O)
```

- main process: `_ChromaWorker` (프록시), `Embedder` (HTTP, 격리 불필요)
- child process: `_chroma_worker_loop` + `_handle_chroma_op` + `PersistentClient`
- `multiprocessing.get_context("spawn")` 사용 — Windows 필수, fork 부작용 없음

**지원 연산**

| op | 설명 |
|----|------|
| get_or_create_collection | 컬렉션 생성 또는 조회 |
| create_collection | 컬렉션 생성 |
| delete_collection | 컬렉션 삭제 |
| add | 문서·임베딩 추가 |
| count | 문서 수 조회 |
| query | 유사도 검색 |
| stop | 워커 정상 종료 |

---

### [수정 내용]

**수정 파일**: `src/text2sql/rag/vector_store.py`

1. **제거**
   - `import chromadb` (top-level)
   - `from chromadb.config import Settings as ChromaSettings` (top-level)
   - `_chroma_clients: Dict[str, PersistentClient]`
   - `_chroma_client_lock = threading.Lock()`
   - `_get_chroma_client()` 함수

2. **추가**
   - `import multiprocessing`
   - `_handle_chroma_op(client, op, task)` — child process 내 연산 디스패처 (module-level)
   - `_chroma_worker_loop(req_queue, res_queue, persist_dir)` — child process 진입점 (module-level)
   - `_ChromaWorker` 클래스 — main process 프록시
     - `_start()`: spawn context로 child process 시작
     - `_ensure_alive()`: 프로세스 죽으면 자동 재시작
     - `_call(op, **task)`: IPC 요청/응답 (threading.Lock 으로 직렬화)
     - 공개 메서드: `get_or_create_collection`, `create_collection`, `delete_collection`, `add`, `count`, `query`, `stop`
   - `_chroma_workers: Dict[str, _ChromaWorker]`
   - `_worker_lock = threading.Lock()`
   - `_get_chroma_worker(persist_dir)` 함수

3. **SchemaVectorStore 변경**
   - `self._client` (PersistentClient) → `self._worker` (_ChromaWorker)
   - `self._collection` 객체 제거 → 연산 시 `self._collection_name` 문자열만 사용
   - `build_index`: `_client.delete_collection` / `_client.create_collection` / `_collection.add` → `_worker.*`
   - `search`: `_collection.count()` / `_collection.query()` → `_worker.count()` / `_worker.query()`
     - count를 한 번만 호출하도록 최적화 (변수 `total` 사용)
   - `is_indexed`: `_collection.count() > 0` → `_worker.count(...) > 0`
   - `has_fk` 메타데이터: `bool` → `int(bool)` 로 변환 (Chroma metadata 타입 안전)

4. **불변 부분** (수정 없음)
   - `Embedder` 클래스 — main process에서 HTTP 임베딩, 격리 불필요
   - `_load_schema_and_meta()` — Oracle-first 로직 (task 5에서 수정)
   - `_table_to_text()` — sample_rows fallback (task 5에서 수정)
   - `_ensure_index()`, `get_vector_store()`, `rebuild_vector_store()` — 변경 없음
   - `_store_lock` — Streamlit 멀티스레드 동시 build_index 방지 (task 4 분석에서 유지 결정)

---

### [변경 코드]

```diff
- import chromadb
- from chromadb.config import Settings as ChromaSettings
+ import multiprocessing

- _chroma_clients: Dict[str, "chromadb.PersistentClient"] = {}
- _chroma_client_lock = threading.Lock()
-
- def _get_chroma_client(persist_dir: str) -> "chromadb.PersistentClient":
-     with _chroma_client_lock:
-         if persist_dir not in _chroma_clients:
-             _chroma_clients[persist_dir] = chromadb.PersistentClient(
-                 path=persist_dir,
-                 settings=ChromaSettings(anonymized_telemetry=False),
-             )
-         return _chroma_clients[persist_dir]

+ def _handle_chroma_op(client, op, task): ...   # child process
+ def _chroma_worker_loop(req_queue, res_queue, persist_dir): ...  # child process
+ class _ChromaWorker: ...   # main process proxy
+ _chroma_workers: Dict[str, _ChromaWorker] = {}
+ _worker_lock = threading.Lock()
+ def _get_chroma_worker(persist_dir): ...

# SchemaVectorStore.__init__
- self._client = _get_chroma_client(self._persist_dir)
- self._collection = self._client.get_or_create_collection(...)
+ self._worker = _get_chroma_worker(self._persist_dir)
+ self._worker.get_or_create_collection(...)

# build_index
- self._client.delete_collection(...)
- self._collection = self._client.create_collection(...)
- self._collection.add(...)
+ self._worker.delete_collection(...)
+ self._worker.create_collection(...)
+ self._worker.add(collection_name=..., ...)

# search
- if self._collection.count() == 0: return []
- results = self._collection.query(
-     n_results=min(top_k, self._collection.count()), ...)
+ total = self._worker.count(self._collection_name)
+ if total == 0: return []
+ results = self._worker.query(
+     collection_name=..., n_results=min(top_k, total), ...)

# is_indexed
- return self._collection.count() > 0
+ return self._worker.count(self._collection_name) > 0
```
