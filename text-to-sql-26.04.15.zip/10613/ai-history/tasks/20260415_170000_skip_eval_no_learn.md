# 작업 기록: 평가 건너뛰기 시 domain_hints 미반영

---

### [요청]

SQL이 생성되고 평가에서 건너뛰기를 했을 때 다음 생성에 영향을 안 줘야함

- SQL이 생성되고 평가에서 건너뛰기를 했을 때 무조건 domain_hints에 들어가는데 (few_shot_examples 등)
- 해당 항목에 추후에 악영향을 주는 것으로 보임

제약 조건: 평가 없이 건너뛰기하면 metadata, domain_hint에 적용이 안 되어야함

---

### [분석]

**버그 경로**

```
node_result_output()
  └─ _try_auto_feedback(state)
       ├─ build_auto_feedback(state) → FeedbackRecord(score=5, is_auto=True)
       ├─ get_feedback_store().add(record)        ← 저장
       └─ get_learner().learn(db_id)              ← 즉시 학습 ← 버그
            ├─ _promote_few_shots() → few_shot_examples 업데이트
            ├─ _expand_keyword_map() → keyword_map 업데이트
            └─ _expand_common_patterns() → common_patterns 업데이트
```

**문제**: `_try_auto_feedback`이 파이프라인 성공(judge_accepted=True)마다 호출되어, 사용자가 피드백 UI에서 평가 버튼을 클릭하기 **전에** domain_hints를 업데이트한다.

**"건너뛰기" 시나리오**:
1. 파이프라인 실행 성공 (judge_accepted=True)
2. `_try_auto_feedback` → score=5 자동 피드백 저장 + `learn()` 호출
3. `learn()` → few_shot_examples에 SQL 추가됨
4. 사용자가 결과를 보고 피드백 버튼을 클릭하지 않음 (건너뜀)
5. SQL이 이미 domain_hints에 반영된 상태 — 실제 품질 확인 없이

**자동 피드백 vs 사용자 명시 피드백 구분 부재**

| 종류 | 발생 시점 | 신뢰도 |
|------|----------|--------|
| 자동 피드백 (`_try_auto_feedback`) | 파이프라인 종료 시 자동 | 낮음 — judge(LLM)도 틀릴 수 있음 |
| 사용자 피드백 (`show_feedback_ui`) | 사용자가 직접 버튼 클릭 | 높음 — 실제 결과 확인 후 평가 |

---

### [수정 내용]

**수정 파일 1: `src/text2sql/feedback/store.py`**

`FeedbackRecord`에 `is_auto: bool = False` 필드 추가.
- 자동 피드백: `is_auto=True`
- 사용자 명시 피드백: `is_auto=False` (기본값)
- 기존 JSON 파일과 호환됨 (기존 레코드는 `is_auto=False`로 로드)

**수정 파일 2: `src/text2sql/feedback/auto_scorer.py`**

`build_auto_feedback()` 반환 레코드에 `is_auto=True` 설정.

**수정 파일 3: `src/text2sql/feedback/learner.py`**

`learn()` 메서드에서 `is_auto=True` 레코드를 few_shot·keyword·pattern 반영에서 제외:

```python
# Before
promotable = self._store.not_yet_promoted(db_id)
positives = self._store.positive(db_id)

# After
promotable = [r for r in self._store.not_yet_promoted(db_id) if not r.is_auto]
positives = [r for r in self._store.positive(db_id) if not r.is_auto]
```

부정 피드백(오류 패턴 기록)은 자동 포함 유지 — 실패 SQL 패턴은 즉시 기록해야 repair에 도움이 됨.

**수정 파일 4: `src/text2sql/agents/repair_output.py`**

`_try_auto_feedback()`에서 `get_learner().learn()` 호출 제거:

```python
# Before
record = build_auto_feedback(state)
get_feedback_store().add(record)
get_learner().learn(state.get("database_id", ""))  # ← 제거

# After
record = build_auto_feedback(state)
get_feedback_store().add(record)
# ※ learn() 호출하지 않음 — 사용자 평가 없는 자동 피드백은 도메인 힌트에 반영 안 함
```

---

### [변경 코드]

```diff
# store.py — FeedbackRecord
     timestamp: str = ""
     promoted_to_few_shot: bool = False
     error_logged: bool = False
+    is_auto: bool = False  # True: 파이프라인 자동 생성, False: 사용자 명시적 평가

# auto_scorer.py — build_auto_feedback()
     return FeedbackRecord(
         ...
+        is_auto=True,
     )

# learner.py — learn()
-    promotable = self._store.not_yet_promoted(db_id)
+    # 자동 피드백(is_auto=True)은 도메인 힌트에서 제외 (사용자 평가 필요)
+    promotable = [r for r in self._store.not_yet_promoted(db_id) if not r.is_auto]
-    positives = self._store.positive(db_id)
+    positives = [r for r in self._store.positive(db_id) if not r.is_auto]

# repair_output.py — _try_auto_feedback()
     record = build_auto_feedback(state)
     get_feedback_store().add(record)
-    get_learner().learn(state.get("database_id", ""))
+    # ※ learn() 호출하지 않음 — 사용자 평가 없는 자동 피드백은 도메인 힌트에 반영 안 함
```

---

### [동작 방식]

**변경 후 흐름**

```
파이프라인 성공 → _try_auto_feedback() → 저장만 (학습 없음)
                                               ↓
                               사용자가 평가 버튼 클릭 (4~5점)
                                               ↓
                               show_feedback_ui() → is_auto=False 레코드 저장
                                               ↓
                               learn() → few_shot·keyword·pattern 업데이트
```

**도메인 힌트 반영 조건**

| 시나리오 | few_shot·keyword·pattern 반영 |
|----------|-------------------------------|
| 파이프라인 성공 + 사용자 평가 없음 (건너뛰기) | ✗ 반영 안 됨 |
| 파이프라인 성공 + 사용자 4~5점 클릭 | ✓ 반영됨 |
| 파이프라인 성공 + 사용자 1~2점 클릭 | ✗ 반영 안 됨 (오류 패턴만 기록) |
| E2E --record-feedback --learn (pass) | ✓ 반영됨 (is_auto=False 레코드) |
| 파이프라인 실패 | ✗ 반영 안 됨 (오류 패턴 기록) |

**E2E 피드백은 그대로**: `run_e2e_suite.py`에서 직접 `FeedbackRecord(...)`를 생성할 때 `is_auto` 필드를 지정하지 않으므로 기본값 `False` → 정상 반영됨.
