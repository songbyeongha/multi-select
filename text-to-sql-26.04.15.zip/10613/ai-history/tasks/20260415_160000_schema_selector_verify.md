# 작업 기록: 스키마 셀렉터 기능 동작 검증 및 고도화

---

### [요청]

스키마 셀렉터 기능 동작이 제대로 되는 지 검증 및 고도화

- 스키마 셀렉터 동작이 제대로 되고 있는지와 효과가 있는지 의문
- RAG를 제대로 활용해서 동작을 하고 있는지 의문스러움
- schema_metadata 기준으로 테이블, 컬럼 값으로 동작해야하는데 DB를 직접 조회해서 스키마 정보를 가지고 오는 것으로 인식됨

제약 조건: DB에서 직접 조회해서 스키마 값을 가지고 오는 것은 초기와 필요할 때만 실행해야함

---

### [분석]

**현재 상태 파악**

| 경로 | 파일 | 동작 |
|------|------|------|
| schema_selector 노드 | `schema_nodes.py` L46-51 | JSON 있으면 `from_meta()` ✓, 없으면 `full_schema()` (DB) |
| vector index 빌드 | `vector_store._load_schema_and_meta()` | **항상 Oracle DB 직접 조회** ← 버그 |
| SchemaReader.from_meta | `executor.py` | JSON만 읽음, DB 접근 없음 ✓ |
| SchemaReader.full_schema | `executor.py` | Oracle DB 직접 조회 (`list_tables()` + `table_info()` × N) |

**버그 원인**

`vector_store._load_schema_and_meta()` (Task 5에서 수정됨):

```python
# Task 5 이후 — 항상 Oracle DB 조회
schema = SchemaReader.full_schema("__oracle__")  # ← 무조건 DB 조회
if meta.get("tables"):
    # ... 메타데이터로 설명만 보강 (구조는 Oracle 기준)
```

Task 5의 의도: "컬럼 누락 방지를 위해 Oracle을 정본으로 사용"
문제: 이미 `schema_metadata JSON`이 있으면 DB 조회가 불필요하고 느림

**schema_selector 노드는 정상**

`schema_nodes.py` L46-51은 이미 JSON-first로 동작:
- `meta.get("tables")` → `SchemaReader.from_meta()` 사용 ✓
- else → `SchemaReader.full_schema()` DB 폴백 ✓
- 로그 없음 → 어떤 경로를 탔는지 알 수 없었음

**get_vector_store() 캐시**

`_stores` 딕셔너리로 캐싱됨 → 프로세스당 한 번만 DB 조회.
하지만 벡터 인덱스 재빌드 시마다 `_load_schema_and_meta()` 호출 → DB 조회 발생.

---

### [수정 내용]

**수정 파일 1: `src/text2sql/rag/vector_store.py`**

`_load_schema_and_meta()` — "항상 Oracle" → "JSON-first, DB는 폴백"

```python
# Before (Task 5 방식 — 항상 Oracle DB)
schema = SchemaReader.full_schema("__oracle__")
if meta.get("tables"):
    # 메타데이터로 설명만 보강

# After (JSON-first)
if meta.get("tables"):
    schema = SchemaReader.from_meta(meta)
    logger.info("[%s] vector index: schema_metadata JSON 기준 로드 — %d개 테이블", ...)
else:
    logger.warning("[%s] vector index: schema_metadata JSON 없음 — Oracle DB 직접 조회 ...", ...)
    schema = SchemaReader.full_schema("__oracle__")
    logger.info("[%s] vector index: Oracle DB에서 %d개 테이블 로드", ...)
```

**수정 파일 2: `src/text2sql/agents/schema_nodes.py`**

1. `import logging` + `logger = logging.getLogger(__name__)` 추가
2. JSON/DB 경로 선택 시 `logger.info()` / `logger.warning()` 추가:

```python
if meta.get("tables"):
    full_schema = SchemaReader.from_meta(meta)
    logger.info("[%s] schema_selector: JSON 기준 스키마 로드 — %d개 테이블", db_id, len(full_schema))
else:
    logger.warning("[%s] schema_selector: schema_metadata JSON 없음 — Oracle DB 직접 조회 ...", ...)
    full_schema = SchemaReader.full_schema(db_path)
    logger.info("[%s] schema_selector: Oracle DB에서 %d개 테이블 로드", db_id, len(full_schema))
```

---

### [변경 코드]

```diff
# vector_store.py
-def _load_schema_and_meta(db_id):
-    """Oracle 스키마를 구조 정본으로 사용..."""
-    ...
-    # Oracle DB에서 전체 스키마 로드 — 모든 테이블·컬럼 보장
-    schema = SchemaReader.full_schema("__oracle__")
-    # 메타데이터로 설명·별칭·샘플값 보강 (구조는 Oracle 기준 유지)
-    if meta.get("tables"):
-        ...  # description/aliases/sample_values 보강
-    return schema, meta
+def _load_schema_and_meta(db_id):
+    """schema_metadata JSON을 정본으로 사용, JSON 없을 때만 Oracle DB 조회..."""
+    ...
+    if meta.get("tables"):
+        schema = SchemaReader.from_meta(meta)
+        logger.info("[%s] vector index: schema_metadata JSON 기준 로드 — %d개 테이블", ...)
+    else:
+        logger.warning("[%s] vector index: schema_metadata JSON 없음 — Oracle DB 직접 조회 ...", ...)
+        schema = SchemaReader.full_schema("__oracle__")
+        logger.info("[%s] vector index: Oracle DB에서 %d개 테이블 로드", ...)
+    return schema, meta

# schema_nodes.py
+import logging
+logger = logging.getLogger(__name__)
 ...
     if meta.get("tables"):
         full_schema = SchemaReader.from_meta(meta)
+        logger.info("[%s] schema_selector: JSON 기준 스키마 로드 — %d개 테이블", db_id, len(full_schema))
     else:
+        logger.warning("[%s] schema_selector: schema_metadata JSON 없음 — Oracle DB 직접 조회 ...", ...)
         full_schema = SchemaReader.full_schema(db_path)
+        logger.info("[%s] schema_selector: Oracle DB에서 %d개 테이블 로드", db_id, len(full_schema))
```

---

### [사용 방법]

**정상 동작 확인 (JSON 있을 때)**

```
INFO  [oracle_prod] schema_selector: JSON 기준 스키마 로드 — 42개 테이블
INFO  [oracle_prod] vector index: schema_metadata JSON 기준 로드 — 42개 테이블
```

**JSON 없을 때 경고**

```
WARNING [oracle_prod] schema_selector: schema_metadata JSON 없음 — Oracle DB 직접 조회
        (prepare 먼저 실행하세요: python scripts/run_ops.py prepare --db-id oracle_prod)
```

**초기 설정 순서**

```powershell
# 1. 메타데이터 추출 (Oracle DB 직접 조회 — 최초 1회)
python scripts/run_ops.py prepare --db-id oracle_prod

# 2. 이후 모든 실행은 JSON 기준 (DB 조회 없음)
python scripts/run_ops.py cli --db-id oracle_prod -q "이번 달 생산량은?"
```

**로그 활성화**

```env
T2SQL_LOG_LEVEL=INFO
```
