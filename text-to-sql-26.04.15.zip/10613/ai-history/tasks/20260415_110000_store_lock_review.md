# 작업 기록: store_lock 필요 여부 검토

---

### [요청]

SQLite 제거 후 Store_lock이 필요한지 확인. 필요없으면 삭제.

제약 조건: RAG 사용에 문제가 없어야 함.

---

### [분석]

**Lock 목록**

1. `_chroma_client_lock` (vector_store.py line 90)
   - `_get_chroma_client()` 에서 사용
   - PersistentClient 를 경로당 하나만 생성하기 위한 Lock
   - Chroma는 내부 스토리지로 `data/vector_store/chroma.sqlite3` 를 사용함
   - 여러 인스턴스가 같은 SQLite 파일에 동시 접근 시 충돌 → Lock 유지 필요

2. `_store_lock` (vector_store.py line 345)
   - `get_vector_store()`, `rebuild_vector_store()` 에서 사용
   - Streamlit 멀티스레드 환경에서 동시 `build_index()` 호출 방지
   - 중복 호출 시: LLM embedding API 이중 호출 + Chroma write 충돌 → Lock 유지 필요

**결론**

애플리케이션 SQLite(data/*.db)는 제거됐지만,
Chroma가 내부적으로 SQLite 파일을 사용하므로 두 Lock 모두 유지해야 함.

삭제 대상 없음.

**주석 오류 수정**

- line 116-117: "SQLite lock 충돌" → "Chroma 동시 초기화 방지"
- line 351 주석: "SQLite lock 충돌 방지" → "Chroma 동시 초기화 방지"

---

### [수정 내용]

**수정 파일**: `src/text2sql/rag/vector_store.py`

오해를 일으키는 주석 2곳 수정 (코드 변경 없음)
