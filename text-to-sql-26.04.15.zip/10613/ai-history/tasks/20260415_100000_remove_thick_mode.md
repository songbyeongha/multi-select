# 작업 기록: thick_mode / lib_dir 제거

---

### [요청]

T2SQL_DB_LIB_DIR 및 lib_dir 사용 목적 확인, 필요없으면 삭제.
Oracle DB는 IP/port/user/password로 접속 가능 → LIB_DIR 불필요해 보임.

제약 조건: oracle db 접속에 문제가 없어야 함.

---

### [분석]

**thick_mode / lib_dir 역할**

- `thick_mode=true` 일 때만 `oracledb.init_oracle_client(lib_dir=...)` 호출
- Oracle Instant Client(OCI) 기반 연결이 필요한 특수 환경에서만 사용
  (구버전 Oracle, 기업망 특수 인증, Oracle Wallet 등)
- 일반 IP/port/user/password 연결 = thin mode → Instant Client 불필요

**현재 상태 확인**

- `settings.py`: `thick_mode` 기본값 `false` (환경변수 `T2SQL_DB_THICK_MODE`, 기본 `"false"`)
- 현재 `.env`: `T2SQL_DB_THICK_MODE` 미설정 → thick_mode=false 적용 중
- `oracle_adapter.py`: `if thick_mode:` 블록이므로 현재 미실행
- 결론: 코드를 삭제해도 Oracle 연결에 영향 없음 ✅

**영향 범위**

소스:
- `oracle_adapter.py` — `_THICK_MODE_INITIALIZED`, `_init_thick_mode()`, thick_mode/lib_dir 파라미터 제거
- `settings.py` — `DBCfg.thick_mode`, `DBCfg.lib_dir` 필드 제거
- `factory.py` — `thick_mode=`, `lib_dir=` 인자 제거
- `operations_tab.py` — `thick_mode=`, `lib_dir=` 인자 제거
- `oracle_release_gate.py` — `thick_mode=`, `lib_dir=` 인자 제거

문서:
- `.env.example` — `T2SQL_DB_THICK_MODE`, `T2SQL_DB_LIB_DIR` 항목 제거
- `docs/operations/ORACLE_DB_QUICKSTART.md` — thick mode 섹션 제거
- `docs/operations/FIRST_PRODUCTION_ATTACH.md` — DPY-6001 thick mode 오류 항목 제거

---

### [수정 내용]

**수정 파일 5개**: oracle_adapter.py, settings.py, factory.py, operations_tab.py, oracle_release_gate.py
**수정 문서 3개**: .env.example, ORACLE_DB_QUICKSTART.md, FIRST_PRODUCTION_ATTACH.md
