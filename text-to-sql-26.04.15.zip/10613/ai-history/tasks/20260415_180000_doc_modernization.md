# 작업 기록: 문서 현행화

## [요청]

[목표] 문서 현행화
[현재 문제] 문서가 현재 프로젝트와 상이한 내용이 있음 / 설명에 옵션인 값도 확정 값으로 명령어가 나와 있음 / CLAUDE.md도 현행화가 필요 / .env.example에 환경변수 예제 누락이 있음
[수정 대상 파일] docs/*, README.md, CLAUDE.md, .env.example
[제약 조건] CLAUDE.md에 하네스 엔지니어링에 필요한 내용은 수정하면 안됨

---

## [분석]

### 문제 원인

1. `oracle_prod` 하드코딩 — 운영 명령어 예제 30곳 이상에서 `--db-id oracle_prod`가 고정값처럼 표시됨
2. `check-hints` 명령어 누락 — Task 14에서 추가된 진단 도구인데 모든 문서에서 빠져 있음
3. T2SQL_AUTO_FEEDBACK 설명 오류 — Task 10 변경 후 "domain_hints에 자동 반영"이 아닌 "통계·이력용"으로 변경됐는데 문서가 미반영
4. .env.example 환경변수 누락 — LLM 튜닝, Fast 모델, Azure 듀얼 모델, Embedding 분리, DSN 등
5. CLAUDE.md 아키텍처 규칙 미반영 — schema_selector 소스 우선순위, 피드백 학습 구분 규칙

### 영향 범위

- docs/START_HERE.md
- docs/operations/OPERATOR_ONE_PAGE.md
- docs/operations/SCRIPT_SELECTION_GUIDE.md
- docs/operations/ENDPOINT_USAGE_GUIDE.md
- docs/operations/FIRST_PRODUCTION_ATTACH.md
- docs/operations/DAILY_OPERATIONS_CHECKLIST.md
- docs/operations/RELEASE_CHECKLIST.md
- docs/metadata/SQL_METADATA_ENRICHMENT.md
- CLAUDE.md
- .env.example

---

## [수정 내용]

### .env.example
- LLM 튜닝 선택 항목 추가: `T2SQL_LLM_TIMEOUT_SEC`, `T2SQL_LLM_TEMPERATURE`, `T2SQL_LLM_MAX_TOKENS`
- Fast 모델 설정 추가 (주석): `T2SQL_LLM_MODEL_FAST`, `T2SQL_LLM_BASE_URL_FAST`, `T2SQL_LLM_API_KEY_FAST`
- Azure 듀얼 모델 추가 (주석): `SKCC_AZURE_MODEL_FAST`, `SKCC_AZURE_ENDPOINT_FAST`, `SKCC_AZURE_OPENAI_KEY_FAST`, `SKCC_AZURE_API_VERSION`
- Embedding 분리 URL 추가 (주석): `T2SQL_EMBED_BASE_URL`, `T2SQL_EMBED_API_KEY`
- Oracle DSN 대안 추가 (주석): `T2SQL_DB_DSN`
- `T2SQL_AUTO_FEEDBACK` 설명 수정: domain_hints 반영은 별점 클릭 시만 실행

### CLAUDE.md
- schema_selector 규칙에 JSON-first 로드 정책 추가
- memory/audit 섹션에 피드백 학습 규칙 추가 (is_auto 구분)

### docs/START_HERE.md
- `<db-id>` 플레이스홀더 안내 추가
- `oracle_prod` → `<db-id>` 교체 (prepare, first-run)
- `--catalog` 선택 사항 명시

### docs/operations/OPERATOR_ONE_PAGE.md
- `oracle_prod` → `<db-id>` 전체 교체
- `check-hints` 명령어 추가 (자주 쓰는 명령, 서브커맨드 표, 도움말 예제)
- test `--catalog` 필수 안내 추가
- `domain_hints_oracle_manual.json` 생성 파일 표에 추가

### docs/operations/SCRIPT_SELECTION_GUIDE.md
- `oracle_prod` → `<db-id>` 전체 교체
- `check-hints` 서브커맨드 선택 트리에 추가
- `check-hints` 명령 섹션 신규 추가
- test/release `--catalog` 조건 명확화

### docs/operations/ENDPOINT_USAGE_GUIDE.md
- 피드백 점수별 동작 테이블 형식으로 정비
- 자동/명시 피드백 차이 설명 추가
- `T2SQL_AUTO_FEEDBACK` env var 설명 수정

### docs/operations/FIRST_PRODUCTION_ATTACH.md
- `<db-id>` 플레이스홀더 안내 추가
- `oracle_prod` → `<db-id>` 전체 교체 (prepare, test, first-run 명령)
- `domain_hints_oracle_manual.json` 생성 파일 목록에 추가

### docs/operations/DAILY_OPERATIONS_CHECKLIST.md
- `oracle_prod` → `<db-id>` 전체 교체 (daily, prepare, test, maintain, 긴급 prepare)

### docs/operations/RELEASE_CHECKLIST.md
- `oracle_prod` → `<db-id>` 전체 교체 (release, test, daily, 서브커맨드 예제)
- `<db-id>` 플레이스홀더 안내 추가

### docs/metadata/SQL_METADATA_ENRICHMENT.md
- `<db-id>` 플레이스홀더 안내 추가 (1단계 섹션)
- `oracle_prod` → `<db-id>` 교체 (명령어 예제: prepare, maintain ×3)
- JSON 구조 예제의 `"oracle_prod"` 키는 유지 (JSON이므로 `<db-id>` 불가) — 안내문 추가

---

## [변경 코드]

### docs/operations/DAILY_OPERATIONS_CHECKLIST.md

```diff
- .venv\Scripts\python.exe scripts\run_ops.py daily --db-id oracle_prod
+ .venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db-id>
```

### docs/operations/RELEASE_CHECKLIST.md

```diff
- release --db-id oracle_prod --catalog data/catalog.json
+ release --db-id <db-id> --catalog data/catalog.json

+ > `<db-id>` 는 `.env`의 `T2SQL_DB_ID` 값으로 교체하세요.
```

### docs/metadata/SQL_METADATA_ENRICHMENT.md

```diff
+ > `<db-id>` 는 `.env`의 `T2SQL_DB_ID` 값으로 교체하세요. JSON 예제의 `"oracle_prod"` 키도 실제 값으로 바꾸세요.
- prepare --db-id oracle_prod
+ prepare --db-id <db-id>
```
