# 작업 기록: run_ops.py 사용성 제고

---

### [요청]

scripts에 run_ops.py 기능 사용성 제고.
run_ops.py 의 사용 방법을 모름. 사용성이 떨어지면 제거해야 할 듯.

제약 조건:
1. CLI 도구 + 관리 스크립트
2. CLI 인터페이스
3. 메타데이터 추출
4. 메타데이터 자동 강화
5. E2E 테스트
6. 연결 테스트 — 위 기능은 삭제 금지

---

### [분석]

**문제 원인**
- `--help` 출력이 옵션 나열만 있고, 언제/어떤 순서로 실행해야 하는지 전혀 드러나지 않음
- 에러 메시지가 단순 `[ERROR]` 문자열 — 다음 행동 안내 없음
- 7개 서브커맨드 간 실행 순서 (doctor → prepare → test → release) 가 코드 어디에도 설명 없음
- `usage` 서브커맨드 미존재 — 초보 운영자는 진입점을 찾지 못함

**영향 범위**
- `scripts/run_ops.py` 단독 파일
- `ops_gateway.py` 는 변경 없음

---

### [수정 내용]

**수정 파일**: `scripts/run_ops.py`

1. `description` / `epilog` 에 워크플로 다이어그램 + 예시 명령어 추가
2. `usage` 서브커맨드 추가 — 전체 운영 가이드를 터미널에 출력
3. `_execute_steps` 에러 메시지 개선 — 실패한 단계명 + 종료코드 + 해결 힌트 출력
4. 각 서브커맨드 `help` 문구를 한국어 + 실행 순서 번호 포함으로 개선
5. `formatter_class=RawDescriptionHelpFormatter` 적용 — epilog 줄바꿈 보존

---

### [변경 코드]

```diff
- parser = argparse.ArgumentParser(
-     description="Unified operator endpoint for Oracle Text-to-SQL operations",
- )
+ WORKFLOW = """
+ 워크플로 (처음 → 운영 → 배포):
+   1. doctor    — Oracle 연결 확인
+   2. prepare   — 메타데이터 추출 + 강화
+   3. test      — E2E 회귀 테스트
+   4. release   — 배포 게이트
+   (daily / maintain 은 매일 반복)
+ """
+ parser = argparse.ArgumentParser(
+     description="Oracle Text-to-SQL 통합 운영 도구",
+     epilog=USAGE_EXAMPLES,
+     formatter_class=argparse.RawDescriptionHelpFormatter,
+ )

- subparsers.add_parser("doctor", help="Check Oracle connectivity and metadata access")
+ subparsers.add_parser("doctor",  help="[1단계] Oracle 연결 + 메타뷰 접근 확인")

+ subparsers.add_parser("usage", help="전체 운영 워크플로와 명령어 예시 출력")

- print(f"[ERROR] Unknown command: {command}")
+ print(f"\n[ERROR] 알 수 없는 커맨드: '{command}'")
+ print(f"  사용 가능: {', '.join(COMMANDS)}")
+ print(f"  도움말: python scripts/run_ops.py --help")
```
