# 작업 기록: domain_hints_oracle_manual.json 사용성 확인 및 개선

---

### [요청]

domain_hints_oracle의 data가 제대로 활용이 안 되는 것으로 보임.
domain_hints_oracle_manual.json 가 전혀 생성이 안됨.

제약 조건: domain_hints_oracle_manual.json의 활용이 된다면 문서에 사용 방법을 정확히 표기.

---

### [분석]

**파일 생성 여부 확인**

`run_ops.py prepare` → `export_oracle_metadata.py` → line 154:
```python
ensure_seed_file(domain_hints_manual_path, scaffold_manual_domain_hints(payload, db_id))
```

파일은 정상적으로 생성됨. 단, `scaffold_manual_domain_hints()`가 모든 필드를 빈 값으로 채워
사용자가 "생성이 안 됐다"고 오인하는 구조였음.

**데이터 활용 경로 확인**

`settings.domain_hints(db_id)` = `merge_db_entries([primary, manual], db_id)`
- primary (`domain_hints_oracle.json`): `keyword_map`, `relation_bonus_map` 자동 생성됨
- manual (`domain_hints_oracle_manual.json`): 사용자 편집 + enrichment 결과 저장

deep_merge 로직: primary 먼저 로드 후 manual이 덮어씀 (dict는 재귀 merge, list는 replace).
empty `keyword_map: {}` + deep_merge = primary의 keyword_map 보존. **버그 없음.**

**실제 파이프라인 활용:**

| 필드 | 사용 위치 | 상태 |
|------|-----------|------|
| `keyword_map` | `schema_nodes.py` SchemaSelector | ✓ 자동 생성됨, 활용 중 |
| `relation_bonus_map` | `schema_nodes.py` SchemaSelector | ✓ 자동 생성됨, 활용 중 |
| `few_shot_examples` | `generation_nodes.py` CandidateGenerator | ✗ --catalog 없이 항상 빈 배열 |
| `common_patterns` | `_utils.py` get_reference_sql() | ✗ learner/--catalog 없으면 빈 dict |

**문서 오류 확인:**

`SQL_METADATA_ENRICHMENT.md` 섹션 4 "도메인 힌트 강화" 에 **실제로 사용하지 않는 필드명** 기술:
- `term_mappings` → 실제 필드: `keyword_map`
- `query_patterns` → 실제 필드: `common_patterns`
- `join_hints` → 존재하지 않는 필드 (fictional)

**문제 요약:**

1. `scaffold_manual_domain_hints()` 가 빈 템플릿만 생성 → 사용자가 무엇을 넣어야 하는지 모름
2. `SQL_METADATA_ENRICHMENT.md` 섹션 4에 잘못된 필드명 기술
3. `few_shot_examples` 자동 추가를 위한 `--catalog` 옵션이 문서에 미기재
4. `common_patterns`의 `fb_` 접두사 명명 규칙이 문서에 없음

---

### [수정 내용]

**수정 파일 1**: `src/text2sql/tools/oracle_metadata.py`

`scaffold_manual_domain_hints()`에 `_usage_guide` 필드 추가.
`_usage_guide`는 파이프라인 코드에서 읽지 않으므로(알려진 키만 `.get()`으로 읽음) 무해함.

각 필드의 형식, 예시, 자동 추가 방법을 `_usage_guide` 딕셔너리로 기술.

**수정 파일 2**: `docs/metadata/SQL_METADATA_ENRICHMENT.md`

섹션 4 전체 재작성:
- 잘못된 필드명(`term_mappings`, `query_patterns`, `join_hints`) 제거
- 실제 4개 필드(`keyword_map`, `relation_bonus_map`, `few_shot_examples`, `common_patterns`)로 교체
- 각 필드의 역할, 형식, JSON 예시 추가
- `few_shot_examples` 자동 추가 명령어 추가 (`--catalog` 옵션)
- `common_patterns`의 `fb_<query_pattern>_<이름>` 명명 규칙 명시
- 데이터 흐름 다이어그램 추가

---

### [변경 코드]

```diff
# oracle_metadata.py — scaffold_manual_domain_hints()
 def scaffold_manual_domain_hints(payload, db_id):
     db_meta = payload.get("databases", {}).get(db_id, {})
     return {
         "databases": {
             db_id: {
                 "name": db_meta.get("name", db_id),
+                "_usage_guide": {
+                    "keyword_map": "{ '업무용어': ['TABLE_NAME'] } — ...",
+                    "relation_bonus_map": "{ 'TABLE_A': ['TABLE_B'] } — ...",
+                    "few_shot_examples": "[ {'question': '...', 'sql': '...'} ] — ...",
+                    "common_patterns": "{ 'fb_<query_pattern>_<이름>': 'SQL 조각' } — ...",
+                },
                 "keyword_map": {},
                 "relation_bonus_map": {},
                 "few_shot_examples": [],
                 "common_patterns": {},
             }
         }
     }
```
