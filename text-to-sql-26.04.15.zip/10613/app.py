"""Text-to-SQL Assistant Streamlit entrypoint."""
from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.ui.context import build_app_context, init_session_state
from text2sql.ui.sidebar import render_sidebar
from text2sql.ui.styles import render_app_shell, render_footer
from text2sql.ui.tabs import (
    render_batch_tab,
    render_history_tab,
    render_learn_tab,
    render_main_tab,
    render_operations_tab,
)

render_app_shell()
init_session_state()

app_context = build_app_context()
max_retries, hitl_enabled = render_sidebar(app_context)

tab_main, tab_batch, tab_history, tab_learn, tab_ops = st.tabs(
    [
        "💬 질의 실행",
        "📦 대량 질의",
        "📜 히스토리",
        "🧠 학습 로그",
        "🛠️ 운영 관리",
    ]
)

with tab_main:
    render_main_tab(app_context, max_retries=max_retries, hitl_enabled=hitl_enabled)

with tab_batch:
    render_batch_tab(app_context, max_retries=max_retries, hitl_enabled=hitl_enabled)

with tab_history:
    render_history_tab()

with tab_learn:
    render_learn_tab()

with tab_ops:
    render_operations_tab(app_context)

render_footer(app_context.settings)
