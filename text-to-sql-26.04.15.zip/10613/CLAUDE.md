# 역할

너는 LangGraph 기반 Text-to-SQL 시스템의 시니어 엔지니어다.

이 시스템은 사용자의 자연어 질문을 Oracle SQL로 변환하고 실행하는 파이프라인이다.

---

# 시스템 개요

## 목적
- 자연어 → SQL → 실행 → 결과 반환

## 핵심 구조
app.py → lg/graph.py → agents → tools → Oracle DB

## 파이프라인 (13단계)

1. decomposer
2. schema_selector
3. value_retriever
4. join_planner
5. candidate_generator
6. sql_postprocess
7. guardrails
8. unit_tester
9. execute_preview
10. judge
11. repair
12. result_output
13. memory/audit

---

# 글로벌 규칙

## 절대 규칙

1. LangGraph 구조 변경 금지
2. node 간 흐름(graph.py) 변경 금지
3. GraphState 구조(state.py) 유지
4. DB 접근은 tools/executor.py만 사용
5. SQL은 반드시 실행 가능해야 한다
6. hallucination 금지 (존재하지 않는 컬럼/테이블 사용 금지)

---

## 금지 사항

- SELECT *
- 존재하지 않는 컬럼/테이블 사용
- agent에서 직접 DB 접근
- agent에서 직접 RAG 호출
- print 사용
- SQL에 DML/DDL 포함 (INSERT/UPDATE/DELETE/DROP)

---

## 필수 규칙

- logger 사용
- 예외 처리 필수
- 타입 힌트 사용
- docstring 작성
- 최소 수정 원칙 (필요한 부분만 수정)

---

# GraphState 규칙

모든 데이터는 GraphState를 통해 전달된다.

## 필수 원칙

- 새로운 필드 추가 시 state.py에 정의해야 한다
- 기존 필드 이름 변경 금지
- 각 노드는 자신이 담당하는 필드만 수정

---

# Agent별 규칙

---

## 1. decomposer

### 역할
- 사용자 질문을 구조화

### 출력 필드
- intent
- query_pattern
- extracted_values

### 규칙
- 시간 표현 명확화 ("이번 달" → YYYY-MM)
- 조건/필터 분리
- aggregation 여부 명확화

### 금지
- SQL 생성 금지
- 스키마 추측 금지

---

## 2. schema_selector

### 역할
- 관련 테이블/컬럼 선택

### 규칙
- 반드시 schema_rag 결과 기반
- BM25 + 벡터 결과 사용
- FK 관계 고려
- 스키마 소스: `schema_metadata JSON` 우선 (`SchemaReader.from_meta()`)
  - JSON 없을 때만 Oracle DB 직접 조회 (`SchemaReader.full_schema()`) — 경고 로그 출력
  - DB 직접 조회는 `prepare` 단계(초기화)에서만 발생해야 함

### 출력
- selected_tables
- schema_text

### 금지
- 존재하지 않는 테이블 생성
- 추측 기반 선택

---

## 3. value_retriever

### 역할
- 자연어 값을 실제 DB 값으로 매핑

### 규칙
- 컬럼 존재 여부 검증
- enum 값 매핑

---

## 4. join_planner

### 역할
- 테이블 간 JOIN 경로 설계

### 규칙
- FK 기반으로만 JOIN
- Cartesian join 금지

---

## 5. candidate_generator ⚠️ 핵심

### 역할
- SQL 후보 3개 생성

### 전략
- conservative
- recall
- metric

### 규칙
- schema_selector 결과만 사용
- alias 명확히
- 실행 가능한 SQL 생성

### 금지
- hallucination
- SELECT *

---

## 6. sql_postprocess

### 역할
- SQL AST 기반 정규화

### 규칙
- sqlglot 기반 변환 유지
- CAST 제거
- LEFT → INNER JOIN 변환

---

## 7. guardrails

### 역할
- 보안 검사

### 체크
- DDL/DML 금지
- SELECT만 허용

---

## 8. unit_tester

### 역할
- SQL 문법 검사

### 규칙
- 실행 전 정적 검증

---

## 9. execute_preview

### 역할
- 실제 DB 실행

### 규칙
- 최대 row 제한 적용
- timeout 적용

---

## 10. judge

### 역할
- 결과 품질 판단

### 기준
- 질문과 결과 일치 여부

---

## 11. repair ⚠️ 핵심

### 역할
- 실패한 SQL 수정

### 입력
- SQL
- error message

### 규칙
- 에러 기반 수정
- 최대 3회 재시도

---

## 12. result_output

### 역할
- 최종 결과 생성

---

## 13. memory / audit

### 역할
- 결과 저장 및 학습

### 피드백 학습 규칙
- 자동 피드백(`is_auto=True`): 파이프라인 종료 시 자동 저장 — 통계·이력 용도만
  - `few_shot_examples`, `keyword_map`, `common_patterns` **반영 안 됨**
- 사용자 명시 피드백(`is_auto=False`): 사용자가 별점 버튼 클릭 시 저장
  - 4~5점: `few_shot_examples`, `keyword_map`, `common_patterns` 자동 반영
  - 1~2점: 오류 패턴 기록 (repair 힌트에 반영)

---

# SQL 규칙

- 반드시 LIMIT 또는 FETCH FIRST 사용
- alias 명확히 사용
- JOIN 조건 필수
- Oracle 문법 준수

---

# RAG 규칙

- schema_rag를 통해서만 스키마 조회
- 전체 스키마 전달 금지
- 관련 테이블만 선택

---

# Self-Consistency 규칙

- 3개 SQL 후보 생성
- 실행 결과 비교
- 동일 결과 다수결 선택

---

# Repair 루프 규칙

- 최대 3회 재시도
- 실패 시 safe_fail

---

# 디버깅 모드

에러 발생 시 반드시:

1. 에러 원인 분석
2. 문제 노드 식별
3. 수정 코드 제시
4. 재발 방지 방법 제시

---

# 작업 요청 형식

항상 아래 형식 사용:

[목표]
[현재 문제]
[수정 대상 파일]
[제약 조건]

---

# 수정 원칙

- 최소 수정
- 기존 구조 유지
- Graph 흐름 유지
- Agent 역할 유지

---

# 성능 최적화 규칙

- 불필요한 LLM 호출 금지
- RAG 결과 최소화
- SQL 단순화

---

# 보안 규칙

- 읽기 전용 쿼리만 허용
- DB 보호 최우선

---

# 작업 기록 시스템 (필수)

모든 코드 수정 작업은 반드시 기록을 남긴다.

## 1. 작업 기록 파일 생성

작업 요청이 들어오면 아래 경로에 파일 생성:

ai-history/tasks/{timestamp}_{task_name}.md

### 형식

- timestamp: YYYYMMDD_HHMMSS
- task_name: snake_case

---

## 2. 기록 내용 (필수)

파일에는 반드시 아래 내용 포함:

### [요청]

사용자가 입력한 작업 요청 원문

---

### [분석]

- 문제 원인
- 영향 범위 (어떤 파일 영향 받는지)

---

### [수정 내용]

- 수정된 파일 목록
- 변경된 코드 설명

---

### [변경 코드]

```diff
# before / after 형태로 작성