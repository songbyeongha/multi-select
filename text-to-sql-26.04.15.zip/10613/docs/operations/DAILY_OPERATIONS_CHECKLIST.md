# 일일 운영 체크리스트

매일 실행하면 좋은 항목들입니다. 자동화하거나 업무 시작 전 실행하세요.

---

## 필수 (매일)

### 1. 연결 + 유지보수 일괄 실행

```powershell
.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db-id>
```

이 명령 하나로:
- Oracle 연결 상태 확인 (`doctor`)
- 메타데이터 갱신 + 벡터 재구축 + 자동 학습 (`maintain` 1 사이클)

---

## 선택 (필요 시)

### DB 스키마가 변경된 경우

```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db-id>
```

신규 테이블 추가, 컬럼 변경 시 실행합니다.

### E2E 회귀 테스트 실행

```powershell
.venv\Scripts\python.exe scripts\run_ops.py test ^
    --db-id <db-id> ^
    --catalog data/catalog.json ^
    --report data/e2e_report.json
```

카탈로그(질문-정답 쌍)가 있을 때 주기적으로 실행해 품질을 모니터링합니다.

### 수동으로 단건 질문 테스트

```powershell
.venv\Scripts\python.exe scripts\run_cli.py -q "오늘 생산 현황을 보여줘"
```

---

## 로그 / 결과 확인 위치

| 항목 | 위치 |
|------|------|
| 메타데이터 | `src/text2sql/config/generated/` |
| 피드백 기록 | `data/feedback/` |
| 벡터 인덱스 | `data/vector_store/` |
| E2E 리포트 | `data/e2e_report.json` (--report 지정 시) |

---

## 이상 징후 체크리스트

- [ ] `doctor` 에서 `[OK]` 확인
- [ ] SQL 생성 결과가 빈 결과(empty result) 로 계속 나오는지 확인
- [ ] LLM 응답이 느려졌는지 확인 (Ollama 경우 메모리 부족 징후)
- [ ] `data/feedback/` 에 1~2점 피드백이 쌓이는지 주기적으로 확인

---

## 주간 / 정기

### 메타데이터 수동 오버레이 검토

`src/text2sql/config/generated/schema_metadata_oracle_manual.json` 을 열어 자동 생성된 설명이 실제 업무 용어와 맞는지 확인합니다.

자세한 방법 → [../metadata/SQL_METADATA_ENRICHMENT.md](../metadata/SQL_METADATA_ENRICHMENT.md)

### 벡터 재구축 강제 실행

```powershell
.venv\Scripts\python.exe scripts\run_ops.py maintain ^
    --db-id <db-id> ^
    --no-metadata ^
    --no-enrich
```

---

## 긴급 대응

### SQL 생성이 갑자기 잘못되는 경우

1. `doctor` 로 DB 연결 확인
2. `prepare` 로 메타데이터 재추출
3. `maintain` 으로 벡터 재구축

### LLM 엔드포인트 장애

- Ollama: `ollama serve` 재시작
- Azure: Azure Portal에서 할당량/상태 확인

### 메타데이터 초기화 (극단적 경우)

```powershell
# generated/ 폴더 내용 삭제 후 재생성
rd /s /q src\text2sql\config\generated\
mkdir src\text2sql\config\generated\
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db-id>
```
