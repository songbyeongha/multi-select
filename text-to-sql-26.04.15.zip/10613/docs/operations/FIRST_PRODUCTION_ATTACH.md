# 첫 Oracle DB 연결 — 단계별 가이드

처음으로 운영 Oracle DB를 이 시스템에 연결하는 전체 절차를 설명합니다.

---

## 사전 조건

- Python 3.10+ 설치
- Oracle DB 접근 가능 계정 (SELECT 권한)
- LLM 엔드포인트 (Ollama 로컬 또는 Azure OpenAI)

---

## 단계 1 — 패키지 설치

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

---

## 단계 2 — .env 구성

```powershell
copy .env.example .env
```

최소 필수 항목:

```env
T2SQL_DB_HOST=your-oracle-host
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=YOURPDB
T2SQL_DB_USER=YOURUSER
T2SQL_DB_PASSWORD=YOURPASSWORD
T2SQL_DB_SCHEMA=YOURSCHEMA
```

> **주의**: `T2SQL_DB_READ_ONLY=true` 는 꼭 유지하세요. 이 설정이 SELECT 이외의 쿼리를 차단합니다.

### LLM 설정 (Ollama 기본)

```env
T2SQL_LLM_PROVIDER=openai_compatible
T2SQL_LLM_BASE_URL=http://localhost:11434/v1
T2SQL_LLM_API_KEY=ollama
T2SQL_LLM_MODEL_PRIMARY=qwen3:8b
```

### LLM 설정 (Azure OpenAI)

```env
SKCC_AZURE_ENDPOINT=https://your-resource.openai.azure.com/
SKCC_AZURE_OPENAI_KEY=your-key
SKCC_AZURE_MODEL=gpt-4o
T2SQL_LLM_PROVIDER=azure
```

---

## 단계 3 — Oracle 연결 검증

```powershell
.venv\Scripts\python.exe scripts\run_ops.py doctor
```

성공 예시:
```
[1/1] Oracle 연결 확인
  → [OK] oracle_prod_local connected
  → [OK] ALL_TABLES accessible (1,234 rows)
```

### 오류 대응

| 오류 메시지 | 원인 | 해결 |
|-------------|------|------|
| `ORA-12541` | 리스너 미가동 | Oracle 리스너 시작 또는 HOST/PORT 확인 |
| `ORA-01017` | 계정/비밀번호 오류 | .env 자격증명 확인 |
| `ORA-12514` | 서비스명 오류 | SERVICE_NAME 확인 |

---

## 단계 4 — 메타데이터 추출 및 강화

> `<db-id>` 는 `.env`의 `T2SQL_DB_ID` 값으로 교체하세요 (예: `oracle_prod`).

```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db-id>
```

이 명령은 두 단계로 실행됩니다:

1. **export**: `ALL_TABLES`, `ALL_COLUMNS`, `ALL_CONSTRAINTS` 메타뷰에서 스키마 정보 수집
2. **enrich**: LLM을 통해 컬럼 한국어 설명, 도메인 힌트 자동 생성

결과 파일:
```
src/text2sql/config/generated/
  schema_metadata_oracle.json        ← 자동 추출 메타데이터 (소스)
  schema_metadata_oracle_manual.json ← 수동 편집용 오버레이
  domain_hints_oracle.json           ← LLM 생성 도메인 힌트 (소스)
  domain_hints_oracle_manual.json    ← 수동 편집용 오버레이
```

특정 테이블만 처리하려면:
```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare ^
    --db-id <db-id> ^
    --include PROD_ORDER,WIP_LOT,ITEM_MASTER
```

---

## 단계 5 — 첫 질문으로 동작 확인

```powershell
.venv\Scripts\python.exe scripts\run_cli.py -q "최근 한 달 생산량을 보여줘"
```

출력 예시:
```
[질문] 최근 한 달 생산량을 보여줘
[SQL]
  SELECT FACTORY_CD, SUM(PROD_QTY) AS TOTAL_QTY
  FROM PROD_RESULT
  WHERE PROD_DATE >= ADD_MONTHS(TRUNC(SYSDATE), -1)
  GROUP BY FACTORY_CD
  FETCH FIRST 50 ROWS ONLY

[결과 미리보기 — 3행]
  FACTORY_CD  TOTAL_QTY
  ──────────  ─────────
  F01         12,345
  F02          8,920
  ...
```

---

## 단계 6 — (선택) E2E 테스트

쿼리 카탈로그 JSON이 있으면 자동화 E2E 테스트를 실행할 수 있습니다.

```powershell
.venv\Scripts\python.exe scripts\run_ops.py test ^
    --db-id <db-id> ^
    --catalog data/catalog.json ^
    --report data/e2e_report.json
```

---

## 단계 7 — (선택) Web UI

```powershell
.venv\Scripts\python.exe -m streamlit run app.py
```

`http://localhost:8501` 에서 채팅 UI 접속.

---

## 한 번에 실행 (first-run)

3~5단계를 묶어서 실행하는 단축 명령:

```powershell
.venv\Scripts\python.exe scripts\run_ops.py first-run ^
    --db-id <db-id> ^
    --smoke-question "최근 한 달 생산량은?" ^
    --run-e2e ^
    --catalog data/catalog.json
```

---

## 다음 단계

- 메타데이터 품질을 높이려면 → [../metadata/SQL_METADATA_ENRICHMENT.md](../metadata/SQL_METADATA_ENRICHMENT.md)
- 일상 운영 루틴 → [DAILY_OPERATIONS_CHECKLIST.md](DAILY_OPERATIONS_CHECKLIST.md)
- 자주 쓰는 명령 참조 → [OPERATOR_ONE_PAGE.md](OPERATOR_ONE_PAGE.md)
