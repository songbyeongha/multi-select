# Text-to-SQL Assistant — 코드베이스 완전 해설

> 초보자도 이해할 수 있도록 작성된 구조 분석 문서

---

## 한 줄 요약

사용자가 한국어로 질문하면 → AI가 자동으로 Oracle SQL을 생성해서 실행하고 → 결과를 보여주는 시스템

---

## 목차

1. [폴더 구조와 역할](#1-폴더-구조와-역할)
2. [실행 흐름 (13단계 파이프라인)](#2-실행-흐름-13단계-파이프라인)
3. [핵심 비즈니스 로직](#3-핵심-비즈니스-로직)
4. [주요 파일별 역할](#4-주요-파일별-역할)
5. [데이터 흐름 (GraphState)](#5-데이터-흐름-graphstate)
6. [기술 스택](#6-기술-스택)
7. [코드 읽기 입문 순서](#7-코드-읽기-입문-순서)

---

## 1. 폴더 구조와 역할

```
10613/
├── app.py                      ← Streamlit 웹앱 시작점 (여기서 실행)
│
├── src/text2sql/               ← 핵심 코드 전체
│   │
│   ├── lg/                     ← 파이프라인 설계도 (LangGraph)
│   │   ├── graph.py            ← 전체 실행 흐름 (13개 단계 연결)
│   │   └── state.py            ← 단계 간 공유되는 데이터 상자
│   │
│   ├── agents/                 ← 각 단계별 실제 작업 코드
│   │   ├── decomposer.py       ← 1단계: 질문 분석
│   │   ├── schema_nodes.py     ← 2단계: 테이블/컬럼 선택
│   │   ├── generation_nodes.py ← 3단계: SQL 초안 생성
│   │   ├── validation_nodes.py ← 4단계: 검증 + 실행
│   │   ├── repair_output.py    ← 5단계: 수정 + 결과 출력
│   │   └── _utils.py           ← 공통 유틸 (trace, 캐시, 해시)
│   │
│   ├── llm/                    ← AI 모델 연결
│   │   ├── client.py           ← OpenAI/Azure 클라이언트
│   │   └── prompts.py          ← AI에게 보내는 모든 지시문(프롬프트)
│   │
│   ├── rag/                    ← 스키마 검색 엔진
│   │   ├── schema_rag.py       ← 관련 테이블 찾기 (BM25 + 벡터)
│   │   └── vector_store.py     ← 벡터 저장소 (ChromaDB)
│   │
│   ├── tools/                  ← 도구 모음
│   │   ├── executor.py         ← SQL 실행기
│   │   ├── guardrails.py       ← 보안 검사 (DROP 금지 등)
│   │   ├── sql_postprocess.py  ← SQL 자동 정규화 (AST 기반)
│   │   ├── cache.py            ← 결과 캐싱
│   │   ├── date_tools.py       ← 상대 날짜 파싱 ("이번 달" 등)
│   │   └── db_adapters/        ← Oracle DB 연결
│   │       ├── oracle_adapter.py  ← Oracle 전용 구현
│   │       ├── factory.py         ← Adapter 생성 팩토리
│   │       └── base.py            ← 추상 베이스 클래스
│   │
│   ├── memory/                 ← 대화 기억 (이전 질문 참고)
│   │   └── conversation.py
│   │
│   ├── feedback/               ← 피드백 저장 + 자동 학습
│   │   ├── store.py            ← 피드백 저장소
│   │   ├── learner.py          ← AutoLearner (few-shot 자동 등록)
│   │   ├── auto_scorer.py      ← 자동 점수 부여
│   │   └── evaluator.py        ← 품질 평가
│   │
│   ├── config/                 ← 설정 (DB, LLM 연결 정보)
│   │   ├── settings.py         ← 환경변수 기반 설정 클래스
│   │   ├── metadata_utils.py   ← 메타데이터 로드/병합
│   │   └── generated/          ← 자동 생성 메타데이터 JSON
│   │
│   └── ui/                     ← 화면 구성
│       ├── context.py          ← 앱 컨텍스트 초기화
│       ├── pipeline.py         ← 파이프라인 실행 헬퍼
│       ├── sidebar.py          ← 사이드바 (설정, 스키마 탐색)
│       ├── renderers.py        ← 결과 렌더링
│       └── tabs/               ← 각 탭 UI
│           ├── main_tab.py     ← 💬 질의 실행
│           ├── batch_tab.py    ← 📦 대량 질의
│           ├── history_tab.py  ← 📜 히스토리
│           ├── learn_tab.py    ← 🧠 학습 로그
│           └── operations_tab.py ← 🛠️ 운영 관리
│
├── scripts/                    ← CLI 도구 + 관리 스크립트
│   ├── run_cli.py              ← CLI 인터페이스
│   ├── export_oracle_metadata.py ← 메타데이터 추출
│   ├── enrich_metadata_from_sql.py ← 메타데이터 자동 강화
│   ├── run_e2e_suite.py        ← E2E 테스트
│   └── check_oracle_connection.py ← 연결 테스트
│
├── docs/                       ← 문서
│   └── CODEBASE_GUIDE.md       ← 설계 문서
│
└── data/                       ← 런타임 데이터
    ├── feedback/               ← 피드백 기록 (JSON)
    └── vector_store/           ← ChromaDB 벡터 저장소
```

---

## 2. 실행 흐름 (13단계 파이프라인)

사용자가 질문을 입력하면 아래 13단계를 순서대로 거칩니다. 각 단계는 **LangGraph 노드**라 부르며, 이전 단계의 결과를 받아서 처리하고 다음 단계로 넘깁니다.

```
사용자 입력: "안전재고보다 현재고가 낮은 품목을 보여줘"
       │
       ▼
 ┌─────────────────────────────────────────────────────────────┐
 │                                                             │
 │  [1] Decomposer           질문 분석                         │
 │      - 의도 파악: "조건 필터링 + 목록 조회"                 │
 │      - 패턴 분류: threshold_filter                          │
 │      - 날짜 해석: "이번 달" → 2026-04                       │
 │                          │                                  │
 │  [2] SchemaSelector       관련 테이블 검색                  │
 │      - BM25 키워드 검색 + 벡터 유사도 검색                  │
 │      - 결과: [INVENTORY, PRODUCT, FACTORY]                  │
 │                          │                                  │
 │  [3] ValueRetriever       값 DB 검증                        │
 │      - "안전재고" → 실제 컬럼명 SAFETY_STOCK 확인           │
 │                          │                                  │
 │  [4] JoinPlanner          JOIN 경로 계획                    │
 │      - 외래키: INVENTORY.PRODUCT_ID → PRODUCT.ID            │
 │                          │                                  │
 │  [5] CandidateGenerator   SQL 후보 3개 병렬 생성            │
 │      - 전략A (conservative): 간단한 WHERE 조건              │
 │      - 전략B (recall):       더 넓은 조건                   │
 │      - 전략C (metric):       메트릭/집계 활용               │
 │                          │                                  │
 │  [6] SQLPostProcess       SQL 자동 정규화 (AST)             │
 │      - 불필요한 CAST 제거, LEFT→INNER JOIN 변환             │
 │                          │                                  │
 │  [7] Guardrails           보안 검사                         │
 │      - DROP/TRUNCATE/ALTER 없음? SELECT만? → 통과 ✅        │
 │        ┌─────────────────┤                                  │
 │        │ 실패             │ 통과                            │
 │        ▼                 ▼                                  │
 │  [Repair]          [8] UnitTester     정적 문법 검사        │
 │  SQL 수정               │ 통과                             │
 │  최대 3회               ▼                                   │
 │  재시도          [9] ExecutePreview   DB 실행               │
 │        ▲              - Oracle DB에서 실제 실행             │
 │        │              - 최대 50행 미리보기                  │
 │        │                │ 성공                             │
 │        │                ▼                                   │
 │        └──── [10] Judge              결과 품질 판정 (LLM)  │
 │  실패(3회 초과)   - "질문과 결과가 일치하는가?" 판정        │
 │        │                │ 승인                             │
 │        ▼                ▼                                   │
 │  [SafeFail]      [11] ResultSummarizer  결과 요약           │
 │  안전 실패        - "조건 미달 품목 12건을 찾았습니다"       │
 │                          │                                  │
 │                  [12] AuditLogger    감사 로그 기록         │
 │                  [13] Memory 저장    다음 질문 시 참고       │
 │                                                             │
 └─────────────────────────────────────────────────────────────┘
       │
       ▼
 SQL + 결과 테이블 화면에 표시
```

### 조건부 분기 규칙

| 노드 | 성공 시 | 실패 시 |
|------|---------|---------|
| Guardrails | UnitTester로 이동 | Repair로 이동 |
| UnitTester | ExecutePreview로 이동 | Repair로 이동 |
| ExecutePreview | Judge로 이동 | Repair로 이동 |
| Judge | ResultSummarizer로 이동 | Repair로 이동 |
| Repair (3회 미만) | Guardrails로 다시 시도 | SafeFail |

---

## 3. 핵심 비즈니스 로직

### 3-1. 스마트 스키마 검색 (하이브리드 RAG)

테이블이 수백 개일 때 전부 AI에 넘기면 비용과 속도 문제가 생깁니다. 그래서 **관련 테이블만 골라** 넘깁니다.

```
최종 스코어 = α × BM25 점수 + (1-α) × 벡터 유사도 점수

예) 질문: "월별 생산량"
    BM25:   PRODUCTION_ORDER=0.9,  INVENTORY=0.3,  CUSTOMER=0.1
    벡터:   PRODUCTION_ORDER=0.85, WORK_CENTER=0.7, FACTORY=0.5
    최종:   PRODUCTION_ORDER 선택, 외래키로 연결된 WORK_CENTER도 포함
```

추가 점수 부여:
- **도메인 보너스**: `domain_hints.json`에 등록된 키워드 매칭 시 가산
- **외래키 부스트**: 선택된 테이블과 FK로 연결된 테이블에 가산

### 3-2. 3후보 경쟁 방식 (Self-Consistency Voting)

SQL을 한 번만 생성하면 틀릴 위험이 있습니다. **3가지 다른 전략**으로 동시에 생성하고, 실제 DB에서 실행해 **같은 결과를 내는 쪽을 다수결**로 선택합니다.

```
전략A 생성 → DB 실행 → 결과: 12행 ┐
전략B 생성 → DB 실행 → 결과: 12행 ┤← 다수결 승리 (자신감 높은 쪽 선택)
전략C 생성 → DB 실행 → 결과: 0행  ┘← 탈락
```

### 3-3. AST 기반 SQL 자동 정규화

LLM이 생성한 SQL의 불필요한 패턴을 코드로 자동 제거합니다. (프롬프트 지시 아님, 확정적 변환)

| 변환 전 | 변환 후 | 이유 |
|---------|---------|------|
| `CAST(x AS INT)` | `x` | Oracle은 암묵적 변환 |
| `LEFT JOIN` | `INNER JOIN` | NULL 포함 방지 |
| `COALESCE(x, 0)` | `x` | 방어적 패턴 제거 |
| `WITH a AS (...) WITH b AS (...)` | `WITH a AS (...), b AS (...)` | 올바른 CTE 문법 |

### 3-4. 피드백 자동 학습 루프

```
사용자가 결과에 점수를 매김
        │
        ├─ 4~5점 (좋음) ───► few-shot 예제 자동 등록
        │                    keyword_map 자동 확장
        │                    → 다음 번엔 더 정확하게
        │
        └─ 1~2점 (나쁨) ───► 오류 패턴 기록
                             negative_hints에 저장
                             → 같은 실수 반복 방지
```

### 3-5. 보안 다중 방어

```
1. Guardrails (7단계)
   - sqlglot AST로 SQL 구문 트리 파싱
   - DROP/TRUNCATE/ALTER/INSERT/UPDATE/DELETE 즉시 차단
   - 존재하지 않는 테이블 참조 감지

2. Oracle Adapter (실행 직전)
   - DML/DDL 정규식으로 하드 차단 (읽기 전용 모드)
   - ; 제거 후 실행 (Oracle cursor 호환)

3. 타임아웃
   - 기본 15초 초과 시 자동 중단

4. 행 수 제한
   - FETCH FIRST N ROWS ONLY 자동 추가 (기본 50,000행)
```

---

## 4. 주요 파일별 역할

### app.py — 웹앱 진입점

```python
# 앱 실행 시 하는 일
render_app_shell()          # CSS/레이아웃 초기화
init_session_state()        # Streamlit 세션 상태 초기화
app_context = build_app_context()  # Oracle 설정 + 날짜 도구 로드
max_retries, hitl_enabled = render_sidebar(app_context)  # 사이드바

# 5개 탭 렌더링
tab_main → render_main_tab()       # 💬 질의 실행
tab_batch → render_batch_tab()     # 📦 대량 질의
tab_history → render_history_tab() # 📜 히스토리
tab_learn → render_learn_tab()     # 🧠 학습 로그
tab_ops → render_operations_tab()  # 🛠️ 운영 관리
```

### lg/graph.py — 파이프라인 설계도

노드(단계)를 등록하고 엣지(연결)로 흐름을 정의하는 파일입니다. 실제 로직은 `agents/` 폴더에 있고, 이 파일은 **어떤 순서로 실행할지**만 정의합니다.

```python
def build_graph() -> StateGraph:
    g = StateGraph(GraphState)

    # 노드 등록 (13개)
    g.add_node("decomposer",          node_decomposer)
    g.add_node("schema_selector",     node_schema_selector)
    g.add_node("value_retriever",     node_value_retriever)
    g.add_node("join_planner",        node_join_planner)
    g.add_node("candidate_generator", node_candidate_generator)
    g.add_node("sql_postprocess",     node_sql_postprocess)
    g.add_node("guardrails",          node_guardrails)
    g.add_node("unit_tester",         node_unit_tester)
    g.add_node("execute_preview",     node_execute_preview)
    g.add_node("judge",               node_judge)
    g.add_node("repair",              node_repair)
    g.add_node("result_output",       node_result_output)
    g.add_node("safe_fail",           node_safe_fail)

    # 직선 경로
    g.add_edge(START, "decomposer")
    g.add_edge("decomposer", "schema_selector")
    # ...

    # 조건부 분기
    g.add_conditional_edges("guardrails", _route_guardrails, {
        "unit_tester": "unit_tester",
        "repair": "repair",
    })
    return g
```

### lg/state.py — 공유 데이터 상자

파이프라인의 모든 단계가 이 TypedDict를 공유합니다. 각 단계는 여기서 값을 읽고, 처리 결과를 여기에 씁니다.

```python
class GraphState(TypedDict, total=False):
    # 입력
    question: str             # "안전재고보다 현재고가 낮은 품목"
    database_id: str          # "oracle_db"
    db_path: str              # "__oracle__"

    # Decomposer가 채움
    intent: str               # "threshold_filter"
    query_pattern: str        # "simple" | "group_top_n" | ...
    current_date: str         # "2026-04-14"
    extracted_values: dict    # {"filters": {"안전재고": "SAFETY_STOCK"}}

    # SchemaSelector가 채움
    selected_tables: list     # ["INVENTORY", "PRODUCT"]
    schema_text: str          # LLM에게 넘길 스키마 텍스트

    # CandidateGenerator가 채움
    candidates: list          # [SQLCandidate, SQLCandidate, ...]

    # 검증 단계들이 채움
    guard_passed: bool
    ut_passed: bool
    exec_report: ExecReport   # 실행 결과
    judge_accepted: bool

    # Repair 추적
    repair_count: int         # 현재 재시도 횟수
    max_retries: int          # 최대 재시도 (기본 3)
    last_error_type: ErrorType

    # 최종 결과
    final_sql: str
    final_result: list        # 결과 행 목록
    success: bool
```

### config/settings.py — 설정 클래스

`.env` 파일의 환경변수를 읽어 설정 객체를 만듭니다.

```
주요 환경변수 (.env 파일에 설정)

[LLM]
T2SQL_LLM_PROVIDER=openai_compatible    # 또는 azure_openai
T2SQL_LLM_BASE_URL=http://localhost:8000/v1
T2SQL_LLM_API_KEY=your-key
T2SQL_LLM_MODEL_PRIMARY=gpt-4

[Oracle DB]
T2SQL_DB_DIALECT=oracle
T2SQL_DB_HOST=your-oracle-host
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=your-service
T2SQL_DB_USER=your-user
T2SQL_DB_PASSWORD=your-password
T2SQL_DB_SCHEMA=your-schema

[보안]
T2SQL_MAX_ROWS=50000
T2SQL_TIMEOUT_MS=15000
T2SQL_ENFORCE_LIMIT=true
```

### llm/prompts.py — AI 지시문 모음

LLM에게 보내는 모든 System/User 프롬프트가 여기에 정의됩니다.

| 프롬프트 | 용도 |
|---------|------|
| `DECOMPOSER_SYS/USR` | 질문 분석 지시 |
| `SCHEMA_SYS/USR` | 테이블 선택 지시 |
| `COMPOSER_SYS/USR` | SQL 생성 지시 |
| `UT_SYS/USR` | SQL 단위 테스트 지시 |
| `JUDGE_SYS/USR` | 결과 품질 판정 지시 |
| `REPAIR_SYS/USR` | SQL 수정 지시 |
| `SUMMARIZER_SYS/USR` | 결과 요약 지시 |
| `DIALECT_GUIDE_ORACLE` | Oracle SQL 규칙 (프롬프트에 삽입) |

---

## 5. 데이터 흐름 (GraphState)

질문 하나가 처리되는 동안 GraphState에 데이터가 축적되는 과정입니다.

```
입력 시점
state = {
    "question": "안전재고보다 현재고가 낮은 품목",
    "database_id": "oracle_db",
    "db_path": "__oracle__",
}

Decomposer 실행 후
state += {
    "intent": "현재고가 안전재고보다 낮은 품목 필터링",
    "query_pattern": "threshold_filter",
    "current_date": "2026-04-14",
    "extracted_values": {"filters": {"현재고": "CURRENT_STOCK"}},
}

SchemaSelector 실행 후
state += {
    "selected_tables": ["INVENTORY", "PRODUCT", "FACTORY"],
    "schema_text": "## INVENTORY\n  PRODUCT_ID  NUMBER ...",
}

CandidateGenerator 실행 후
state += {
    "candidates": [
        SQLCandidate(sql="SELECT p.PRODUCT_NAME ...", strategy="conservative"),
        SQLCandidate(sql="SELECT ...", strategy="recall"),
    ]
}

ExecutePreview 실행 후
state += {
    "exec_report": ExecReport(ok=True, row_count=12, rows_preview=[...]),
    "selected_sql": "SELECT p.PRODUCT_NAME, f.FACTORY_NAME ...",
}

최종
state += {
    "final_sql": "SELECT p.PRODUCT_NAME, f.FACTORY_NAME ...",
    "final_result": [{"PRODUCT_NAME": "볼트M6", "FACTORY_NAME": "1공장"}, ...],
    "result_summary": "현재고가 안전재고보다 낮은 품목 12건을 찾았습니다.",
    "success": True,
}
```

---

## 6. 기술 스택

| 역할 | 기술 | 버전 |
|------|------|------|
| 파이프라인 | LangGraph | 0.2.62 |
| AI 모델 | OpenAI / Azure OpenAI | openai 1.61.0 |
| SQL 파싱·검증 | sqlglot | 26.1.1 |
| Oracle DB | python-oracledb | 2.0.0+ |
| 벡터 검색 | ChromaDB | 0.5.0+ |
| 웹 UI | Streamlit | 1.42.0 |
| CLI 스타일링 | Rich | 13.0.0+ |
| 환경변수 | python-dotenv | 1.0.1 |

### LangGraph란?

LangGraph는 AI 파이프라인을 **그래프(노드 + 엣지)** 형태로 설계하는 프레임워크입니다.

```
일반 파이프라인:  A → B → C → D   (항상 직선)

LangGraph:        A → B ─┬─ C → D
                         └─ E → B  (조건에 따라 분기, 루프 가능)
```

이 프로젝트에서는 검증 실패 시 Repair 노드로 분기하고, 재시도 후 다시 Guardrails로 돌아오는 루프를 구현하는 데 사용합니다.

---

## 7. 코드 읽기 입문 순서

처음 이 코드를 접하는 분들을 위한 학습 순서입니다.

### Step 1 — 전체 흐름 파악 (1시간)

1. `app.py` — 앱이 어떻게 시작되는지
2. `src/text2sql/lg/graph.py` — 13단계가 어떻게 연결되는지
3. `src/text2sql/lg/state.py` — 단계 간 어떤 데이터가 오가는지

### Step 2 — 각 단계 로직 이해 (2~3시간)

4. `src/text2sql/agents/decomposer.py` — 질문 분석 로직
5. `src/text2sql/agents/schema_nodes.py` — 테이블 선택 로직
6. `src/text2sql/agents/generation_nodes.py` — SQL 생성 로직
7. `src/text2sql/agents/validation_nodes.py` — 검증 로직
8. `src/text2sql/agents/repair_output.py` — 수정 + 출력 로직

### Step 3 — 설정과 도구 (1시간)

9. `src/text2sql/config/settings.py` — 어떤 설정이 있는지
10. `src/text2sql/llm/prompts.py` — AI에게 무슨 지시를 하는지
11. `src/text2sql/tools/guardrails.py` — 보안 검사 방법

### Step 4 — RAG와 피드백 (1시간)

12. `src/text2sql/rag/schema_rag.py` — 하이브리드 검색 방법
13. `src/text2sql/feedback/learner.py` — 자동 학습 방법

### 핵심 개념 정리

| 개념 | 설명 |
|------|------|
| **LangGraph** | 노드와 엣지로 구성된 AI 파이프라인 프레임워크 |
| **GraphState** | 파이프라인 전체에서 공유되는 딕셔너리 (데이터 상자) |
| **노드** | 특정 작업을 수행하는 함수 하나 |
| **조건부 엣지** | 이전 노드 결과에 따라 다음 노드를 결정하는 분기 |
| **RAG** | 스키마에서 관련 정보를 검색해 LLM에 제공하는 방식 |
| **Guardrails** | 보안·문법 검증 레이어 (DROP 금지, 문법 체크) |
| **Few-shot** | LLM에 예제 쿼리를 제공해 정확도를 높이는 기법 |
| **Repair** | 실패한 SQL을 LLM이 분석해 수정하는 자동 복구 |
| **Self-Consistency** | 여러 후보 중 동일 결과를 내는 쪽을 다수결로 선택 |
| **Feedback Loop** | 사용자 피드백 → AutoLearner → 설정 자동 갱신 |
| **AST** | SQL을 트리 구조로 파싱해 코드로 변환·검증하는 방식 |
| **Metadata** | 테이블·컬럼의 이름, 타입, 설명, 도메인 정보를 담은 JSON |
