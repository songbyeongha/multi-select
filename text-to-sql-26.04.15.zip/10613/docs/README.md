# 문서 인덱스

이 폴더의 모든 문서는 **Oracle Text-to-SQL Assistant** 운영을 위한 참조 자료입니다.

---

## 처음 시작

| 문서 | 내용 |
|------|------|
| [START_HERE.md](START_HERE.md) | 처음 사용자 진입점 — 여기서 시작하세요 |
| [operations/FIRST_PRODUCTION_ATTACH.md](operations/FIRST_PRODUCTION_ATTACH.md) | Oracle DB 첫 연결 단계별 가이드 |
| [operations/ORACLE_DB_QUICKSTART.md](operations/ORACLE_DB_QUICKSTART.md) | Oracle 환경 빠른 설치/설정 |

---

## 일상 운영

| 문서 | 내용 |
|------|------|
| [operations/OPERATOR_ONE_PAGE.md](operations/OPERATOR_ONE_PAGE.md) | 한 장 참조 카드 — 자주 쓰는 명령어 |
| [operations/ENDPOINT_USAGE_GUIDE.md](operations/ENDPOINT_USAGE_GUIDE.md) | CLI / Streamlit UI 사용법 |
| [operations/DAILY_OPERATIONS_CHECKLIST.md](operations/DAILY_OPERATIONS_CHECKLIST.md) | 일일 운영 체크리스트 |
| [operations/SCRIPT_SELECTION_GUIDE.md](operations/SCRIPT_SELECTION_GUIDE.md) | 어떤 스크립트를 쓸지 결정 가이드 |

---

## 배포 / 릴리즈

| 문서 | 내용 |
|------|------|
| [operations/RELEASE_CHECKLIST.md](operations/RELEASE_CHECKLIST.md) | 배포 전 검증 체크리스트 |

---

## 메타데이터

| 문서 | 내용 |
|------|------|
| [metadata/SQL_METADATA_ENRICHMENT.md](metadata/SQL_METADATA_ENRICHMENT.md) | 스키마 메타데이터 강화 가이드 |

---

## 아키텍처 / 코드 이해

| 문서 | 내용 |
|------|------|
| [CODEBASE_GUIDE.md](CODEBASE_GUIDE.md) | 폴더 구조, 파이프라인, 핵심 로직 상세 설명 |
| [architecture/PROJECT_DESIGN.md](architecture/PROJECT_DESIGN.md) | 시스템 설계 의사결정 기록 |

---

