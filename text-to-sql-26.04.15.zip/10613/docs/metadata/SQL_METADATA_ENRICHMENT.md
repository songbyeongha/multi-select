# 스키마 메타데이터 강화 가이드

Text-to-SQL 품질은 메타데이터 품질에 직결됩니다.
이 문서는 자동 추출된 메타데이터를 업무 맥락에 맞게 보완하는 방법을 설명합니다.

---

## 파일 구조

```
src/text2sql/config/generated/
  schema_metadata_oracle.json        ← [자동] Oracle 메타뷰에서 추출 (덮어쓰기 금지)
  schema_metadata_oracle_manual.json ← [수동] 스키마 설명 오버레이 ★편집 대상
  domain_hints_oracle.json           ← [자동] 스키마 기반 키워드/관계 자동 생성 (덮어쓰기 금지)
  domain_hints_oracle_manual.json    ← [수동] 도메인 힌트 오버레이 ★편집 대상
```

**자동 파일(`_oracle.json`)은 `prepare` 실행 시 재생성됩니다.**  
**수동 편집은 반드시 `_manual.json` 파일에만 하세요. — 재생성 시 보존됩니다.**

---

## 1단계 — 자동 추출 실행

> `<db-id>` 는 `.env`의 `T2SQL_DB_ID` 값으로 교체하세요. JSON 예제의 `"oracle_prod"` 키도 실제 값으로 바꾸세요.

```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db-id>
```

실행 결과 생성 파일:

| 파일 | 내용 |
|------|------|
| `schema_metadata_oracle.json` | 모든 테이블·컬럼 정보 (Oracle ALL_COLUMNS 기반) |
| `schema_metadata_oracle_manual.json` | 빈 편집 템플릿 (첫 실행 시 생성) |
| `domain_hints_oracle.json` | 자동 생성 keyword_map + relation_bonus_map |
| `domain_hints_oracle_manual.json` | 빈 편집 템플릿 + 사용 가이드 |

---

## 2단계 — 스키마 설명 편집 (schema_metadata_oracle_manual.json)

`schema_metadata_oracle_manual.json`에 덮어쓸 내용을 추가합니다.

```json
{
  "databases": {
    "oracle_prod": {
      "tables": {
        "PROD_RESULT": {
          "description": "일별 공장별 생산 실적. 주문 대비 실적 분석에 사용.",
          "aliases": ["생산실적", "실적"],
          "columns": {
            "PROD_DATE": {
              "description": "생산 날짜 (YYYYMMDD 문자열)",
              "domain_hint": "날짜 필터 시 TO_DATE(PROD_DATE, 'YYYYMMDD') 사용"
            },
            "PROD_QTY": {
              "description": "생산 수량 (단위: EA)",
              "domain_hint": "공장별 합계는 SUM(PROD_QTY) GROUP BY FACTORY_CD"
            }
          }
        }
      }
    }
  }
}
```

`_manual.json`에 있는 항목이 자동 파일의 동일 항목을 덮어씁니다.  
없는 항목은 자동 파일 값이 그대로 사용됩니다.

---

## 3단계 — 도메인 힌트 편집 (domain_hints_oracle_manual.json)

도메인 힌트는 **SQL 생성 파이프라인 3곳**에서 활용됩니다:

| 필드 | 사용 위치 | 역할 |
|------|-----------|------|
| `keyword_map` | SchemaSelector | 자연어 → 테이블 매핑 (BM25 검색 보강) |
| `relation_bonus_map` | SchemaSelector | 자주 함께 쓰이는 테이블 관계 (JOIN 우선순위) |
| `few_shot_examples` | CandidateGenerator | LLM에 전달하는 질문-SQL 예제 |
| `common_patterns` | CandidateGenerator | query_pattern별 SQL 조각 (참조용) |

### 3-1. keyword_map — 키워드 매핑

자연어 키워드를 테이블명으로 연결합니다.  
사용자가 "재고", "LOT", "생산량" 같은 용어를 쓸 때 정확한 테이블을 찾도록 합니다.

```json
{
  "databases": {
    "oracle_prod": {
      "keyword_map": {
        "재고": ["INVENTORY_BALANCE", "INVENTORY_TRANSACTION"],
        "lot": ["WIP_LOT"],
        "생산량": ["PROD_RESULT"],
        "불량": ["QC_DEFECT", "QC_INSPECTION"],
        "납기": ["DELIVERY_PLAN", "PROD_ORDER"]
      }
    }
  }
}
```

> **주의**: `domain_hints_oracle.json`에 자동 생성된 `keyword_map`은 계속 유효합니다.  
> `_manual.json`에 추가하면 자동 생성 맵에 **병합(merge)** 됩니다.

### 3-2. relation_bonus_map — 조인 관계 힌트

함께 조인해서 쓰는 테이블 쌍을 등록합니다.  
SchemaSelector가 관련 테이블을 더 높은 우선순위로 선택합니다.

```json
{
  "databases": {
    "oracle_prod": {
      "relation_bonus_map": {
        "PROD_ORDER": ["PROD_RESULT", "ITEM_MASTER", "BOM"],
        "WIP_LOT": ["QC_INSPECTION", "PROCESS_HISTORY"],
        "ITEM_MASTER": ["INVENTORY_BALANCE", "BOM"]
      }
    }
  }
}
```

### 3-3. few_shot_examples — 질문-SQL 예제

LLM SQL 생성 시 함께 전달되는 참조 예제입니다.  
질문과 유사한 예제가 있으면 LLM 응답 정확도가 크게 향상됩니다.

**형식:**
```json
{
  "databases": {
    "oracle_prod": {
      "few_shot_examples": [
        {
          "question": "이번 달 공장별 생산량 합계를 보여줘",
          "sql": "SELECT FACTORY_CD, SUM(PROD_QTY) AS TOTAL_QTY\nFROM PROD_RESULT\nWHERE PROD_DATE >= TO_CHAR(TRUNC(SYSDATE, 'MM'), 'YYYYMMDD')\nGROUP BY FACTORY_CD\nORDER BY TOTAL_QTY DESC\nFETCH FIRST 50 ROWS ONLY"
        },
        {
          "question": "재고가 안전재고 이하인 품목 목록",
          "sql": "SELECT ITEM_CD, ITEM_NM, CURR_STOCK_QTY, SAFETY_STOCK_QTY\nFROM ITEM_MASTER\nWHERE CURR_STOCK_QTY < SAFETY_STOCK_QTY\nORDER BY CURR_STOCK_QTY ASC\nFETCH FIRST 50 ROWS ONLY"
        }
      ]
    }
  }
}
```

**자동 추가 방법** (카탈로그 파일로 자동 추출):
```powershell
.venv\Scripts\python.exe scripts\run_ops.py prepare ^
    --db-id <db-id> ^
    --catalog data/catalog.json
```

카탈로그에 있는 질문-SQL 쌍이 `few_shot_examples`에 자동으로 추가됩니다.  
카탈로그 형식은 `data/catalog.example.json` 참고.

### 3-4. common_patterns — SQL 패턴 조각

query_pattern(집계/조인/비교 등)에 따라 LLM에 제공되는 참조 SQL 조각입니다.

**키 명명 규칙: `fb_<query_pattern>_<이름>`**

| query_pattern | 사용 시점 |
|---------------|-----------|
| `group_aggregate` | GROUP BY + SUM/AVG 집계 |
| `group_top_n` | 상위 N개 조회 |
| `period_comparison` | 기간 비교 (전년 대비 등) |
| `threshold_filter` | 기준값 이상/이하 필터 |
| `ratio_calculation` | 비율 계산 |
| `running_calc` | 누계 계산 |
| `set_operation` | UNION / INTERSECT |

```json
{
  "databases": {
    "oracle_prod": {
      "common_patterns": {
        "fb_group_aggregate_monthly": "TRUNC(TO_DATE(날짜컬럼, 'YYYYMMDD'), 'MM')",
        "fb_group_aggregate_factory": "GROUP BY FACTORY_CD ORDER BY SUM(PROD_QTY) DESC",
        "fb_threshold_filter_stock": "CURR_STOCK_QTY < SAFETY_STOCK_QTY",
        "fb_period_comparison_yoy": "EXTRACT(YEAR FROM TO_DATE(날짜컬럼, 'YYYYMMDD'))"
      }
    }
  }
}
```

> **참고**: `common_patterns`는 learner가 피드백 데이터를 학습할 때 자동 추가하기도 합니다.  
> 수동 키도 `fb_` 접두사를 사용해야 파이프라인이 인식합니다.

---

## 4단계 — 변경 반영

`_manual.json`을 수정한 후에는 **재실행 없이 즉시 반영**됩니다.  
파이프라인이 쿼리 실행 시마다 파일을 로드합니다.

단, 벡터 인덱스(`keyword_map`, 컬럼 설명 등)를 변경했다면 재구축이 필요합니다:

```powershell
.venv\Scripts\python.exe scripts\run_ops.py maintain ^
    --db-id <db-id> ^
    --no-metadata ^
    --no-enrich ^
    --no-learn
```

`--no-metadata --no-enrich --no-learn` 옵션으로 벡터 재구축만 실행합니다.

---

## 데이터 흐름

```
domain_hints_oracle.json        domain_hints_oracle_manual.json
(자동: keyword_map 포함)     +  (수동: few_shot, keyword 추가 등)
            │                                │
            └────────────── merge ───────────┘
                                │
                    settings.domain_hints(db_id)
                                │
            ┌───────────────────┼────────────────────┐
            ▼                   ▼                    ▼
    SchemaSelector      CandidateGenerator    get_reference_sql
    (keyword_map,       (few_shot_examples)   (common_patterns)
    relation_bonus_map)
```

manual 파일의 값이 자동 파일 값을 **덮어씁니다** (dict는 deep merge, list는 override).

---

## 품질 개선 전략

### 자주 묻는 질문의 SQL이 틀리는 경우

`few_shot_examples`에 해당 질문과 정확한 SQL을 직접 등록합니다.  
정확히 일치하는 질문이 있으면 LLM 없이 즉시 반환합니다.

### 테이블 선택이 틀리는 경우

1. `keyword_map`에 질문에 사용된 용어 → 정확한 테이블 매핑 추가
2. `relation_bonus_map`에 실제 JOIN에서 함께 쓰이는 테이블 등록

### 날짜 컬럼이 VARCHAR2(8, YYYYMMDD)인 경우

`schema_metadata_oracle_manual.json`의 해당 컬럼 `domain_hint`에 명시:

```json
{
  "domain_hint": "날짜 비교 시 TO_DATE(컬럼명, 'YYYYMMDD') 사용"
}
```

### SQL 코퍼스로 자동 강화

기존 업무 SQL 파일(.sql)이나 카탈로그가 있으면 자동 분석해서 메타데이터를 강화합니다:

```powershell
# 카탈로그 JSON으로 강화
.venv\Scripts\python.exe scripts\run_ops.py prepare ^
    --db-id <db-id> ^
    --catalog data/catalog.json

# SQL 파일 glob으로 강화
.venv\Scripts\python.exe scripts\run_ops.py maintain ^
    --db-id <db-id> ^
    --sql-glob "sql/**/*.sql"
```

---

## 메타데이터 초기화

처음부터 다시 추출하려면:

```powershell
# generated/ 폴더 삭제 후 재생성
rd /s /q src\text2sql\config\generated\
.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db-id>
```

> **주의**: `_manual.json` 파일도 삭제됩니다. 반드시 백업 후 진행하세요.

---

## 참고

- 자동 추출 로직: `src/text2sql/tools/oracle_metadata.py`
- 도메인 힌트 사용: `src/text2sql/agents/schema_nodes.py` (keyword_map), `generation_nodes.py` (few_shots)
- 벡터 인덱스: `data/vector_store/` (ChromaDB)
- 카탈로그 형식: `data/catalog.example.json`
