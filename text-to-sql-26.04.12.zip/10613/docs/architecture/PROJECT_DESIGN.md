# 프로젝트 설계

## 목적

이 프로젝트는 업무 언어 질문을 Oracle 운영 환경에서 안전한 읽기 전용 SQL로 변환하는 것을 목표로 한다.

설계의 중심 제약은 다음 네 가지다.

1. 운영 기준은 Oracle이다.
2. Oracle metadata 품질이 낮을 수 있다.
3. 창의성보다 정확성과 안전성이 중요하다.
4. 배포 후에도 시스템이 계속 개선되어야 한다.

## 런타임 설계

실행 경로는 LangGraph 파이프라인으로 구성된다.

1. 질문 분해
2. 스키마 선택
3. 값 후보 검색
4. JOIN 경로 계획
5. SQL 후보 생성
6. SQL 후처리
7. guardrails
8. 정적 SQL 검증
9. 실행 preview
10. judge와 repair
11. 결과 출력

핵심 목표는 잘못된 SQL을 최대한 DB에 보내지 않으면서, 정상적인 생성 오류는 repair 루프로 복구하는 것이다.

## 데이터와 metadata 설계

이 프로젝트는 metadata를 한 층으로 보지 않는다.

- Oracle에서 export한 base metadata
- 운영자가 유지하는 manual metadata overlay
- metadata 기반으로 생성한 base domain hints
- 운영자가 유지하는 manual domain hints overlay
- SQL corpus 기반 enrichment 결과

이 분리는 매우 중요하다. Oracle에서 metadata를 다시 export해도 업무 설명, alias, inferred join, keyword, few-shot이 사라지지 않기 때문이다.

## 검색 설계

스키마 검색은 다음을 조합한다.

- BM25 lexical matching
- schema text vector similarity
- keyword_map과 relation bonus

vector index는 현재 metadata fingerprint와 비교해 stale 여부를 감지하며, 필요 시 자동 재생성이 가능하다.

## 품질 설계

정확도는 프롬프트 한 장으로 결정되지 않는다.

- metadata description과 sample value
- 명시적 또는 추론된 relationship
- 검증된 few-shot 예제
- dialect-aware SQL 후처리
- SELECT-only guardrails
- judge/repair 루프
- 기대 결과 기반 E2E 회귀 검증

## 지속 개선 설계

자가 개선 루프의 신호원은 세 가지다.

- 사용자 명시 피드백
- 파이프라인 성공/실패 결과
- 운영 SQL corpus

`oracle_ops.py`는 metadata, vector, learner, evaluator를 반복 주기 안에서 최신 상태로 유지한다.

## 현재 구조 부채

- `app.py`는 여전히 너무 크다.
- UI, orchestration, reporting이 분리되어 있지 않다.
- 자가 학습은 존재하지만 거버넌스 규칙은 더 강화할 여지가 있다.

## 다음 리팩터링 우선순위

1. `app.py` 분리
2. 자가 학습 artifact 승격/롤백 규칙 강화
3. 도메인별 하네스 확장
4. 운영 자동화와 스케줄링 강화
