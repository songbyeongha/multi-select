# SQL Metadata Enrichment

이 프로젝트는 많은 Oracle 환경에서 metadata가 부족하다는 현실을 전제로 한다.

- table/column comment가 비어 있다.
- FK가 선언되어 있지 않다.
- 관계 의미가 운영 SQL 안에만 숨어 있다.

그래서 enrichment 파이프라인은 실제 SQL 사용 패턴에서 업무 의미를 복원하는 역할을 맡는다.

## enrichment 스크립트가 하는 일

`python scripts/enrich_metadata_from_sql.py`는 SQL corpus를 읽어 manual overlay를 갱신한다.

- JOIN predicate 기반 relationship 추론
- 비어 있는 table/column description 생성
- 질문 문장에서 keyword map 생성
- relation bonus map 생성
- 검증된 few-shot 예제 축적

## 지원 입력 형식

- `queries`를 가진 JSON catalog
- JSONL catalog
- raw `.sql` 파일

catalog 항목은 최소한 아래 값을 가지는 것이 좋다.

```json
{
  "question": "공장별 지연 생산오더를 보여줘",
  "expected_sql": "SELECT ...",
  "title": "지연 생산오더",
  "tags": ["production", "delay"]
}
```

## 권장 절차

1. 최신 metadata를 export한다.
2. 업무 SQL catalog로 enrichment를 실행한다.
3. 생성된 manual overlay를 검토한다.
4. 사람이 직접 쓴 설명이 더 정확하면 그 값을 유지한다.
5. enrichment 후 E2E를 다시 실행한다.

## Oracle에 FK가 없을 때

예를 들어 아래 SQL이 있다고 하자.

```sql
SELECT ...
FROM production_orders po
JOIN products p ON po.product_id = p.product_id
JOIN plants pl ON po.plant_id = pl.plant_id
```

이 스크립트는 다음 관계를 추론 후보로 만든다.

- `PRODUCTION_ORDERS.PRODUCT_ID -> PRODUCTS.PRODUCT_ID`
- `PRODUCTION_ORDERS.PLANT_ID -> PLANTS.PLANT_ID`

이 결과는 base metadata를 덮어쓰지 않고 manual metadata overlay에 추가된다.

## 검토 원칙

- 추론된 JOIN은 실제 업무 의미와 맞을 때만 채택한다.
- alias와 keyword는 기술 용어보다 업무 용어를 우선한다.
- synthetic SQL보다 운영 또는 승인 리포트 SQL을 우선한다.
- enrichment를 돌린 뒤에는 release gate를 다시 확인한다.
