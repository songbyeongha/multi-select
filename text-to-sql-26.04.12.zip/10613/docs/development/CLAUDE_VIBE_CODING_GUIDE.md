# Claude 바이브 코딩 가이드

이 문서는 `C:/Users/SBH/Downloads/vibe_coding_project_ready_pack.md` 기준으로 이 저장소에 맞게 구성한 Claude 중심 작업 방식을 설명한다.

## 1. 이 저장소에서의 역할 분리

### Claude

- 저장소 분석
- 구현 계획 작성
- 구현 후 리뷰

### Codex

- 승인된 범위 안에서 구현
- 코드 수정
- 테스트/검증 보조

### Cursor

- IDE 안에서 빠른 편집
- 현재 파일 중심 반복 작업

## 2. 폴더 구조

```text
.ai/
  prompts/
  context/
  tasks/
  outputs/
  scripts/
README_AI_WORKFLOW.md
Makefile
```

## 3. 작업 시작

### PowerShell

```powershell
.ai\scripts\start-task.ps1 TASK-20260408-001 "메타데이터 경로 정리"
.\.venv\Scripts\python.exe .ai\scripts\package-context.py --task-id TASK-20260408-001
```

작업 폴더는 아래에 생성된다.

```text
.ai/outputs/TASK-20260408-001/
  task.md
  research.md
  plan.md
  implementation_notes.md
  test_report.md
  review_report.md
```

## 4. Claude 사용 순서

### 4-1. Research

Claude에 아래 파일을 먼저 준다.

- `.ai/outputs/context_bundle.md`
- `.ai/outputs/<TASK_ID>/task.md`
- `.ai/prompts/claude-system.md`
- `.ai/prompts/claude-research.md`

요구:

- 아직 구현하지 말 것
- `research.md` 형식으로 저장소 분석만 할 것

출력 저장 위치:

- `.ai/outputs/<TASK_ID>/research.md`

### 4-2. Plan

입력:

- `.ai/outputs/<TASK_ID>/task.md`
- `.ai/outputs/<TASK_ID>/research.md`
- `.ai/prompts/claude-system.md`
- `.ai/prompts/claude-plan.md`

요구:

- 아직 구현하지 말 것
- 수정 대상 파일과 검증 전략을 구체적으로 쓸 것

출력 저장 위치:

- `.ai/outputs/<TASK_ID>/plan.md`

### 4-3. Implement

입력:

- `task.md`
- `research.md`
- `plan.md`
- `.ai/prompts/claude-implement.md`

요구:

- 승인된 범위만 구현
- `implementation_notes.md`와 `test_report.md`를 같이 작성

### 4-4. Review

입력:

- 변경된 코드
- `plan.md`
- `.ai/prompts/claude-review.md`

출력:

- `.ai/outputs/<TASK_ID>/review_report.md`

## 5. Codex에 맡길 때

Codex에는 분석과 계획이 끝난 뒤에만 넘긴다.

권장 입력:

- `.ai/outputs/context_bundle.md`
- `.ai/outputs/<TASK_ID>/task.md`
- `.ai/outputs/<TASK_ID>/research.md`
- `.ai/outputs/<TASK_ID>/plan.md`
- `.ai/prompts/codex-system.md`

핵심 규칙:

- plan 없이 바로 구현시키지 않는다.
- 승인된 범위를 넘기지 않는다.
- 구현 후 `implementation_notes.md`, `test_report.md`를 갱신한다.

## 6. Cursor에서 쓸 때

Cursor는 짧은 명령으로 단계별로 나누는 편이 좋다.

### 분석

```text
Read .ai/outputs/context_bundle.md and .ai/outputs/TASK-20260408-001/task.md.
Do not code.
Summarize the relevant files and architecture for this task.
```

### 계획

```text
Based on the task and repository structure, write a concrete implementation plan.
Do not implement yet.
List exact files to modify and proposed tests.
```

### 구현

```text
Implement only the approved plan.
Do not widen scope.
Keep changes minimal and consistent with existing code style.
```

### 리뷰

```text
Review the current changes for correctness, edge cases, and test gaps.
Be specific and reference exact files/functions.
```

## 7. 검증 스크립트

### 산출물 확인

```powershell
.ai\scripts\check-deliverables.ps1 TASK-20260408-001
```

### 컨텍스트 번들 생성

```powershell
.\.venv\Scripts\python.exe .ai\scripts\package-context.py --task-id TASK-20260408-001
```

### 작업 산출물 미리보기

```powershell
.ai\scripts\review-task.ps1 TASK-20260408-001
```

## 8. 이 저장소에서 지켜야 할 실무 규칙

1. 운영자 문서와 개발자 문서는 한국어로 유지한다.
2. 운영 코드는 Oracle read-only 원칙을 깨면 안 된다.
3. 공개 엔드포인트는 `app.py`, `scripts/run_cli.py`, `scripts/run_ops.py` 중심을 유지한다.
4. 문서와 코드가 다르면 같이 수정한다.
5. 테스트가 번들에 없으면 검증 한계를 `test_report.md`에 명시한다.

## 9. 가장 추천하는 실제 운영 방식

1. Claude로 `research.md`
2. Claude로 `plan.md`
3. 사람이 계획 검토
4. Codex 또는 Claude로 구현
5. `test_report.md` 작성
6. Claude로 `review_report.md`

이 순서를 지키면 막무가내 바이브 코딩이 아니라 통제 가능한 AI 개발 흐름으로 유지할 수 있다.
