# START HERE

운영 DB를 처음 붙이는 상황이면 이 문서부터 읽으면 됩니다.

## 30초 요약

- 기억할 공개 진입점은 3개뿐입니다.
  - `app.py`
  - `scripts/run_cli.py`
  - `scripts/run_ops.py`
- 첫 운영 DB 연결은 아래 명령 하나로 시작합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

## 가장 짧은 경로

1. `.env`를 운영 DB 정보로 수정합니다.
2. 첫 연결 확인과 metadata 준비를 같이 수행합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

3. 질문 1건을 바로 확인합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "안전재고보다 현재고가 낮은 품목과 공장을 보여줘"
```

4. 화면에서 확인합니다.

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

## 꼭 볼 문서

- [operations/FIRST_PRODUCTION_ATTACH.md](operations/FIRST_PRODUCTION_ATTACH.md)
- [operations/OPERATOR_ONE_PAGE.md](operations/OPERATOR_ONE_PAGE.md)
- [operations/ENDPOINT_USAGE_GUIDE.md](operations/ENDPOINT_USAGE_GUIDE.md)
- [metadata/SQL_METADATA_ENRICHMENT.md](metadata/SQL_METADATA_ENRICHMENT.md)

## generated 폴더

- `src/text2sql/config/generated/`는 초기 상태에서 비어 있어도 정상입니다.
- 첫 실행 시 metadata와 domain hints가 이 폴더 아래에 생성됩니다.
- 운영 DB를 교체할 때는 이 폴더만 따로 관리하면 됩니다.
