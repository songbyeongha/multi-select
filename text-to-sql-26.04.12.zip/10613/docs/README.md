# 문서 안내

처음에는 아래 4개만 보면 됩니다.

1. [START_HERE.md](START_HERE.md)
2. [operations/FIRST_PRODUCTION_ATTACH.md](operations/FIRST_PRODUCTION_ATTACH.md)
3. [operations/OPERATOR_ONE_PAGE.md](operations/OPERATOR_ONE_PAGE.md)
4. [operations/ENDPOINT_USAGE_GUIDE.md](operations/ENDPOINT_USAGE_GUIDE.md)

## 남겨 둔 문서

### Architecture

- `architecture/SYSTEM_VISION.md`
- `architecture/PROJECT_DESIGN.md`

### Operations

- `operations/FIRST_PRODUCTION_ATTACH.md`
- `operations/SCRIPT_SELECTION_GUIDE.md`
- `operations/ENDPOINT_USAGE_GUIDE.md`
- `operations/OPERATOR_ONE_PAGE.md`
- `operations/OPERATOR_SETUP_TO_RELEASE_CHECKLIST.md`
- `operations/DAILY_OPERATIONS_CHECKLIST.md`
- `operations/INCIDENT_RUNBOOK.md`
- `operations/OPERATOR_ONBOARDING.md`
- `operations/ORACLE_DB_QUICKSTART.md`
- `operations/ORACLE_PRODUCTION_PLAYBOOK.md`
- `operations/RELEASE_CHECKLIST.md`
- `operations/ENDPOINT_AUDIT.md`

### Metadata

- `metadata/SQL_METADATA_ENRICHMENT.md`
- `../src/text2sql/config/generated/README.md`

### Development

- `development/CLAUDE_VIBE_CODING_GUIDE.md`
