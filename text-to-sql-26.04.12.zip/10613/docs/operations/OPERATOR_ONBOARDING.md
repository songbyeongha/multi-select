# 신규 운영자 온보딩 문서

## 목적

새로 투입된 운영자가 이 시스템의 목적, 운영 방식, 위험 포인트, 필수 명령을 빠르게 익히도록 돕는 문서다.

## 이 시스템을 한 문장으로 설명하면

업무 질문을 Oracle 읽기 전용 SQL로 변환하고, metadata / SQL corpus / 회귀 하네스로 품질을 유지하는 Text-to-SQL 운영 시스템이다.

## 운영자가 꼭 이해해야 할 핵심 개념

### 1. 이 시스템은 단순 LLM 챗봇이 아니다

- Oracle 연결
- metadata
- manual overlay
- SQL enrichment
- E2E harness
- release gate
- feedback learner

이 7개가 함께 돌아가야 운영 품질이 유지된다.

### 2. 정확도는 DB comment만으로 나오지 않는다

Oracle 환경에서는 comment와 FK가 부족할 수 있다. 그래서 이 시스템은 아래를 함께 쓴다.

- base metadata
- manual metadata overlay
- base domain hints
- manual domain hints overlay
- 운영 SQL 기반 enrichment
- feedback 기반 learner

### 3. 운영자가 가장 위험하게 봐야 할 것

- SYSTEM/SYS 스키마 연결
- read-only 비활성화
- stale vector index 방치
- 실패 질문을 catalog에 반영하지 않는 운영 습관

## 1일차 온보딩 순서

### 1. 문서 읽기

아래 순서대로 읽는다.

1. `docs/operations/OPERATOR_ONE_PAGE.md`
2. `docs/operations/OPERATOR_SETUP_TO_RELEASE_CHECKLIST.md`
3. `docs/operations/SCRIPT_SELECTION_GUIDE.md`
4. `docs/operations/ENDPOINT_USAGE_GUIDE.md`
5. `docs/operations/INCIDENT_RUNBOOK.md`

### 2. 로컬에서 직접 실행

아래 명령은 직접 실행해 보는 것이 좋다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
.\.venv\Scripts\python.exe -m streamlit run app.py
```

### 3. 운영 상태 화면 확인

Streamlit `운영 관리` 탭에서 아래를 확인한다.

- Oracle 연결 상태
- LLM 상태
- Embedding 상태
- Vector freshness
- metadata 자산 경로
- feedback / few-shot / keyword 현황

## 첫 주에 익혀야 할 운영 작업

### A. 연결과 환경 확인

- `.env` 읽기
- `check_oracle_connection.py` 결과 해석
- 업무 스키마와 시스템 스키마 구분

### B. metadata와 overlay 이해

- primary metadata와 manual metadata 차이 이해
- domain hints와 manual domain hints 차이 이해
- 어떤 경우 enrichment를 다시 돌려야 하는지 이해

### C. 품질 검증 이해

- query catalog 구조 이해
- `run_e2e_suite.py` 실행 및 결과 읽기
- `oracle_release_gate.py` report 해석

### D. 운영 개선 이해

- feedback가 어디 저장되는지
- learner가 어떤 자산을 갱신하는지
- `oracle_ops.py`가 어떤 단계를 수행하는지

## 운영자가 실제로 자주 쓰는 명령

### 연결 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
```

### metadata 생성

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id>
```

### SQL 기반 보강

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
```

### 회귀 테스트

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py test --db-id <db_id> --catalog <catalog.json>
```

### 최종 게이트

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py release --db-id <db_id> --catalog <catalog.json>
```

### 운영 유지보수

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```

## 신규 운영자가 자주 하는 실수

### 1. 연결만 되면 끝난 줄 아는 것

연결 성공은 시작일 뿐이다. metadata, enrichment, E2E, release gate가 뒤따라야 한다.

### 2. SYSTEM/SYS 계열 스키마를 업무 스키마로 착각하는 것

테이블 이름이 시스템성인지 반드시 확인해야 한다.

### 3. 문제 질문을 catalog에 반영하지 않는 것

같은 실수가 반복되는 가장 큰 이유다.

### 4. manual overlay를 무시하는 것

운영 품질의 핵심은 manual overlay와 SQL corpus 기반 지식이다.

## 2주차 이후 기대 수준

이 단계에서는 아래를 혼자 할 수 있어야 한다.

- 일일점검표 수행
- 간단한 연결/metadata 문제 분류
- E2E 재실행
- release gate 결과 해석
- 실패 질문을 catalog 보강 대상으로 분류

## 모르면 먼저 볼 문서

- 운영 흐름: `docs/operations/OPERATOR_ONE_PAGE.md`
- 체크리스트: `docs/operations/OPERATOR_SETUP_TO_RELEASE_CHECKLIST.md`
- 일일 운영: `docs/operations/DAILY_OPERATIONS_CHECKLIST.md`
- 장애 대응: `docs/operations/INCIDENT_RUNBOOK.md`
- 상세 명령: `docs/operations/ENDPOINT_USAGE_GUIDE.md`
