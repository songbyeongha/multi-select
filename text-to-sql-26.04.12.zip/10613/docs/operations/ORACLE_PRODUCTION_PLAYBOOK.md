# Oracle 운영 플레이북

이 문서는 배포, 일일 점검, 품질 유지까지 책임지는 운영자를 위한 실무 절차다.

## 일일 운영 흐름

1. `.env`가 `SYSTEM`/`SYS`가 아닌 업무 스키마를 가리키는지 확인한다.
2. `python scripts/run_ops.py doctor`를 실행한다.
3. 스키마 변경이나 신규 운영 SQL이 있었으면 `python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>`를 실행한다.
4. `python scripts/run_ops.py daily --db-id <db_id> --catalog <catalog.json>`로 일일 유지보수를 수행한다.

## 릴리즈 흐름

1. 릴리즈에 사용할 SQL regression catalog를 동결한다.
2. `python scripts/run_ops.py test --db-id <db_id> --catalog <catalog.json>`를 실행한다.
3. `python scripts/run_ops.py release --db-id <db_id> --catalog <catalog.json>`를 실행한다.
4. `logs/oracle_release_gate.json`을 검토한다.
5. 게이트가 통과하고 업무 스키마가 확인된 경우에만 배포한다.

## 스키마 변경이 있을 때

1. `python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>`로 metadata 준비를 다시 수행한다.
2. manual overlay에서 업무 설명이 유지되는지 확인한다.
3. `python scripts/run_ops.py daily --db-id <db_id> --catalog <catalog.json>` 또는 `python scripts/run_ops.py release --db-id <db_id> --catalog <catalog.json>`로 vector freshness를 복구한다.
4. `python scripts/run_ops.py test --db-id <db_id> --catalog <catalog.json>`로 E2E를 다시 실행한다.

## 잘못된 SQL 제보가 들어왔을 때

1. 실패한 질문과 정답 SQL을 regression catalog에 추가한다.
2. few-shot 또는 domain hints overlay를 보강한다.
3. 누락된 join이면 manual metadata overlay에 relationship를 추가하거나 `run_ops.py prepare`로 복원한다.
4. 수정한 도메인이나 태그만 필터링해 `run_ops.py test`를 재실행한다.
5. release gate dimension 점수와 recommendation을 확인한다.

## 운영자가 실질적으로 관리하는 파일

- `src/text2sql/config/generated/schema_metadata_oracle_manual.json`
- `src/text2sql/config/generated/domain_hints_oracle_manual.json`
- 업무 SQL catalog
- `logs/oracle_release_gate.json`

## 운영 원칙

- `SYSTEM`/`SYS`로 릴리즈하지 않는다.
- `T2SQL_DB_READ_ONLY=true`를 유지한다.
- 업무 의미의 원천은 manual overlay다.
- 실제 JOIN 의미의 원천은 운영 SQL과 회귀 카탈로그다.
- 배포 전에는 항상 녹색 release gate를 요구한다.
