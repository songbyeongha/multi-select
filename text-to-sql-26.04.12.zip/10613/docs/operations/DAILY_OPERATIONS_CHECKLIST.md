# 운영 일일점검표

## 목적

운영자가 매일 반복적으로 확인해야 하는 항목을 빠뜨리지 않도록 만든 일일점검표다.

이 문서는 "오늘 시스템이 정상인지", "무엇을 먼저 확인해야 하는지", "언제 추가 조치를 해야 하는지"에 집중한다.

## 사용 원칙

- 근무 시작 시 반드시 1회 수행한다.
- 장애나 배포가 있었던 날은 점심 전후로 1회 추가 확인한다.
- 체크 결과는 운영 기록에 남긴다.

## A. 근무 시작 직후 점검

### 1. 환경 확인

- [ ] `.env`가 올바른 운영 설정을 가리킨다.
- [ ] `T2SQL_DB_DIALECT=oracle`다.
- [ ] `T2SQL_DB_READ_ONLY=true`다.
- [ ] `T2SQL_DB_SCHEMA`가 업무 스키마다.
- [ ] `SYSTEM`/`SYS`가 아니다.

### 2. Oracle 연결 점검

- [ ] 아래 명령을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
```

- [ ] 연결 성공
- [ ] 읽기 가능한 테이블 수가 예상 범위와 유사
- [ ] 샘플 SELECT 성공

### 3. 운영 상태 점검

- [ ] Streamlit `운영 관리` 탭 또는 로그 기준으로 LLM endpoint 상태를 확인했다.
- [ ] Embedding endpoint 상태를 확인했다.
- [ ] vector index freshness를 확인했다.
- [ ] feedback 로그 저장 위치가 정상인지 확인했다.

### 4. 최근 변경 여부 확인

- [ ] 전일 이후 스키마 변경이 없었다.
- [ ] 전일 이후 신규 운영 SQL이 없었다.
- [ ] 전일 이후 query catalog 변경이 없었다.

## B. 변경이 있었을 때 추가 작업

### 스키마 변경이 있었으면

- [ ] metadata export를 다시 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id>
```

- [ ] manual metadata overlay가 유지되는지 확인했다.

### 신규 운영 SQL이 있었으면

- [ ] SQL enrichment를 다시 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
```

- [ ] relationship / keyword / few-shot 변화가 기대와 맞는지 확인했다.

### vector freshness가 stale이면

- [ ] `oracle_ops.py --cycles 1` 또는 metadata/release gate 경로로 freshness를 복구했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```

## C. 질문 품질 이상 징후 점검

- [ ] 잘못된 SQL 제보가 증가하지 않았다.
- [ ] 동일한 실패 패턴이 반복되지 않는다.
- [ ] 최근 feedback 평균 점수가 급격히 하락하지 않았다.
- [ ] 특정 도메인에서만 실패가 집중되지 않는다.

### 이상이 있으면

- [ ] 실패 질문을 수집했다.
- [ ] catalog 또는 few-shot 보강 후보로 분류했다.
- [ ] 관계 metadata 누락 여부를 확인했다.
- [ ] 필요 시 E2E 일부 도메인을 재실행했다.

## D. 일일 유지보수 실행

기본적으로 아래 중 하나를 선택한다.

### 변경 없음, 상태 정상

- [ ] 유지보수 cycle 1회를 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```

### 변경 있음, 품질 영향 가능성 있음

- [ ] metadata export
- [ ] enrichment
- [ ] 필요한 domain/tag E2E
- [ ] ops cycle 1회

## E. 근무 종료 전 점검

- [ ] 오늘 발생한 실패 질문을 정리했다.
- [ ] 추가된 운영 SQL이나 query catalog 변경분을 기록했다.
- [ ] release gate 또는 E2E 재실행 필요 여부를 기록했다.
- [ ] 다음 근무자에게 전달할 리스크를 남겼다.

## 빨간 신호

아래 중 하나라도 보이면 즉시 추가 대응이 필요하다.

- [ ] Oracle 연결 실패
- [ ] 업무 스키마 대신 시스템 스키마 감지
- [ ] read-only 비활성화
- [ ] vector freshness stale 지속
- [ ] LLM endpoint 불안정
- [ ] 동일 유형의 SQL 오류 반복 증가
- [ ] 특정 핵심 도메인 품질 급락

## 오늘 최소 실행 명령 요약

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```
