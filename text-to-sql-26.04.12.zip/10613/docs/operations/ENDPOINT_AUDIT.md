# 엔드포인트 점검 기록

점검일: 2026-04-08

## 목적

이 문서는 현재 배포 번들 기준으로 실제 사용 가능한 진입점과 내부 스크립트 상태를 점검한 결과를 정리한다.

## 공개 엔드포인트

현재 운영자가 직접 사용하는 공개 엔드포인트는 3개다.

1. `app.py`
2. `scripts/run_cli.py`
3. `scripts/run_ops.py`

그 외 스크립트는 `run_ops.py`가 호출하는 내부 단계로 본다.

## 점검 결과

### 1. `app.py`

- 용도: Streamlit UI
- 상태: 사용 가능
- 메모: Oracle 모드에서는 `.env`의 `T2SQL_DB_ID` 단일 값만 사용한다.
- 메모: 시나리오 통합 테스트 탭은 제거되었고, 현재는 질문 실행·대량 질의·히스토리·학습 로그·운영 관리만 제공한다.

### 2. `scripts/run_cli.py`

- 용도: 질문 1건 실행
- 상태: 사용 가능
- 메모: 운영 smoke test와 HITL 검토에 적합하다.

### 3. `scripts/run_ops.py`

- 용도: 운영 통합 진입점
- 상태: 사용 가능
- 공개 서브커맨드:
  - `doctor`
  - `first-run`
  - `prepare`
  - `test`
  - `release`
  - `daily`
  - `maintain`
  - `demo`
- 메모: 처음 운영 DB를 붙일 때는 `first-run`만으로 시작 가능하다.
- 메모: `catalog`는 선택 자산이며, E2E/배포 검증 단계에서만 필수다.

## 내부 단계 점검

### `scripts/check_oracle_connection.py`

- 상태: 사용 가능
- 역할: Oracle 연결, readable table, sample query 확인

### `scripts/export_oracle_metadata.py`

- 상태: 사용 가능
- 역할: 운영 DB metadata export와 overlay seed 생성

### `scripts/enrich_metadata_from_sql.py`

- 상태: 사용 가능
- 역할: 기존 운영 SQL 또는 catalog를 바탕으로 metadata와 domain hints를 보강

### `scripts/run_e2e_suite.py`

- 상태: 사용 가능
- 역할: catalog 기반 회귀 검증
- 주의: `catalog`가 있을 때만 사용한다.

### `scripts/oracle_release_gate.py`

- 상태: 사용 가능
- 역할: 배포 전 점검
- 메모: 패키지에 `tests/`가 없으면 pytest 단계는 자동 skip된다.
- 메모: vulture는 현재 번들에 포함된 소스만 대상으로 실행한다.

### `scripts/setup_oracle_mfg_demo.py`

- 상태: 유지
- 역할: 로컬 Docker Oracle 데모 데이터 구축
- 주의: 운영 DB 첫 연결 절차의 필수 단계는 아니다.

## 이번 현행화에서 반영한 정리

1. 삭제된 시나리오 통합 테스트 탭 참조를 제거했다.
2. 삭제된 데모 catalog 경로 예시를 제거하고 `<업무_catalog.json>` placeholder로 통일했다.
3. release gate가 삭제된 `tests/local`을 강제로 호출하지 않도록 정리했다.
4. 운영 탭에서 `catalog`를 필수처럼 보이던 안내를 수정했다.

## 현재 운영 기준 해석

- 처음 운영 DB를 붙일 때 필요한 것은 `.env`, `run_ops.py first-run`, `run_cli.py`, `app.py`다.
- `catalog`는 처음에는 없어도 된다.
- `catalog`가 생기면 E2E, release gate, SQL 기반 metadata enrichment에 활용한다.
