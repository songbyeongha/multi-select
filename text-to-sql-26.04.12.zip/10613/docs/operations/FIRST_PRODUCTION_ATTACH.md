# 운영 DB 첫 연결 가이드

이 문서는 `.env`를 이미 채운 상태에서 처음 운영 DB에 연결해 실행하는 절차만 설명합니다.

## 목적

- 운영 Oracle DB 연결 확인
- 기본 metadata 생성
- 필요하면 SQL 기반 metadata 보강
- 질문 1건과 UI 실행 확인

## 1. `.env` 점검

최소한 아래 항목이 맞아야 합니다.

```env
T2SQL_DB_DIALECT=oracle
T2SQL_DB_ID=<db_id>
T2SQL_DB_HOST=<host>
T2SQL_DB_PORT=1521
T2SQL_DB_SERVICE_NAME=<service_name>
T2SQL_DB_USER=<user>
T2SQL_DB_PASSWORD=<password>
T2SQL_DB_SCHEMA=<business_schema>
T2SQL_DB_READ_ONLY=true
```

주의:

- `T2SQL_DB_SCHEMA`는 `SYSTEM` 또는 `SYS`가 아니라 업무 스키마여야 합니다.
- 처음에는 `T2SQL_INCLUDE_TABLES`를 좁게 잡는 편이 안전합니다.

## 2. 첫 연결 실행

catalog가 아직 없어도 아래 명령으로 시작할 수 있습니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

이 명령은 아래 순서로 동작합니다.

1. Oracle 연결 점검
2. readable table 확인
3. metadata export
4. manual overlay seed 생성
5. domain hints seed 생성
6. 선택적으로 include/exclude 범위를 반영

## 3. 운영 SQL 또는 catalog가 있으면 같이 보강

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id> --catalog <catalog.json> --run-e2e
```

이 경우 아래 작업이 추가됩니다.

- query catalog 검증
- SQL 기반 metadata enrichment
- E2E 실행

`catalog`는 필수가 아닙니다. 이미 검증된 질문과 정답 SQL이 있을 때만 붙이면 됩니다.

## 4. 질문 1건 직접 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "안전재고보다 현재고가 낮은 품목과 공장을 보여줘"
```

HITL로 사람이 SQL을 확인하고 싶으면:

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문" --hitl
```

## 5. 화면 확인

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

운영 탭에서 아래를 확인합니다.

- Oracle 연결 상태
- metadata 경로
- vector freshness
- LLM/embedding 연결 상태

## 6. 다음 단계

첫 연결이 끝나면 아래 순서로 진행합니다.

1. `run_ops.py test`
2. `run_ops.py release`
3. `run_ops.py daily` 또는 `run_ops.py maintain`

## generated 폴더 기준

- 첫 연결 전에는 `src/text2sql/config/generated/`가 비어 있어도 정상입니다.
- `first-run` 또는 `prepare`가 metadata/domain hints/manual overlay를 이 폴더에 생성합니다.
- 다른 환경으로 이동하거나 초기화할 때는 이 폴더만 별도로 백업·삭제하면 됩니다.
