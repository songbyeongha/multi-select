# 릴리즈 체크리스트

운영 배포 전마다 아래 항목을 확인한다.

- [ ] `.env`가 올바른 업무 스키마를 가리킨다.
- [ ] `T2SQL_DB_READ_ONLY=true`다.
- [ ] `python scripts/run_ops.py doctor`가 통과한다.
- [ ] 최근 스키마 변경 이후 `python scripts/run_ops.py prepare --db-id <db_id>` 또는 `python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>`를 실행했다.
- [ ] manual metadata와 manual domain hints overlay를 검토했다.
- [ ] 최근 SQL corpus 변경 이후 `python scripts/run_ops.py prepare --db-id <db_id> --catalog <catalog.json>`를 실행했다.
- [ ] `python scripts/run_ops.py test --db-id <db_id> --catalog <catalog.json>`가 목표 pass rate를 만족한다.
- [ ] `python scripts/run_ops.py release --db-id <db_id> --catalog <catalog.json>`가 통과한다.
- [ ] high-confidence dead code가 남아 있지 않다.
- [ ] vector index가 현재 metadata 기준으로 stale 하지 않다.
- [ ] release gate report를 배포 기록과 함께 보관했다.
