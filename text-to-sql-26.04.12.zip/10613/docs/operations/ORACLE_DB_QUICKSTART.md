# Oracle DB Quickstart

## 전제

- `.env`는 이미 채워져 있다.
- 대상은 Oracle 운영 DB 또는 운영과 유사한 검증 DB다.

## 가장 빠른 시작

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

## 질문 1건 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "안전재고보다 현재고가 낮은 품목과 공장을 보여줘"
```

## UI 확인

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

## catalog까지 있으면

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id> --catalog <catalog.json> --run-e2e
```
