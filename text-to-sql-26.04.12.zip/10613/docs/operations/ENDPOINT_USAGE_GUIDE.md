# 엔드포인트 사용 설명서

이 프로젝트에서 직접 사용하는 공개 엔드포인트는 3개입니다.

1. `app.py`
2. `scripts/run_cli.py`
3. `scripts/run_ops.py`

## 1. Streamlit UI

실행:

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

주요 용도:

- 질문을 화면에서 직접 확인
- 대량 실행과 운영 상태 확인
- 운영 탭에서 DB, metadata, vector, LLM 상태 확인

## 2. CLI

실행:

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
```

HITL 실행:

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문" --hitl
```

권장 용도:

- 질문 1건 빠른 확인
- 운영 배포 전 smoke test

## 3. 운영 통합 진입점

도움말:

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py --help
```

### `first-run`

운영 DB를 처음 붙일 때 사용합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

catalog까지 있으면:

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id> --catalog <catalog.json> --run-e2e
```

### `doctor`

Oracle 연결과 metadata 접근만 확인합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
```

### `prepare`

metadata export와 SQL 기반 enrichment를 준비합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
```

catalog 없이 metadata만 먼저 만들려면:

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id>
```

### `test`

E2E를 실행합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py test --db-id <db_id> --catalog <catalog.json>
```

`catalog`는 검증된 질문-SQL 모음 파일입니다. 처음 운영 DB를 붙일 때는 없어도 되지만, E2E와 릴리즈 검증에는 필요합니다.

### `release`

배포 전 점검을 실행합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py release --db-id <db_id> --catalog <catalog.json>
```

### `daily`

일일 운영용으로 `doctor + maintain 1 cycle`을 실행합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```

### `maintain`

반복 개선 사이클을 실행합니다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py maintain --db-id <db_id> --catalog <catalog.json> --cycles 10
```
