# 스크립트 선택 가이드

이 패키지에서 운영자가 직접 기억해야 하는 스크립트는 3개뿐입니다.

## 1. `app.py`

언제 쓰나:

- 화면에서 질문을 확인할 때
- 운영 탭으로 상태를 볼 때

실행:

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

## 2. `scripts/run_cli.py`

언제 쓰나:

- 질문 1건을 바로 검증할 때
- HITL로 SQL을 직접 확인할 때

실행:

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
```

## 3. `scripts/run_ops.py`

언제 쓰나:

- 운영 DB 첫 연결
- metadata 준비
- E2E
- 배포 전 점검
- 일일 운영

가장 중요한 서브커맨드:

- `first-run`: 처음 운영 DB 붙을 때
- `doctor`: 연결 점검만 할 때
- `prepare`: metadata 준비
- `test`: E2E 실행
- `release`: 배포 전 점검
- `daily`: 일일 운영
- `maintain`: 반복 개선

## 상황별 바로 가기

### 운영 DB 처음 연결

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

### 연결만 점검

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
```

### metadata와 enrichment 준비

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
```

### 질문 1건 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
```
