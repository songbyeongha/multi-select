# 초기 세팅부터 배포 전 점검까지 체크리스트

## 0. 시작 전

- [ ] `.env`가 현재 운영 DB 정보로 채워져 있다.
- [ ] `T2SQL_DB_DIALECT=oracle`이다.
- [ ] `T2SQL_DB_READ_ONLY=true`이다.
- [ ] `T2SQL_DB_SCHEMA`가 업무 스키마다.
- [ ] `SYSTEM` 또는 `SYS` 계열이 아니다.

## 1. 운영 DB 첫 연결

- [ ] 아래 명령을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

- [ ] 연결 성공 메시지를 확인했다.
- [ ] 읽히는 테이블 목록이 업무 테이블 중심이다.
- [ ] metadata 파일이 생성됐다.
- [ ] manual overlay seed가 생성됐다.

## 2. metadata 보강

- [ ] 운영 SQL 또는 query catalog를 준비했다.
- [ ] 아래 명령을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
```

- [ ] relationship가 필요한 수준으로 보강됐다.
- [ ] manual overlay에 업무 설명을 반영했다.

## 3. 질문 1건 확인

- [ ] CLI로 질문 1건을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
```

- [ ] 필요하면 HITL로 SQL을 확인했다.
- [ ] 결과가 업무 기대와 크게 다르지 않다.

## 4. 화면 확인

- [ ] Streamlit UI가 정상 실행된다.

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

- [ ] 운영 탭에서 DB/metadata/vector/LLM 상태가 보인다.

## 5. E2E

- [ ] query catalog가 최신이다.
- [ ] 아래 명령을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py test --db-id <db_id> --catalog <catalog.json>
```

- [ ] 실패 케이스를 catalog 또는 metadata 보강 대상으로 분류했다.

## 6. 배포 전 점검

- [ ] 아래 명령을 실행했다.

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py release --db-id <db_id> --catalog <catalog.json>
```

- [ ] blocking issue가 없다.
- [ ] query accuracy가 목표 기준 이상이다.
- [ ] stale vector 경고가 없다.
- [ ] 업무 스키마가 맞다.
