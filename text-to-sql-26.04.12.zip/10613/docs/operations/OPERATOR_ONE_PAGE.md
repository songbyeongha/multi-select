# 운영자 1페이지 요약

## 시스템 목적

- 자연어 질문을 Oracle 조회 SQL로 안전하게 변환합니다.
- FK와 comment가 부족한 환경에서도 metadata와 운영 SQL을 이용해 보강합니다.
- E2E와 release gate로 배포 가능 여부를 검증합니다.

## 운영자가 기억할 핵심

1. 공개 진입점은 `app.py`, `scripts/run_cli.py`, `scripts/run_ops.py` 세 개뿐입니다.
2. 운영 DB를 처음 붙일 때는 `run_ops.py first-run`부터 시작합니다.
3. 업무 스키마가 아닌 `SYSTEM` 또는 `SYS` 계열이면 바로 수정합니다.
4. `T2SQL_DB_READ_ONLY=true`를 유지합니다.
5. metadata 준비 없이 바로 E2E나 배포 점검으로 가지 않습니다.

## 가장 많이 쓰는 명령

### 첫 연결

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py first-run --db-id <db_id>
```

### metadata 준비

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id>
```

### 질문 1건 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_cli.py --db <db_id> -q "질문"
```

### 화면 확인

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

### E2E

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py test --db-id <db_id> --catalog <catalog.json>
```

### 배포 전 점검

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py release --db-id <db_id> --skip-e2e
```

## 자주 보는 파일

- `.env`
- `src/text2sql/config/generated/*manual*.json`
- `<업무_catalog.json>` 또는 기존 운영 SQL 모음
- `logs/*.json`

## catalog가 뭔가

- `catalog`는 검증된 질문과 정답 SQL을 모아 둔 회귀 검증 파일입니다.
- 처음 운영 DB를 붙일 때는 없어도 됩니다.
- E2E, 릴리즈 게이트, SQL 기반 metadata 보강 단계에서 있으면 좋습니다.

## 먼저 볼 문서

1. `FIRST_PRODUCTION_ATTACH.md`
2. `ENDPOINT_USAGE_GUIDE.md`
3. `OPERATOR_SETUP_TO_RELEASE_CHECKLIST.md`
