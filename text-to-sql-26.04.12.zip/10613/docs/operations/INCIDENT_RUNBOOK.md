# 장애 대응 런북

## 목적

운영 중 문제가 발생했을 때 누가 보더라도 같은 순서로 대응할 수 있도록 만든 실무 런북이다.

## 기본 원칙

1. 먼저 영향 범위를 확인한다.
2. 즉시 복구 가능한지 판단한다.
3. 증거를 남기고 변경한다.
4. 증상만 고치지 말고 원인을 분류한다.
5. 운영 품질 이슈는 catalog / overlay / SQL corpus까지 함께 본다.

## 장애 분류

### P1

- 서비스 사용이 사실상 불가능
- Oracle 연결 불가
- LLM endpoint 전체 장애
- read-only 안전성 위반 가능성

### P2

- 일부 핵심 질문 도메인 품질 급락
- 특정 주요 기능 탭 사용 불가
- E2E 핵심 도메인 대량 실패

### P3

- 일부 성능 저하
- 비핵심 도메인 품질 저하
- 운영 문서/도구 불편

## 공통 대응 순서

### 1. 사고 접수

- [ ] 발생 시각 기록
- [ ] 신고자 기록
- [ ] 실패 질문 또는 증상 원문 확보
- [ ] 영향 범위 확인

### 2. 즉시 상태 확인

- [ ] Oracle 연결 확인

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
```

- [ ] Streamlit `운영 관리` 탭 또는 로그로 LLM / Embedding / Vector 상태 확인
- [ ] 최근 배포/스키마 변경/metadata 변경 여부 확인

### 3. 증거 확보

- [ ] 실패 질문 저장
- [ ] 생성된 SQL 저장
- [ ] 관련 로그 경로 기록
- [ ] `logs/oracle_release_gate.json` 또는 E2E report 확인
- [ ] 필요 시 실패 케이스를 임시 catalog로 분리

### 4. 복구 경로 선택

- [ ] 연결 문제인지
- [ ] 데이터/스키마 문제인지
- [ ] metadata 문제인지
- [ ] few-shot / keyword / relation 문제인지
- [ ] LLM endpoint 문제인지
- [ ] vector freshness 문제인지

## 유형별 대응

### 1. Oracle 연결 실패

#### 증상

- `run_ops.py doctor` 실패
- UI/CLI에서 DB 연결 오류

#### 확인

- [ ] `.env` 값 확인
- [ ] host/port/service name 확인
- [ ] user/password 확인
- [ ] 스키마 존재 여부 확인

#### 대응

- [ ] 운영자가 관리 가능한 설정 오류면 `.env` 수정
- [ ] DB 자체 장애면 DBA 또는 인프라 담당자에게 즉시 전달
- [ ] 복구 전까지 품질 이슈 분석 작업은 중단

### 2. 시스템 스키마로 잘못 연결됨

#### 증상

- SYSTEM/SYS 계열 테이블 다수 노출
- 업무 테이블보다 시스템 테이블이 많이 보임

#### 대응

- [ ] `T2SQL_DB_SCHEMA` 확인
- [ ] `T2SQL_INCLUDE_TABLES` / `T2SQL_EXCLUDE_TABLES` 확인
- [ ] 업무 스키마로 수정 후 `run_ops.py doctor` 재실행
- [ ] metadata export 다시 수행

### 3. SQL 품질 저하

#### 증상

- 질문은 실행되지만 결과가 의도와 다름
- join 오류 또는 filter 오류 반복

#### 1차 대응

- [ ] 실패 질문과 생성 SQL을 수집
- [ ] 수동 정답 SQL을 확보
- [ ] 동일 패턴 재현 여부 확인

#### 2차 점검

- [ ] metadata export 최신 여부 확인
- [ ] enrichment 최신 여부 확인
- [ ] relationship metadata 누락 여부 확인
- [ ] few-shot 부족 여부 확인
- [ ] keyword map 부족 여부 확인

#### 복구

- [ ] 실패 케이스를 query catalog에 추가
- [ ] `run_ops.py prepare --db-id <db_id> --catalog <catalog.json>` 재실행
- [ ] manual overlay 보강
- [ ] 필요한 domain/tag만 E2E 재실행

### 4. LLM endpoint 문제

#### 증상

- 응답 지연 급증
- timeout 또는 endpoint unreachable
- UI/CLI에서 모델 호출 실패

#### 대응

- [ ] `운영 관리` 탭에서 LLM 상태 확인
- [ ] base URL / API key / provider 설정 확인
- [ ] 로컬 endpoint면 프로세스 상태 확인
- [ ] 외부 endpoint면 네트워크/서비스 담당자에게 전달
- [ ] 복구 후 CLI 1건과 E2E 일부 케이스로 검증

### 5. Embedding / Vector 문제

#### 증상

- vector mode가 stale 또는 비정상
- retrieval 품질 저하

#### 대응

- [ ] Embedding endpoint 상태 확인
- [ ] metadata export 최신 여부 확인
- [ ] `run_ops.py daily --db-id <db_id> --catalog <catalog.json>` 실행
- [ ] 필요 시 release gate로 freshness 재확인

### 6. E2E 대량 실패

#### 증상

- 특정 domain 또는 전체 pass rate 급락

#### 대응

- [ ] catalog 변경 여부 확인
- [ ] 최근 스키마 변경 여부 확인
- [ ] `run_ops.py prepare` 재실행
- [ ] domain 또는 tag 기준으로 축소 재실행
- [ ] release gate 전면 중지

## 사고 종료 기준

- [ ] 동일 증상이 재현되지 않는다.
- [ ] CLI 또는 UI 질문 1건 이상 정상 확인했다.
- [ ] 필요한 E2E domain 재검증을 통과했다.
- [ ] 원인과 조치 내용을 기록했다.
- [ ] 재발 방지 후보를 backlog 또는 catalog에 반영했다.

## 사고 후 필수 기록

- 발생 시각
- 영향 범위
- 원인 분류
- 수행 명령
- 수정한 파일 또는 설정
- 재검증 결과
- 후속 개선 필요 항목

## 자주 쓰는 복구 명령

```powershell
.\.venv\Scripts\python.exe scripts\run_ops.py doctor
.\.venv\Scripts\python.exe scripts\run_ops.py prepare --db-id <db_id> --catalog <catalog.json>
.\.venv\Scripts\python.exe scripts\run_ops.py test --db-id <db_id> --catalog <catalog.json> --domain <domain>
.\.venv\Scripts\python.exe scripts\run_ops.py daily --db-id <db_id> --catalog <catalog.json>
```
