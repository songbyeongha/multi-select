#!/usr/bin/env python3
"""Public operator entrypoint that consolidates granular Oracle scripts."""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

from text2sql.tools.ops_gateway import (
    build_daily_commands,
    build_demo_command,
    build_doctor_command,
    build_e2e_command,
    build_first_run_commands,
    build_maintain_command,
    build_prepare_commands,
    build_release_command,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Unified operator endpoint for Oracle Text-to-SQL operations",
    )
    parser.add_argument("--dry-run", action="store_true", help="Print commands without executing them")

    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("doctor", help="Check Oracle connectivity and metadata access")

    first_run = subparsers.add_parser(
        "first-run",
        help="First-time production DB onboarding: doctor + prepare + optional smoke/E2E",
    )
    first_run.add_argument("--db-id", default="", help="Database ID")
    first_run.add_argument("--catalog", default="", help="Query catalog path")
    first_run.add_argument("--include", default="", help="Comma-separated include tables")
    first_run.add_argument("--exclude", default="", help="Comma-separated exclude tables")
    first_run.add_argument("--samples", type=int, default=5, help="Sample value count per column")
    first_run.add_argument(
        "--smoke-question",
        default="",
        help="Optional CLI smoke test question",
    )
    first_run.add_argument("--hitl", action="store_true", help="Run CLI smoke in HITL mode")
    first_run.add_argument("--max-retries", type=int, default=2, help="Pipeline max retries")
    first_run.add_argument("--run-e2e", action="store_true", help="Run E2E after bootstrap")
    first_run.add_argument("--e2e-report", default="", help="Optional E2E report output path")
    first_run.add_argument("--limit", type=int, default=20, help="Result comparison row limit")
    first_run.add_argument("--max-items", type=int, default=0, help="Run only first N E2E cases")

    demo = subparsers.add_parser("demo", help="Setup local Oracle manufacturing demo schema")
    demo.add_argument("--admin-user", default="", help="Oracle admin user")
    demo.add_argument("--admin-password", default="", help="Oracle admin password")
    demo.add_argument("--service-name", default="", help="Oracle service name")
    demo.add_argument("--host", default="", help="Oracle host")
    demo.add_argument("--port", type=int, default=0, help="Oracle port")
    demo.add_argument("--schema-user", default="", help="Demo schema user")
    demo.add_argument("--schema-password", default="", help="Demo schema password")
    demo.add_argument("--drop-existing", action="store_true", help="Drop and recreate schema")
    demo.add_argument("--schema-only", action="store_true", help="Recreate objects inside current schema only")

    prepare = subparsers.add_parser("prepare", help="Export metadata and optionally enrich it from SQL/catalog")
    prepare.add_argument("--db-id", default="", help="Database ID")
    prepare.add_argument("--catalog", default="", help="Query catalog path")
    prepare.add_argument("--include", default="", help="Comma-separated include tables")
    prepare.add_argument("--exclude", default="", help="Comma-separated exclude tables")
    prepare.add_argument("--samples", type=int, default=5, help="Sample value count per column")

    daily = subparsers.add_parser("daily", help="Run the daily operator flow: doctor + maintain(1 cycle)")
    daily.add_argument("--db-id", default="", help="Database ID")
    daily.add_argument("--catalog", default="", help="Query catalog path")

    test = subparsers.add_parser("test", help="Run the E2E regression suite")
    test.add_argument("--db-id", default="", help="Database ID")
    test.add_argument("--catalog", required=True, help="Query catalog path")
    test.add_argument("--max-retries", type=int, default=2, help="Pipeline max retries")
    test.add_argument("--report", default="", help="E2E report output path")
    test.add_argument("--limit", type=int, default=20, help="Result comparison row limit")
    test.add_argument("--probe-timeout-sec", type=int, default=10, help="LLM endpoint probe timeout")
    test.add_argument("--skip-llm-check", action="store_true", help="Skip LLM endpoint preflight check")
    test.add_argument("--record-feedback", action="store_true", help="Write E2E outcomes into feedback records")
    test.add_argument("--learn", action="store_true", help="Run learner after recording E2E feedback")
    test.add_argument("--domain", default="", help="Run only one domain")
    test.add_argument("--tag", default="", help="Run only one tag")
    test.add_argument("--max-items", type=int, default=0, help="Run only first N filtered cases")

    release = subparsers.add_parser("release", help="Run the release gate")
    release.add_argument("--db-id", default="", help="Database ID")
    release.add_argument("--catalog", default="", help="Query catalog path")
    release.add_argument("--e2e-report", default="", help="Existing E2E report path")
    release.add_argument("--report", default="", help="Release gate report output path")
    release.add_argument("--max-retries", type=int, default=2, help="Pipeline max retries")
    release.add_argument("--skip-e2e", action="store_true", help="Do not run E2E as part of the gate")
    release.add_argument("--skip-pytest", action="store_true", help="Do not run pytest as part of the gate")
    release.add_argument("--skip-vulture", action="store_true", help="Do not run vulture as part of the gate")
    release.add_argument("--allow-system-schema", action="store_true", help="Allow SYSTEM/SYS-like schema")

    maintain = subparsers.add_parser("maintain", help="Run the maintenance/self-improvement cycle")
    maintain.add_argument("--db-id", default="", help="Database ID")
    maintain.add_argument("--cycles", type=int, default=1, help="Number of maintenance cycles")
    maintain.add_argument("--samples", type=int, default=5, help="Sample value count per column")
    maintain.add_argument("--report", default="", help="Maintenance report path")
    maintain.add_argument("--catalog", default="", help="Query catalog path")
    maintain.add_argument("--sql-glob", default="", help="Glob pattern for SQL files")
    maintain.add_argument("--no-enrich", action="store_true", help="Skip enrichment")
    maintain.add_argument("--no-metadata", action="store_true", help="Skip metadata export")
    maintain.add_argument("--no-vector", action="store_true", help="Skip vector rebuild")
    maintain.add_argument("--no-learn", action="store_true", help="Skip learner")
    maintain.add_argument("--no-eval", action="store_true", help="Skip evaluator")
    maintain.add_argument("--fail-under-score", type=int, default=0, help="Fail when score is below threshold")

    return parser.parse_args()


def _execute_steps(steps: list[tuple[str, list[str]]], *, dry_run: bool) -> int:
    for label, command in steps:
        print(f"[STEP] {label}")
        print("       " + " ".join(command))
        if dry_run:
            continue
        result = subprocess.run(command, cwd=str(ROOT))
        if result.returncode != 0:
            return result.returncode
    return 0


def main() -> int:
    args = parse_args()
    command = args.command

    if command == "doctor":
        return _execute_steps([("doctor", build_doctor_command())], dry_run=args.dry_run)

    if command == "first-run":
        if args.run_e2e and not args.catalog:
            print("[ERROR] --catalog is required when --run-e2e is used.")
            return 2
        max_items = args.max_items if args.max_items > 0 else None
        return _execute_steps(
            build_first_run_commands(
                db_id=args.db_id,
                catalog=args.catalog,
                include=args.include,
                exclude=args.exclude,
                samples=args.samples,
                smoke_question=args.smoke_question,
                hitl=args.hitl,
                max_retries=args.max_retries,
                run_e2e=args.run_e2e,
                e2e_report=args.e2e_report,
                limit=args.limit,
                max_items=max_items,
            ),
            dry_run=args.dry_run,
        )

    if command == "demo":
        return _execute_steps(
            [
                (
                    "demo setup",
                    build_demo_command(
                        admin_user=args.admin_user,
                        admin_password=args.admin_password,
                        service_name=args.service_name,
                        host=args.host,
                        port=args.port or None,
                        schema_user=args.schema_user,
                        schema_password=args.schema_password,
                        drop_existing=args.drop_existing,
                        schema_only=args.schema_only,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    if command == "prepare":
        return _execute_steps(
            build_prepare_commands(
                db_id=args.db_id,
                catalog=args.catalog,
                include=args.include,
                exclude=args.exclude,
                samples=args.samples,
            ),
            dry_run=args.dry_run,
        )

    if command == "daily":
        return _execute_steps(
            build_daily_commands(db_id=args.db_id, catalog=args.catalog),
            dry_run=args.dry_run,
        )

    if command == "test":
        max_items = args.max_items if args.max_items > 0 else None
        return _execute_steps(
            [
                (
                    "e2e",
                    build_e2e_command(
                        db_id=args.db_id,
                        catalog=args.catalog,
                        max_retries=args.max_retries,
                        report=args.report,
                        limit=args.limit,
                        probe_timeout_sec=args.probe_timeout_sec,
                        skip_llm_check=args.skip_llm_check,
                        record_feedback=args.record_feedback,
                        learn=args.learn,
                        domain=args.domain,
                        tag=args.tag,
                        max_items=max_items,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    if command == "release":
        run_e2e = not args.skip_e2e
        if run_e2e and not args.catalog:
            print("[ERROR] --catalog is required unless --skip-e2e is used.")
            return 2
        return _execute_steps(
            [
                (
                    "release gate",
                    build_release_command(
                        db_id=args.db_id,
                        catalog=args.catalog,
                        e2e_report=args.e2e_report,
                        report=args.report,
                        max_retries=args.max_retries,
                        run_e2e=run_e2e,
                        run_pytest=not args.skip_pytest,
                        run_vulture=not args.skip_vulture,
                        allow_system_schema=args.allow_system_schema,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    if command == "maintain":
        fail_under_score = args.fail_under_score if args.fail_under_score > 0 else None
        return _execute_steps(
            [
                (
                    "maintenance",
                    build_maintain_command(
                        db_id=args.db_id,
                        cycles=args.cycles,
                        samples=args.samples,
                        report=args.report,
                        sql_catalog=args.catalog,
                        sql_glob=args.sql_glob,
                        no_enrich=args.no_enrich,
                        no_metadata=args.no_metadata,
                        no_vector=args.no_vector,
                        no_learn=args.no_learn,
                        no_eval=args.no_eval,
                        fail_under_score=fail_under_score,
                    ),
                )
            ],
            dry_run=args.dry_run,
        )

    print(f"[ERROR] Unknown command: {command}")
    return 2


if __name__ == "__main__":
    sys.exit(main())
