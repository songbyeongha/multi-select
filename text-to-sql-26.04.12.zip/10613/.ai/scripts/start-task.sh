#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
TASK_ID="${1:-}"
TITLE="${2:-}"

if [ -z "$TASK_ID" ]; then
  echo "Usage: .ai/scripts/start-task.sh TASK_ID \"Task title\""
  exit 1
fi

BASE="${ROOT}/.ai/outputs/${TASK_ID}"
mkdir -p "${BASE}"

cat > "${BASE}/task.md" <<EOF
# TASK

## Task ID
${TASK_ID}

## Title
${TITLE}

## Background
TODO

## Goal
TODO

## In Scope
- TODO

## Out of Scope
- TODO

## Constraints
- TODO

## Acceptance Criteria
- TODO

## References
- TODO
EOF

touch "${BASE}/research.md"
touch "${BASE}/plan.md"
touch "${BASE}/implementation_notes.md"
touch "${BASE}/test_report.md"
touch "${BASE}/review_report.md"

echo "Created task workspace at ${BASE}"
