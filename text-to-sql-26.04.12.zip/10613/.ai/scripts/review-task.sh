#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
TASK_ID="${1:-}"

if [ -z "$TASK_ID" ]; then
  echo "Usage: .ai/scripts/review-task.sh TASK_ID"
  exit 1
fi

BASE="${ROOT}/.ai/outputs/${TASK_ID}"

echo "== Task files =="
ls -1 "${BASE}"

echo
echo "== Research head =="
head -n 20 "${BASE}/research.md" || true

echo
echo "== Plan head =="
head -n 30 "${BASE}/plan.md" || true

echo
echo "== Test report head =="
head -n 30 "${BASE}/test_report.md" || true

echo
echo "== Review report head =="
head -n 30 "${BASE}/review_report.md" || true
