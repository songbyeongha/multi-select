#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
TASK_ID="${1:-}"

if [ -z "$TASK_ID" ]; then
  echo "Usage: .ai/scripts/check-deliverables.sh TASK_ID"
  exit 1
fi

BASE="${ROOT}/.ai/outputs/${TASK_ID}"

required=(
  "task.md"
  "research.md"
  "plan.md"
  "implementation_notes.md"
  "test_report.md"
  "review_report.md"
)

missing=0
for f in "${required[@]}"; do
  if [ ! -f "${BASE}/${f}" ]; then
    echo "[MISSING] ${BASE}/${f}"
    missing=1
  else
    echo "[OK] ${BASE}/${f}"
  fi
done

if [ "${missing}" -ne 0 ]; then
  echo "Deliverable check failed"
  exit 1
fi

echo "All required deliverables exist"
