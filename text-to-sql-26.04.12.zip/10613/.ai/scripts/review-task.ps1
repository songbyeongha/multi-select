param(
    [Parameter(Mandatory = $true)]
    [string]$TaskId
)

$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$base = Join-Path $root ".ai\outputs\$TaskId"

Write-Host "== Task files =="
Get-ChildItem -Path $base | Select-Object -ExpandProperty Name

foreach ($name in @("research.md", "plan.md", "test_report.md", "review_report.md")) {
    $path = Join-Path $base $name
    Write-Host ""
    Write-Host "== $name =="
    if (Test-Path $path) {
        Get-Content -Path $path -TotalCount 30
    } else {
        Write-Host "(missing)"
    }
}
