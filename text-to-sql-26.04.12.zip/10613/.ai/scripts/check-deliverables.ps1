param(
    [Parameter(Mandatory = $true)]
    [string]$TaskId
)

$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$base = Join-Path $root ".ai\outputs\$TaskId"
$required = @(
    "task.md",
    "research.md",
    "plan.md",
    "implementation_notes.md",
    "test_report.md",
    "review_report.md"
)

$missing = $false
foreach ($file in $required) {
    $path = Join-Path $base $file
    if (Test-Path $path) {
        Write-Host "[OK] $path"
    } else {
        Write-Host "[MISSING] $path"
        $missing = $true
    }
}

if ($missing) {
    throw "Deliverable check failed"
}

Write-Host "All required deliverables exist"
