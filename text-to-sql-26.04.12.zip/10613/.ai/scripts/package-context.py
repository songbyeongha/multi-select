from __future__ import annotations

import argparse
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def read_file(path: Path) -> str:
    if not path.exists():
        return f"## {path.relative_to(ROOT)}\n\n(없음)\n"
    try:
        return f"## {path.relative_to(ROOT)}\n\n{path.read_text(encoding='utf-8')}\n"
    except Exception as exc:
        return f"## {path.relative_to(ROOT)}\n\n(읽기 실패: {exc})\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a Claude/Codex context bundle")
    parser.add_argument("--task-id", default="", help="Optional task id to include task.md")
    parser.add_argument("--output", default=".ai/outputs/context_bundle.md", help="Output path")
    args = parser.parse_args()

    include_files = [
        ROOT / "README.md",
        ROOT / ".ai" / "context" / "project-overview.md",
        ROOT / ".ai" / "context" / "architecture.md",
        ROOT / ".ai" / "context" / "constraints.md",
        ROOT / ".ai" / "context" / "coding-standards.md",
        ROOT / "docs" / "START_HERE.md",
        ROOT / "docs" / "operations" / "FIRST_PRODUCTION_ATTACH.md",
        ROOT / "docs" / "operations" / "ENDPOINT_USAGE_GUIDE.md",
    ]

    if args.task_id:
        include_files.append(ROOT / ".ai" / "outputs" / args.task_id / "task.md")

    parts = ["# AI Context Bundle\n"]
    for path in include_files:
        parts.append(read_file(path))
        parts.append("")

    output_path = ROOT / args.output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(parts), encoding="utf-8")
    print(f"Wrote {output_path}")


if __name__ == "__main__":
    main()
