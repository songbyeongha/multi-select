param(
    [Parameter(Mandatory = $true)]
    [string]$TaskId,
    [string]$Title = ""
)

$base = Join-Path ".ai\outputs" $TaskId
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
$base = Join-Path $root ".ai\outputs\$TaskId"
New-Item -ItemType Directory -Force -Path $base | Out-Null

$taskContent = @"
# TASK

## Task ID
$TaskId

## Title
$Title

## Background
TODO

## Goal
TODO

## In Scope
- TODO

## Out of Scope
- TODO

## Constraints
- TODO

## Acceptance Criteria
- TODO

## References
- TODO
"@

Set-Content -Encoding utf8 -Path (Join-Path $base "task.md") -Value $taskContent

foreach ($file in @("research.md", "plan.md", "implementation_notes.md", "test_report.md", "review_report.md")) {
    if (-not (Test-Path (Join-Path $base $file))) {
        New-Item -ItemType File -Path (Join-Path $base $file) | Out-Null
    }
}

Write-Host "Created task workspace at $base"
