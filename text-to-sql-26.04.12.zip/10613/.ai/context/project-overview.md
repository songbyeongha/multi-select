# 프로젝트 개요

이 저장소는 Oracle 운영 DB를 대상으로 자연어 질문을 안전한 조회 SQL로 변환하는 Text-to-SQL 시스템이다.

## 핵심 목적

- 운영 Oracle DB에 대해 read-only 조회 SQL을 생성한다.
- metadata, domain hints, 운영 SQL을 활용해 스키마 이해도를 높인다.
- 운영자는 `app.py`, `scripts/run_cli.py`, `scripts/run_ops.py` 세 진입점만 사용한다.

## 현재 공개 진입점

1. `app.py`
2. `scripts/run_cli.py`
3. `scripts/run_ops.py`

## 현재 운영 흐름

1. `.env` 설정
2. `run_ops.py first-run`
3. `run_cli.py`로 질문 1건 검증
4. `app.py`로 UI 검증
5. 필요 시 `prepare`, `test`, `release`, `maintain`

## 작업 시 주의

- 운영 모드는 Oracle 기준이다.
- 쓰기 SQL은 금지다.
- metadata와 domain hints는 운영 품질에 직접 영향을 준다.
- 운영 문서는 한국어 기준으로 유지한다.
