# 구조 요약

## 상위 구조

- `app.py`: Streamlit UI 진입점
- `scripts/`: CLI, 운영 명령, metadata/export, release gate
- `src/text2sql/`: 실제 애플리케이션 로직
- `docs/`: 운영자용 및 개발자용 문서

## 주요 런타임 구성

### UI

- `src/text2sql/ui/`
- 질문 실행, 대량 질의, 히스토리, 학습 로그, 운영 관리 탭으로 구성

### 파이프라인

- `src/text2sql/lg/`
- LangGraph 상태와 파이프라인 흐름 관리

### 설정

- `src/text2sql/config/settings.py`
- `.env` 기반으로 LLM, DB, metadata 경로를 읽음

### 데이터 접근

- `src/text2sql/tools/db_adapters/oracle_adapter.py`
- Oracle 연결, 테이블 조회, 메타뷰 조회, 샘플 조회 수행

### 운영 자동화

- `scripts/run_ops.py`
- 내부적으로 metadata export, enrichment, E2E, release gate, maintenance를 호출

## 구현 시 자주 보는 파일

- `app.py`
- `src/text2sql/config/settings.py`
- `src/text2sql/ui/tabs/*.py`
- `scripts/run_cli.py`
- `scripts/run_ops.py`
- `scripts/export_oracle_metadata.py`
- `scripts/enrich_metadata_from_sql.py`
