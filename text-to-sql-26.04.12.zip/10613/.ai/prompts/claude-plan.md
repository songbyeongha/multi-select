Task:
Create an implementation plan based on research.

Output file:
.ai/outputs/{TASK_ID}/plan.md

Plan format:
1. Goal
2. Scope
3. Files to add
4. Files to modify
5. Detailed implementation steps
6. Edge cases
7. Validation strategy
8. Rollback / failure handling
9. Assumptions

Rules:
- Do not implement yet.
- Keep steps actionable.
- Mention exact files and expected changes.
- If the task is large, split it into phases.
- Write the plan in Korean.
