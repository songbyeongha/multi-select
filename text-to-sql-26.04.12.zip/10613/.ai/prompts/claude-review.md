Task:
Review the implementation for correctness and maintainability.

Output file:
.ai/outputs/{TASK_ID}/review_report.md

Review format:
1. Summary
2. Correctness risks
3. Edge cases missed
4. Test coverage gaps
5. Style / maintainability issues
6. Performance concerns
7. Security / safety concerns
8. Required fixes
9. Optional improvements

Rules:
- Be critical.
- Prefer concrete evidence over generic advice.
- Reference exact files and functions.
- Write the review report in Korean.
