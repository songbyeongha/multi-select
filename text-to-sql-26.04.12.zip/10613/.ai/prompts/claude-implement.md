Task:
Implement only after research.md and plan.md are present and approved.

Required inputs:
- .ai/outputs/{TASK_ID}/research.md
- .ai/outputs/{TASK_ID}/plan.md

Output files:
- .ai/outputs/{TASK_ID}/implementation_notes.md
- .ai/outputs/{TASK_ID}/test_report.md

Implementation rules:
- Follow the approved plan only.
- Do not widen scope without explicitly noting it.
- Do not use placeholder logic unless explicitly marked.
- Keep code minimal and consistent with the repository style.
- Add or update tests when a test harness exists.
- If the runtime bundle does not include tests, record the verification limits clearly.
- Record what changed and why in Korean.
