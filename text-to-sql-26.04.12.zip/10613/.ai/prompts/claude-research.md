Task:
Analyze this repository before implementing anything.

Output file:
.ai/outputs/{TASK_ID}/research.md

Research format:
1. Task summary
2. Relevant existing files
3. Current architecture related to this task
4. Data flow / control flow
5. Constraints and risks
6. Open questions
7. Recommended implementation direction

Rules:
- Do not write code.
- Do not modify source files.
- Be concrete and repo-specific.
- If a file seems relevant, explain why.
- Write the final research document in Korean.
