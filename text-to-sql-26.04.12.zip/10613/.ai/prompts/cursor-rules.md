Cursor operating rules:

- Do not implement before research and plan are written.
- Prefer editing existing files over creating unnecessary new files.
- Every task must produce:
  - research.md
  - plan.md
  - implementation_notes.md
  - test_report.md
  - review_report.md
- Before finalizing:
  - run tests when available
  - run at least smoke or compile checks when tests are absent
  - summarize diffs
- If a requested change is risky, say so explicitly.
- Keep team-facing notes in Korean.
