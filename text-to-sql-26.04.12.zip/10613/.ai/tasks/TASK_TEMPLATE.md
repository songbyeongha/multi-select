# TASK

## Task ID
TASK-YYYYMMDD-001

## Title
[간단한 작업명]

## Background
[왜 필요한지]

## Goal
[최종 목표]

## In Scope
- 

## Out of Scope
- 

## Constraints
- 

## Acceptance Criteria
- 

## References
- 
