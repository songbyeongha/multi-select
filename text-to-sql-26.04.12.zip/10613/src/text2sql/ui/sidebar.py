"""Sidebar rendering for runtime controls and schema peek."""
from __future__ import annotations

from pathlib import Path

import streamlit as st

from text2sql.tools.executor import SchemaReader

from .context import AppContext
from .renderers import show_feedback_stats


def render_sidebar(context: AppContext) -> tuple[int, bool]:
    """Render the global sidebar and return runtime controls."""
    settings = context.settings

    with st.sidebar:
        provider = settings.current_provider()
        dialect = settings.current_dialect()
        model = settings.current_model()

        st.markdown(f"### 🔌 환경: `{dialect}` + `{provider}`")
        st.caption(f"**DB Dialect:** `{dialect}`")
        st.caption(f"**LLM Provider:** `{provider}`")

        st.markdown("### 🤖 모델 정보")
        if settings.is_dual_model():
            st.caption(f"**메인 LLM:** `{model}` _(정확도 우선)_")
            st.caption("사용처: SQL 생성, Judge, Repair")
            fast_model = (
                settings.llm_fast_cfg.model
                if provider == "openai_compatible"
                else settings.llm_fast_cfg.azure_deployment
            )
            st.caption(f"**보조 LLM:** `{fast_model}` _(속도 우선)_")
            st.caption("사용처: 분석, 선택, 검증, 요약")
        else:
            st.caption(f"**LLM:** `{model}`")
            st.caption("모든 Agent가 이 모델을 사용합니다")

        st.divider()
        max_retries = st.slider("최대 Repair 시도", 1, 5, settings.pipeline.max_retries)

        st.divider()
        hitl_enabled = st.toggle(
            "🧑‍⚖️ SQL 실행 전 검토 (HITL)",
            value=False,
            help="활성화 시 SQL 생성 후 실행 전에 사용자가 검토·수정",
        )

        st.divider()
        st.markdown("### 📊 스키마")
        if settings.db.dialect == "oracle":
            oracle_db_id = settings.db.db_id or "oracle"
            st.caption(f"Oracle DB: `{oracle_db_id}`")
            try:
                for table in SchemaReader.tables(context.oracle_path):
                    with st.expander(f"📁 {table}", expanded=False):
                        info = SchemaReader.table_info(context.oracle_path, table)
                        for column in info["columns"]:
                            pk = " 🔑" if column.get("pk") else ""
                            st.caption(f"`{column['name']}` {column['type']}{pk}")
            except Exception as exc:
                st.warning(f"Oracle 스키마 로드 실패: {exc}")
        else:
            peek_db = st.selectbox("DB", list(context.db_map.keys()))
            if peek_db and Path(context.db_map[peek_db]).exists():
                for table in SchemaReader.tables(context.db_map[peek_db]):
                    with st.expander(f"📁 {table}", expanded=False):
                        info = SchemaReader.table_info(context.db_map[peek_db], table)
                        for column in info["columns"]:
                            pk = " 🔑" if column["pk"] else ""
                            st.caption(f"`{column['name']}` {column['type']}{pk}")

        st.divider()
        show_feedback_stats()

    return max_retries, hitl_enabled

