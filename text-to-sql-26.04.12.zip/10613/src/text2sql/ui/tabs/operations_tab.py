"""Operator-facing runtime status tab."""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import streamlit as st

from text2sql.config.metadata_utils import (
    default_domain_hints_path,
    default_metadata_path,
    sibling_overlay_path,
)
from text2sql.config.settings import get_settings
from text2sql.feedback.evaluator import AgentEvaluator
from text2sql.feedback.store import get_feedback_store
from text2sql.tools.release_gate import vector_index_status
from text2sql.tools.runtime_checks import probe_embedding_endpoint, probe_llm_endpoint

from ..context import AppContext, ROOT


def _resolve_runtime_paths(settings) -> dict[str, Path]:
    metadata_path = (
        Path(settings.db.metadata_path)
        if settings.db.metadata_path
        else default_metadata_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    if not metadata_path.is_absolute():
        metadata_path = ROOT / metadata_path

    manual_metadata_path = (
        Path(settings.db.manual_metadata_path)
        if settings.db.manual_metadata_path
        else sibling_overlay_path(metadata_path)
    )
    if not manual_metadata_path.is_absolute():
        manual_metadata_path = ROOT / manual_metadata_path

    hints_primary_env = os.getenv("T2SQL_DOMAIN_HINTS_PATH", "").strip()
    domain_hints_path = (
        Path(hints_primary_env)
        if hints_primary_env
        else default_domain_hints_path(ROOT / "src" / "text2sql" / "config", settings.db.dialect)
    )
    if not domain_hints_path.is_absolute():
        domain_hints_path = ROOT / domain_hints_path

    hints_manual_env = os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", "").strip()
    manual_domain_hints_path = (
        Path(hints_manual_env)
        if hints_manual_env
        else domain_hints_path.with_name(f"{domain_hints_path.stem}_manual{domain_hints_path.suffix}")
    )
    if not manual_domain_hints_path.is_absolute():
        manual_domain_hints_path = ROOT / manual_domain_hints_path

    return {
        "metadata": metadata_path,
        "manual_metadata": manual_metadata_path,
        "domain_hints": domain_hints_path,
        "manual_domain_hints": manual_domain_hints_path,
        "vector_manifest": ROOT / "data" / "vector_store" / "manifest.json",
        "feedback_log": ROOT / "data" / "feedback" / "feedback_log.json",
        "release_gate_report": ROOT / "logs" / "oracle_release_gate.json",
    }


def _cache_key(context: AppContext) -> str:
    settings = context.settings
    return "|".join(
        [
            settings.current_dialect(),
            settings.db.db_id or "",
            settings.db.host,
            str(settings.db.port),
            settings.db.service_name,
            settings.db.schema,
            settings.current_provider(),
            settings.current_model(),
            settings.embed.provider,
            settings.embed.model,
            settings.embed.deployment,
            settings.db.metadata_path,
            settings.db.manual_metadata_path,
            os.getenv("T2SQL_DOMAIN_HINTS_PATH", ""),
            os.getenv("T2SQL_DOMAIN_HINTS_MANUAL_PATH", ""),
        ]
    )


@st.cache_data(ttl=30, show_spinner=False)
def _collect_runtime_snapshot(_: str) -> dict[str, Any]:
    settings = get_settings()
    db_id = settings.db.db_id or "oracle"
    metadata = settings.schema_metadata(db_id)
    hints = settings.domain_hints(db_id)
    evaluator = AgentEvaluator().evaluate(db_id, cycle_index=10)
    feedback_stats = get_feedback_store().stats(db_id)
    paths = _resolve_runtime_paths(settings)
    path_rows = [{"구성": name, "경로": str(path), "존재": "✅" if path.exists() else "❌"} for name, path in paths.items()]

    connection: dict[str, Any]
    live_table_count = 0
    if settings.db.dialect == "oracle":
        try:
            from text2sql.tools.db_adapters.oracle_adapter import OracleAdapter

            adapter = OracleAdapter(
                host=settings.db.host,
                port=settings.db.port,
                service_name=settings.db.service_name,
                dsn=settings.db.dsn,
                user=settings.db.user,
                password=settings.db.password,
                schema=settings.db.schema,
                connect_timeout_sec=settings.db.connect_timeout_sec,
                query_timeout_ms=settings.guard.timeout_ms,
                read_only=settings.db.read_only,
            )
            connection = adapter.test_connection()
            if connection.get("ok"):
                try:
                    live_table_count = len(adapter.list_tables())
                except Exception:
                    live_table_count = 0
            adapter.close()
        except Exception as exc:
            connection = {"ok": False, "message": str(exc), "schema": settings.db.schema}
    else:
        connection = {"ok": True, "message": "SQLite mode", "schema": "", "path": "data/databases"}

    return {
        "db_id": db_id,
        "llm": probe_llm_endpoint(settings),
        "embedding": probe_embedding_endpoint(settings),
        "vector": vector_index_status(db_id, metadata),
        "evaluator": evaluator,
        "feedback_stats": feedback_stats,
        "paths": path_rows,
        "connection": connection,
        "metadata_table_count": len(metadata.get("tables", {}) or {}),
        "relationship_count": len(metadata.get("relationships", []) or []),
        "few_shot_count": len(hints.get("few_shot_examples", []) or []),
        "keyword_count": len(hints.get("keyword_map", {}) or {}),
        "live_table_count": live_table_count,
        "read_only": settings.db.read_only,
        "execution_mode": settings.pipeline.execution_mode,
        "schema": settings.db.schema,
        "include_tables": settings.db.include_table_list(),
        "exclude_tables": settings.db.exclude_table_list(),
    }


def render_operations_tab(context: AppContext) -> None:
    """Render operator-facing health, asset, and command views."""
    st.markdown("#### 🛠️ 운영 관리")
    st.caption("운영자 기준으로 연결, metadata, 자동 개선 자산을 한 화면에서 점검합니다.")

    if st.button("운영 상태 새로고침", key="ops_refresh"):
        _collect_runtime_snapshot.clear()
        st.rerun()

    snapshot = _collect_runtime_snapshot(_cache_key(context))
    connection = snapshot["connection"]
    llm = snapshot["llm"]
    embedding = snapshot["embedding"]
    vector = snapshot["vector"]
    evaluator = snapshot["evaluator"]
    metadata_metrics = evaluator.get("metadata", {})
    feedback_metrics = evaluator.get("feedback", {})
    readiness = evaluator.get("readiness", {})

    metric1, metric2, metric3, metric4 = st.columns(4)
    with metric1:
        st.metric("DB 연결", "정상" if connection.get("ok") else "실패")
    with metric2:
        st.metric("LLM", "정상" if llm.get("ok") else "실패")
    with metric3:
        st.metric("임베딩", "정상" if embedding.get("ok") else "BM25-only")
    with metric4:
        vector_state = "Fresh" if vector.get("fresh") else ("Indexed" if vector.get("indexed") else "없음")
        st.metric("Vector Index", vector_state)

    metric5, metric6, metric7, metric8 = st.columns(4)
    with metric5:
        st.metric("운영 점수", f"{evaluator.get('score', 0)}/100")
    with metric6:
        st.metric("Metadata 테이블", snapshot["metadata_table_count"])
    with metric7:
        st.metric("관계 수", snapshot["relationship_count"])
    with metric8:
        st.metric("Live 테이블", snapshot["live_table_count"])

    st.markdown("##### 상태 상세")
    st.info(
        f"실행 모드: `{snapshot['execution_mode']}` | "
        f"Read Only: `{'true' if snapshot['read_only'] else 'false'}` | "
        f"Schema: `{snapshot['schema'] or '-'}` | DB ID: `{snapshot['db_id']}`"
    )
    st.caption(f"LLM: {llm.get('message', '')}")
    st.caption(f"Embedding: {embedding.get('message', '')}")
    st.caption(f"Vector manifest: {vector.get('path', '')}")

    if not connection.get("ok"):
        st.error(f"DB 연결 실패: {connection.get('message', '알 수 없는 오류')}")
    if snapshot["schema"].upper() in {"SYSTEM", "SYS"}:
        st.warning("현재 스키마가 SYSTEM/SYS 계열로 보입니다. 운영용 업무 스키마로 전환해야 합니다.")
    if not embedding.get("ok"):
        st.warning("임베딩 endpoint가 준비되지 않아 현재 검색 품질은 BM25 fallback에 의존합니다.")
    if not vector.get("fresh"):
        st.warning("Vector index가 최신 metadata와 맞지 않습니다. metadata export 이후 재색인이 필요합니다.")

    st.divider()
    st.markdown("##### 자동 개선 현황")
    auto1, auto2, auto3, auto4 = st.columns(4)
    with auto1:
        st.metric("피드백 수", feedback_metrics.get("count", 0))
    with auto2:
        st.metric("최근 평균 점수", feedback_metrics.get("recent_avg_score", 0.0))
    with auto3:
        st.metric("Few-shot", readiness.get("few_shot_count", snapshot["few_shot_count"]))
    with auto4:
        st.metric("Keyword Map", readiness.get("keyword_count", snapshot["keyword_count"]))

    coverage_rows = [
        {"항목": "테이블 설명 커버리지", "값": f"{metadata_metrics.get('table_description_coverage', 0.0)}%"},
        {"항목": "컬럼 설명 커버리지", "값": f"{metadata_metrics.get('column_description_coverage', 0.0)}%"},
        {"항목": "샘플 값 커버리지", "값": f"{metadata_metrics.get('sample_coverage', 0.0)}%"},
        {"항목": "별칭 커버리지", "값": f"{metadata_metrics.get('alias_coverage', 0.0)}%"},
    ]
    st.dataframe(coverage_rows, use_container_width=True, hide_index=True)

    recommendations = evaluator.get("recommendations", [])
    if recommendations:
        st.markdown("##### 우선 개선 권고")
        for item in recommendations:
            st.caption(f"• {item}")

    st.divider()
    st.markdown("##### 운영 자산 경로")
    st.dataframe(snapshot["paths"], use_container_width=True, hide_index=True)

    st.markdown("##### 운영 실행 명령")
    venv_python = ".\\.venv\\Scripts\\python.exe"
    db_id = snapshot["db_id"]
    st.caption("`catalog`는 검증된 질문-SQL 모음입니다. 처음 운영 DB를 붙일 때는 없어도 되고, E2E/배포 검증 단계에서 추가하면 됩니다.")
    st.code(f"{venv_python} scripts\\run_ops.py doctor", language="powershell")
    st.code(
        f"{venv_python} scripts\\run_ops.py first-run --db-id {db_id}",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py prepare --db-id {db_id}",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py prepare --db-id {db_id} --catalog <업무_catalog.json>",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py test --db-id {db_id} --catalog <업무_catalog.json>",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py release --db-id {db_id} --skip-e2e",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py release --db-id {db_id} --catalog <업무_catalog.json>",
        language="powershell",
    )
    st.code(
        f"{venv_python} scripts\\run_ops.py maintain --db-id {db_id} --catalog <업무_catalog.json> --cycles 10",
        language="powershell",
    )
    st.caption("세부 스크립트는 내부용으로 유지하고, 운영자는 `run_ops.py`를 기본 진입점으로 사용합니다.")

    if snapshot["include_tables"] or snapshot["exclude_tables"]:
        st.markdown("##### 테이블 범위 제한")
        if snapshot["include_tables"]:
            st.caption(f"Include tables: {', '.join(snapshot['include_tables'])}")
        if snapshot["exclude_tables"]:
            st.caption(f"Exclude tables: {', '.join(snapshot['exclude_tables'])}")
