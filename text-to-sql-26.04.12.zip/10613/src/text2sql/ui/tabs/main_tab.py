"""Main question-execution tab."""
from __future__ import annotations

import time
from pathlib import Path

import streamlit as st

from text2sql.tools.date_tools import parse_relative_dates

from ..context import AppContext, append_history_entry, get_db_path
from ..pipeline import run_hitl_feedback_repair, run_phase1_generate, run_phase2_execute
from ..renderers import clean_summary, format_sql, show_result, show_token_usage, show_trace


def _reset_hitl_state() -> None:
    st.session_state.hitl_phase1_state = None
    st.session_state.hitl_phase1_elapsed = 0.0
    st.session_state.hitl_phase1_token_usage = None
    st.session_state.hitl_sql_approved = False
    st.session_state.hitl_repair_cycle = 0
    st.session_state["_hitl_question"] = ""
    st.session_state["_hitl_db"] = ""


def render_main_tab(context: AppContext, *, max_retries: int, hitl_enabled: bool) -> None:
    """Render the primary question input and HITL flow."""
    settings = context.settings

    st.markdown("#### ✏️ 질문 입력")

    col_q, col_db = st.columns([3, 1])
    with col_q:
        question = st.text_area(
            "자연어 질문",
            height=80,
            placeholder="예: 올해 가장 많이 팔린 앨범은?",
            label_visibility="collapsed",
        )
    with col_db:
        if settings.db.dialect == "oracle":
            oracle_id = settings.db.db_id or "oracle"
            st.selectbox("데이터베이스", [oracle_id], disabled=True)
            st.caption("Oracle 모드에서는 `.env`의 `T2SQL_DB_ID` 값을 사용합니다.")
            db_choice = oracle_id
        else:
            db_choice = st.selectbox("데이터베이스", list(context.db_map.keys()), index=0)

    if question.strip():
        detected_dates = parse_relative_dates(question)
        if detected_dates:
            st.markdown(
                f"""
            <div class="date-support">
            ⏰ <b>시간 표현 해석</b> (기준: {context.current_ref.isoformat()}):<br/>
            {"<br/>".join([f"• <b>{item.original_expression}</b> → {item.description}" for item in detected_dates])}
            </div>
                """,
                unsafe_allow_html=True,
            )

    run_btn = st.button("🚀  SQL 생성 및 실행", type="primary", use_container_width=True)

    if run_btn and question.strip():
        _reset_hitl_state()
        db_path = get_db_path(context, db_choice)

        if settings.db.dialect != "oracle" and not Path(db_path).exists():
            st.error(f"DB 파일 없음: {db_path}")
            st.stop()

        from text2sql.lg.state import new_state
        from text2sql.llm.client import get_token_accumulator

        initial = new_state(
            question=question,
            database_id=db_choice,
            db_path=db_path,
            max_retries=max_retries,
            hitl_enabled=hitl_enabled,
        )

        if hitl_enabled:
            with st.spinner("🔄 Phase 1: SQL 생성 중..."):
                get_token_accumulator().reset()
                started_at = time.time()
                try:
                    phase1_state = run_phase1_generate(initial)
                    phase1_elapsed = time.time() - started_at
                    phase1_tokens = get_token_accumulator().summary()
                except Exception as exc:
                    st.error(f"파이프라인 오류: {exc}")
                    import traceback

                    st.code(traceback.format_exc())
                    st.stop()

            st.session_state.hitl_phase1_state = phase1_state
            st.session_state.hitl_phase1_elapsed = phase1_elapsed
            st.session_state.hitl_phase1_token_usage = phase1_tokens
            st.session_state.hitl_sql_approved = False
            st.session_state["_hitl_question"] = question
            st.session_state["_hitl_db"] = db_choice
            st.rerun()
        else:
            from text2sql.lg.graph import get_compiled_graph

            with st.spinner("🔄 파이프라인 실행 중..."):
                get_token_accumulator().reset()
                started_at = time.time()
                try:
                    graph = get_compiled_graph()
                    result = graph.invoke(initial)
                    elapsed = time.time() - started_at
                except Exception as exc:
                    st.error(f"파이프라인 오류: {exc}")
                    import traceback

                    st.code(traceback.format_exc())
                    st.stop()

            show_result(result, elapsed, settings)
            append_history_entry(
                question=question,
                db=db_choice,
                sql=result.get("final_sql", ""),
                success=result.get("success", False),
                elapsed=elapsed,
                summary=clean_summary(result.get("result_summary", "")),
            )
    elif run_btn:
        st.warning("질문을 입력하세요.")

    if st.session_state.get("hitl_phase1_state") is not None and not st.session_state.get("hitl_sql_approved"):
        phase1_state = st.session_state.hitl_phase1_state
        phase1_elapsed = st.session_state.get("hitl_phase1_elapsed", 0.0)
        phase1_token_usage = st.session_state.get("hitl_phase1_token_usage")
        repair_cycle = st.session_state.get("hitl_repair_cycle", 0)

        st.divider()
        st.markdown("#### 🔍 SQL 실행 전 검토 (HITL)")

        preview_sql = phase1_state.get("preview_sql", "")
        if preview_sql:
            metric1, metric2, metric3, metric4 = st.columns(4)
            with metric1:
                st.metric("생성 시간", f"{phase1_elapsed:.1f}s")
            with metric2:
                st.metric("후보 수", len(phase1_state.get("candidates", [])))
            with metric3:
                st.metric("선택 테이블", len(phase1_state.get("selected_tables", [])))
            with metric4:
                st.metric("수정 횟수", repair_cycle)

            show_token_usage(phase1_token_usage)
            st.markdown("**생성된 SQL:**")
            st.code(format_sql(preview_sql), language="sql")
            show_trace(phase1_state)

            st.divider()
            edited_sql = st.text_area(
                "SQL 수정 (필요 시 직접 수정 가능)",
                value=format_sql(preview_sql),
                height=150,
                key="hitl_sql_editor",
            )

            col_approve, col_cancel = st.columns([3, 1])
            with col_approve:
                if st.button("✅ 실행 승인", type="primary", use_container_width=True, key="hitl_approve"):
                    if edited_sql.strip() != preview_sql:
                        from text2sql.lg.state import SQLCandidate

                        phase1_state["candidates"] = [
                            SQLCandidate(
                                sql=edited_sql.strip(),
                                strategy="user_edited",
                                confidence=1.0,
                                rationale="사용자가 직접 수정",
                                is_valid=True,
                                ut_passed=True,
                            )
                        ]
                        phase1_state["preview_sql"] = edited_sql.strip()
                        phase1_state["selected_sql"] = edited_sql.strip()

                    st.session_state.hitl_sql_approved = True
                    st.session_state.hitl_phase1_state = phase1_state
                    st.session_state.hitl_repair_cycle = 0
                    st.rerun()

            with col_cancel:
                if st.button("❌ 취소", use_container_width=True, key="hitl_reject"):
                    _reset_hitl_state()
                    st.rerun()

            st.divider()
            st.markdown("**🔄 수정 요청**")
            st.caption("SQL이 의도와 다르면 수정 사항을 입력하세요. LLM이 피드백을 반영하여 SQL을 재생성합니다.")
            feedback = st.text_area(
                "수정 요청 사항",
                placeholder="예: GROUP BY 대신 WINDOW 함수를 사용해줘, WHERE 조건에 날짜 필터 추가해줘",
                height=80,
                key="hitl_feedback",
            )
            if st.button(
                "🔄 수정 요청",
                use_container_width=True,
                key="hitl_repair_btn",
                disabled=not feedback.strip(),
            ):
                with st.spinner("🔄 피드백 반영하여 SQL 수정 중..."):
                    repaired = run_hitl_feedback_repair(phase1_state, feedback.strip())
                st.session_state.hitl_phase1_state = repaired
                st.session_state.hitl_repair_cycle = repair_cycle + 1
                st.rerun()
        else:
            st.error("유효한 SQL을 생성하지 못했습니다.")
            show_trace(phase1_state)
            st.divider()
            st.markdown("**🔄 수정 요청**")
            feedback_fail = st.text_area(
                "추가 지시사항 입력",
                placeholder="예: 테이블명을 확인해줘, 조건을 단순화해줘",
                height=80,
                key="hitl_feedback_fail",
            )
            col_retry, col_cancel = st.columns([3, 1])
            with col_retry:
                if st.button(
                    "🔄 수정 요청",
                    use_container_width=True,
                    key="hitl_repair_fail_btn",
                    disabled=not feedback_fail.strip(),
                ):
                    with st.spinner("🔄 피드백 반영하여 SQL 수정 중..."):
                        repaired = run_hitl_feedback_repair(phase1_state, feedback_fail.strip())
                    st.session_state.hitl_phase1_state = repaired
                    st.session_state.hitl_repair_cycle = repair_cycle + 1
                    st.rerun()
            with col_cancel:
                if st.button("❌ 취소", use_container_width=True, key="hitl_cancel_fail"):
                    _reset_hitl_state()
                    st.rerun()

    if st.session_state.get("hitl_sql_approved") and st.session_state.get("hitl_phase1_state") is not None:
        phase1_state = st.session_state.hitl_phase1_state
        phase1_elapsed = st.session_state.get("hitl_phase1_elapsed", 0.0)

        st.divider()
        with st.spinner("🔄 Phase 2: SQL 실행 중..."):
            started_at = time.time()
            try:
                result = run_phase2_execute(phase1_state)
                elapsed = phase1_elapsed + (time.time() - started_at)
            except Exception as exc:
                st.error(f"실행 오류: {exc}")
                import traceback

                st.code(traceback.format_exc())
                _reset_hitl_state()
                st.stop()

        show_result(result, elapsed, settings)
        append_history_entry(
            question=st.session_state.get("_hitl_question", ""),
            db=st.session_state.get("_hitl_db", ""),
            sql=result.get("final_sql", ""),
            success=result.get("success", False),
            elapsed=elapsed,
            summary=clean_summary(result.get("result_summary", "")),
        )
        _reset_hitl_state()
