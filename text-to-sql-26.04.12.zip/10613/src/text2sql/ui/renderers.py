"""Shared rendering helpers for Streamlit tabs."""
from __future__ import annotations

import re

import sqlglot
import streamlit as st

NODE_COLORS = {
    "Decomposer": "tn-decomposer",
    "ValueRetriever": "tn-valueretriever",
    "SchemaSelector": "tn-schemaselector",
    "JoinPlanner": "tn-joinplanner",
    "CandidateGenerator": "tn-candidategenerator",
    "Guardrails": "tn-guardrails",
    "SQLUnitTester": "tn-sqlunittester",
    "ExecutePreview": "tn-executepreview",
    "Judge": "tn-judge",
    "Repair": "tn-repair",
    "ResultSummarizer": "tn-resultsummarizer",
    "MemorySave": "tn-memorysave",
    "SAFE_FAIL": "tn-safe_fail",
}


def format_sql(sql: str) -> str:
    """Pretty-print SQL when possible."""
    if not sql or sql == "N/A":
        return sql
    try:
        formatted = sqlglot.transpile(sql, read="sqlite", pretty=True)
        return formatted[0] if formatted else sql
    except Exception:
        return sql


def clean_summary(text: str) -> str:
    """Strip leftover markdown from LLM summaries."""
    if not text:
        return text
    text = re.sub(r"\*{1,2}([^*]+?)\*{1,2}", r"\1", text)
    text = re.sub(r"~~([^~]+)~~", r"\1", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    return text.strip()


def show_token_usage(token_usage):
    """Render token and cost metrics."""
    if not token_usage:
        return
    st.markdown("#### 💰 토큰 사용량 & 비용")
    tc1, tc2, tc3, tc4 = st.columns(4)
    with tc1:
        st.metric("총 토큰", f"{token_usage.get('total_tokens', 0):,}")
    with tc2:
        st.metric("입력 토큰", f"{token_usage.get('total_prompt_tokens', 0):,}")
    with tc3:
        st.metric("출력 토큰", f"{token_usage.get('total_completion_tokens', 0):,}")
    with tc4:
        st.metric("예상 비용", f"${token_usage.get('total_cost_usd', 0):.4f}")

    with st.expander("모델별 상세", expanded=False):
        for model_name, detail in token_usage.get("by_model", {}).items():
            st.caption(
                f"**{model_name}**: {detail['calls']}회 호출 | "
                f"입력 {detail['prompt_tokens']:,} | "
                f"출력 {detail['completion_tokens']:,} | "
                f"비용 ${detail.get('cost_usd', 0):.4f}"
            )


def show_trace(result):
    """Render pipeline trace details."""
    st.markdown("#### 🔍 파이프라인 추적 로그")
    trace = result.get("trace", [])
    if not trace:
        st.caption("추적 로그가 없습니다.")
        return

    for index, entry in enumerate(trace):
        node = entry.get("node", "")
        detail = entry.get("detail", "")
        extra = entry.get("extra", {})
        css_cls = NODE_COLORS.get(node, "tn-decomposer")

        elapsed_ms = extra.get("elapsed_ms") if extra else None
        time_tag = f" ⏱️ {elapsed_ms}ms" if elapsed_ms is not None else ""
        with st.expander(
            f"**{index + 1}.** {node}{time_tag} — {detail[:80]}",
            expanded=(index < 3 or "❌" in detail or "✅ 승인" in detail),
        ):
            meta_parts = []
            if elapsed_ms is not None:
                if elapsed_ms >= 1000:
                    meta_parts.append(f"⏱️ {elapsed_ms / 1000:.1f}s")
                else:
                    meta_parts.append(f"⏱️ {elapsed_ms}ms")
            model_name = extra.get("model") if extra else None
            if model_name and model_name != "—":
                meta_parts.append(f"🤖 {model_name}")
            if meta_parts:
                st.caption(" | ".join(meta_parts))

            st.markdown(
                f'<span class="trace-node {css_cls}">{node}</span> {detail}',
                unsafe_allow_html=True,
            )
            if not extra:
                continue
            for key, value in extra.items():
                if key in {"elapsed_ms", "model"}:
                    continue
                if key == "sql":
                    st.code(format_sql(value), language="sql")
                elif key == "reasoning":
                    st.markdown(f"**📝 이유:** {value}")
                elif key == "issues":
                    for issue in (value if isinstance(value, list) else [value]):
                        st.warning(issue)
                elif key == "sub_questions":
                    for sub_question in value:
                        st.caption(f"  ▸ {sub_question}")
                elif key == "extracted_values":
                    st.json(value)
                elif key == "detected_dates":
                    st.markdown("**🕐 감지된 날짜:**")
                    for detected in value:
                        st.caption(f"  • {detected['original']} → {detected['description']}")
                elif key == "confidence":
                    st.progress(min(float(value), 1.0), text=f"신뢰도: {value}")
                elif key == "query_pattern":
                    st.caption(f"🏷️ 쿼리 패턴: {value}")
                else:
                    st.caption(f"{key}: {value}")


def show_feedback_ui(result: dict, settings) -> None:
    """Collect end-user feedback and trigger the learner."""
    from text2sql.feedback import (
        FeedbackRecord,
        FeedbackScore,
        build_auto_comment,
        compute_auto_score,
        get_feedback_store,
        get_learner,
    )

    question = result.get("question", "")
    sql = result.get("final_sql", "") or result.get("selected_sql", "")
    db_id = result.get("database_id", "")
    if not question or not sql:
        return

    feedback_key = f"fb_{hash(question + sql)}"
    if st.session_state.get(feedback_key):
        previous = st.session_state[feedback_key]
        st.info(f"피드백 완료: {previous['emoji']} {previous['label']}")
        return

    auto_score = compute_auto_score(result)
    auto_feedback = FeedbackScore(auto_score)
    auto_comment = build_auto_comment(result, auto_score)

    st.markdown("#### 📝 결과 피드백")
    st.caption(
        f"자동 평가: {auto_feedback.emoji} **{auto_feedback.label_ko}** ({auto_comment}) "
        "— 아래 버튼으로 직접 평가하면 자동 평가를 덮어씁니다."
    )

    clicked_score = None
    labels = [
        ("🤩", "매우 좋음", 5),
        ("😊", "좋음", 4),
        ("😐", "보통", 3),
        ("😞", "나쁨", 2),
        ("😡", "매우 나쁨", 1),
    ]
    for column, (emoji, label, score) in zip(st.columns(5), labels):
        with column:
            if st.button(f"{emoji}\n{label}", key=f"{feedback_key}_{score}", use_container_width=True):
                clicked_score = score

    comment = st.text_input(
        "한 줄 코멘트 (선택)",
        key=f"{feedback_key}_comment",
        placeholder="예: 부서 이름이 아니라 부서 ID가 나왔어요",
    )

    if clicked_score is None:
        return

    feedback_score = FeedbackScore(clicked_score)
    exec_report = result.get("exec_report")
    row_count = getattr(exec_report, "row_count", 0) if exec_report else 0

    record = FeedbackRecord(
        question=question,
        sql=sql,
        database_id=db_id,
        score=clicked_score,
        user_comment=comment,
        query_pattern=result.get("query_pattern", ""),
        row_count=row_count or 0,
        dialect=result.get("dialect", settings.current_dialect()),
        tables_used=result.get("selected_tables", []),
    )
    get_feedback_store().add(record)

    learn_result = get_learner().learn(db_id)
    st.session_state[feedback_key] = {
        "emoji": feedback_score.emoji,
        "label": feedback_score.label_ko,
    }
    st.success(f"{feedback_score.emoji} 피드백 감사합니다! ({feedback_score.label_ko})")

    if learn_result.get("few_shots_added", 0) > 0:
        st.toast(f"좋은 SQL이 학습 데이터에 자동 등록되었습니다 (+{learn_result['few_shots_added']}개)")
    if learn_result.get("keywords_added", 0) > 0:
        st.toast(f"키워드 매핑이 자동 확장되었습니다 (+{learn_result['keywords_added']}개)")
    if learn_result.get("errors_logged", 0) > 0:
        st.toast("오류 패턴이 기록되어 다음 질문에 반영됩니다")

    st.rerun()


def show_result(result, elapsed: float, settings) -> None:
    """Render the end-to-end execution result."""
    st.divider()

    metric1, metric2, metric3, metric4 = st.columns(4)
    with metric1:
        st.metric("상태", "✅ 성공" if result.get("success") else "❌ 실패")
    with metric2:
        st.metric("처리 시간", f"{elapsed:.1f}s")
    with metric3:
        st.metric("Repair 횟수", result.get("repair_count", 0))
    with metric4:
        st.metric("선택 테이블", len(result.get("selected_tables", [])))

    show_token_usage(result.get("token_usage"))

    st.markdown("#### 🔧 생성된 SQL")
    st.code(format_sql(result.get("final_sql", "N/A")), language="sql")

    if result.get("success"):
        st.markdown("#### 💡 결과 요약")
        st.success(clean_summary(result.get("result_summary", "")))
        if result.get("final_result"):
            st.markdown("#### 📊 실행 결과")
            st.dataframe(result["final_result"], use_container_width=True, hide_index=True)
    else:
        st.error(result.get("error", "알 수 없는 오류"))

    st.divider()
    show_trace(result)
    show_feedback_ui(result, settings)


def show_feedback_stats() -> None:
    """Render lightweight feedback stats in the sidebar."""
    from text2sql.feedback import get_feedback_store

    stats = get_feedback_store().stats()
    if stats["total"] == 0:
        return

    st.markdown("### 📈 피드백 통계")
    st.caption(f"총 {stats['total']}건 | 평균 {stats['avg_score']}점 | 긍정률 {stats['positive_rate']}%")
    for label, count in stats["distribution"].items():
        if count > 0:
            st.caption(f"  {label}: {count}건")

