"""Shared helpers for agent nodes."""
from __future__ import annotations
import hashlib
import time
from typing import Dict, Any

from ..lg.state import GraphState
from ..config.settings import get_settings
from ..llm.client import get_llm, get_llm_fast

def get_llm_for_node(state: GraphState, *, prefer_primary: bool = True):
    """
    use_fast_only=True (simple 쿼리)면 항상 fast LLM 반환.
    그 외에는 prefer_primary에 따라 primary/fast 반환.
    """
    if state.get("use_fast_only", False):
        return get_llm_fast()
    return get_llm() if prefer_primary else get_llm_fast()

_cli_display = None


def set_cli_display(display):
    """CLI 디스플레이 인스턴스 설정 (None이면 비활성화)."""
    global _cli_display
    _cli_display = display


def get_cli_display():
    """현재 CLI 디스플레이 인스턴스 반환."""
    return _cli_display


def trace(state: GraphState, node: str, detail: str,
          extra: Dict[str, Any] | None = None):
    """UI 추적 로그 추가 + CLI 디스플레이 연동."""
    entry = {"node": node, "detail": detail, "ts": time.time()}
    if extra:
        entry["extra"] = extra
    state.setdefault("trace", []).append(entry)
    if _cli_display is not None:
        try:
            _cli_display.print_step(node, detail, extra)
        except Exception:
            pass

def safe_json(llm, prompt, *, system="", node_name="", fallback=None):
    """JSON 생성 with fallback"""
    try:
        return llm.generate_json(prompt, system=system, node_name=node_name)
    except Exception:
        if fallback is not None:
            return fallback
        raise

PATTERN_TO_KEYS = {
    "group_top_n": ["top_album_per_year", "top_track_per_artist", "top_track_per_genre",
                    "top_selling_tracks"],
    "group_aggregate": ["album_sales_by_year", "yearly_total_sales",
                        "revenue_by_country", "year_with_largest_monthly_range"],
    "period_comparison": ["yearly_revenue_growth", "monthly_revenue_growth",
                          "yearly_growth_top_country"],
    "threshold_filter": ["above_average_customers",
                         "above_average_spending",
                         "customer_percentile_filter"],
    "ratio_calculation": ["genre_sales_ratio", "country_revenue_ratio"],
    "running_calc": ["cumulative_monthly_revenue"],
    "set_operation": [],
    "nested_condition": [],
}


def get_reference_sql(db_id: str, query_pattern: str) -> str:
    """query_pattern에 맞는 참고 CTE SQL 조각을 반환.

    정적 매핑(PATTERN_TO_KEYS) + 피드백에서 자동 등록된 fb_ 패턴 모두 포함.
    """
    settings = get_settings()
    hints = settings.domain_hints(db_id)
    patterns = hints.get("common_patterns", {})

    reference_parts = []

    # 정적 매핑
    for key in PATTERN_TO_KEYS.get(query_pattern, []):
        if key in patterns:
            reference_parts.append(f"-- 참고({key}):\n{patterns[key]}")

    # 피드백에서 자동 등록된 패턴 (fb_{query_pattern}_*)
    fb_prefix = f"fb_{query_pattern}_"
    for key, sql in patterns.items():
        if key.startswith(fb_prefix):
            reference_parts.append(f"-- 피드백 참고({key}):\n{sql}")

    return "\n\n".join(reference_parts) if reference_parts else "없음"

def sql_hash(s: str) -> str:
    """공백/대소문자/세미콜론 무시한 SQL 해시"""
    normalized = " ".join(s.lower().strip().rstrip(";").split())
    return hashlib.md5(normalized.encode()).hexdigest()

def make_cache_key(prefix: str, question: str, db_path: str) -> str:
    """질문+DB 경로 기반 캐시 키 생성 (프리픽스 포함으로 타입 간 충돌 방지)"""
    raw = f"{prefix}:{question}:{db_path}"
    return f"{prefix}_{hashlib.sha256(raw.encode()).hexdigest()[:32]}"
