"""
FeedbackStore — 피드백 영속 저장소
==================================
JSON 파일 기반. 질문 + SQL + 결과 + 사용자 평가를 저장한다.
"""
from __future__ import annotations

import json
import logging
import threading
from dataclasses import asdict, dataclass, field
from datetime import datetime
from enum import IntEnum
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

_DATA_DIR = Path(__file__).resolve().parents[3] / "data" / "feedback"


class FeedbackScore(IntEnum):
    """5단계 피드백 점수."""
    VERY_BAD = 1   # 매우 나쁨 — 완전히 틀린 SQL / 의미 없는 결과
    BAD = 2        # 나쁨 — SQL은 실행되지만 의도와 다름
    NORMAL = 3     # 보통 — 대충 맞지만 개선 여지 있음
    GOOD = 4       # 좋음 — 올바른 결과, 사소한 차이
    VERY_GOOD = 5  # 매우 좋음 — 완벽한 SQL + 결과

    @classmethod
    def from_label(cls, label: str) -> "FeedbackScore":
        _map = {
            "매우 좋음": cls.VERY_GOOD, "very_good": cls.VERY_GOOD,
            "좋음": cls.GOOD, "good": cls.GOOD,
            "보통": cls.NORMAL, "normal": cls.NORMAL,
            "나쁨": cls.BAD, "bad": cls.BAD,
            "매우 나쁨": cls.VERY_BAD, "very_bad": cls.VERY_BAD,
        }
        return _map.get(label.strip(), cls.NORMAL)

    @property
    def label_ko(self) -> str:
        return {1: "매우 나쁨", 2: "나쁨", 3: "보통", 4: "좋음", 5: "매우 좋음"}[self.value]

    @property
    def emoji(self) -> str:
        return {1: "😡", 2: "😞", 3: "😐", 4: "😊", 5: "🤩"}[self.value]

    @property
    def is_positive(self) -> bool:
        return self.value >= 4

    @property
    def is_negative(self) -> bool:
        return self.value <= 2


@dataclass
class FeedbackRecord:
    question: str
    sql: str
    database_id: str
    score: int
    score_label: str = ""
    user_comment: str = ""
    query_pattern: str = ""
    row_count: int = 0
    exec_ms: float = 0.0
    dialect: str = "sqlite"
    tables_used: List[str] = field(default_factory=list)
    timestamp: str = ""
    promoted_to_few_shot: bool = False
    error_logged: bool = False

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        if not self.score_label:
            self.score_label = FeedbackScore(self.score).label_ko


class FeedbackStore:
    """JSON 파일 기반 피드백 저장소."""

    def __init__(self, data_dir: Path | str | None = None):
        self._dir = Path(data_dir) if data_dir else _DATA_DIR
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / "feedback_log.json"
        self._lock = threading.Lock()
        self._records: List[FeedbackRecord] = self._load()

    def _load(self) -> List[FeedbackRecord]:
        if not self._file.exists():
            return []
        try:
            raw = json.loads(self._file.read_text(encoding="utf-8"))
            return [FeedbackRecord(**r) for r in raw]
        except Exception as e:
            logger.warning(f"피드백 로드 실패: {e}")
            return []

    def _save(self):
        self._file.write_text(
            json.dumps([asdict(r) for r in self._records],
                       ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def add(self, record: FeedbackRecord) -> None:
        with self._lock:
            self._records.append(record)
            self._save()
        logger.info(f"피드백 저장: [{record.score_label}] {record.question[:50]}")
        try:
            from .logger import get_feedback_logger
            get_feedback_logger().log_feedback_received(
                question=record.question, sql=record.sql,
                db_id=record.database_id,
                score=record.score, score_label=record.score_label,
                comment=record.user_comment,
            )
        except Exception:
            pass

    def all(self) -> List[FeedbackRecord]:
        with self._lock:
            return list(self._records)

    def by_db(self, db_id: str) -> List[FeedbackRecord]:
        with self._lock:
            return [r for r in self._records if r.database_id == db_id]

    def positive(self, db_id: str = "") -> List[FeedbackRecord]:
        recs = self.by_db(db_id) if db_id else self.all()
        return [r for r in recs if FeedbackScore(r.score).is_positive]

    def negative(self, db_id: str = "") -> List[FeedbackRecord]:
        recs = self.by_db(db_id) if db_id else self.all()
        return [r for r in recs if FeedbackScore(r.score).is_negative]

    def not_yet_promoted(self, db_id: str = "") -> List[FeedbackRecord]:
        return [r for r in self.positive(db_id) if not r.promoted_to_few_shot]

    def mark_promoted(self, record: FeedbackRecord):
        with self._lock:
            for r in self._records:
                if r.timestamp == record.timestamp and r.question == record.question:
                    r.promoted_to_few_shot = True
            self._save()

    def pattern_stats(self, db_id: str, query_pattern: str) -> Dict[str, Any]:
        """특정 query_pattern에 대한 피드백 통계를 반환한다."""
        recs = [r for r in self.by_db(db_id)
                if r.query_pattern == query_pattern and r.sql]
        if not recs:
            return {"count": 0, "avg_score": 0.0, "best_score": 0,
                    "best_record": None}
        scores = [r.score for r in recs]
        best_idx = scores.index(max(scores))
        return {
            "count": len(recs),
            "avg_score": round(sum(scores) / len(scores), 2),
            "best_score": max(scores),
            "best_record": recs[best_idx],
        }

    def mark_error_logged(self, record: FeedbackRecord):
        with self._lock:
            for r in self._records:
                if r.timestamp == record.timestamp and r.question == record.question:
                    r.error_logged = True
            self._save()

    def stats(self, db_id: str = "") -> Dict[str, Any]:
        recs = self.by_db(db_id) if db_id else self.all()
        if not recs:
            return {"total": 0, "avg_score": 0.0, "distribution": {}}
        scores = [r.score for r in recs]
        dist = {}
        for s in range(1, 6):
            cnt = scores.count(s)
            dist[FeedbackScore(s).label_ko] = cnt
        return {
            "total": len(recs),
            "avg_score": round(sum(scores) / len(scores), 2),
            "positive_rate": round(len([s for s in scores if s >= 4]) / len(scores) * 100, 1),
            "distribution": dist,
        }

    def count(self) -> int:
        return len(self._records)


_inst: Optional[FeedbackStore] = None


def get_feedback_store() -> FeedbackStore:
    global _inst
    if _inst is None:
        _inst = FeedbackStore()
    return _inst
