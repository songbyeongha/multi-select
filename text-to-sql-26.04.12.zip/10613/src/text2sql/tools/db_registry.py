"""
DB Registry  --  db_id -> 실제 파일 경로 해석
==========================================================
탐색 우선순위:
  1. data/databases/{db_id}.db          (기존 Chinook/monitor)

Oracle 모드에서는 파일 경로가 아닌 adapter를 사용합니다.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional, List

# 프로젝트 루트 (src/text2sql/tools/ 에서 3단계 위)
_PROJECT_ROOT = Path(__file__).resolve().parents[3]

# 기본 경로
_FLAT_DB_DIR = _PROJECT_ROOT / "data" / "databases"


class DBNotFoundError(FileNotFoundError):
    """db_id에 해당하는 DB 파일을 찾을 수 없을 때"""


def resolve_db_path(db_id: str) -> str:
    """
    db_id를 실제 SQLite 파일 경로(str)로 변환합니다.

    Args:
        db_id: 데이터베이스 식별자 (예: "chinook")

    Returns:
        절대 경로 문자열

    Raises:
        DBNotFoundError: DB를 찾지 못한 경우
    """
    flat_path = _FLAT_DB_DIR / f"{db_id}.db"
    if flat_path.exists():
        return str(flat_path)

    raise DBNotFoundError(
        f"DB '{db_id}' not found.\n"
        f"  checked: {flat_path}"
    )


def list_flat_dbs() -> dict[str, str]:
    """기존 data/databases/*.db 목록을 {stem: abs_path} 로 반환 (UI 용)"""
    if not _FLAT_DB_DIR.exists():
        return {}
    return {p.stem: str(p) for p in sorted(_FLAT_DB_DIR.glob("*.db"))}
