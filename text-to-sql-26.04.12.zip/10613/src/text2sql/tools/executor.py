"""
SQL 실행기 · SchemaReader  –  Adapter 기반 dialect-agnostic
==========================================================
SQLite / Oracle 모두 지원. 기존 인터페이스 유지.
"""
from __future__ import annotations
import sqlite3, time
from typing import Dict, List, Any, Optional
from pathlib import Path

from ..lg.state import ErrorType, ExecReport


class SQLExecutor:
    """Adapter 기반 SQL 실행기. db_path(SQLite) 또는 adapter 직접 사용 지원."""

    def __init__(self, preview_limit: int = 50, timeout_ms: int | None = None):
        self.preview_limit = preview_limit
        if timeout_ms is not None:
            self._timeout_ms = timeout_ms
        else:
            from ..config.settings import get_settings
            self._timeout_ms = get_settings().guard.timeout_ms

    def execute(self, db_path: str, sql: str,
                limit: int | None = None) -> ExecReport:
        """
        실행 진입점. db_path가 파일이면 SQLite, 아니면 adapter를 시도.
        """
        limit = limit or self.preview_limit

        # Oracle adapter가 등록되어 있으면 adapter 경로 사용
        from ..config.settings import get_settings
        dialect = get_settings().db.dialect

        if dialect == "oracle" and not Path(db_path).exists():
            return self._execute_via_adapter(sql, limit)

        # 기존 SQLite 경로
        return self._execute_sqlite(db_path, sql, limit)

    def execute_with_adapter(self, adapter, sql: str,
                             limit: int | None = None) -> ExecReport:
        """Adapter를 직접 전달하여 실행."""
        limit = limit or self.preview_limit
        result = adapter.execute(sql, limit=limit, timeout_ms=self._timeout_ms)
        return self._adapter_result_to_report(result)

    def _execute_via_adapter(self, sql: str, limit: int) -> ExecReport:
        from .db_adapters import get_adapter
        try:
            adapter = get_adapter()
            result = adapter.execute(sql, limit=limit, timeout_ms=self._timeout_ms)
            return self._adapter_result_to_report(result)
        except Exception as e:
            return ExecReport(ok=False, error_type=ErrorType.UNKNOWN,
                              error_message=str(e))

    @staticmethod
    def _adapter_result_to_report(result: Dict[str, Any]) -> ExecReport:
        if result["ok"]:
            return ExecReport(
                ok=True, rows_preview=result["rows"],
                row_count=result["row_count"], exec_ms=result["exec_ms"],
            )
        etype_map = {
            "SCHEMA": ErrorType.SCHEMA,
            "SYNTAX": ErrorType.SYNTAX,
            "TIMEOUT": ErrorType.TIMEOUT,
            "RUNTIME": ErrorType.RUNTIME,
            "SAFETY": ErrorType.SAFETY,
        }
        return ExecReport(
            ok=False,
            error_type=etype_map.get(result.get("error_type", ""), ErrorType.UNKNOWN),
            error_message=result.get("error_message", ""),
        )

    def _execute_sqlite(self, db_path: str, sql: str, limit: int) -> ExecReport:
        conn = None
        t0 = time.time()
        try:
            conn = sqlite3.connect(db_path)
            conn.row_factory = sqlite3.Row

            timeout_sec = self._timeout_ms / 1000.0
            def _timeout_check():
                if time.time() - t0 > timeout_sec:
                    return 1
                return 0
            conn.set_progress_handler(_timeout_check, 1000)

            cur = conn.execute(sql)
            rows = [dict(r) for r in cur.fetchmany(limit)]
            remaining = 0
            if len(rows) == limit:
                while True:
                    batch = cur.fetchmany(1000)
                    if not batch:
                        break
                    remaining += len(batch)
            total_rows = len(rows) + remaining
            ms = (time.time() - t0) * 1000
            return ExecReport(ok=True, rows_preview=rows,
                              row_count=total_rows, exec_ms=ms)
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if "no such table" in msg or "no such column" in msg or "ambiguous" in msg:
                etype = ErrorType.SCHEMA
            elif "syntax" in msg:
                etype = ErrorType.SYNTAX
            elif "interrupt" in msg:
                etype = ErrorType.TIMEOUT
            else:
                etype = ErrorType.RUNTIME
            return ExecReport(ok=False, error_type=etype, error_message=str(e))
        except Exception as e:
            return ExecReport(ok=False, error_type=ErrorType.UNKNOWN,
                              error_message=str(e))
        finally:
            if conn:
                conn.close()


class SchemaReader:
    """Adapter 기반 스키마 리더. SQLite 하위 호환 유지."""

    @staticmethod
    def subset(schema: List[Dict[str, Any]], tables: List[str]) -> List[Dict[str, Any]]:
        wanted = set(tables or [])
        if not wanted:
            return list(schema)
        return [tbl for tbl in schema if tbl.get("table_name") in wanted]

    @staticmethod
    def tables(db_path: str) -> List[str]:
        from ..config.settings import get_settings
        dialect = get_settings().db.dialect

        if dialect == "oracle" and not Path(db_path).exists():
            from .db_adapters import get_adapter
            return get_adapter().list_tables()

        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchall()
            return [r[0] for r in rows]
        finally:
            conn.close()

    @staticmethod
    def table_info(db_path: str, table: str) -> Dict[str, Any]:
        from ..config.settings import get_settings
        dialect = get_settings().db.dialect

        if dialect == "oracle" and not Path(db_path).exists():
            from .db_adapters import get_adapter
            return get_adapter().table_info(table).to_legacy_dict()

        conn = sqlite3.connect(db_path)
        try:
            cols = [{"name": r[1], "type": r[2], "notnull": bool(r[3]),
                     "pk": bool(r[5])}
                    for r in conn.execute(f"PRAGMA table_info({table})")]
            fks = [{"from": r[3], "to_table": r[2], "to_column": r[4]}
                   for r in conn.execute(f"PRAGMA foreign_key_list({table})")]
            try:
                cur = conn.execute(f"SELECT * FROM [{table}] LIMIT 3")
                names = [d[0] for d in cur.description]
                samples = [dict(zip(names, row)) for row in cur.fetchall()]
            except Exception:
                samples = []
            return {"table_name": table, "columns": cols,
                    "foreign_keys": fks, "sample_rows": samples}
        finally:
            conn.close()

    @staticmethod
    def full_schema(db_path: str) -> List[Dict[str, Any]]:
        return [SchemaReader.table_info(db_path, t)
                for t in SchemaReader.tables(db_path)]

    @staticmethod
    def from_meta(meta: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        schema_metadata의 tables를 full_schema 형식으로 변환.
        DB 연결 없이 metadata JSON만으로 스키마 구성 (Oracle 포함).
        """
        full_schema = []
        table_entries = meta.get("tables") or {}
        relationship_map: Dict[str, List[Dict[str, str]]] = {}
        for rel in meta.get("relationships") or []:
            from_ref = str(rel.get("from") or "")
            to_ref = str(rel.get("to") or "")
            if "." not in from_ref or "." not in to_ref:
                continue
            from_table, from_column = from_ref.rsplit(".", 1)
            to_table, to_column = to_ref.rsplit(".", 1)
            relationship_map.setdefault(from_table, []).append({
                "from": from_column,
                "to_table": to_table,
                "to_column": to_column,
            })

        for tname, tmeta in table_entries.items():
            columns = []
            sample_values = tmeta.get("sample_values", {}) if isinstance(tmeta, dict) else {}
            for cname, cmeta in (tmeta.get("columns") or {}).items():
                if isinstance(cmeta, dict):
                    column_entry = {
                        "name": cname,
                        "type": cmeta.get("type", ""),
                        "pk": bool(cmeta.get("is_pk")),
                        "notnull": False,
                        "description": cmeta.get("description", ""),
                    }
                    col_samples = cmeta.get("sample_values") or sample_values.get(cname) or []
                    if col_samples:
                        column_entry["sample_values"] = list(col_samples)
                    columns.append(column_entry)
                else:
                    columns.append({"name": str(cname), "type": "",
                                    "pk": False, "notnull": False, "description": ""})
            fks = []
            for cname, cmeta in (tmeta.get("columns") or {}).items():
                if isinstance(cmeta, dict) and cmeta.get("references"):
                    parts = str(cmeta["references"]).rsplit(".", 1)
                    if len(parts) == 2:
                        fks.append({"from": cname,
                                    "to_table": parts[0], "to_column": parts[1]})
            for fk in relationship_map.get(tname, []):
                if fk not in fks:
                    fks.append(fk)

            aliases = list(tmeta.get("aliases") or tmeta.get("table_aliases") or [])
            short_name = tmeta.get("short_name") or tname.split(".")[-1]
            if short_name and short_name not in aliases:
                aliases.insert(0, short_name)
            if tname not in aliases:
                aliases.insert(0, tname)

            sample_text = tmeta.get("sample_text", "")
            if not sample_text and sample_values:
                parts = []
                for cname, vals in sample_values.items():
                    if vals:
                        parts.append(f"{cname}={', '.join(str(v) for v in vals[:3])}")
                sample_text = "; ".join(parts[:8])

            full_schema.append({
                "table_name": tname,
                "table_description": tmeta.get("description", ""),
                "table_aliases": aliases,
                "short_name": short_name,
                "database_name": tmeta.get("database_name", meta.get("name", "")),
                "schema_name": tmeta.get("schema_name", ""),
                "ddl_excerpt": tmeta.get("ddl_excerpt", ""),
                "sample_text": sample_text,
                "columns": columns,
                "foreign_keys": fks,
                "sample_rows": [],
                "sample_values": sample_values,
            })
        return full_schema

    @staticmethod
    def format_text(schema: List[Dict[str, Any]],
                    meta: Dict[str, Any] | None = None) -> str:
        """스키마를 LLM 프롬프트용 텍스트로 변환 (메타데이터 + 샘플 값 반영)"""
        lines: List[str] = []
        tables_meta = (meta or {}).get("tables", {})

        for tbl in schema:
            name = tbl["table_name"]
            tmeta = tables_meta.get(name, {})
            desc = tmeta.get("description", "")
            lines.append(f"## {name}" + (f"  -- {desc}" if desc else ""))
            aliases = tbl.get("table_aliases") or tmeta.get("aliases") or tmeta.get("table_aliases") or []
            if aliases:
                alias_text = ", ".join(str(a) for a in aliases[:8] if a)
                if alias_text:
                    lines.append(f"  aliases: {alias_text}")

            col_meta = tmeta.get("columns", {})
            samples = tbl.get("sample_rows", [])
            sample_values = tbl.get("sample_values") or tmeta.get("sample_values") or {}

            for c in tbl["columns"]:
                pk = " [PK]" if c.get("pk") else ""
                cdesc = ""
                if isinstance(col_meta, dict):
                    cm = col_meta.get(c["name"], {})
                    if isinstance(cm, dict):
                        cdesc = cm.get("description", "")
                    elif isinstance(cm, str):
                        cdesc = cm
                line = f"  {c['name']}  {c['type']}{pk}"
                if cdesc:
                    line += f"  -- {cdesc}"

                inline_sample_vals = c.get("sample_values") or sample_values.get(c["name"], [])
                if inline_sample_vals:
                    preview = ", ".join(str(v) for v in inline_sample_vals[:3])
                    line += f"  (예: {preview})"
                elif samples:
                    cname = c["name"]
                    sample_vals = []
                    for row in samples[:3]:
                        val = row.get(cname)
                        if val is not None:
                            sv = str(val)
                            if len(sv) > 30:
                                sv = sv[:27] + "..."
                            sample_vals.append(sv)
                    if sample_vals:
                        unique_vals = list(dict.fromkeys(sample_vals))[:3]
                        line += f"  (예: {', '.join(unique_vals)})"

                lines.append(line)

            for fk in tbl.get("foreign_keys", []):
                lines.append(f"  FK: {fk['from']} → {fk['to_table']}.{fk['to_column']}")

            if tbl.get("sample_text"):
                lines.append(f"  sample_text: {tbl['sample_text']}")
            lines.append("")

        return "\n".join(lines)
