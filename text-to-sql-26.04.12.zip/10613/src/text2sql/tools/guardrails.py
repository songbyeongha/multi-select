"""
SQL Guardrails  ──  sqlglot AST 기반 + regex 백업
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from typing import List, Tuple

try:
    import sqlglot
    from sqlglot import exp as E
    _HAS_SQLGLOT = True
except ImportError:
    _HAS_SQLGLOT = False

from ..config.settings import get_settings


@dataclass
class ValidationResult:
    valid: bool
    sql: str
    issues: List[str] = field(default_factory=list)


class SQLGuard:
    def __init__(self, known_tables: List[str] | None = None):
        cfg = get_settings().guard
        self._allowed = set(cfg.allowed_statements)
        self._max_rows = cfg.max_rows
        self._forbidden = set(k.upper() for k in cfg.forbidden_kw)
        self._known = set(t.lower() for t in (known_tables or []))
        self._known_original = {t.lower(): t for t in (known_tables or [])}
        self._enforce_limit_flag = cfg.enforce_limit
        self._dml_re = re.compile(
            r"^\s*(insert|update|delete|merge|create|alter|drop|truncate|grant|revoke)\b",
            re.I,
        )

    @staticmethod
    def _part_name(value) -> str:
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        name = getattr(value, "name", None)
        if name:
            return str(name)
        inner = getattr(value, "this", None)
        if inner:
            return str(inner)
        return str(value)

    def _table_candidates(self, table_expr) -> List[str]:
        short_name = self._part_name(getattr(table_expr, "name", None)).strip()
        schema_name = self._part_name(getattr(table_expr, "db", None)).strip()
        database_name = self._part_name(getattr(table_expr, "catalog", None)).strip()
        candidates: List[str] = []
        if short_name:
            candidates.append(short_name.lower())
        if schema_name and short_name:
            candidates.append(f"{schema_name}.{short_name}".lower())
        if database_name and schema_name and short_name:
            candidates.append(f"{database_name}.{schema_name}.{short_name}".lower())
        return candidates

    def _suggest_table(self, unknown: str) -> str:
        """Unknown table에 대해 fuzzy match로 유사 테이블명 제안"""
        ul = unknown.lower()
        best, best_score = "", 0.0
        for known in self._known:
            # 접두사/접미사 일치
            if ul.startswith(known) or known.startswith(ul):
                score = min(len(ul), len(known)) / max(len(ul), len(known))
                if score > best_score:
                    best, best_score = known, score
            # 단복수 변형 (s 추가/제거)
            if ul.rstrip("s") == known.rstrip("s"):
                best, best_score = known, 0.95
            # 부분 문자열 일치
            if ul in known or known in ul:
                score = min(len(ul), len(known)) / max(len(ul), len(known))
                if score > best_score:
                    best, best_score = known, score
        if best and best_score > 0.5:
            orig = self._known_original.get(best, best)
            return f" (유사: {orig})"
        return ""

    def validate(self, sql: str, dialect: str | None = None) -> ValidationResult:
        if dialect is None:
            from ..config.settings import get_settings
            dialect = get_settings().db.dialect
        if not sql or not sql.strip():
            return ValidationResult(False, sql, ["빈 SQL"])

        sql = sql.strip()
        issues: List[str] = []

        # 1) 금지 키워드
        for kw in self._forbidden:
            if re.search(rf"\b{kw}\b", sql, re.I):
                issues.append(f"금지 키워드: {kw}")
        if re.search(r"\bpragma(?:\b|_)", sql, re.I):
            issues.append("금지 키워드: PRAGMA")
        if issues:
            return ValidationResult(False, sql, issues)

        # 2) AST 검증 또는 regex
        ok, msgs = (self._ast_check(sql, dialect) if _HAS_SQLGLOT
                     else self._regex_check(sql))
        if not ok:
            return ValidationResult(False, sql, msgs)

        # 3) LIMIT 강제 (T2SQL_ENFORCE_LIMIT=false 시 비활성화)
        if self._enforce_limit_flag:
            safe = self._enforce_limit(sql, dialect=dialect)
            return ValidationResult(True, safe, [])
        return ValidationResult(True, sql.strip().rstrip(";") + ";", [])

    # ── 내부 ────────────────────────────────────────────
    def _ast_check(self, sql: str, dialect: str) -> Tuple[bool, List[str]]:
        try:
            parsed = sqlglot.parse_one(sql, read=dialect)
        except Exception as e:
            return False, [f"파싱 오류: {e}"]

        # sqlglot v26: Except/Intersect는 Union의 서브클래스가 아님 (SetOperation → Query)
        if not isinstance(parsed, (E.Select, E.Union, E.Except, E.Intersect, E.With)):
            return False, ["SELECT/CTE/UNION/EXCEPT/INTERSECT만 허용"]

        banned = (E.Update, E.Delete, E.Insert, E.Create,
                  E.Alter, E.Drop, E.TruncateTable, E.Merge)
        if list(parsed.find_all(banned)):
            return False, ["DML/DDL 감지"]

        # EXCEPT 체인 감지: A EXCEPT B EXCEPT C → 실패
        if self._has_except_chain(parsed):
            return False, ["EXCEPT 체인 감지 (A EXCEPT B EXCEPT C) — 서브쿼리로 재작성 필요"]

        if self._known:
            # CTE 별칭 수집 — CTE 이름은 실제 테이블이 아니므로 검증 제외
            cte_names: set[str] = set()
            for cte in parsed.find_all(E.CTE):
                alias = cte.alias
                if alias:
                    cte_names.add(alias.lower())

            for tbl in parsed.find_all(E.Table):
                name = tbl.name
                if not name:
                    continue
                if name.lower() in cte_names:
                    continue
                candidates = self._table_candidates(tbl)
                if not any(candidate in self._known for candidate in candidates):
                    unknown_name = candidates[-1] if candidates else name
                    hint = self._suggest_table(unknown_name)
                    return False, [f"알 수 없는 테이블: {unknown_name}{hint}"]
        return True, []

    def _regex_check(self, sql: str) -> Tuple[bool, List[str]]:
        if self._dml_re.match(sql):
            return False, ["DML/DDL 감지"]
        u = sql.upper().strip()
        if not (u.startswith("SELECT") or u.startswith("WITH")):
            return False, ["SELECT/WITH만 허용"]
        if len(re.findall(r"\bEXCEPT\b", sql, re.I)) > 1:
            return False, ["EXCEPT 체인 감지 (A EXCEPT B EXCEPT C)"]
        return True, []

    @staticmethod
    def _has_except_chain(parsed) -> bool:
        """EXCEPT가 2번 이상 등장하는 체인/중첩 구문 차단"""
        if not _HAS_SQLGLOT:
            return False
        return sum(1 for _ in parsed.find_all(E.Except)) > 1

    def _enforce_limit(self, sql: str, dialect: str = "sqlite") -> str:
        """
        Row limit 강제 — dialect별 분기.
        SQLite: LIMIT N
        Oracle: FETCH FIRST N ROWS ONLY (12c+)
        """
        sql = sql.strip().rstrip(";")

        if _HAS_SQLGLOT:
            try:
                parsed = sqlglot.parse_one(sql, read=dialect)
                if self._ast_has_outer_limit(parsed):
                    return sql + ";"
                limited = parsed.limit(self._max_rows)
                return limited.sql(dialect=dialect) + ";"
            except Exception:
                pass  # AST 실패 시 regex fallback

        if dialect == "oracle":
            return self._regex_enforce_limit_oracle(sql) + ";"
        return self._regex_enforce_limit(sql) + ";"

    def _ast_has_outer_limit(self, parsed) -> bool:
        """
        AST에서 최외곽 쿼리의 LIMIT 존재 여부를 재귀적으로 확인.
        CTE 내부의 LIMIT은 무시하고 최종 쿼리만 검사합니다.
        """
        # Case 1: WITH ... (CTE)
        #   parsed.this = 최종 body (SELECT 또는 UNION)
        if isinstance(parsed, E.With):
            body = parsed.this
            if body is None:
                return False
            return self._ast_has_outer_limit(body)

        # Case 2: UNION / UNION ALL / INTERSECT / EXCEPT
        #   SetOperation 노드 자체에 limit이 있는지 확인
        if isinstance(parsed, (E.Union, E.Except, E.Intersect)):
            return parsed.args.get("limit") is not None

        # Case 3: Subquery wrapper
        if isinstance(parsed, E.Subquery):
            inner = parsed.this
            if inner:
                return self._ast_has_outer_limit(inner)
            return False

        # Case 4: 일반 SELECT
        if isinstance(parsed, E.Select):
            return parsed.args.get("limit") is not None

        # 알 수 없는 타입 – 안전을 위해 LIMIT 없음으로 처리
        return False

    def _regex_enforce_limit(self, sql: str) -> str:
        """
        Regex 기반 LIMIT 강제 (개선 버전)
        ─────────────────────────────────
        CTE 내부의 LIMIT과 최종 쿼리의 LIMIT을 구분합니다.
        괄호 깊이(depth)를 추적하여 최외곽 레벨에서만 LIMIT을 감지합니다.
        """
        # 괄호 깊이 기반으로 최외곽 SQL 영역 추출
        outer_sql = self._extract_outer_sql(sql)

        if re.search(r"\bLIMIT\s+\d+", outer_sql, re.I):
            return sql

        return f"{sql} LIMIT {self._max_rows}"

    def _regex_enforce_limit_oracle(self, sql: str) -> str:
        """Oracle용 regex 기반 row limit (FETCH FIRST N ROWS ONLY)."""
        outer_sql = self._extract_outer_sql(sql)
        if re.search(r"\bFETCH\s+(FIRST|NEXT)\s+\d+\s+ROWS?\s+(ONLY|WITH\s+TIES)", outer_sql, re.I):
            return sql
        if re.search(r"\bROWNUM\s*<=\s*\d+", outer_sql, re.I):
            return sql
        return f"{sql} FETCH FIRST {self._max_rows} ROWS ONLY"

    @staticmethod
    def _extract_outer_sql(sql: str) -> str:
        """
        괄호 깊이(depth)를 추적하여 depth=0인 부분만 추출.
        CTE의 AS (...) 내부는 depth≥1이므로 자연스럽게 제외됩니다.
        """
        depth = 0
        outer_parts: List[str] = []
        for ch in sql:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth = max(0, depth - 1)
            elif depth == 0:
                outer_parts.append(ch)
        return "".join(outer_parts)
