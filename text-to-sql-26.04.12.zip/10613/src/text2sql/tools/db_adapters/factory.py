"""
Adapter Factory — dialect 설정에 따라 적절한 DBAdapter 반환
==========================================================
"""
from __future__ import annotations

import logging
from typing import Optional

from .base import DBAdapter

logger = logging.getLogger(__name__)

# 싱글톤 캐시
_adapters: dict[str, DBAdapter] = {}


def get_adapter(
    db_id: str = "",
    *,
    dialect: str | None = None,
    db_path: str | None = None,
    force_new: bool = False,
) -> DBAdapter:
    """
    dialect과 db_id에 따라 적절한 DBAdapter를 생성·반환한다.

    Args:
        db_id: DB 식별자 (캐시 키)
        dialect: "sqlite" | "oracle" (None이면 settings에서 결정)
        db_path: SQLite 전용 — 파일 경로
        force_new: True이면 캐시 무시
    """
    from ...config.settings import get_settings

    settings = get_settings()
    resolved_dialect = dialect or settings.db.dialect

    cache_key = f"{resolved_dialect}:{db_id or db_path or 'default'}"
    if not force_new and cache_key in _adapters:
        return _adapters[cache_key]

    adapter: DBAdapter

    if resolved_dialect == "sqlite":
        from .sqlite_adapter import SQLiteAdapter
        if not db_path:
            from ..db_registry import resolve_db_path
            db_path = resolve_db_path(db_id)
        adapter = SQLiteAdapter(
            db_path,
            timeout_ms=settings.guard.timeout_ms,
        )

    elif resolved_dialect == "oracle":
        from .oracle_adapter import OracleAdapter
        db_cfg = settings.db
        adapter = OracleAdapter(
            host=db_cfg.host,
            port=db_cfg.port,
            service_name=db_cfg.service_name,
            dsn=db_cfg.dsn,
            user=db_cfg.user,
            password=db_cfg.password,
            schema=db_cfg.schema,
            connect_timeout_sec=db_cfg.connect_timeout_sec,
            query_timeout_ms=settings.guard.timeout_ms,
            read_only=db_cfg.read_only,
        )

    else:
        raise ValueError(f"지원하지 않는 dialect: {resolved_dialect}")

    _adapters[cache_key] = adapter
    logger.info(f"DB adapter 생성: dialect={resolved_dialect}, id={db_id or 'default'}")
    return adapter


def reset_adapters() -> None:
    """모든 캐시된 adapter를 정리한다."""
    for adapter in _adapters.values():
        try:
            adapter.close()
        except Exception:
            pass
    _adapters.clear()
