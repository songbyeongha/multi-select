"""
SQLite Adapter — 로컬 개발용
==============================
기존 executor.py + SchemaReader 로직을 adapter 인터페이스로 래핑.
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List

from .base import DBAdapter, ColumnInfo, ForeignKey, TableMeta


class SQLiteAdapter(DBAdapter):
    """SQLite 파일 기반 DB adapter."""

    def __init__(self, db_path: str, *, timeout_ms: int = 15000):
        self._db_path = str(db_path)
        self._default_timeout_ms = timeout_ms
        # 파일 존재 확인
        if not Path(self._db_path).exists():
            raise FileNotFoundError(f"SQLite DB not found: {self._db_path}")

    @property
    def dialect(self) -> str:
        return "sqlite"

    @property
    def db_path(self) -> str:
        return self._db_path

    # ── 연결 테스트 ──────────────────────────────────────
    def test_connection(self) -> Dict[str, Any]:
        try:
            conn = sqlite3.connect(self._db_path)
            tables = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
            ).fetchone()[0]
            conn.close()
            return {"ok": True, "user": "local", "schema": "main",
                    "message": f"SQLite 연결 성공 — 테이블 {tables}개",
                    "table_count": tables}
        except Exception as e:
            return {"ok": False, "message": str(e)}

    # ── 스키마 조회 ──────────────────────────────────────
    def list_tables(self) -> List[str]:
        conn = sqlite3.connect(self._db_path)
        try:
            rows = conn.execute(
                "SELECT name FROM sqlite_master "
                "WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
            return [r[0] for r in rows]
        finally:
            conn.close()

    def table_info(self, table: str) -> TableMeta:
        conn = sqlite3.connect(self._db_path)
        try:
            columns = []
            for r in conn.execute(f"PRAGMA table_info([{table}])"):
                columns.append(ColumnInfo(
                    name=r[1], type=r[2] or "TEXT",
                    nullable=not bool(r[3]), is_pk=bool(r[5]),
                ))

            fks = []
            for r in conn.execute(f"PRAGMA foreign_key_list([{table}])"):
                fks.append(ForeignKey(
                    from_column=r[3], to_table=r[2], to_column=r[4],
                ))

            samples = []
            try:
                cur = conn.execute(f"SELECT * FROM [{table}] LIMIT 3")
                names = [d[0] for d in cur.description]
                samples = [dict(zip(names, row)) for row in cur.fetchall()]
            except Exception:
                pass

            return TableMeta(
                table_name=table, columns=columns,
                foreign_keys=fks, sample_rows=samples,
            )
        finally:
            conn.close()

    # ── 쿼리 실행 ────────────────────────────────────────
    def execute(self, sql: str, *, limit: int = 50,
                timeout_ms: int | None = None) -> Dict[str, Any]:
        timeout = timeout_ms or self._default_timeout_ms
        conn = None
        t0 = time.time()
        try:
            conn = sqlite3.connect(self._db_path)
            conn.row_factory = sqlite3.Row

            timeout_sec = timeout / 1000.0

            def _timeout_check():
                if time.time() - t0 > timeout_sec:
                    return 1
                return 0
            conn.set_progress_handler(_timeout_check, 1000)

            cur = conn.execute(sql)
            rows = [dict(r) for r in cur.fetchmany(limit)]
            remaining = 0
            if len(rows) == limit:
                while True:
                    batch = cur.fetchmany(1000)
                    if not batch:
                        break
                    remaining += len(batch)
            total_rows = len(rows) + remaining
            ms = (time.time() - t0) * 1000
            return {"ok": True, "rows": rows, "row_count": total_rows,
                    "exec_ms": ms, "error_type": None, "error_message": None}
        except sqlite3.OperationalError as e:
            msg = str(e).lower()
            if "no such table" in msg or "no such column" in msg or "ambiguous" in msg:
                etype = "SCHEMA"
            elif "syntax" in msg:
                etype = "SYNTAX"
            elif "interrupt" in msg:
                etype = "TIMEOUT"
            else:
                etype = "RUNTIME"
            return {"ok": False, "rows": [], "row_count": 0,
                    "exec_ms": (time.time() - t0) * 1000,
                    "error_type": etype, "error_message": str(e)}
        except Exception as e:
            return {"ok": False, "rows": [], "row_count": 0,
                    "exec_ms": (time.time() - t0) * 1000,
                    "error_type": "UNKNOWN", "error_message": str(e)}
        finally:
            if conn:
                conn.close()

    def _sample_values_sql(self, table: str, column: str, limit: int) -> str:
        return (f"SELECT DISTINCT [{column}] FROM [{table}] "
                f"WHERE [{column}] IS NOT NULL LIMIT {limit}")

    def close(self) -> None:
        pass  # SQLite는 쿼리별 연결이므로 별도 정리 불필요
