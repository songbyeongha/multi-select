# Claude Vibe Coding 워크플로우

이 저장소는 Claude를 메인으로, Codex와 Cursor를 보조로 쓰는 파일 기반 바이브 코딩 워크플로우를 포함한다.

## 목적

- 구현 전에 반드시 분석과 계획을 남긴다.
- 채팅이 아니라 저장소 파일로 결과를 축적한다.
- Claude가 큰 그림과 리뷰를 담당하고, Codex/Cursor는 승인된 범위에서 구현하게 만든다.

## 추가된 폴더

```text
.ai/
  prompts/
  context/
  tasks/
  outputs/
  scripts/
```

## 가장 빠른 시작

### PowerShell 기준

```powershell
cd "c:\Users\SBH\Desktop\AI master\26.02.07\text-to-sql-assistant-v1.0.0\10613"

.ai\scripts\start-task.ps1 TASK-20260408-001 "운영 탭 정리"
.\.venv\Scripts\python.exe .ai\scripts\package-context.py --task-id TASK-20260408-001
.ai\scripts\check-deliverables.ps1 TASK-20260408-001
```

## 작업 순서

1. `start-task`로 작업 폴더 생성
2. `package-context.py`로 Claude에게 줄 컨텍스트 번들 생성
3. Claude로 `research.md` 작성
4. Claude로 `plan.md` 작성
5. 사람 피드백 반영
6. Claude 또는 Codex로 구현
7. `implementation_notes.md`, `test_report.md` 작성
8. Claude로 `review_report.md` 작성

## Claude에 넣는 파일

기본적으로 아래 파일을 같이 주면 된다.

- `.ai/outputs/context_bundle.md`
- `.ai/outputs/<TASK_ID>/task.md`
- `.ai/prompts/claude-system.md`
- 필요한 단계별 프롬프트 파일

## 단계별 설명서

자세한 사용법은 [docs/development/CLAUDE_VIBE_CODING_GUIDE.md](docs/development/CLAUDE_VIBE_CODING_GUIDE.md)를 본다.
