# 작업 기록: 스키마 셀렉터 처리 속도 개선

## [요청]

[목표] 스키마셀렉터 처리 속도 개선
[현재 문제] 스키마 셀렉터에서 동작하는데 2분 이상 걸리는 현상 / 빠르고 정확한 스키마 셀렉터 필요
[수정 대상 파일] 스키마 셀렉터를 실행하는 모든 파일
[제약 조건] 스키마 셀렉터의 기본 로직은 변경되면 안됨 / SQL 생성 성능이 떨어지면 안됨

---

## [분석]

### 병목 원인 (우선순위 순)

| # | 원인 | 영향 |
|---|------|------|
| 1 | **JSON 파일 매 쿼리마다 반복 읽기** | `settings.schema_metadata()` + `settings.domain_hints()` = 4개 JSON 파일 디스크 읽기 + 딥 파싱, 캐싱 없음 |
| 2 | **BM25 3중 계산** | `_doc_text()` + `_tok()` 를 N 테이블에 대해 3번 반복: `_df()` N번 + `_avg_dl()` N번 + 메인 루프 N번 = 3N |
| 3 | **BM25 · 벡터 검색 순차 실행** | 임베딩 API 호출(I/O bound) + ChromaDB IPC가 BM25(CPU) 완료 후 직렬 대기 |
| 4 | **`count()` IPC 반복** | `search()` 호출마다 ChromaDB subprocess에 count 조회 왕복 추가 |
| 5 | **keyword_map 소문자 변환 반복** | `_kw_bonus()` 내에서 `[x.lower() for x in kw_map[tok]]` 매 토큰마다 재생성 |

### 영향 범위

- `src/text2sql/agents/schema_nodes.py` — 메인 노드 함수
- `src/text2sql/rag/schema_rag.py` — SchemaSelector.select()
- `src/text2sql/rag/vector_store.py` — SchemaVectorStore.search(), is_indexed()

---

## [수정 내용]

### schema_nodes.py — `_schema_ctx` 캐시 추가

- 모듈 수준 `_schema_ctx: Dict[str, Dict]` + `_SCHEMA_CTX_TTL = 300` 추가
- `node_schema_selector()` 에서 `db_id` 기준으로 `full_schema + meta + hints + selector` 인스턴스를 캐싱
- 캐시 히트 시 JSON 파일 읽기/파싱/SchemaSelector 재생성 전체 스킵
- TTL(5분) 만료 시 자동 갱신 → domain_hints/schema_metadata 변경 반영

**절감 효과**: 쿼리당 4개 JSON 파일 디스크 읽기 + `SchemaReader.from_meta()` 파싱 제거

### schema_rag.py — BM25 사전 계산 + 벡터 병렬화

1. **`SchemaSelector.__init__`**: `_kw_map_lower` 사전 소문자 변환 저장
2. **`SchemaSelector.select()`**:
   - `_df()` (N번) + `_avg_dl()` (N번) + 메인 루프 (N번) = 3N 호출 → **1번 순회로 통합**
   - 벡터 검색(`_get_vector_scores`)을 `threading.Thread`로 백그라운드 실행
   - BM25 계산(CPU bound)과 임베딩+IPC(I/O bound) **동시 실행**
   - `vec_thread.join(timeout=30)` 으로 결과 수집 (타임아웃 시 BM25만 사용)
3. **`_kw_bonus()`**: `_kw_map_lower` 사용으로 루프 내 list 생성 제거

**절감 효과**: BM25 계산량 2/3 감소 + 벡터 검색 대기 시간 숨김

### vector_store.py — `_indexed_count` 캐시

- `SchemaVectorStore.__init__`: `_indexed_count: int = -1` 추가
- `build_index()`: 완료 후 `_indexed_count = len(schema)` 설정
- `is_indexed()`: `_indexed_count > 0`이면 IPC 없이 즉시 반환
- `search()`: `count()` IPC 제거 → `_indexed_count` 로 `n_results` 결정, 오류 시 빈 리스트 반환

**절감 효과**: `search()` 호출마다 발생하던 ChromaDB subprocess 왕복 1회 제거

---

## [변경 코드]

### schema_nodes.py

```diff
+ _schema_ctx: Dict[str, Dict[str, Any]] = {}
+ _SCHEMA_CTX_TTL = 300

  def node_schema_selector(state):
      ...
-     meta = settings.schema_metadata(db_id)
-     hints = settings.domain_hints(db_id)
-     full_schema = SchemaReader.from_meta(meta)
-     selector = SchemaSelector(keyword_map=..., relation_bonus=...)
+     ctx = _schema_ctx.get(db_id)
+     if ctx and _time.time() < ctx["expires_at"]:
+         full_schema, meta, hints, selector = ctx[...]
+     else:
+         # 기존 로드 + selector 생성 로직
+         _schema_ctx[db_id] = {full_schema, meta, hints, selector, expires_at}
```

### schema_rag.py

```diff
  def select(self, question, schema, top_k, db_id):
-     doc_freq = self._df(schema)   # N 호출
-     avg_dl = self._avg_dl(schema) # N 호출
-     for tbl in schema:
-         dtoks = self._tok(self._doc_text(tbl))  # N 호출 (합계 3N)
-         bm = self._bm25(...)

+     # 토큰 1회 계산
+     dtoks_list = [(tname, self._tok(self._doc_text(tbl))) for tbl in schema]
+     df = {tok: count for ...}
+     avg_dl = sum(...) / n
+
+     # 벡터 검색 병렬 시작
+     vec_thread = Thread(target=_run_vec); vec_thread.start()
+
+     # BM25 계산 (사전 계산된 토큰 사용)
+     for tname, dtoks in dtoks_list:
+         bm = self._bm25(qtoks, dtoks, df, avg_dl, n)
+
+     # 벡터 결과 수집
+     vec_thread.join(timeout=30)
```

### vector_store.py

```diff
  def search(self, question, top_k=5):
-     total = self._worker.count(...)  # IPC 왕복
-     if total == 0: return []
-     results = self._worker.query(..., n_results=min(top_k, total), ...)
+     n_results = min(top_k, self._indexed_count) if self._indexed_count > 0 else top_k
+     results = self._worker.query(..., n_results=n_results, ...)

  def is_indexed(self):
-     return self._worker.count(...) > 0
+     if self._indexed_count > 0: return True
+     count = self._worker.count(...)
+     self._indexed_count = count
+     return count > 0
```

---

## [기대 효과 요약]

| 항목 | 기존 | 개선 |
|------|------|------|
| JSON 파일 읽기 | 매 쿼리 4회 | TTL 내 0회 |
| BM25 `_tok/_doc_text` 호출 | 3N번 | N번 |
| 벡터 검색 대기 | BM25 완료 후 직렬 | BM25와 병렬 |
| `count()` IPC | `search()` 마다 1회 | 최초 1회 후 0회 |
| keyword_map 소문자 변환 | 매 토큰마다 | `__init__` 1회 |

로직 변경 없음: 선택 알고리즘(BM25 + 벡터 하이브리드), 스코어 공식, LLM 호출, FK 브리지 보완 등 기본 동작 유지.
