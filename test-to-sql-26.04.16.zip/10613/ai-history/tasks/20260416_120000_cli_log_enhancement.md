# 작업 기록: CLI 로그 보강

## [요청]

[목표] cli로 sql 생성시 보여지는 로그 보강
[현재 문제]
- SchemaSelector: 선택된 테이블에서 몇 개의 테이블이 선택된 건지 어떤 테이블이 선택된 건지 모두 알고 싶은데 안보임
- 어떤 LLM을 사용하고 언제 LLM을 사용하고 있는지 모름
[수정 대상 파일] cli 로그가 나오는 파일들
[제약 조건] 메인 로직 수정은 안해야함

---

## [분석]

### 문제 원인

`extra` dict에 필요한 데이터가 이미 존재하지만 `PipelineDisplay.print_step()`이 표시하지 않음.

| 노드 | extra 내 사용 가능한 필드 |
|------|--------------------------|
| SchemaSelector | `selector_prompt_tables` (BM25 후보 목록), `model` (LLM 모델명) |
| JoinPlanner | `model` |
| CandidateGenerator | `model` |
| Repair | `model` |
| ResultSummarizer | `model` |

추가 문제: `detail` 문자열이 80자에서 잘려 테이블 목록이 일부만 표시됨.
- `SchemaSelector`의 `detail` = `"선택된 테이블: ['TABLE1', 'TABLE2', ...]"` → 80자 초과 시 잘림

### 영향 범위

- `src/text2sql/tools/cli_display.py` — `PipelineDisplay.print_step()` 메서드만 수정

---

## [수정 내용]

### cli_display.py — `print_step()` 출력 보강

1. **SchemaSelector 테이블 전체 표시**: `detail` 잘림 제거 (80자 → 전체 표시)
2. **BM25 후보 수 표시**: `extra["selector_prompt_tables"]` 활용 → `"BM25 후보 N개 → LLM 최종 확정"` 서브라인 추가
3. **LLM 모델 표시**: `extra.get("model")` 값이 있고 `"—"`가 아니면 → `"LLM: {모델명}"` 표시
4. **LLM + 경과 시간 통합**: 기존 `(Nms)` 단독 라인 → `"LLM: {모델} · Nms"` 한 줄로 합산

---

## [변경 코드]

### cli_display.py

```diff
  def print_step(self, node, detail, extra=None):
      ...
-     # 상세 정보 축약
-     short_detail = detail[:80] + "..." if len(detail) > 80 else detail
+     # 상세 정보 축약 (SchemaSelector는 테이블 목록을 전부 표시)
+     if node == "SchemaSelector":
+         short_detail = detail
+     else:
+         short_detail = detail[:80] + "..." if len(detail) > 80 else detail

      ...

      if extra:
          ...
+         # SchemaSelector: BM25 후보 수 표시
+         if node == "SchemaSelector" and "selector_prompt_tables" in extra:
+             n_cand = len(extra["selector_prompt_tables"])
+             console.print(f"           [dim]BM25 후보 {n_cand}개 → LLM 최종 확정[/dim]")
+         # LLM 모델 + 경과 시간 (한 줄로 표시)
+         model = extra.get("model", "")
+         elapsed_ms = extra.get("elapsed_ms")
+         footer_parts = []
+         if model and model != "—":
+             footer_parts.append(f"LLM: {model}")
+         if elapsed_ms is not None:
+             footer_parts.append(f"{elapsed_ms}ms")
+         if footer_parts:
+             console.print(f"           [dim]{' · '.join(footer_parts)}[/dim]")
-         if "elapsed_ms" in extra:
-             console.print(f"           [dim]({extra['elapsed_ms']}ms)[/dim]")
```

---

## [출력 예시]

### 변경 전
```
   1.2s [2] SchemaSelector: 선택된 테이블: ['INVENTORY', 'PRODUCT', 'F...
           (856ms)

   5.3s [5] CandidateGenerator: 후보 3개 생성 완료
           (3420ms)
```

### 변경 후
```
   1.2s [2] SchemaSelector: 선택된 테이블: ['INVENTORY', 'PRODUCT', 'FACTORY']
           BM25 후보 15개 → LLM 최종 확정
           LLM: gpt-4o-mini · 856ms

   5.3s [5] CandidateGenerator: 후보 3개 생성 완료
           LLM: gpt-4o · 3420ms
```
