# 작업 기록: 엔드포인트 정상화 · 소스 정리 · 문서 현행화

## [요청]

[목표] end point에서 정상 동작, 사용하지 않는 소스 정리, 문서 현행화
[현재 문제] 모든 end point에서 정상 동작 / 사용하지 않는 소스 코드 및 주석 정리 필요 / 문서 현행화 필요
[수정 대상 파일] 모든 파일
[제약 조건] 문서 현행화 시 대상은 처음 프로젝트를 사용하는 사람이 대상 / ai-history 아래의 문서는 수정 불가 / CLAUDE.md 수정 시 하네스 엔지니어링 관련 내용은 수정 불가 / .env 설정 수정 불가

---

## [분석]

### 엔드포인트 이상

| 파일 | 문제 | 영향 |
|------|------|------|
| `scripts/run_cli.py` | `--no-feedback` 옵션이 `docs/operations/ENDPOINT_USAGE_GUIDE.md`에 문서화되어 있으나 argparse에 없음 | `--no-feedback` 전달 시 argparse 오류 |

### 미사용 소스 코드

| 파일 | 항목 | 사유 |
|------|------|------|
| `src/text2sql/rag/schema_rag.py` | `SchemaSelector._df()`, `SchemaSelector._avg_dl()` 메서드 | Task 13 최적화 시 `select()`에 인라인 통합 후 호출부 없음 |
| `src/text2sql/agents/generation_nodes.py` | `from ..lg.state import ErrorType` | 파일 내 사용 없음 |
| `src/text2sql/tools/executor.py` | `from typing import Optional` | 파일 내 사용 없음 |

### 문서 오류

| 파일 | 문제 |
|------|------|
| `docs/CODEBASE_GUIDE.md` | `scripts/` 목록이 5개만 나열 (실제 11개) |
| `docs/CODEBASE_GUIDE.md` | 환경변수 `T2SQL_MAX_ROWS` (존재 안 함), `T2SQL_TIMEOUT_MS` (실제: `T2SQL_DB_QUERY_TIMEOUT_MS`) |

---

## [수정 내용]

### scripts/run_cli.py — `--no-feedback` 옵션 추가

- `parse_args()`에 `--no-feedback` argparse 인수 추가
- `run_single_query()` 시그니처에 `no_feedback: bool = False` 파라미터 추가
- `_collect_cli_feedback()` 호출을 `if not no_feedback:` 조건으로 감쌈
- `main()`에서 `args.no_feedback`을 `run_single_query()`에 전달

### src/text2sql/rag/schema_rag.py — 미사용 메서드 제거

- `SchemaSelector._df()` 삭제 (10줄)
- `SchemaSelector._avg_dl()` 삭제 (4줄)
- 두 메서드의 로직은 Task 13에서 `select()` 내 1-pass 순회로 이미 통합됨

### src/text2sql/agents/generation_nodes.py — 미사용 import 제거

- `from ..lg.state import ErrorType` → `from ..lg.state import GraphState, SQLCandidate`

### src/text2sql/tools/executor.py — 미사용 import 제거

- `from typing import Dict, List, Any, Optional` → `from typing import Dict, List, Any`

### docs/CODEBASE_GUIDE.md — 문서 현행화

1. `scripts/` 목록: 5개 → 11개 전체 나열 (run_ops.py, check_domain_hints.py, oracle_release_gate.py, setup_oracle_mfg_demo.py, oracle_ops.py, validate_query_catalog.py 추가)
2. 환경변수 수정:
   - `T2SQL_MAX_ROWS` 제거 (`max_rows`는 코드 내 50_000 고정값, env var 없음)
   - `T2SQL_TIMEOUT_MS` → `T2SQL_DB_QUERY_TIMEOUT_MS` (실제 변수명으로 수정)

---

## [변경 코드]

### run_cli.py

```diff
- def run_single_query(db_id, question, db_path, max_retries, *, hitl=False):
+ def run_single_query(db_id, question, db_path, max_retries, *, hitl=False, no_feedback=False):
      ...
-     _collect_cli_feedback(question, sql, db_id, final_state)
+     if not no_feedback:
+         _collect_cli_feedback(question, sql, db_id, final_state)

  def parse_args():
      ...
      parser.add_argument("--hitl", ...)
+     parser.add_argument("--no-feedback", action="store_true", help="피드백 입력 건너뜀")

  def main():
-     run_single_query(args.db, args.question, db_path, args.max_retries, hitl=args.hitl)
+     run_single_query(args.db, args.question, db_path, args.max_retries, hitl=args.hitl, no_feedback=args.no_feedback)
```

### schema_rag.py

```diff
- def _df(self, schema):
-     df = Counter()
-     for t in schema:
-         df.update(set(self._tok(self._doc_text(t))))
-     return dict(df)
-
- def _avg_dl(self, schema):
-     if not schema:
-         return 1.0
-     return sum(len(self._tok(self._doc_text(t))) for t in schema) / len(schema)
```

### generation_nodes.py

```diff
- from ..lg.state import GraphState, SQLCandidate, ErrorType
+ from ..lg.state import GraphState, SQLCandidate
```

### executor.py

```diff
- from typing import Dict, List, Any, Optional
+ from typing import Dict, List, Any
```
