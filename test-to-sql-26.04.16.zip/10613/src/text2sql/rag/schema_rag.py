"""
Schema RAG  ──  BM25 + 도메인 키워드 보너스 + 벡터 유사도 기반 테이블·컬럼 선택
v1.0 – Chroma 벡터 검색 하이브리드 (항상 BM25 + 벡터)
"""
from __future__ import annotations
import re, math, logging, threading
from collections import Counter
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class TableScore:
    table_name: str
    score: float
    matched_keywords: List[str] = field(default_factory=list)


class SchemaSelector:
    """
    하이브리드 스키마 선택기:
    - BM25 (키워드 기반) + 도메인 보너스  → 항상 활성
    - 벡터 유사도 (Embedding + Chroma)  → 항상 활성

    최종 스코어 = α × BM25_norm + (1-α) × Vector_norm   (α = vector_weight)
    """

    def __init__(self, keyword_map: Dict[str, List[str]] | None = None,
                 relation_bonus: Dict[str, List[str]] | None = None,
                 vector_weight: float = 0.3):
        self.kw_map = keyword_map or {}
        self.rel_bonus = relation_bonus or {}
        self._vector_weight = vector_weight  # 벡터 스코어 비중 (0.0~1.0)
        # keyword_map 값을 소문자로 사전 변환 — _kw_bonus 내 반복 변환 제거
        self._kw_map_lower: Dict[str, List[str]] = {
            k: [x.lower() for x in v] for k, v in self.kw_map.items()
        }

    def select(self, question: str,
               schema: List[Dict[str, Any]],
               top_k: int = 5,
               db_id: str | None = None) -> List[TableScore]:
        """
        테이블 선택 (하이브리드 검색)

        Args:
            question: 사용자 질문
            schema: 전체 스키마 리스트
            top_k: 반환할 최대 테이블 수
            db_id: 벡터 스토어 조회용 DB ID (None이면 벡터 검색 스킵)
        """
        qtoks = self._tok(question)
        n = len(schema)

        # ── 1. 문서 토큰 사전 계산 (기존 3N → 1N 호출) ─────
        # _df() · _avg_dl() · 메인 루프가 각각 _tok(_doc_text(t))를 N번 호출하던 것을
        # 한 번의 순회로 통합한다.
        dtoks_list: List[Tuple[str, List[str]]] = [
            (tbl["table_name"], self._tok(self._doc_text(tbl))) for tbl in schema
        ]
        df: Dict[str, int] = {}
        for _, dtoks in dtoks_list:
            for tok in set(dtoks):
                df[tok] = df.get(tok, 0) + 1
        avg_dl = sum(len(dtoks) for _, dtoks in dtoks_list) / max(n, 1)

        # ── 2. 벡터 검색을 백그라운드 스레드에서 실행 ───────
        # 임베딩 API 호출 + ChromaDB IPC(I/O bound)를 BM25 계산(CPU)과 병렬화한다.
        vector_scores: Dict[str, float] = {}
        vec_thread: threading.Thread | None = None
        if db_id and self._vector_weight > 0:
            def _run_vec() -> None:
                nonlocal vector_scores
                vector_scores = self._get_vector_scores(question, db_id, top_k)
            vec_thread = threading.Thread(target=_run_vec, daemon=True)
            vec_thread.start()

        # ── 3. BM25 스코어 (사전 계산된 토큰 사용) ─────────
        bm25_scores: Dict[str, float] = {}
        kw_matched: Dict[str, List[str]] = {}
        for tname, dtoks in dtoks_list:
            bm = self._bm25(qtoks, dtoks, df, avg_dl, n)
            bonus, matched = self._kw_bonus(qtoks, tname)
            bm25_scores[tname] = bm + bonus
            kw_matched[tname] = matched

        # ── 4. 벡터 검색 결과 수집 ──────────────────────────
        if vec_thread is not None:
            vec_thread.join(timeout=30)

        # ── 5. 하이브리드 스코어 합산 ──────────────────────
        scored = self._merge_scores(schema, bm25_scores, vector_scores, kw_matched)

        # ── 6. 관계 부스트 + 정렬 ─────────────────────────
        scored = self._rel_boost(scored)
        scored.sort(key=lambda x: x.score, reverse=True)

        # keyword_map 매칭 결과 디버그 로그
        if logger.isEnabledFor(logging.DEBUG):
            kw_hits = {t: m for t, m in kw_matched.items() if m}
            if kw_hits:
                summary = ", ".join(
                    f"{t}←[{','.join(m)}]" for t, m in kw_hits.items()
                )
                logger.debug("keyword_map 매칭: %s", summary)

        result = [s for s in scored[:top_k] if s.score > 0]
        return result or scored[:3]

    # ── 벡터 검색 ─────────────────────────────────────────
    def _get_vector_scores(self, question: str, db_id: str,
                           top_k: int) -> Dict[str, float]:
        """Chroma 벡터 스토어에서 유사도 검색"""
        try:
            from .vector_store import get_vector_store
            store = get_vector_store(db_id)
            hits = store.search(question, top_k=top_k)
            return {h["table_name"]: max(0, h["score"]) for h in hits}
        except Exception as e:
            logger.debug(f"벡터 검색 실패: {e}")
            return {}

    def _merge_scores(self, schema: List[Dict[str, Any]],
                      bm25: Dict[str, float],
                      vector: Dict[str, float],
                      kw_matched: Dict[str, List[str]]) -> List[TableScore]:
        """BM25 + 벡터 스코어 정규화 합산"""
        bm25_norm = self._normalize(bm25)

        if vector:
            vec_norm = self._normalize(vector)
            alpha = 1.0 - self._vector_weight
        else:
            vec_norm = {}
            alpha = 1.0

        scored = []
        for tbl in schema:
            tname = tbl["table_name"]
            bm_score = bm25_norm.get(tname, 0.0) * alpha
            vec_score = vec_norm.get(tname, 0.0) * (1.0 - alpha) if vector else 0.0
            scored.append(TableScore(
                tname,
                bm_score + vec_score,
                kw_matched.get(tname, []),
            ))
        return scored

    @staticmethod
    def _normalize(scores: Dict[str, float]) -> Dict[str, float]:
        """Min-max 정규화 (0~1)"""
        if not scores:
            return {}
        vmin = min(scores.values())
        vmax = max(scores.values())
        rng = vmax - vmin
        if rng == 0:
            return {k: 1.0 for k in scores}
        return {k: (v - vmin) / rng for k, v in scores.items()}

    # ── 내부 ────────────────────────────────────────────
    @staticmethod
    def _tok(text: str) -> List[str]:
        parts = re.findall(r"[A-Za-z0-9가-힣]+", text.lower())
        out: List[str] = []
        for p in parts:
            subs = re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?=[A-Z]|$)|\d+", p)
            out.extend(s.lower() for s in subs) if subs else out.append(p)
        return out

    @staticmethod
    def _doc_text(tbl: Dict[str, Any]) -> str:
        parts = [
            tbl.get("table_name", ""),
            tbl.get("short_name", ""),
            tbl.get("database_name", ""),
            tbl.get("schema_name", ""),
            tbl.get("table_description", ""),
            tbl.get("ddl_excerpt", ""),
            tbl.get("sample_text", ""),
            " ".join(tbl.get("table_aliases", []) or []),
        ]
        for c in tbl.get("columns", []):
            if isinstance(c, dict):
                parts.append(c.get("name", ""))
                parts.append(c.get("type", ""))
                parts.append(c.get("description", ""))
                parts.append(" ".join(c.get("sample_values", []) or []))
            else:
                parts.append(str(c))
        return " ".join(parts)

    @staticmethod
    def _bm25(qtoks, dtoks, df, avg_dl, n, k1=1.5, b=0.75):
        score = 0.0
        tf_map = Counter(dtoks)
        dl = len(dtoks)
        for t in qtoks:
            if t not in tf_map:
                continue
            tf = tf_map[t]
            idf = math.log((n - df.get(t, 0) + 0.5) / (df.get(t, 0) + 0.5) + 1)
            score += idf * (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl / avg_dl))
        return score

    def _kw_bonus(self, qtoks, table_name) -> Tuple[float, List[str]]:
        bonus = 0.0
        matched: List[str] = []
        tl = table_name.lower()
        for tok in qtoks:
            # __init__에서 사전 소문자 변환된 _kw_map_lower 사용
            if tok in self._kw_map_lower and tl in self._kw_map_lower[tok]:
                bonus += 2.0
                matched.append(tok)
        return bonus, matched

    def _rel_boost(self, scored: List[TableScore]) -> List[TableScore]:
        names = {s.table_name.lower(): s for s in scored}
        for s in scored:
            for rel in self.rel_bonus.get(s.table_name.lower(), []):
                if rel.lower() in names and names[rel.lower()].score > 0:
                    s.score += 0.5
        return scored


class JoinPlanner:
    def __init__(self, schema: List[Dict[str, Any]]):
        self.g: Dict[str, List[Tuple[str, str, str]]] = {}
        for tbl in schema:
            tn = tbl["table_name"]
            self.g.setdefault(tn, [])
            for fk in tbl.get("foreign_keys", []):
                to = fk["to_table"]
                self.g[tn].append((to, fk["from"], fk["to_column"]))
                self.g.setdefault(to, [])
                self.g[to].append((tn, fk["to_column"], fk["from"]))

    def plan(self, tables: List[str]) -> List[str]:
        if len(tables) < 2:
            return []
        joins, visited = [], {tables[0]}
        queue = [tables[0]]
        while queue and len(visited) < len(tables):
            cur = queue.pop(0)
            for rel, fc, tc in self.g.get(cur, []):
                if rel in tables and rel not in visited:
                    joins.append(f"{cur}.{fc} = {rel}.{tc}")
                    visited.add(rel)
                    queue.append(rel)
        return joins
