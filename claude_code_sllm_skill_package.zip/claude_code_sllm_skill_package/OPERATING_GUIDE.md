# Claude Code 자동화 운영 가이드

실제 운영 환경에서 Claude Code의 `/loop`, `/batch`, `/schedule`을 활용하는 방법을 소개합니다.

---

## 📋 목차

1. [빠른 시작](#빠른-시작)
2. [세 가지 자동화 기능](#세-가지-자동화-기능)
3. [실제 운영 시나리오](#실제-운영-시나리오)
4. [Skill 활용](#skill-활용)
5. [로그 분석](#로그-분석)
6. [문제 해결](#문제-해결)
7. [모범 사례](#모범-사례)

---

## 빠른 시작

### 1단계: 설정 확인

```powershell
# .claude/settings.local.json 확인
cat .\.claude\settings.local.json
```

### 2단계: 기본 명령 실행

```bash
# /loop 테스트 (10초마다 상태 체크)
/loop 10s /status-checker --all

# /batch 테스트 (3개 작업 순차 실행)
/batch /log-analyzer logs/batch-2026-05-19.log --stats && 
       /status-checker --memory &&
       echo "Batch completed"

# /schedule 테스트 (현재 시간 + 1분에 실행)
/schedule 0 * * * * /status-checker --disk
```

### 3단계: 로그 확인

```powershell
# 최신 로그 확인
Get-Content .\logs\automation-summary.log -Tail 20
```

---

## 세 가지 자동화 기능

### /loop - 반복 실행

**용도**: 주기적인 모니터링 및 점검

```bash
/loop <간격> <명령>
```

#### 옵션
- `10s` - 10초마다
- `5m` - 5분마다  
- `1h` - 1시간마다

#### 실제 예제

```bash
# 5분마다 시스템 상태 확인
/loop 5m /status-checker --memory --disk

# 30초마다 특정 로그 파일 모니터링
/loop 30s /log-analyzer logs/automation-summary.log --errors

# 1시간마다 디스크 정리 상태 확인
/loop 1h /status-checker --disk
```

#### 특징
- 🔄 무한 반복 (사용자가 중단할 때까지)
- 📊 각 반복의 결과가 자동 기록됨
- ⏱️ 간격은 유연하게 조정 가능
- 💾 최소 메모리 사용 (sLLM 친화적)

---

### /batch - 배치 처리

**용도**: 여러 작업을 한 번에 처리

```bash
/batch <작업1> && <작업2> && <작업3>
```

#### 실제 예제

```bash
# 일일 운영 작업
/batch /log-analyzer logs/batch-2026-05-19.log --stats && 
       /status-checker --all &&
       echo "Daily check completed"

# 장기간 누적된 로그 분석 및 정리
/batch /log-analyzer logs/automation-summary.log --errors &&
       /log-analyzer logs/scheduled-jobs.log --warnings &&
       echo "Log analysis complete"
```

#### 병렬 실행

```bash
# 병렬 실행 (다중 작업)
/batch <명령1> & /batch <명령2> & wait
```

#### 특징
- ⚡ 여러 작업을 순차 또는 병렬 실행
- 📝 하나의 로그에 모든 결과 기록
- ⏱️ 전체 실행 시간 추적
- ❌ 한 작업 실패 시 계속 진행 가능

---

### /schedule - 정각 실행

**용도**: 특정 시간에 자동 실행

```bash
/schedule <분> <시> <일> <월> <요일> <명령>
# 또는: /schedule <cron-표현식> <명령>
```

#### 실제 예제

```bash
# 매일 6시에 아침 상태 확인
/schedule 0 6 * * * /status-checker --all

# 매일 12시에 중간 백업
/schedule 0 12 * * * /batch /log-analyzer && echo "Noon check done"

# 평일(월~금) 오전 9시에 주간 리포트
/schedule 0 9 * * 1-5 /log-analyzer logs/batch-*.log --stats

# 매월 1일 자정에 월간 정리
/schedule 0 0 1 * * /status-checker --disk && /log-analyzer --stats
```

#### Cron 시간 표현식 빠른 참조

| 표현 | 의미 |
|------|------|
| `0 6 * * *` | 매일 오전 6시 |
| `30 14 * * *` | 매일 오후 2시 30분 |
| `0 0 * * 0` | 매주 일요일 자정 |
| `0 12 1 * *` | 매월 1일 정오 |
| `0 * * * *` | 매시간 |
| `*/15 * * * *` | 15분마다 |

#### 특징
- 🕐 정확한 시간에 자동 실행
- 📅 Cron 포맷 지원
- 🔔 실행 여부 자동 기록
- 🚫 놓친 작업도 자동 보충

---

## 실제 운영 시나리오

### 시나리오 1: 24시간 모니터링 (권장)

**목표**: 시스템을 항상 감시하고 문제 발생 시 즉시 감지

```bash
# 방법 1: /loop 사용
/loop 10m /status-checker --all

# 또는 더 가볍게
/loop 30m /status-checker --memory
```

**예상 결과**:
- 5분마다 메모리 체크 (가벼움)
- 시스템 변화 추적
- 평균 응답시간: < 2초

**로그 위치**: `logs/automation-summary.log`

---

### 시나리오 2: 일일 자동화 작업 (추천)

**목표**: 매일 정해진 시간에 중요한 작업 자동 실행

```bash
# 설정 1: 아침 6시 시작 점검
/schedule 0 6 * * * /batch /status-checker --all && \
                         /log-analyzer logs/batch-*.log --stats

# 설정 2: 정오 정크 파일 정리
/schedule 0 12 * * * /batch /status-checker --disk && \
                          echo "Disk check: OK"

# 설정 3: 저녁 6시 일일 요약 리포트
/schedule 0 18 * * * /batch /log-analyzer logs/automation-summary.log --stats

# 설정 4: 자정 야간 정리
/schedule 0 0 * * * /batch /status-checker --all
```

**예상 결과**:
```
6:00  - ✓ Morning status check
12:00 - ✓ Disk maintenance
18:00 - ✓ Daily report generated
0:00  - ✓ Nightly cleanup
```

---

### 시나리오 3: 주간 분석 및 리포트

**목표**: 주 1회 깊이 있는 분석 수행

```bash
# 매주 월요일 오전 9시에 주간 분석
/schedule 0 9 * * 1 /batch \
  /log-analyzer logs/batch-*.log --stats && \
  /log-analyzer logs/scheduled-jobs.log --errors && \
  /status-checker --all --json && \
  echo "Weekly analysis complete"
```

**분석 항목**:
- 배치 작업 통계
- 에러 분석
- 시스템 상태 스냅샷
- JSON 형식 저장 (추후 분석용)

---

## Skill 활용

### log-analyzer 활용법

```bash
# 에러만 필터링
/log-analyzer logs/batch-2026-05-19.log --errors

# 통계 출력
/log-analyzer logs/automation-summary.log --stats

# 마지막 50줄만 분석
/log-analyzer logs/scheduled-jobs.log --tail 50

# 경고 목록
/log-analyzer logs/batch-2026-05-19.log --warnings
```

**실제 운영 활용**:
```bash
# /loop와 함께: 매 시간 에러 체크
/loop 1h /log-analyzer logs/automation-summary.log --errors

# /batch와 함께: 일일 종합 분석
/batch /log-analyzer logs/batch-*.log --stats && \
       /log-analyzer logs/scheduled-jobs.log --warnings

# /schedule과 함께: 매일 저녁 종합 리포트
/schedule 0 18 * * * /log-analyzer logs/automation-summary.log --stats
```

---

### status-checker 활용법

```bash
# 전체 상태 확인
/status-checker --all

# 디스크만 확인
/status-checker --disk

# 메모리만 확인
/status-checker --memory

# 프로세스 확인
/status-checker --process

# JSON 형식 출력 (프로그래밍 분석용)
/status-checker --all --json
```

**실제 운영 활용**:
```bash
# /loop와 함께: 매 10분마다 경량 체크
/loop 10m /status-checker --memory --disk

# /batch와 함께: 일일 상세 점검
/batch /status-checker --all && \
       /status-checker --all --json > status-$(date +%Y%m%d).json

# /schedule과 함께: 정시 점검
/schedule 0 */2 * * * /status-checker --disk
```

---

## 로그 분석

### 로그 파일 구조

```
logs/
├── batch-2026-05-19.log       # /batch 작업 로그
├── scheduled-jobs.log          # /schedule 작업 로그  
├── automation-summary.log      # 통합 요약 로그
└── loop-status.log            # /loop 반복 기록
```

### 로그 확인 명령

```powershell
# 최신 로그 확인
Get-Content .\logs\automation-summary.log -Tail 30

# 에러만 필터링
Select-String -Path ".\logs\*" -Pattern "ERROR|FAIL"

# 특정 날짜 로그
Get-ChildItem ".\logs\batch-2026-05-19.log" | Get-Content

# 실시간 로그 모니터링
Get-Content .\logs\automation-summary.log -Wait -Tail 1
```

### 로그 해석 가이드

```
[2026-05-19 09:00:00] = 타임스탐프
[INFO]  = 정보 메시지
[OK]    = 성공
[WARN]  = 경고 (주의 필요)
[ERROR] = 에러 (조치 필요)
```

---

## 문제 해결

### 문제 1: 작업이 실행되지 않음

**원인 확인**:
```powershell
# 설정 파일 확인
Get-Content .\.claude\settings.local.json

# 권한 확인
# Read, Write 권한이 있는지 확인
```

**해결**:
```json
{
  "permissions": {
    "allow": [
      "Bash(powershell *)",
      "Read(logs/*)",
      "Write(logs/*)"
    ]
  }
}
```

---

### 문제 2: 로그 파일이 너무 커짐

**해결 방법**:
```bash
# 일정 기간 이상 된 로그 정리
/batch "Remove-Item logs/batch-*.log -OlderThan 30days" && \
       echo "Old logs cleaned"

# 또는 /schedule로 자동화
/schedule 0 0 * * 0 "Remove-Item logs/batch-*.log -OlderThan 30days"
```

---

### 문제 3: 스케줄 작업이 놓침

**확인**:
```powershell
# 실행 기록 확인
Get-Content .\logs\scheduled-jobs.log | Select-String "FAIL" | Tail 10
```

**해결**:
```bash
# 놓친 작업 수동 실행
/batch /status-checker --all && \
       /log-analyzer logs/automation-summary.log --stats
```

---

## 모범 사례

### ✅ 추천하는 조합

```bash
# 경량 모니터링 + 정기 분석
/loop 10m /status-checker --memory     # 가벼운 반복
/schedule 0 18 * * * /batch \          # 일일 종합 분석
  /log-analyzer logs/automation-summary.log --stats
```

### ✅ 효율적인 스케줄 설계

```bash
06:00 - 아침 상태 점검 (가볍게)
12:00 - 중간 정크 정리
18:00 - 일일 종합 분석
23:59 - 야간 정리
```

### ✅ sLLM 환경 최적화

```bash
# 작은 모델에 부담 적게
/loop 30m /status-checker --memory    # 무거운 --all 대신 --memory만
/batch /log-analyzer logs/ --tail 20  # 전체 대신 최근 부분만

# JSON 저장으로 추후 분석
/schedule 0 18 * * * /status-checker --all --json > status-report.json
```

---

## 설정 파일 위치

모든 설정은 `.claude/` 폴더 아래에 있습니다:

```
.claude/
├── settings.local.json      # 권한 설정
├── AUTOMATION.md            # 자동화 기본 설정
└── (다른 프로젝트에도 복사 가능)
```

---

## 빠른 명령어 치트시트

```bash
# 5분마다 상태 확인
/loop 5m /status-checker --memory

# 3개 작업 한 번에 실행
/batch /log-analyzer --stats && /status-checker --disk && echo "Done"

# 매일 6시에 점검
/schedule 0 6 * * * /status-checker --all

# 에러 로그만 확인
/log-analyzer logs/batch-2026-05-19.log --errors

# 전체 시스템 상태
/status-checker --all

# JSON 형식 (자동화용)
/status-checker --all --json
```

---

## 다음 단계

1. **기본 설정**: `.claude/AUTOMATION.md` 읽기
2. **Skills 테스트**: `/log-analyzer` 및 `/status-checker` 실행
3. **자동화 시작**: 간단한 `/loop`로 시작
4. **점진 확대**: `/batch` → `/schedule` 순서로 추가

---

## 요약

| 기능 | 주기 | 용도 | 예제 |
|------|------|------|------|
| `/loop` | 반복 | 지속 모니터링 | 5분마다 상태 체크 |
| `/batch` | 한 번 | 다중 작업 | 3개 작업 순차 실행 |
| `/schedule` | 정각 | 자동 실행 | 매일 6시 점검 |

이 가이드를 따르면 안정적인 자동화 운영이 가능합니다!

---

*마지막 수정: 2026-05-19*  
*Claude Code v2.1.15 기준*  
*sLLM 환경 최적화 완료*
