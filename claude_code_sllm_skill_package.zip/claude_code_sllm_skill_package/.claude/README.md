# Claude Code 자동화 패키지

`.claude` 폴더 내 모든 파일을 다른 프로젝트에 복사하여 사용할 수 있습니다.

## 📁 구조

```
.claude/
├── settings.local.json          # 권한 설정
├── AUTOMATION.md               # 자동화 기본 설정
├── skills/
│   ├── log-analyzer.skill.md   # 로그 분석 스킬
│   └── status-checker.skill.md # 시스템 상태 체크 스킬
└── README.md                   # 이 파일
```

## 🚀 빠른 시작

### 1. 다른 프로젝트에 적용
```powershell
# .claude 폴더 전체 복사
Copy-Item -Recurse ".\.claude" "다른프로젝트\.claude" -Force
```

### 2. Skills 사용
```bash
# 로그 분석
/log-analyzer logs/batch-2026-05-19.log --stats

# 상태 체크
/status-checker --all
```

### 3. 자동화 명령
```bash
# 반복 (5분마다)
/loop 5m /status-checker --memory

# 배치 (여러 작업)
/batch /log-analyzer --stats && /status-checker --disk

# 스케줄 (매일 6시)
/schedule 0 6 * * * /status-checker --all
```

## 📖 문서

- **AUTOMATION.md** - 자동화 개요 및 기본 설정
- **프로젝트 루트의 OPERATING_GUIDE.md** - 상세 운영 가이드

## ⚙️ 설정 파일

**settings.local.json** - 권한 설정
```json
{
  "permissions": {
    "allow": [
      "Bash(powershell *)",
      "Read(logs/*)",
      "Write(logs/*)",
      "Write(.claude/*)"
    ]
  }
}
```

## 📝 Skills 정의

### log-analyzer
- 로그 파일 분석
- 에러/경고/통계 추출
- 옵션: `--errors`, `--warnings`, `--stats`, `--tail N`

### status-checker
- 시스템 상태 점검
- 디스크/메모리/프로세스 모니터링
- 옵션: `--disk`, `--memory`, `--process`, `--all`, `--json`

## 💡 활용법

모든 자동화는 다음 3가지 조합으로 구성됩니다:

1. **반복**: `/loop 5m <명령>` - 5분마다 실행
2. **배치**: `/batch <명령1> && <명령2>` - 순차 실행
3. **스케줄**: `/schedule 0 6 * * * <명령>` - 정각 실행

---

**다른 프로젝트에도 `.claude` 폴더를 통째로 복사하면 바로 사용 가능합니다!**
