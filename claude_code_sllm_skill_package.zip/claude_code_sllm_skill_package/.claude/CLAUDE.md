# Claude Code 자동화 가이드

## 커스텀 명령어

### log-analyzer
로그 파일을 분석하여 에러, 경고, 통계를 추출합니다.

**사용법:**
```powershell
# 에러만 필터링
Select-String -Path "logs/*.log" -Pattern "\[ERROR\]|\[ERR\]"

# 특정 로그 분석
Get-Content logs/batch-2026-05-19.log | Where-Object { $_ -match '\[ERROR\]' }

# 통계 출력
$content = Get-Content logs/automation-summary.log
$errors = ($content | Where-Object { $_ -match '\[ERROR\]' }).Count
$warnings = ($content | Where-Object { $_ -match '\[WARN\]' }).Count
Write-Host "Errors: $errors, Warnings: $warnings"
```

### status-checker
시스템 상태를 점검합니다 (디스크/메모리/프로세스).

**사용법:**
```powershell
# 디스크 확인
Get-Volume | Where-Object { $_.DriveLetter } | ForEach-Object {
  $used = $_.Size - $_.SizeRemaining
  $percent = [math]::Round($used / $_.Size * 100, 1)
  Write-Host "$($_.DriveLetter): $percent%"
}

# 메모리 확인
$os = Get-CimInstance Win32_OperatingSystem
$totalMem = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
$usedMem = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB, 2)
Write-Host "Memory: $usedMem GB / $totalMem GB"

# 상위 프로세스
Get-Process | Sort-Object CPU -Descending | Select-Object -First 5 | 
  ForEach-Object { Write-Host "$($_.Name): CPU $([math]::Round($_.CPU, 1))s" }
```

## 자동화 기능

### /loop - 반복 실행
```bash
/loop 5m <명령>
```
- 5분마다 명령 반복
- 사용자가 중단할 때까지 계속
- 모든 결과가 로그에 기록

**예제:**
```bash
/loop 10m "Get-CimInstance Win32_OperatingSystem | Select-Object @{Name='Memory%';Expression={[math]::Round((($.TotalVisibleMemorySize - $.FreePhysicalMemory) / $.TotalVisibleMemorySize) * 100, 1)}}"
```

### /batch - 배치 처리
```bash
/batch <명령1> && <명령2> && <명령3>
```
- 여러 명령을 순차 실행
- 하나의 로그에 모든 결과 기록
- 한 작업 실패해도 계속 진행

**예제:**
```bash
/batch "Get-Volume | Select-Object DriveLetter, @{N='Used%';E={[math]::Round(($_.Size - $_.SizeRemaining)/$_.Size*100,1)}}" && 
       "Get-Process | Sort CPU -Desc | Select -First 3" && 
       "echo 'Batch complete'"
```

### /schedule - 정각 실행
```bash
/schedule <분> <시> <일> <월> <요일> <명령>
```
- Cron 표현식 지원
- 특정 시간에 자동 실행
- 실행 기록 자동 저장

**Cron 참조:**
- `0 6 * * *` - 매일 6시
- `0 12 * * 1-5` - 평일 정오
- `0 0 1 * *` - 매월 1일

**예제:**
```bash
# 매일 6시에 메모리 확인
/schedule 0 6 * * * "Get-CimInstance Win32_OperatingSystem | Select-Object @{N='Memory%';E={[math]::Round((($.TotalVisibleMemorySize - $.FreePhysicalMemory) / $.TotalVisibleMemorySize) * 100, 1)}}"
```

## 로그 위치

- `logs/batch-2026-05-19.log` - /batch 작업 로그
- `logs/scheduled-jobs.log` - /schedule 작업 기록
- `logs/automation-summary.log` - 통합 일일 요약

## 실행 팁

### 1. 디스크 모니터링 (5분마다)
```bash
/loop 5m "Get-Volume | Where DriveLetter | Select DriveLetter, @{N='Used%';E={[math]::Round(($_.Size-$_.SizeRemaining)/$_.Size*100,1)}}"
```

### 2. 일일 종합 점검 (매일 6시)
```bash
/schedule 0 6 * * * "Write-Host 'Daily Check'; Get-CimInstance Win32_OperatingSystem | Select TotalVisibleMemorySize, FreePhysicalMemory; Get-Volume | Select DriveLetter, @{N='Used%';E={[math]::Round(($_.Size-$_.SizeRemaining)/$_.Size*100,1)}}"
```

### 3. 배치 분석 (로그 확인)
```bash
/batch "Get-Content logs/batch-2026-05-19.log | Measure-Object | Select Count" && 
       "Select-String -Path 'logs/*.log' -Pattern '\[ERROR\]' | Measure | Select Count" && 
       "echo 'Analysis complete'"
```

## sLLM 최적화

작은 언어 모델에서 효율적으로 실행:
- 가벼운 명령어 조합
- 최소한의 데이터 처리
- JSON 형식 저장 (추후 분석용)

---

**설정:** `.claude/settings.local.json`  
**문서:** `OPERATING_GUIDE.md`  
**로그:** `logs/` 폴더
