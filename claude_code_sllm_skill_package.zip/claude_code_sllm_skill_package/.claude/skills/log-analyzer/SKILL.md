---
name: log-analyzer
description: 로그 파일 분석 (에러/경고/통계 추출)
category: automation
triggers: 
  - log-analyzer
  - 로그 분석
  - log analysis
tags: 
  - automation
  - logging
  - monitoring
---

# 로그 분석

로그 파일을 분석하여 에러, 경고, 성능 지표를 추출합니다.

## 사용법

```bash
/log-analyzer <로그파일경로> [옵션]
```

## 옵션

- `--errors` - 에러만 필터링
- `--warnings` - 경고만 필터링  
- `--stats` - 통계 출력
- `--tail N` - 마지막 N줄만 분석

## 예제

```bash
/log-analyzer logs/batch-2026-05-19.log --errors
/log-analyzer logs/automation-summary.log --stats
/log-analyzer logs/scheduled-jobs.log --tail 50
```

## 구현

```powershell
#!/usr/bin/env powershell
param(
    [string]$LogPath = "logs/automation-summary.log",
    [string[]]$Options = @()
)

if (-not (Test-Path $LogPath)) {
    Write-Host "❌ 로그 파일을 찾을 수 없습니다: $LogPath" -ForegroundColor Red
    exit 1
}

$content = Get-Content $LogPath -ErrorAction SilentlyContinue
if (-not $content) {
    Write-Host "⚠️  로그 파일이 비어있습니다" -ForegroundColor Yellow
    exit 0
}

$lines = if ($content -is [array]) { $content } else { @($content) }

Write-Host "📊 로그 분석 결과: $LogPath" -ForegroundColor Cyan
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan

$errorCount = ($lines | Where-Object { $_ -match '\[ERROR\]|\[ERR\]' }).Count
$warningCount = ($lines | Where-Object { $_ -match '\[WARN\]|\[WARNING\]' }).Count
$successCount = ($lines | Where-Object { $_ -match '\[OK\]|\[SUCCESS\]' }).Count

Write-Host "📈 통계:"
Write-Host "  • 총 줄 수: $($lines.Count)"
Write-Host "  • 에러: $errorCount" -ForegroundColor Red
Write-Host "  • 경고: $warningCount" -ForegroundColor Yellow
Write-Host "  • 성공: $successCount" -ForegroundColor Green

if ($Options -contains "--errors") {
    Write-Host "`n🔴 에러 목록:" -ForegroundColor Red
    $lines | Where-Object { $_ -match '\[ERROR\]|\[ERR\]' } | ForEach-Object { Write-Host "  $_" }
}

if ($Options -contains "--warnings") {
    Write-Host "`n🟡 경고 목록:" -ForegroundColor Yellow
    $lines | Where-Object { $_ -match '\[WARN\]|\[WARNING\]' } | ForEach-Object { Write-Host "  $_" }
}

if ($Options -contains "--stats") {
    $timestamps = $lines | Where-Object { $_ -match '\d{2}:\d{2}:\d{2}' } | Measure-Object
    Write-Host "`n📅 추가 통계:"
    Write-Host "  • 타임스탐프가 있는 줄: $($timestamps.Count)"
}

if ($Options -contains "--tail") {
    $tailIndex = $Options.IndexOf("--tail")
    if ($tailIndex -ge 0 -and $tailIndex + 1 -lt $Options.Count) {
        $tailCount = [int]$Options[$tailIndex + 1]
        if ($tailCount -gt 0) {
            Write-Host "`n📝 마지막 $tailCount 줄:"
            $lines | Select-Object -Last $tailCount | ForEach-Object { Write-Host "  $_" }
        }
    }
}

Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
```
