---
name: status-checker
description: 시스템 상태 점검 (디스크/메모리/프로세스)
category: automation
triggers:
  - status-checker
  - 상태 체크
  - system status
  - 시스템 상태
tags:
  - automation
  - monitoring
  - health-check
---

# 시스템 상태 체크

시스템의 디스크 사용률, 메모리 사용률, 프로세스 상태를 확인합니다.

## 사용법

```bash
/status-checker [옵션]
```

## 옵션

- `--disk` - 디스크 사용률 확인
- `--memory` - 메모리 사용률 확인
- `--process` - 상위 프로세스 확인
- `--all` - 모든 항목 확인 (기본값)
- `--json` - JSON 형식 출력

## 예제

```bash
/status-checker --all
/status-checker --disk
/status-checker --memory
/status-checker --all --json
```

## 구현

```powershell
#!/usr/bin/env powershell
param(
    [string[]]$Options = @("--all")
)

Write-Host "🔍 시스템 상태 점검" -ForegroundColor Cyan
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "시간: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray

$status = @{
    timestamp = Get-Date -Format 'o'
    checks = @()
}

# 디스크 체크
if ($Options -contains "--disk" -or $Options -contains "--all") {
    Write-Host "`n💾 디스크 사용률:" -ForegroundColor Cyan
    
    $drives = Get-Volume | Where-Object { $_.DriveLetter -and $_.DriveLetter -ne '' }
    $driveStatus = @()
    
    foreach ($drive in $drives) {
        $driveLetter = $drive.DriveLetter
        $sizeGB = [math]::Round($drive.Size / 1GB, 2)
        $freeGB = [math]::Round($drive.SizeRemaining / 1GB, 2)
        $usagePercent = if ($sizeGB -gt 0) { [math]::Round(($sizeGB - $freeGB) / $sizeGB * 100, 1) } else { 0 }
        
        $statusIcon = if ($usagePercent -ge 90) { "🔴" } elseif ($usagePercent -ge 70) { "🟡" } else { "🟢" }
        $statusColor = if ($usagePercent -ge 90) { "Red" } elseif ($usagePercent -ge 70) { "Yellow" } else { "Green" }
        
        Write-Host "  $statusIcon ${driveLetter}: $usagePercent% 사용중 ($freeGB GB 남음)" -ForegroundColor $statusColor
        
        $driveStatus += @{
            drive = $driveLetter
            totalGB = $sizeGB
            freeGB = $freeGB
            usagePercent = $usagePercent
        }
    }
    
    $status.checks += @{
        type = "disk"
        drives = $driveStatus
        timestamp = Get-Date -Format 'o'
    }
}

# 메모리 체크
if ($Options -contains "--memory" -or $Options -contains "--all") {
    Write-Host "`n🧠 메모리 사용률:" -ForegroundColor Cyan
    
    try {
        $osInfo = Get-CimInstance Win32_OperatingSystem
        
        $totalMem = [math]::Round($osInfo.TotalVisibleMemorySize / 1MB, 2)
        $freeMem = [math]::Round($osInfo.FreePhysicalMemory / 1MB, 2)
        $usedMem = $totalMem - $freeMem
        $memPercent = if ($totalMem -gt 0) { [math]::Round($usedMem / $totalMem * 100, 1) } else { 0 }
        
        $statusIcon = if ($memPercent -ge 90) { "🔴" } elseif ($memPercent -ge 70) { "🟡" } else { "🟢" }
        $statusColor = if ($memPercent -ge 90) { "Red" } elseif ($memPercent -ge 70) { "Yellow" } else { "Green" }
        
        Write-Host "  $statusIcon 사용중: $memPercent% ($usedMem GB / $totalMem GB)" -ForegroundColor $statusColor
        
        $status.checks += @{
            type = "memory"
            totalGB = $totalMem
            usedGB = $usedMem
            freeGB = $freeMem
            usagePercent = $memPercent
            timestamp = Get-Date -Format 'o'
        }
    } catch {
        Write-Host "  ⚠️  메모리 정보를 가져올 수 없습니다" -ForegroundColor Yellow
    }
}

# 프로세스 체크
if ($Options -contains "--process" -or $Options -contains "--all") {
    Write-Host "`n⚙️  상위 프로세스 (CPU 사용률):" -ForegroundColor Cyan
    
    try {
        $processes = Get-Process | Sort-Object -Property CPU -Descending | Select-Object -First 5
        $processStatus = @()
        
        foreach ($proc in $processes) {
            $cpuUsage = [math]::Round($proc.CPU, 1)
            $memUsageMB = [math]::Round($proc.WorkingSet / 1MB, 1)
            
            Write-Host "  • $($proc.Name): CPU $cpuUsage`s, MEM $memUsageMB MB"
            
            $processStatus += @{
                name = $proc.Name
                id = $proc.Id
                cpu = $cpuUsage
                memoryMB = $memUsageMB
            }
        }
        
        $status.checks += @{
            type = "process"
            topProcesses = $processStatus
            timestamp = Get-Date -Format 'o'
        }
    } catch {
        Write-Host "  ⚠️  프로세스 정보를 가져올 수 없습니다" -ForegroundColor Yellow
    }
}

# JSON 출력
if ($Options -contains "--json") {
    Write-Host "`n📋 JSON 형식:" -ForegroundColor Cyan
    $status | ConvertTo-Json -Depth 3 | Write-Host
}

Write-Host "`n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "✅ 상태 점검 완료" -ForegroundColor Green
```
